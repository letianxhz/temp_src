package config;

public class CompileArg {
	public static final boolean isdebug=false;
}
