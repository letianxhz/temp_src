package knight.gsp;

import xdb.Procedure;

public class PUidToUserid extends Procedure{
	int userid;
	String uid;
	public PUidToUserid(int userid, String uid){
		this.userid = userid;
		this.uid = uid;
	}
	@Override
	public boolean process(){
		Integer userId = xtable.Uid2userid.select(uid);
		if(userId != null){
			if(!userId.equals(userId)){
			   if (xdb.Trace.isInfoEnabled()){
				   xdb.Trace.info("ERROR: uid" + uid + " olduserid = " + userId + " newuserid = " + userid);
			   }
			}
			return true;
		}
		xtable.Uid2userid.insert(uid, userid);	
		return true;
	}
}
