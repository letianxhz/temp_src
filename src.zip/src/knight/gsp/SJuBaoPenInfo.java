
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SJuBaoPenInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SJuBaoPenInfo extends __SJuBaoPenInfo__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786544;

	public int getType() {
		return 786544;
	}

	public long diamondnum;
	public int viplv;
	public java.lang.String familyname;
	public int iscreaterole; // 是否创建角色，1表示是创建角色，0表示不是新创建的角色

	public SJuBaoPenInfo() {
		familyname = "";
	}

	public SJuBaoPenInfo(long _diamondnum_, int _viplv_, java.lang.String _familyname_, int _iscreaterole_) {
		this.diamondnum = _diamondnum_;
		this.viplv = _viplv_;
		this.familyname = _familyname_;
		this.iscreaterole = _iscreaterole_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(diamondnum);
		_os_.marshal(viplv);
		_os_.marshal(familyname, "UTF-16LE");
		_os_.marshal(iscreaterole);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		diamondnum = _os_.unmarshal_long();
		viplv = _os_.unmarshal_int();
		familyname = _os_.unmarshal_String("UTF-16LE");
		iscreaterole = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SJuBaoPenInfo) {
			SJuBaoPenInfo _o_ = (SJuBaoPenInfo)_o1_;
			if (diamondnum != _o_.diamondnum) return false;
			if (viplv != _o_.viplv) return false;
			if (!familyname.equals(_o_.familyname)) return false;
			if (iscreaterole != _o_.iscreaterole) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)diamondnum;
		_h_ += viplv;
		_h_ += familyname.hashCode();
		_h_ += iscreaterole;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(diamondnum).append(",");
		_sb_.append(viplv).append(",");
		_sb_.append("T").append(familyname.length()).append(",");
		_sb_.append(iscreaterole).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

