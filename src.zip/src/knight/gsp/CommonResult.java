package knight.gsp;

/**
 * 通用返回结果
 * 
 * @author yangzhenyu
 * 
 *         2014-1-7 下午12:12:21
 */
public class CommonResult<T> {
	
	T t;
	
	private boolean finish;
	
	public CommonResult(T t) {
		this.t = t;
	}
	
	public T getResult() {
		return t;
	}
	
	public void setFinish(boolean finish) {
		this.finish = finish;
	}
	
	public boolean isFinish() {
		return finish;
	}
}
