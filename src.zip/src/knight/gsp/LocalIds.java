package knight.gsp;

import java.util.ArrayList;
import java.util.List;

import knight.gsp.log.Logger;

/**
 * 记录本服所有的localId，考虑合服
 * 
 * @author yangzhenyu
 * 
 *         2014-6-15 上午12:59:04
 */
public class LocalIds {
	
	public static final Logger logger = Logger.getLogger(LocalIds.class);
	
	private static Boolean inited = false;
	
	public static final List<Integer> SAVE_LOCAL_IDS = new ArrayList<Integer>();  //存储了本服所有的localId
	
	public static void init(List<Integer> localIds) {
		synchronized (inited) {
			if (inited)
				return;
			
			SAVE_LOCAL_IDS.clear();
			SAVE_LOCAL_IDS.addAll(localIds);
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			for (int i = 0; i < localIds.size(); i ++) {
				if (i > 0)
					sb.append(",");
				sb.append(localIds.get(i));
			}
			sb.append("]");
			inited = true;
			logger.info("%%%%%%%%%%%% save server localId = " + sb.toString() + " %%%%%%%%%%%%%%%%%%");
		}
	}
	
	public static boolean validateIncreaseId(long increaseId) {
		
		for (int localId : SAVE_LOCAL_IDS) {
			long check = increaseId / 4096;
			if (increaseId - check * 4096 == localId)
				return true;
		}
		
		return false;
	}
	
	/**
	 * 是否是别的服务器的角色roleId
	 * 
	 * @param roleId
	 * @return
	 */
	public static boolean isRemoteServerRole(long roleId) {
		return !validateIncreaseId(roleId);
	}
}
