package knight.gsp;

import gnet.link.User;

import java.util.LinkedList;

import knight.gsp.log.LogUtil;
import knight.gsp.main.ConfigManager;
import knight.gsp.scene.battle.BattleField;

public class PSendRoleList extends xdb.Procedure
{
	private final User user;
	private final boolean isReturnList;
	public PSendRoleList(User user, boolean isReturnList)
	{
		this.user = user;
		this.isReturnList = isReturnList;
	}
	
	@Override
	protected boolean process() throws Exception
	{
		xbean.AUUserInfo xuserinfo = xtable.Auuserinfo.get(user.getUserid());
		if(xuserinfo == null)
		{//没有auuserinfo不让登入
			gnet.link.Onlines.getInstance().getOnlineUsers().addAuuserInfoId(user.getUserid(),user);
			return true;
		}
		final xbean.User u = xtable.User.select(user.getUserid());
		if(u == null || u.getIdlist().isEmpty())
		{
			SRoleList sRoleList = new SRoleList();
			user.send(sRoleList);
			//记录账号登陆日志
			LogUtil.doUserLoginLog(user.getUserid());
			return true;
		}
		
		long prevloginroleid = u.getPrevloginroleid();
		boolean hasPreLoginRole = false;
		
		//把这个账号下的所有角色都发给客户端
		LinkedList<knight.gsp.RoleInfo> roles = new LinkedList<knight.gsp.RoleInfo>();
		for (int i=0; i<u.getIdlist().size(); i++){
			final knight.gsp.RoleInfo info = new knight.gsp.RoleInfo();
			info.roleid = u.getIdlist().get(i);
			final xbean.Properties pro = xtable.Properties.select(info.roleid);
			if(null == pro){
				continue;
			}
			info.rolename = pro.getRolename();
			info.level = pro.getLevel();
			info.school = pro.getSchool();
			info.showfashion = (byte) pro.getShowfashion();
			knight.gsp.map.Role.getPlayerComponents(info.roleid, info.components, pro.getSchool(), false);
			roles.add(info);
			
			if (info.roleid == prevloginroleid) {
				hasPreLoginRole = true;
			}
		}
		
		byte isInBattleField = 0;
		if (prevloginroleid > 0) {
			xbean.CrossState crossState = xtable.Crossstate.select(prevloginroleid);
			if (crossState != null && crossState.getSceneid() > 0 && crossState.getServerid() > 0) {
				isInBattleField = 1;
			} else {
				isInBattleField = (byte) (BattleField.getBattleState(prevloginroleid) > 0 ? 1 : 0);
			}
			
			if (!hasPreLoginRole) {
				prevloginroleid = u.getIdlist().get(0); //预防一下。上一次登陆的角色如果不在rolelist里，则置零
			}
		}
		
		if(isReturnList)
			user.send(new SReturnRoleList(prevloginroleid, isInBattleField, roles));
		else{
			user.send(new SRoleList(roles, prevloginroleid, isInBattleField));
			//记录账号登陆日志
			LogUtil.doUserLoginLog(user.getUserid());
		}
		user.send(new SZoneInfo(ConfigManager.getGsZoneId()));
		return true;
	}
	
}
