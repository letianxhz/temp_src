package knight.gsp;

import java.util.List;

import knight.gsp.friends.Constant;
import knight.gsp.ranklist.RankType;
import knight.gsp.ranklist.proc.PRankOperation;
import xbean.RolePropertyRankList;
import xdb.Bean;

public class PTryAddRolepropertyRank extends PRankOperation {

	long roleid;
	int proValue;
	boolean needRemove;

	public PTryAddRolepropertyRank(long roleid, int proValue, int rankType, boolean needRemove) {
		super(rankType);
		this.roleid = roleid;
		this.proValue = proValue;
		this.needRemove = needRemove;
	}

	@Override
	protected boolean isGotOnRankCondition() {
		boolean got = true;

		switch (rankType) {
		case RankType.POWER_RANK:
			got = proValue >= Constant.ROLE_POWER_MIN_LEVEL;
			break;
		case RankType.LEVEL_RANK:
			got = proValue >= Constant.ROLE_ONRANKLIST_MIN_LEVEL;
			break;
		case RankType.EQUIP_RANK:
			got = proValue >= Constant.EQUIP_ONRANK_MIN_SCORE;
			break;
		}

		return got;
	}

	@Override
	protected List<? extends xdb.Bean> getAllCanWriteRankRecords() {
		RolePropertyRankList result = xtable.Rolepropertyrank.get(rankType);
		if (result == null) {
			result = xbean.Pod.newRolePropertyRankList();
			xtable.Rolepropertyrank.insert(rankType, result);
		}

		return result.getRecords();
	}

	@Override
	protected Bean getNewRecord() {
		xbean.RolePropertyRankRecord record = xbean.Pod.newRolePropertyRankRecord();
		record.setTime(System.currentTimeMillis());
		record.getMarshaldata().setProvalue(proValue);
		record.getMarshaldata().setRoleid(roleid);
		xbean.Properties pro = xtable.Properties.select(roleid);
		record.getMarshaldata().setRolename(pro.getRolename());
		return record;
	}

	@Override
	protected void notice4FirstOnRank() {
		// TODO Auto-generated method stub

	}

	@Override
	protected boolean needRemove() {
		return needRemove;
	}

}
