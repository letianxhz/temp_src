package knight.gsp;

import java.util.Arrays;

import knight.gsp.activity.AnswerQuestionWrapper;
import knight.gsp.activity.DrawAwardWrapper;
import knight.gsp.activity.VerifyPhoneNumberManager;
import knight.gsp.activity.aprilfoolsday.AprilFoolsDayManager;
import knight.gsp.activity.crossbigwild.PclearBigwildData;
import knight.gsp.activity.eggs.EggsManager;
import knight.gsp.activity.goblin.CashBackManager;
import knight.gsp.activity.guoqing.GuoqingManager;
import knight.gsp.activity.newservergift.NewserverGiftInfoWrapper;
import knight.gsp.activity.procedure.OnlinesTimesAwardManager;
import knight.gsp.activity.protectmilitaryvehicle.MilitaryVehicleManager;
import knight.gsp.activity.retrievereward.RetrieveRewardRole;
import knight.gsp.activity.roleback.RolebackManager;
import knight.gsp.activity.sologhost.SoloGhostManager;
import knight.gsp.activity.soulbless.PClearSoulBlessAwardData;
import knight.gsp.activity.soulbless.SoulblessManager;
import knight.gsp.activity.springfestival.jjsf.JinJiSongFuManager;
import knight.gsp.activity.springfestival.pray.PRemoveNewYearPrayTask;
import knight.gsp.activity.treasure.TreasureManager;
import knight.gsp.anniversary.Util;
import knight.gsp.camp.CampRole;
import knight.gsp.camp.PAddCampZhanli;
import knight.gsp.camp.PSetCurCampFuli;
import knight.gsp.counter.PCheckAndClearDaily;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.fuben.challenge.ChallengeManager;
import knight.gsp.fuben.dailyresource.Module;
import knight.gsp.game.SServerLevelConfig;
import knight.gsp.giftbag.dayfirst.DayFirstCashColumn;
import knight.gsp.giftbag.daygift.EveryDayConsumeColumn;
import knight.gsp.giftbag.daygift.EveryDayPayColumn;
import knight.gsp.giftbag.daygift.MiniCashColumn;
import knight.gsp.giftbag.daygift.PlatEveryChargeColumn;
import knight.gsp.giftbag.handler.ChargeGift2Handler;
import knight.gsp.giftbag.handler.PlatChargeGiftHandler;
import knight.gsp.imagechallenge.ImageChallengeManager;
import knight.gsp.item.PClearGainItemCounter;
import knight.gsp.item.SharedGiftManager;
import knight.gsp.item.shop.PLimitShop;
import knight.gsp.main.ConfigManager;
import knight.gsp.mercenary.proc.POpenMercenaryJiuguan;
import knight.gsp.msg.hongbao.HongbaoManager;
import knight.gsp.myzone.pro.PClearZoneDayData;
import knight.gsp.qixi.QiXiActivityManager;
import knight.gsp.shenqi.ShenQiManager;
import knight.gsp.state.StateManager;
import knight.gsp.task.TaskScenarioColumn;
import knight.gsp.task.activelist.PlayActiveRole;
import knight.gsp.team.PClearInviteStrangerInfo;
import knight.gsp.team.ghost.RoleGhostManager;
import knight.gsp.util.DateValidate;
import knight.gsp.weiwang.PClearWeiWang;
import knight.gsp.wing.WingManager;
import knight.gsp.yuanbao.PRefreshChargeGuide;

import org.apache.log4j.Logger;

import xdb.Procedure;

/**
 * 结算24点还在线的玩家相关数据(在线清除)
 * 
 * @author yangzhenyu
 * 
 *         2014-5-21 下午2:22:45
 */
public class PClearRoleDayData extends Procedure {
	
	private static Logger logger = Logger.getLogger(PClearRoleDayData.class);
	
	private long roleId;
	
	private boolean freshServerLv;
	
	private byte weakCamp;

	public PClearRoleDayData(long roleId, boolean freshServerLv, byte weakCamp) {
		super();
		this.roleId = roleId;
		this.freshServerLv = freshServerLv;
		this.weakCamp = weakCamp;
	}

	@Override
	protected boolean process() throws Exception {
		//因为清理微信分享数据的时会锁住USER，为了遵循先大后小原则，这里手动锁住user
		lock(xtable.Locks.USERLOCK, Arrays.asList(xtable.Properties.selectUserid(roleId)));
		
		final long now = System.currentTimeMillis() + 10000;  //因为结算的时间是23:59:59所以故意加上一个10秒。新的一天的时间
		
		xbean.Properties prop = xtable.Properties.get(roleId);
		if (prop == null)
			return false;
		
		if (DateValidate.inTheSameDay(prop.getLastcleardailydatatick(), now))
			return true; //已经结算过了
		
		prop.setLastcleardailydatatick(now); //记录下清除每日数据的时间
		
		try {
			new TaskScenarioColumn(roleId, false).sendAndAcceptDailyTask(now);
		} catch (Throwable th) {
			logger.error("每日刷新阵营任务出错....", th);
		}
		
		try {
			//轮盘抽奖重置
			DrawAwardWrapper wrapper = new DrawAwardWrapper(roleId, false);
			if (!DateValidate.inTheSameDay(now, wrapper.getBean().getDrawtime())) {
				wrapper.reset();
			}
		} catch (Throwable th) {
			logger.error("轮盘抽奖重置....", th);
		}
		
		PlayActiveRole actrole = PlayActiveRole.getPlayActiveRole(roleId, false);

		actrole.checkClearActivityCount(now);  //防止定时器提前，加上5秒的误差容错
		
		//看看客户端好不好改
		actrole.sendDayData();
		
		knight.gsp.yuanbao.Vip vip = new knight.gsp.yuanbao.Vip(roleId,false);
		vip.checkAndRefreshBuyTime(now);
		//这里不刷新了,让客户端自己set为0
		
		knight.gsp.yuanbao.YbNum ybNum = new knight.gsp.yuanbao.YbNum(roleId, false);
		ybNum.clearDayCash(now);
		
		new POpenMercenaryJiuguan(roleId,now,false).call();
		
		//清除副本相关数据
		FubenCommon.clearDirtyData(roleId, now, true);
		//这里不发协议了，客户端自己重置
		
		// 清除兑换功能的兑换次数
		xtable.Exchangeitem.remove(roleId);
		
		//清除阵营福利等信息
		if (new CampRole(roleId, true).getStandCamp() > 0) {
			CampRole campRole = new CampRole(roleId, false);
			campRole.clearDailyRecord();
			
			//这里不发协议爵位福利的协议了，客户端自己重置
			new PSetCurCampFuli(roleId, weakCamp).call();
			xdb.Procedure.pexecuteWhileCommit(new PAddCampZhanli(prop.getPower(), campRole.getStandCamp()));
		}
		
		try {
			//清除当日兑换的威望值
			new PClearWeiWang(roleId, now).call();
		} catch (Throwable th) {
			logger.error("清除当日兑换的威望值....", th);
		}
		
		
		try {
			//商城在线刷新
			new PLimitShop(roleId,now).call();
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//爬塔
			ChallengeManager.getInstance().clearDirtyData(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			// 清除：道具在给定时间内的获得数量
			new PClearGainItemCounter(roleId, now).call();
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			// 清除资源副本周日的特殊计数
			Module.getInstance().clearFubenCountSunday(roleId);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			// 清除每日奖励
			new knight.gsp.giftbag.lsbz.LsbzColumn(roleId, false).clearDayData(now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//圣灵祝福
			SoulblessManager.getInstance().clearData(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			new PClearSoulBlessAwardData(roleId, now).call();
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			// 地精宝库
			CashBackManager.getInstance().taskState(roleId);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			// 回流活动
			RolebackManager.getInstance().clearExpiredData(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			// 钻石转盘活动状态
			knight.gsp.activity.diamondwheel.CashBackManager.getInstance().taskState(roleId, (byte) 0);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//每日充值活动，1元3元活动
			EveryDayPayColumn everyDay = new EveryDayPayColumn(roleId, false);
			everyDay.refresh(now);
			MiniCashColumn mini = new MiniCashColumn(roleId, false);
			mini.refresh(now);
			//每日消费活动
			EveryDayConsumeColumn dayConsume = new EveryDayConsumeColumn(roleId, false);
			dayConsume.refresh(now);
			//每日首充
			DayFirstCashColumn dayFirstCash = new DayFirstCashColumn(roleId, false);
			dayFirstCash.cleanDay(now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		 //答题
		try{
			AnswerQuestionWrapper wrapper = new AnswerQuestionWrapper(roleId, false);
			//重置答题信息
			wrapper.reset();
		} catch (Exception e) {
			StateManager.logger.error("答题活动处理失败：" , e);
		}
		
		try {
			//平台每日充值
			PlatEveryChargeColumn platEveryChargeColumn = new PlatEveryChargeColumn(roleId, false);
			platEveryChargeColumn.refresh(now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//清空家族祈祷次数
			final xbean.Properties pro = xtable.Properties.get(roleId);
			if (!DateValidate.inTheSameDay(now, pro.getFamilypraytime())) {
				pro.setFamilypraynum(0);
				pro.setFamilypiouspraynum(0);
				pro.setFamilygodpraynum(0);
			}
		
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//新服独享
			NewserverGiftInfoWrapper newserverInfoWrapper = new NewserverGiftInfoWrapper(roleId, false);
			newserverInfoWrapper.checkDailyClear(now);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
//		try{
//			//累计登陆统计
//			new PQiandaoTimesStatistics(roleId, LoginAwardManger.MSG_OPEN_PANEL, true, now).call();
//		}catch (Throwable th) {
//			logger.error("00:00 PLoginTimesStatistics throw exception: " + th);
//		}
		
		try {
			if (freshServerLv) {
				//等级提升了，要重新发送经验加成信息
				SServerLv serverLvInfo = PAddExpProc.getServerExpAddInfo(roleId, now);
				if (serverLvInfo != null) {
					xdb.Procedure.psendWhileCommit(roleId, serverLvInfo);
				} else {
					SServerLevelConfig lvCfg = ConfigManager.getInstance().getGsLevelCfg(now);
					if (lvCfg != null && prop.getLevel() == lvCfg.serverLevel) {
						xdb.Procedure.psendWhileCommit(roleId, new SServerLv((short) lvCfg.getServerLevel(), (byte) 0));
					}
				}
			}
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			VerifyPhoneNumberManager.getInstance().tryClearData(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		// 清除邀请陌生人组队信息
		try
		{
			new PClearInviteStrangerInfo(roleId).call();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		//充值引导
		new PRefreshChargeGuide(roleId, true, now).call();
		SharedGiftManager sharedGiftManager=new SharedGiftManager(roleId, false);
		sharedGiftManager.clearDailyData(now);
		
		RoleGhostManager roleGhostManager=new RoleGhostManager(roleId, false);
		roleGhostManager.clearDailyData(now);
		
		SoloGhostManager.getInstance().resetData(roleId);
		
		prop.setHasclickquestionsurvey(false);
		
		xbean.YjxrInfo yjxrInfo = xtable.Yjxrroles.get(roleId);
		if (yjxrInfo != null) {
			yjxrInfo.setTodayawardminute((short) 0);
			yjxrInfo.setTotalexp(0);
		}
		
		TreasureManager.getInstance().clearDailyData(roleId, now);
		
		//复活节数据
		EggsManager.getInstance().clearEasterData(roleId, now);
		
		
		new RetrieveRewardRole(roleId, false).sendRetrieveRewardList(now);
		
		WingManager.getInstance().clearDailyData(roleId, now);
		
		xbean.Pvp8MatchInfo matchInfo = xtable.Pvp8matchdata.get(roleId);
		if (matchInfo != null) {
			//清除8V8首胜
			matchInfo.setIsreachfirstwin(false);
			matchInfo.setIsloadrule(true);
			matchInfo.getBuynums().clear();
			matchInfo.setTodaygetpiontcard(0);
			matchInfo.setTodaygetintegral(0);
		}
		
		xbean.VoiceGuideRole vgr = xtable.Voiceguiderole.get(roleId);
		if (vgr != null) {
			vgr.getGuidedvoices().remove(CPlayVoiceGuide.LIN_YE_FENG_HUO_EVERY_DAY);
			vgr.getGuidedvoices().remove(CPlayVoiceGuide.FAMILY_GATHER_EVERYDAY);
			vgr.getGuidedvoices().remove(CPlayVoiceGuide.FAMILY_BATTLE_EVERYDAY);
			vgr.getGuidedvoices().remove(CPlayVoiceGuide.PVP8_EVERYDAY);
			vgr.getGuidedvoices().remove(CPlayVoiceGuide.APOLLO_FIGHT);
		}
		xbean.SwornMemberData sData = xtable.Swornmember.get(roleId);
		if (null != sData) {
			sData.getHonorinfos().clear();
		}
		xbean.BalrogFubenInfo balrogFubenInfo = xtable.Balrogfubeninfos.get(roleId);
		if (null != balrogFubenInfo) {
			balrogFubenInfo.setGetseedcount(0);
			balrogFubenInfo.setPasscount(0);
		}
		
		xbean.RoleFamilyRobberInfo robberRole = xtable.Familyrobberroles.get(roleId);
		if (robberRole != null) {
			robberRole.setEntercount((short) 0);
		}
		
		try {
			// 清理次数
			new PCheckAndClearDaily(roleId,false).call();
		} catch (Throwable th) {
			th.printStackTrace();
		}
			
		//跨天要清空频道发言次数
		xtable.Channelspeekrecord.remove(roleId);
		
		try {
			PlatChargeGiftHandler platHander = (PlatChargeGiftHandler)knight.gsp.giftbag.GiftBagModule.getInstance().getGiftEventHandlerByType((short)xbean.Gift.PLAT_CHARGE_GIFT);
			platHander.sendChargeGiftInfoWhileCrossDay(roleId, now);
		} catch (Exception e) {
			StateManager.logger.error("首冲礼包：" , e);
		}
		
		try {
			ChargeGift2Handler platHander = (ChargeGift2Handler)knight.gsp.giftbag.GiftBagModule.getInstance().getGiftEventHandlerByType((short)xbean.Gift.CHARGE_GIFT2);
			platHander.sendChargeGiftInfoWhileCrossDay(roleId, now);
		} catch (Exception e) {
			StateManager.logger.error("天天好礼：" , e);
		}
		
		xbean.SpeedCompeteRole scr = xtable.Speedcompeteroles.get(roleId);
		if (scr != null) {
			scr.setTodaycount((short) 0);
		}
		xbean.ShenFaLeiTaiRole sTaiRole = xtable.Shenfaleitairoles.get(roleId);
		if (null != sTaiRole) {
			sTaiRole.setTodaycount((short)0);
		}
		xbean.CrossBossRole crossBossRole = xtable.Crossbossroles.get(roleId);
		if (crossBossRole != null) {
			crossBossRole.setTodayentercount((short) 0);
		}
		
		HongbaoManager.getInstance().clearRoleDailyData(roleId, now);
		
		//清除每日微信分享数据        
		PFirstShareAward.clearWeixinShareData(prop);
		
		xdb.Procedure.psendWhileCommit(roleId, new SFirstShare(CFirstShare.WEI_XIN, prop.getWeixinsharestatus()));
		
		//个人空间 每日数据清理
		try {
			new PClearZoneDayData(roleId).call();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			StateManager.logger.error("个人空间每日数据清理失败", e);
		}
		
		xbean.SendAppleRole sendAppleRole = xtable.Sendappleroles.get(roleId);
		if (sendAppleRole != null) {
			sendAppleRole.setTodayreceivenum(0);
			sendAppleRole.getTodaysendnum().clear();
		}
		
		xbean.ShuangDanRole sdr = xtable.Shuangdanroles.get(roleId);
		if (sdr != null) {
			sdr.setTodaygathernum((short) 0);
			sdr.setTodayhaschallengeboss(false);
		}
		
		try {
			JinJiSongFuManager.getInstance().sendProtocolWhileCrossDay(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		xbean.ShenMiDengLongRole smdlr = xtable.Smdlroles.get(roleId);
		if (smdlr != null) {
			smdlr.setTodayopennum((short) 0);
			smdlr.getAlreadyopen().clear();
			smdlr.getQuestionavailabletime().clear();
		}
		
		try {
			new PRemoveNewYearPrayTask(roleId).call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//清除满城烟火采集的礼包数
		xbean.FireworkRole fireWorkRole = xtable.Fireworkroles.get(roleId);
		if (fireWorkRole != null){
			fireWorkRole.setTodaygathernum((short)0);
		}
		
		xbean.BingJianZuoZhanRole bjzzr = xtable.Bjzzroles.get(roleId);
		if (bjzzr != null) {
			bjzzr.setTodaychallengenum((short) 0);
		}
		
		//清除勇者之塔今日挑战次数
		xbean.BraveTowerRole braveTowerRole = xtable.Bravetowerroles.get(roleId);
		if (null != braveTowerRole){
			braveTowerRole.setHasentertimes(0);
			//当前时间大于活动的结束时间，说明本次活动已结束，清空所有挑战记录
			if (now > braveTowerRole.getActivityendtime()){
				braveTowerRole.setLayer(1);
				braveTowerRole.setLaststatus(0);
				braveTowerRole.setTransnpc(0);
				braveTowerRole.setLastquestionindex(0);
				braveTowerRole.getLastchallengenpc().clear();
				braveTowerRole.setShowlayer(1);
			}
		}
		
		xbean.YingXiongBuXiu yingXiongBuXiu = xtable.Yxburoles.get(roleId);
		if (null != yingXiongBuXiu)
			yingXiongBuXiu.setTodaychallengenum((short)0);
		
		try {
			new PclearBigwildData(roleId).call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			AprilFoolsDayManager.getInstance().sendProtocolWhileCrossDay(roleId, now);
			xbean.pukeInfos pukeInfos = xtable.Puke.get(roleId);
			if (null != pukeInfos) {
				pukeInfos.setFreetimes(0);
				pukeInfos.setTodayjifen(0);
				pukeInfos.setTodayresidueround(0);
				pukeInfos.setTodaybuytimes(0);
			}
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		//清理五一活动相关数据
		xbean.MayDayRole mdr = xtable.Maydayroles.get(roleId);
		if (mdr != null) {
			mdr.setHastakeliangjunkaoshangtask(false);
			mdr.setTodaygathernum((short) 0);
		}
		
		xbean.DuanWuJieBean dBean = xtable.Duanwujieinfos.get(roleId);
		if (null != dBean) {
			dBean.setHastakeliangjunkaoshangtask(false);
			dBean.setTodaygathernum((short) 0);
		}
		
		xbean.DaLuanDouRole dldr = xtable.Daluandouroles.get(roleId);
		if (dldr != null) {
			dldr.setIsreachfirstwin(false);
			dldr.setIsloadrule(true);
			dldr.setEnternum(0);
		}
		//清楚 光影对决 数据
		xbean.GuangYingRole gyRole = xtable.Guangyingroles.get(roleId);
		if(gyRole != null){
			gyRole.setIsreachfirstwin(false);
			gyRole.setIsloadrule(true);
			gyRole.setEnternum(0);
		}
		try {
			OnlinesTimesAwardManager manager = OnlinesTimesAwardManager.getInstance();
			manager.clearRoleData(roleId);
			manager.refreshOnlinesInfos(roleId);
			manager.checkAndSendMorrowPresent(roleId);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		//重置每天对单向好友发送聊天内容次数
		xbean.FriendGroups friendGroups = xtable.Friends.get(roleId);
		if (friendGroups != null) {
			friendGroups.setSendmsgnumforsinggriend(0);
		}
		ShenQiManager.getInstance().clearChenFuchouquData(roleId);
		//清除 周年庆活动期间相关数据
		//只有在线跨天 清理数据 才发送红点
		Util.clearData(roleId, now,true);
		//清楚寻爱之旅 数据
		try {
			QiXiActivityManager.getInstance().clearData(roleId,now);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			GuoqingManager.getInstance().sendProtocolWhileCrossDay(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//军需护送
			MilitaryVehicleManager.getInstance().clearData(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			//清除镜像挑战今日挑战次数
			ImageChallengeManager.getInstance().clearDailyData(roleId,now);
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
		try {
			xtable.Gotowildrolecachedata.remove(roleId);
			xdb.Procedure.psendWhileCommit(roleId, new SConfirmGoToWildScene((byte) 0));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;
	}
}
