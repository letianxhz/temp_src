
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BeanImport__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BeanImport extends __BeanImport__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786432;

	public int getType() {
		return 786432;
	}

	public knight.gsp.KickErrConst b1;
	public knight.gsp.DataInit b2;
	public knight.gsp.LogPriority b3;
	public knight.gsp.SysSetType b4;
	public knight.gsp.move.RoleBasicOctets b5;
	public knight.gsp.move.MoveUnitType b6;
	public knight.gsp.move.battle.OperationType b7;
	public knight.gsp.npc.NpcServices b11;
	public knight.gsp.dragon.DragonColumnTypes b12;
	public knight.gsp.dragon.DragonError b13;
	public knight.gsp.dragon.DragonColour b14;
	public knight.gsp.task.TaskFinishRequire b21;
	public knight.gsp.task.NpcExecuteTaskTypes b22;
	public knight.gsp.task.AllowTeam b24;
	public knight.gsp.task.TaskType b25;
	public knight.gsp.move.DragonBasicOctets b26;
	public knight.gsp.mercenary.JiuguanInfos b27;
	public knight.gsp.team.TeamMemberState b28;
	public knight.gsp.task.ReadTimeType b30;
	public knight.gsp.task.TaskOthersFinishRequire b32;
	public knight.gsp.BeginnerTipType b33;
	public knight.gsp.RoleInitFlag b34;
	public knight.gsp.dragon.DragonField b35;
	public knight.gsp.dragon.DragonFieldFosterType b36;
	public knight.gsp.dragon.DragonVeinPromoteType b37;
	public knight.gsp.fuben.ChallengeGrade b38;
	public knight.gsp.fuben.ChallengeMode b39;
	public knight.gsp.msg.MsgType b40;
	public knight.gsp.activity.AwardState b45;
	public knight.gsp.title.TitleError b48;
	public knight.gsp.move.SceneState b49;
	public knight.gsp.move.FighterStandCamp b50;
	public knight.gsp.KeyCounterIndex b52;
	public knight.gsp.move.DynamicSceneType b53;
	public knight.gsp.DynamicMapID b54;
	public knight.gsp.UserInfoEnum b55;
	public knight.gsp.task.TaskParam b56;
	public knight.gsp.msg.ApnsSaveToken b57;
	public knight.gsp.msg.ApnsMsg b58;
	public knight.gsp.move.HorseOctets b59;
	public knight.gsp.ConnectType b60;
	public knight.gsp.achievement.AchievementState b61;
	public knight.gsp.achievement.Achievement b62;
	public knight.gsp.move.FamilyGatherTitleShowOctets b63;

	public BeanImport() {
		b1 = new knight.gsp.KickErrConst();
		b2 = new knight.gsp.DataInit();
		b3 = new knight.gsp.LogPriority();
		b4 = new knight.gsp.SysSetType();
		b5 = new knight.gsp.move.RoleBasicOctets();
		b6 = new knight.gsp.move.MoveUnitType();
		b7 = new knight.gsp.move.battle.OperationType();
		b11 = new knight.gsp.npc.NpcServices();
		b12 = new knight.gsp.dragon.DragonColumnTypes();
		b13 = new knight.gsp.dragon.DragonError();
		b14 = new knight.gsp.dragon.DragonColour();
		b21 = new knight.gsp.task.TaskFinishRequire();
		b22 = new knight.gsp.task.NpcExecuteTaskTypes();
		b24 = new knight.gsp.task.AllowTeam();
		b25 = new knight.gsp.task.TaskType();
		b26 = new knight.gsp.move.DragonBasicOctets();
		b27 = new knight.gsp.mercenary.JiuguanInfos();
		b28 = new knight.gsp.team.TeamMemberState();
		b30 = new knight.gsp.task.ReadTimeType();
		b32 = new knight.gsp.task.TaskOthersFinishRequire();
		b33 = new knight.gsp.BeginnerTipType();
		b34 = new knight.gsp.RoleInitFlag();
		b35 = new knight.gsp.dragon.DragonField();
		b36 = new knight.gsp.dragon.DragonFieldFosterType();
		b37 = new knight.gsp.dragon.DragonVeinPromoteType();
		b38 = new knight.gsp.fuben.ChallengeGrade();
		b39 = new knight.gsp.fuben.ChallengeMode();
		b40 = new knight.gsp.msg.MsgType();
		b45 = new knight.gsp.activity.AwardState();
		b48 = new knight.gsp.title.TitleError();
		b49 = new knight.gsp.move.SceneState();
		b50 = new knight.gsp.move.FighterStandCamp();
		b52 = new knight.gsp.KeyCounterIndex();
		b53 = new knight.gsp.move.DynamicSceneType();
		b54 = new knight.gsp.DynamicMapID();
		b55 = new knight.gsp.UserInfoEnum();
		b56 = new knight.gsp.task.TaskParam();
		b57 = new knight.gsp.msg.ApnsSaveToken();
		b58 = new knight.gsp.msg.ApnsMsg();
		b59 = new knight.gsp.move.HorseOctets();
		b60 = new knight.gsp.ConnectType();
		b61 = new knight.gsp.achievement.AchievementState();
		b62 = new knight.gsp.achievement.Achievement();
		b63 = new knight.gsp.move.FamilyGatherTitleShowOctets();
	}

	public BeanImport(knight.gsp.KickErrConst _b1_, knight.gsp.DataInit _b2_, knight.gsp.LogPriority _b3_, knight.gsp.SysSetType _b4_, knight.gsp.move.RoleBasicOctets _b5_, knight.gsp.move.MoveUnitType _b6_, knight.gsp.move.battle.OperationType _b7_, knight.gsp.npc.NpcServices _b11_, knight.gsp.dragon.DragonColumnTypes _b12_, knight.gsp.dragon.DragonError _b13_, knight.gsp.dragon.DragonColour _b14_, knight.gsp.task.TaskFinishRequire _b21_, knight.gsp.task.NpcExecuteTaskTypes _b22_, knight.gsp.task.AllowTeam _b24_, knight.gsp.task.TaskType _b25_, knight.gsp.move.DragonBasicOctets _b26_, knight.gsp.mercenary.JiuguanInfos _b27_, knight.gsp.team.TeamMemberState _b28_, knight.gsp.task.ReadTimeType _b30_, knight.gsp.task.TaskOthersFinishRequire _b32_, knight.gsp.BeginnerTipType _b33_, knight.gsp.RoleInitFlag _b34_, knight.gsp.dragon.DragonField _b35_, knight.gsp.dragon.DragonFieldFosterType _b36_, knight.gsp.dragon.DragonVeinPromoteType _b37_, knight.gsp.fuben.ChallengeGrade _b38_, knight.gsp.fuben.ChallengeMode _b39_, knight.gsp.msg.MsgType _b40_, knight.gsp.activity.AwardState _b45_, knight.gsp.title.TitleError _b48_, knight.gsp.move.SceneState _b49_, knight.gsp.move.FighterStandCamp _b50_, knight.gsp.KeyCounterIndex _b52_, knight.gsp.move.DynamicSceneType _b53_, knight.gsp.DynamicMapID _b54_, knight.gsp.UserInfoEnum _b55_, knight.gsp.task.TaskParam _b56_, knight.gsp.msg.ApnsSaveToken _b57_, knight.gsp.msg.ApnsMsg _b58_, knight.gsp.move.HorseOctets _b59_, knight.gsp.ConnectType _b60_, knight.gsp.achievement.AchievementState _b61_, knight.gsp.achievement.Achievement _b62_, knight.gsp.move.FamilyGatherTitleShowOctets _b63_) {
		this.b1 = _b1_;
		this.b2 = _b2_;
		this.b3 = _b3_;
		this.b4 = _b4_;
		this.b5 = _b5_;
		this.b6 = _b6_;
		this.b7 = _b7_;
		this.b11 = _b11_;
		this.b12 = _b12_;
		this.b13 = _b13_;
		this.b14 = _b14_;
		this.b21 = _b21_;
		this.b22 = _b22_;
		this.b24 = _b24_;
		this.b25 = _b25_;
		this.b26 = _b26_;
		this.b27 = _b27_;
		this.b28 = _b28_;
		this.b30 = _b30_;
		this.b32 = _b32_;
		this.b33 = _b33_;
		this.b34 = _b34_;
		this.b35 = _b35_;
		this.b36 = _b36_;
		this.b37 = _b37_;
		this.b38 = _b38_;
		this.b39 = _b39_;
		this.b40 = _b40_;
		this.b45 = _b45_;
		this.b48 = _b48_;
		this.b49 = _b49_;
		this.b50 = _b50_;
		this.b52 = _b52_;
		this.b53 = _b53_;
		this.b54 = _b54_;
		this.b55 = _b55_;
		this.b56 = _b56_;
		this.b57 = _b57_;
		this.b58 = _b58_;
		this.b59 = _b59_;
		this.b60 = _b60_;
		this.b61 = _b61_;
		this.b62 = _b62_;
		this.b63 = _b63_;
	}

	public final boolean _validator_() {
		if (!b1._validator_()) return false;
		if (!b2._validator_()) return false;
		if (!b3._validator_()) return false;
		if (!b4._validator_()) return false;
		if (!b5._validator_()) return false;
		if (!b6._validator_()) return false;
		if (!b7._validator_()) return false;
		if (!b11._validator_()) return false;
		if (!b12._validator_()) return false;
		if (!b13._validator_()) return false;
		if (!b14._validator_()) return false;
		if (!b21._validator_()) return false;
		if (!b22._validator_()) return false;
		if (!b24._validator_()) return false;
		if (!b25._validator_()) return false;
		if (!b26._validator_()) return false;
		if (!b27._validator_()) return false;
		if (!b28._validator_()) return false;
		if (!b30._validator_()) return false;
		if (!b32._validator_()) return false;
		if (!b33._validator_()) return false;
		if (!b34._validator_()) return false;
		if (!b35._validator_()) return false;
		if (!b36._validator_()) return false;
		if (!b37._validator_()) return false;
		if (!b38._validator_()) return false;
		if (!b39._validator_()) return false;
		if (!b40._validator_()) return false;
		if (!b45._validator_()) return false;
		if (!b48._validator_()) return false;
		if (!b49._validator_()) return false;
		if (!b50._validator_()) return false;
		if (!b52._validator_()) return false;
		if (!b53._validator_()) return false;
		if (!b54._validator_()) return false;
		if (!b55._validator_()) return false;
		if (!b56._validator_()) return false;
		if (!b57._validator_()) return false;
		if (!b58._validator_()) return false;
		if (!b59._validator_()) return false;
		if (!b60._validator_()) return false;
		if (!b61._validator_()) return false;
		if (!b62._validator_()) return false;
		if (!b63._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(b1);
		_os_.marshal(b2);
		_os_.marshal(b3);
		_os_.marshal(b4);
		_os_.marshal(b5);
		_os_.marshal(b6);
		_os_.marshal(b7);
		_os_.marshal(b11);
		_os_.marshal(b12);
		_os_.marshal(b13);
		_os_.marshal(b14);
		_os_.marshal(b21);
		_os_.marshal(b22);
		_os_.marshal(b24);
		_os_.marshal(b25);
		_os_.marshal(b26);
		_os_.marshal(b27);
		_os_.marshal(b28);
		_os_.marshal(b30);
		_os_.marshal(b32);
		_os_.marshal(b33);
		_os_.marshal(b34);
		_os_.marshal(b35);
		_os_.marshal(b36);
		_os_.marshal(b37);
		_os_.marshal(b38);
		_os_.marshal(b39);
		_os_.marshal(b40);
		_os_.marshal(b45);
		_os_.marshal(b48);
		_os_.marshal(b49);
		_os_.marshal(b50);
		_os_.marshal(b52);
		_os_.marshal(b53);
		_os_.marshal(b54);
		_os_.marshal(b55);
		_os_.marshal(b56);
		_os_.marshal(b57);
		_os_.marshal(b58);
		_os_.marshal(b59);
		_os_.marshal(b60);
		_os_.marshal(b61);
		_os_.marshal(b62);
		_os_.marshal(b63);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		b1.unmarshal(_os_);
		b2.unmarshal(_os_);
		b3.unmarshal(_os_);
		b4.unmarshal(_os_);
		b5.unmarshal(_os_);
		b6.unmarshal(_os_);
		b7.unmarshal(_os_);
		b11.unmarshal(_os_);
		b12.unmarshal(_os_);
		b13.unmarshal(_os_);
		b14.unmarshal(_os_);
		b21.unmarshal(_os_);
		b22.unmarshal(_os_);
		b24.unmarshal(_os_);
		b25.unmarshal(_os_);
		b26.unmarshal(_os_);
		b27.unmarshal(_os_);
		b28.unmarshal(_os_);
		b30.unmarshal(_os_);
		b32.unmarshal(_os_);
		b33.unmarshal(_os_);
		b34.unmarshal(_os_);
		b35.unmarshal(_os_);
		b36.unmarshal(_os_);
		b37.unmarshal(_os_);
		b38.unmarshal(_os_);
		b39.unmarshal(_os_);
		b40.unmarshal(_os_);
		b45.unmarshal(_os_);
		b48.unmarshal(_os_);
		b49.unmarshal(_os_);
		b50.unmarshal(_os_);
		b52.unmarshal(_os_);
		b53.unmarshal(_os_);
		b54.unmarshal(_os_);
		b55.unmarshal(_os_);
		b56.unmarshal(_os_);
		b57.unmarshal(_os_);
		b58.unmarshal(_os_);
		b59.unmarshal(_os_);
		b60.unmarshal(_os_);
		b61.unmarshal(_os_);
		b62.unmarshal(_os_);
		b63.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BeanImport) {
			BeanImport _o_ = (BeanImport)_o1_;
			if (!b1.equals(_o_.b1)) return false;
			if (!b2.equals(_o_.b2)) return false;
			if (!b3.equals(_o_.b3)) return false;
			if (!b4.equals(_o_.b4)) return false;
			if (!b5.equals(_o_.b5)) return false;
			if (!b6.equals(_o_.b6)) return false;
			if (!b7.equals(_o_.b7)) return false;
			if (!b11.equals(_o_.b11)) return false;
			if (!b12.equals(_o_.b12)) return false;
			if (!b13.equals(_o_.b13)) return false;
			if (!b14.equals(_o_.b14)) return false;
			if (!b21.equals(_o_.b21)) return false;
			if (!b22.equals(_o_.b22)) return false;
			if (!b24.equals(_o_.b24)) return false;
			if (!b25.equals(_o_.b25)) return false;
			if (!b26.equals(_o_.b26)) return false;
			if (!b27.equals(_o_.b27)) return false;
			if (!b28.equals(_o_.b28)) return false;
			if (!b30.equals(_o_.b30)) return false;
			if (!b32.equals(_o_.b32)) return false;
			if (!b33.equals(_o_.b33)) return false;
			if (!b34.equals(_o_.b34)) return false;
			if (!b35.equals(_o_.b35)) return false;
			if (!b36.equals(_o_.b36)) return false;
			if (!b37.equals(_o_.b37)) return false;
			if (!b38.equals(_o_.b38)) return false;
			if (!b39.equals(_o_.b39)) return false;
			if (!b40.equals(_o_.b40)) return false;
			if (!b45.equals(_o_.b45)) return false;
			if (!b48.equals(_o_.b48)) return false;
			if (!b49.equals(_o_.b49)) return false;
			if (!b50.equals(_o_.b50)) return false;
			if (!b52.equals(_o_.b52)) return false;
			if (!b53.equals(_o_.b53)) return false;
			if (!b54.equals(_o_.b54)) return false;
			if (!b55.equals(_o_.b55)) return false;
			if (!b56.equals(_o_.b56)) return false;
			if (!b57.equals(_o_.b57)) return false;
			if (!b58.equals(_o_.b58)) return false;
			if (!b59.equals(_o_.b59)) return false;
			if (!b60.equals(_o_.b60)) return false;
			if (!b61.equals(_o_.b61)) return false;
			if (!b62.equals(_o_.b62)) return false;
			if (!b63.equals(_o_.b63)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += b1.hashCode();
		_h_ += b2.hashCode();
		_h_ += b3.hashCode();
		_h_ += b4.hashCode();
		_h_ += b5.hashCode();
		_h_ += b6.hashCode();
		_h_ += b7.hashCode();
		_h_ += b11.hashCode();
		_h_ += b12.hashCode();
		_h_ += b13.hashCode();
		_h_ += b14.hashCode();
		_h_ += b21.hashCode();
		_h_ += b22.hashCode();
		_h_ += b24.hashCode();
		_h_ += b25.hashCode();
		_h_ += b26.hashCode();
		_h_ += b27.hashCode();
		_h_ += b28.hashCode();
		_h_ += b30.hashCode();
		_h_ += b32.hashCode();
		_h_ += b33.hashCode();
		_h_ += b34.hashCode();
		_h_ += b35.hashCode();
		_h_ += b36.hashCode();
		_h_ += b37.hashCode();
		_h_ += b38.hashCode();
		_h_ += b39.hashCode();
		_h_ += b40.hashCode();
		_h_ += b45.hashCode();
		_h_ += b48.hashCode();
		_h_ += b49.hashCode();
		_h_ += b50.hashCode();
		_h_ += b52.hashCode();
		_h_ += b53.hashCode();
		_h_ += b54.hashCode();
		_h_ += b55.hashCode();
		_h_ += b56.hashCode();
		_h_ += b57.hashCode();
		_h_ += b58.hashCode();
		_h_ += b59.hashCode();
		_h_ += b60.hashCode();
		_h_ += b61.hashCode();
		_h_ += b62.hashCode();
		_h_ += b63.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(b1).append(",");
		_sb_.append(b2).append(",");
		_sb_.append(b3).append(",");
		_sb_.append(b4).append(",");
		_sb_.append(b5).append(",");
		_sb_.append(b6).append(",");
		_sb_.append(b7).append(",");
		_sb_.append(b11).append(",");
		_sb_.append(b12).append(",");
		_sb_.append(b13).append(",");
		_sb_.append(b14).append(",");
		_sb_.append(b21).append(",");
		_sb_.append(b22).append(",");
		_sb_.append(b24).append(",");
		_sb_.append(b25).append(",");
		_sb_.append(b26).append(",");
		_sb_.append(b27).append(",");
		_sb_.append(b28).append(",");
		_sb_.append(b30).append(",");
		_sb_.append(b32).append(",");
		_sb_.append(b33).append(",");
		_sb_.append(b34).append(",");
		_sb_.append(b35).append(",");
		_sb_.append(b36).append(",");
		_sb_.append(b37).append(",");
		_sb_.append(b38).append(",");
		_sb_.append(b39).append(",");
		_sb_.append(b40).append(",");
		_sb_.append(b45).append(",");
		_sb_.append(b48).append(",");
		_sb_.append(b49).append(",");
		_sb_.append(b50).append(",");
		_sb_.append(b52).append(",");
		_sb_.append(b53).append(",");
		_sb_.append(b54).append(",");
		_sb_.append(b55).append(",");
		_sb_.append(b56).append(",");
		_sb_.append(b57).append(",");
		_sb_.append(b58).append(",");
		_sb_.append(b59).append(",");
		_sb_.append(b60).append(",");
		_sb_.append(b61).append(",");
		_sb_.append(b62).append(",");
		_sb_.append(b63).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

