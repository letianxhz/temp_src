
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BeanImport3__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BeanImport3 extends __BeanImport3__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 787429;

	public int getType() {
		return 787429;
	}

	public knight.gsp.ranklist.RolePropertyRankData b1;
	public knight.gsp.ranklist.FlowerRankData b2;
	public knight.gsp.ranklist.WitChallengeRankData b3;
	public knight.gsp.ranklist.MercenariesRankData b4;
	public knight.gsp.ranklist.DragonRankData b5;
	public knight.gsp.ranklist.CampRankData b6;
	public knight.gsp.ranklist.RankType b7;
	public knight.gsp.ranklist.CampKillRoleRankData b8;
	public knight.gsp.ranklist.ChallengeRankData b9;
	public knight.gsp.ranklist.FamilyRankData b10;
	public knight.gsp.ranklist.FamilySLQYScore b11;
	public knight.gsp.ranklist.PVPScore b12;
	public knight.gsp.ranklist.PVPVictor b13;
	public knight.gsp.spvp.TransmitTypes b14;
	public knight.gsp.move.FighterStandCamp2 b15;
	public knight.gsp.move.SceneType2 b16;
	public knight.gsp.move.FightSceneType2 b17;
	public knight.gsp.mercenary.MercenaryFightType2 b18;
	public knight.gsp.task.CountDownType b61;
	public knight.gsp.ranklist.HJCount b23;
	public knight.gsp.ranklist.PvPBetHorse b24;
	public knight.gsp.ranklist.WingsRankData b25;
	public knight.gsp.ranklist.TvtScoreRankData b26;
	public knight.gsp.ranklist.TvtGroupScoreRankData b27;
	public knight.gsp.activity.battlefield.Fight2EndOpType b28;
	public knight.gsp.ranklist.RideRankData b29;
	public knight.gsp.EquipSpecialDate b30;
	public knight.gsp.achievement.AchievementState b31;
	public knight.gsp.UnCommitTasks b32;
	public knight.gsp.item.EquipExtTips b33;
	public knight.gsp.achievement.AchievementPageStatus b35;
	public knight.gsp.family.familygather.FamilyGatherRank b36;
	public knight.gsp.ranklist.MasterShideData b37;
	public knight.gsp.ranklist.HongbaoTotalAmountData b38;
	public knight.gsp.ranklist.HongbaoAmountData b39;
	public knight.gsp.ranklist.HongbaoLuckData b40;
	public knight.gsp.ranklist.ActivenessRankData b41;
	public knight.gsp.family.crossfamilybattle.GroupIndex b42;
	public knight.gsp.ranklist.ParagonLvData b43;
	public knight.gsp.ranklist.FashionRankData b44;
	public knight.gsp.ranklist.PVP4RankData b45;
	public knight.gsp.myzone.MomentTypeEnum b46;
	public knight.gsp.wed.TreeState b47;
	public knight.gsp.wed.WedOrderActionType b48;
	public knight.gsp.ranklist.ShenQiRankData b49;
	public knight.gsp.ranklist.FYMiQingRankData b50;
	public knight.gsp.ranklist.FightSpiritRankData b51;

	public BeanImport3() {
		b1 = new knight.gsp.ranklist.RolePropertyRankData();
		b2 = new knight.gsp.ranklist.FlowerRankData();
		b3 = new knight.gsp.ranklist.WitChallengeRankData();
		b4 = new knight.gsp.ranklist.MercenariesRankData();
		b5 = new knight.gsp.ranklist.DragonRankData();
		b6 = new knight.gsp.ranklist.CampRankData();
		b7 = new knight.gsp.ranklist.RankType();
		b8 = new knight.gsp.ranklist.CampKillRoleRankData();
		b9 = new knight.gsp.ranklist.ChallengeRankData();
		b10 = new knight.gsp.ranklist.FamilyRankData();
		b11 = new knight.gsp.ranklist.FamilySLQYScore();
		b12 = new knight.gsp.ranklist.PVPScore();
		b13 = new knight.gsp.ranklist.PVPVictor();
		b14 = new knight.gsp.spvp.TransmitTypes();
		b15 = new knight.gsp.move.FighterStandCamp2();
		b16 = new knight.gsp.move.SceneType2();
		b17 = new knight.gsp.move.FightSceneType2();
		b18 = new knight.gsp.mercenary.MercenaryFightType2();
		b61 = new knight.gsp.task.CountDownType();
		b23 = new knight.gsp.ranklist.HJCount();
		b24 = new knight.gsp.ranklist.PvPBetHorse();
		b25 = new knight.gsp.ranklist.WingsRankData();
		b26 = new knight.gsp.ranklist.TvtScoreRankData();
		b27 = new knight.gsp.ranklist.TvtGroupScoreRankData();
		b28 = new knight.gsp.activity.battlefield.Fight2EndOpType();
		b29 = new knight.gsp.ranklist.RideRankData();
		b30 = new knight.gsp.EquipSpecialDate();
		b31 = new knight.gsp.achievement.AchievementState();
		b32 = new knight.gsp.UnCommitTasks();
		b33 = new knight.gsp.item.EquipExtTips();
		b35 = new knight.gsp.achievement.AchievementPageStatus();
		b36 = new knight.gsp.family.familygather.FamilyGatherRank();
		b37 = new knight.gsp.ranklist.MasterShideData();
		b38 = new knight.gsp.ranklist.HongbaoTotalAmountData();
		b39 = new knight.gsp.ranklist.HongbaoAmountData();
		b40 = new knight.gsp.ranklist.HongbaoLuckData();
		b41 = new knight.gsp.ranklist.ActivenessRankData();
		b42 = new knight.gsp.family.crossfamilybattle.GroupIndex();
		b43 = new knight.gsp.ranklist.ParagonLvData();
		b44 = new knight.gsp.ranklist.FashionRankData();
		b45 = new knight.gsp.ranklist.PVP4RankData();
		b46 = new knight.gsp.myzone.MomentTypeEnum();
		b47 = new knight.gsp.wed.TreeState();
		b48 = new knight.gsp.wed.WedOrderActionType();
		b49 = new knight.gsp.ranklist.ShenQiRankData();
		b50 = new knight.gsp.ranklist.FYMiQingRankData();
		b51 = new knight.gsp.ranklist.FightSpiritRankData();
	}

	public BeanImport3(knight.gsp.ranklist.RolePropertyRankData _b1_, knight.gsp.ranklist.FlowerRankData _b2_, knight.gsp.ranklist.WitChallengeRankData _b3_, knight.gsp.ranklist.MercenariesRankData _b4_, knight.gsp.ranklist.DragonRankData _b5_, knight.gsp.ranklist.CampRankData _b6_, knight.gsp.ranklist.RankType _b7_, knight.gsp.ranklist.CampKillRoleRankData _b8_, knight.gsp.ranklist.ChallengeRankData _b9_, knight.gsp.ranklist.FamilyRankData _b10_, knight.gsp.ranklist.FamilySLQYScore _b11_, knight.gsp.ranklist.PVPScore _b12_, knight.gsp.ranklist.PVPVictor _b13_, knight.gsp.spvp.TransmitTypes _b14_, knight.gsp.move.FighterStandCamp2 _b15_, knight.gsp.move.SceneType2 _b16_, knight.gsp.move.FightSceneType2 _b17_, knight.gsp.mercenary.MercenaryFightType2 _b18_, knight.gsp.task.CountDownType _b61_, knight.gsp.ranklist.HJCount _b23_, knight.gsp.ranklist.PvPBetHorse _b24_, knight.gsp.ranklist.WingsRankData _b25_, knight.gsp.ranklist.TvtScoreRankData _b26_, knight.gsp.ranklist.TvtGroupScoreRankData _b27_, knight.gsp.activity.battlefield.Fight2EndOpType _b28_, knight.gsp.ranklist.RideRankData _b29_, knight.gsp.EquipSpecialDate _b30_, knight.gsp.achievement.AchievementState _b31_, knight.gsp.UnCommitTasks _b32_, knight.gsp.item.EquipExtTips _b33_, knight.gsp.achievement.AchievementPageStatus _b35_, knight.gsp.family.familygather.FamilyGatherRank _b36_, knight.gsp.ranklist.MasterShideData _b37_, knight.gsp.ranklist.HongbaoTotalAmountData _b38_, knight.gsp.ranklist.HongbaoAmountData _b39_, knight.gsp.ranklist.HongbaoLuckData _b40_, knight.gsp.ranklist.ActivenessRankData _b41_, knight.gsp.family.crossfamilybattle.GroupIndex _b42_, knight.gsp.ranklist.ParagonLvData _b43_, knight.gsp.ranklist.FashionRankData _b44_, knight.gsp.ranklist.PVP4RankData _b45_, knight.gsp.myzone.MomentTypeEnum _b46_, knight.gsp.wed.TreeState _b47_, knight.gsp.wed.WedOrderActionType _b48_, knight.gsp.ranklist.ShenQiRankData _b49_, knight.gsp.ranklist.FYMiQingRankData _b50_, knight.gsp.ranklist.FightSpiritRankData _b51_) {
		this.b1 = _b1_;
		this.b2 = _b2_;
		this.b3 = _b3_;
		this.b4 = _b4_;
		this.b5 = _b5_;
		this.b6 = _b6_;
		this.b7 = _b7_;
		this.b8 = _b8_;
		this.b9 = _b9_;
		this.b10 = _b10_;
		this.b11 = _b11_;
		this.b12 = _b12_;
		this.b13 = _b13_;
		this.b14 = _b14_;
		this.b15 = _b15_;
		this.b16 = _b16_;
		this.b17 = _b17_;
		this.b18 = _b18_;
		this.b61 = _b61_;
		this.b23 = _b23_;
		this.b24 = _b24_;
		this.b25 = _b25_;
		this.b26 = _b26_;
		this.b27 = _b27_;
		this.b28 = _b28_;
		this.b29 = _b29_;
		this.b30 = _b30_;
		this.b31 = _b31_;
		this.b32 = _b32_;
		this.b33 = _b33_;
		this.b35 = _b35_;
		this.b36 = _b36_;
		this.b37 = _b37_;
		this.b38 = _b38_;
		this.b39 = _b39_;
		this.b40 = _b40_;
		this.b41 = _b41_;
		this.b42 = _b42_;
		this.b43 = _b43_;
		this.b44 = _b44_;
		this.b45 = _b45_;
		this.b46 = _b46_;
		this.b47 = _b47_;
		this.b48 = _b48_;
		this.b49 = _b49_;
		this.b50 = _b50_;
		this.b51 = _b51_;
	}

	public final boolean _validator_() {
		if (!b1._validator_()) return false;
		if (!b2._validator_()) return false;
		if (!b3._validator_()) return false;
		if (!b4._validator_()) return false;
		if (!b5._validator_()) return false;
		if (!b6._validator_()) return false;
		if (!b7._validator_()) return false;
		if (!b8._validator_()) return false;
		if (!b9._validator_()) return false;
		if (!b10._validator_()) return false;
		if (!b11._validator_()) return false;
		if (!b12._validator_()) return false;
		if (!b13._validator_()) return false;
		if (!b14._validator_()) return false;
		if (!b15._validator_()) return false;
		if (!b16._validator_()) return false;
		if (!b17._validator_()) return false;
		if (!b18._validator_()) return false;
		if (!b61._validator_()) return false;
		if (!b23._validator_()) return false;
		if (!b24._validator_()) return false;
		if (!b25._validator_()) return false;
		if (!b26._validator_()) return false;
		if (!b27._validator_()) return false;
		if (!b28._validator_()) return false;
		if (!b29._validator_()) return false;
		if (!b30._validator_()) return false;
		if (!b31._validator_()) return false;
		if (!b32._validator_()) return false;
		if (!b33._validator_()) return false;
		if (!b35._validator_()) return false;
		if (!b36._validator_()) return false;
		if (!b37._validator_()) return false;
		if (!b38._validator_()) return false;
		if (!b39._validator_()) return false;
		if (!b40._validator_()) return false;
		if (!b41._validator_()) return false;
		if (!b42._validator_()) return false;
		if (!b43._validator_()) return false;
		if (!b44._validator_()) return false;
		if (!b45._validator_()) return false;
		if (!b46._validator_()) return false;
		if (!b47._validator_()) return false;
		if (!b48._validator_()) return false;
		if (!b49._validator_()) return false;
		if (!b50._validator_()) return false;
		if (!b51._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(b1);
		_os_.marshal(b2);
		_os_.marshal(b3);
		_os_.marshal(b4);
		_os_.marshal(b5);
		_os_.marshal(b6);
		_os_.marshal(b7);
		_os_.marshal(b8);
		_os_.marshal(b9);
		_os_.marshal(b10);
		_os_.marshal(b11);
		_os_.marshal(b12);
		_os_.marshal(b13);
		_os_.marshal(b14);
		_os_.marshal(b15);
		_os_.marshal(b16);
		_os_.marshal(b17);
		_os_.marshal(b18);
		_os_.marshal(b61);
		_os_.marshal(b23);
		_os_.marshal(b24);
		_os_.marshal(b25);
		_os_.marshal(b26);
		_os_.marshal(b27);
		_os_.marshal(b28);
		_os_.marshal(b29);
		_os_.marshal(b30);
		_os_.marshal(b31);
		_os_.marshal(b32);
		_os_.marshal(b33);
		_os_.marshal(b35);
		_os_.marshal(b36);
		_os_.marshal(b37);
		_os_.marshal(b38);
		_os_.marshal(b39);
		_os_.marshal(b40);
		_os_.marshal(b41);
		_os_.marshal(b42);
		_os_.marshal(b43);
		_os_.marshal(b44);
		_os_.marshal(b45);
		_os_.marshal(b46);
		_os_.marshal(b47);
		_os_.marshal(b48);
		_os_.marshal(b49);
		_os_.marshal(b50);
		_os_.marshal(b51);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		b1.unmarshal(_os_);
		b2.unmarshal(_os_);
		b3.unmarshal(_os_);
		b4.unmarshal(_os_);
		b5.unmarshal(_os_);
		b6.unmarshal(_os_);
		b7.unmarshal(_os_);
		b8.unmarshal(_os_);
		b9.unmarshal(_os_);
		b10.unmarshal(_os_);
		b11.unmarshal(_os_);
		b12.unmarshal(_os_);
		b13.unmarshal(_os_);
		b14.unmarshal(_os_);
		b15.unmarshal(_os_);
		b16.unmarshal(_os_);
		b17.unmarshal(_os_);
		b18.unmarshal(_os_);
		b61.unmarshal(_os_);
		b23.unmarshal(_os_);
		b24.unmarshal(_os_);
		b25.unmarshal(_os_);
		b26.unmarshal(_os_);
		b27.unmarshal(_os_);
		b28.unmarshal(_os_);
		b29.unmarshal(_os_);
		b30.unmarshal(_os_);
		b31.unmarshal(_os_);
		b32.unmarshal(_os_);
		b33.unmarshal(_os_);
		b35.unmarshal(_os_);
		b36.unmarshal(_os_);
		b37.unmarshal(_os_);
		b38.unmarshal(_os_);
		b39.unmarshal(_os_);
		b40.unmarshal(_os_);
		b41.unmarshal(_os_);
		b42.unmarshal(_os_);
		b43.unmarshal(_os_);
		b44.unmarshal(_os_);
		b45.unmarshal(_os_);
		b46.unmarshal(_os_);
		b47.unmarshal(_os_);
		b48.unmarshal(_os_);
		b49.unmarshal(_os_);
		b50.unmarshal(_os_);
		b51.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BeanImport3) {
			BeanImport3 _o_ = (BeanImport3)_o1_;
			if (!b1.equals(_o_.b1)) return false;
			if (!b2.equals(_o_.b2)) return false;
			if (!b3.equals(_o_.b3)) return false;
			if (!b4.equals(_o_.b4)) return false;
			if (!b5.equals(_o_.b5)) return false;
			if (!b6.equals(_o_.b6)) return false;
			if (!b7.equals(_o_.b7)) return false;
			if (!b8.equals(_o_.b8)) return false;
			if (!b9.equals(_o_.b9)) return false;
			if (!b10.equals(_o_.b10)) return false;
			if (!b11.equals(_o_.b11)) return false;
			if (!b12.equals(_o_.b12)) return false;
			if (!b13.equals(_o_.b13)) return false;
			if (!b14.equals(_o_.b14)) return false;
			if (!b15.equals(_o_.b15)) return false;
			if (!b16.equals(_o_.b16)) return false;
			if (!b17.equals(_o_.b17)) return false;
			if (!b18.equals(_o_.b18)) return false;
			if (!b61.equals(_o_.b61)) return false;
			if (!b23.equals(_o_.b23)) return false;
			if (!b24.equals(_o_.b24)) return false;
			if (!b25.equals(_o_.b25)) return false;
			if (!b26.equals(_o_.b26)) return false;
			if (!b27.equals(_o_.b27)) return false;
			if (!b28.equals(_o_.b28)) return false;
			if (!b29.equals(_o_.b29)) return false;
			if (!b30.equals(_o_.b30)) return false;
			if (!b31.equals(_o_.b31)) return false;
			if (!b32.equals(_o_.b32)) return false;
			if (!b33.equals(_o_.b33)) return false;
			if (!b35.equals(_o_.b35)) return false;
			if (!b36.equals(_o_.b36)) return false;
			if (!b37.equals(_o_.b37)) return false;
			if (!b38.equals(_o_.b38)) return false;
			if (!b39.equals(_o_.b39)) return false;
			if (!b40.equals(_o_.b40)) return false;
			if (!b41.equals(_o_.b41)) return false;
			if (!b42.equals(_o_.b42)) return false;
			if (!b43.equals(_o_.b43)) return false;
			if (!b44.equals(_o_.b44)) return false;
			if (!b45.equals(_o_.b45)) return false;
			if (!b46.equals(_o_.b46)) return false;
			if (!b47.equals(_o_.b47)) return false;
			if (!b48.equals(_o_.b48)) return false;
			if (!b49.equals(_o_.b49)) return false;
			if (!b50.equals(_o_.b50)) return false;
			if (!b51.equals(_o_.b51)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += b1.hashCode();
		_h_ += b2.hashCode();
		_h_ += b3.hashCode();
		_h_ += b4.hashCode();
		_h_ += b5.hashCode();
		_h_ += b6.hashCode();
		_h_ += b7.hashCode();
		_h_ += b8.hashCode();
		_h_ += b9.hashCode();
		_h_ += b10.hashCode();
		_h_ += b11.hashCode();
		_h_ += b12.hashCode();
		_h_ += b13.hashCode();
		_h_ += b14.hashCode();
		_h_ += b15.hashCode();
		_h_ += b16.hashCode();
		_h_ += b17.hashCode();
		_h_ += b18.hashCode();
		_h_ += b61.hashCode();
		_h_ += b23.hashCode();
		_h_ += b24.hashCode();
		_h_ += b25.hashCode();
		_h_ += b26.hashCode();
		_h_ += b27.hashCode();
		_h_ += b28.hashCode();
		_h_ += b29.hashCode();
		_h_ += b30.hashCode();
		_h_ += b31.hashCode();
		_h_ += b32.hashCode();
		_h_ += b33.hashCode();
		_h_ += b35.hashCode();
		_h_ += b36.hashCode();
		_h_ += b37.hashCode();
		_h_ += b38.hashCode();
		_h_ += b39.hashCode();
		_h_ += b40.hashCode();
		_h_ += b41.hashCode();
		_h_ += b42.hashCode();
		_h_ += b43.hashCode();
		_h_ += b44.hashCode();
		_h_ += b45.hashCode();
		_h_ += b46.hashCode();
		_h_ += b47.hashCode();
		_h_ += b48.hashCode();
		_h_ += b49.hashCode();
		_h_ += b50.hashCode();
		_h_ += b51.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(b1).append(",");
		_sb_.append(b2).append(",");
		_sb_.append(b3).append(",");
		_sb_.append(b4).append(",");
		_sb_.append(b5).append(",");
		_sb_.append(b6).append(",");
		_sb_.append(b7).append(",");
		_sb_.append(b8).append(",");
		_sb_.append(b9).append(",");
		_sb_.append(b10).append(",");
		_sb_.append(b11).append(",");
		_sb_.append(b12).append(",");
		_sb_.append(b13).append(",");
		_sb_.append(b14).append(",");
		_sb_.append(b15).append(",");
		_sb_.append(b16).append(",");
		_sb_.append(b17).append(",");
		_sb_.append(b18).append(",");
		_sb_.append(b61).append(",");
		_sb_.append(b23).append(",");
		_sb_.append(b24).append(",");
		_sb_.append(b25).append(",");
		_sb_.append(b26).append(",");
		_sb_.append(b27).append(",");
		_sb_.append(b28).append(",");
		_sb_.append(b29).append(",");
		_sb_.append(b30).append(",");
		_sb_.append(b31).append(",");
		_sb_.append(b32).append(",");
		_sb_.append(b33).append(",");
		_sb_.append(b35).append(",");
		_sb_.append(b36).append(",");
		_sb_.append(b37).append(",");
		_sb_.append(b38).append(",");
		_sb_.append(b39).append(",");
		_sb_.append(b40).append(",");
		_sb_.append(b41).append(",");
		_sb_.append(b42).append(",");
		_sb_.append(b43).append(",");
		_sb_.append(b44).append(",");
		_sb_.append(b45).append(",");
		_sb_.append(b46).append(",");
		_sb_.append(b47).append(",");
		_sb_.append(b48).append(",");
		_sb_.append(b49).append(",");
		_sb_.append(b50).append(",");
		_sb_.append(b51).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

