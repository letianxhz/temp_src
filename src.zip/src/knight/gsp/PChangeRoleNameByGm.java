package knight.gsp;

import knight.gsp.msg.Message;
import xdb.Procedure;

public class PChangeRoleNameByGm extends Procedure {
	private long roleId;
	private String newRoleName;
	public PChangeRoleNameByGm(long roleId, String newRoleName) {
		super();
		this.roleId = roleId;
		this.newRoleName = newRoleName;
	}
	@Override
	protected boolean process() throws Exception {
		if(new PChangeRoleName(roleId, newRoleName).call()){
			Message.psendMsgNotify(roleId, 1039267);// 您因为角色名称违反规定，已被强制更名。
			return true;
		}
		return false;
	}
	
	
	
}
