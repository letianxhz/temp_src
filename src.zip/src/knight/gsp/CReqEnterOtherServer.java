
package knight.gsp;

import knight.gsp.main.ServerInfoProvider;
import gnet.link.User;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CReqEnterOtherServer__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CReqEnterOtherServer extends __CReqEnterOtherServer__ {
	@Override
	protected void process() {
		final int userID = ((gnet.link.Dispatch) this.getContext()).userid;
		if (userID <= 0) {
			return;
		}
		User user = gnet.link.Onlines.getInstance().getOnlineUsers().get(userID);
		if (user == null)
			return;
		int realServerId = ServerInfoProvider.localId2zoneid(serverid);
		global.rsp.ServerInfo serverInfo = ServerInfoProvider.getServerInfo(realServerId);
		if (serverInfo == null)
			return;
		
		xbean.AUUserInfo auUserInfo = xtable.Auuserinfo.select(userID);
		if (auUserInfo == null)
			return;
		
		SServerPassword snd = new SServerPassword();
		snd.ipstr = connecttype == ConnectType.TYPE_GAMEX ? serverInfo.gamexloginip : serverInfo.ip;
		snd.serverid = serverid;
		snd.statport = serverInfo.dockerstartport;
		snd.token = auUserInfo.getRelogintoken();
		user.send(snd);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786528;

	public int getType() {
		return 786528;
	}

	public int serverid; // 服务器id
	public byte connecttype; // 参考枚举ConnectType

	public CReqEnterOtherServer() {
	}

	public CReqEnterOtherServer(int _serverid_, byte _connecttype_) {
		this.serverid = _serverid_;
		this.connecttype = _connecttype_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(serverid);
		_os_.marshal(connecttype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		serverid = _os_.unmarshal_int();
		connecttype = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CReqEnterOtherServer) {
			CReqEnterOtherServer _o_ = (CReqEnterOtherServer)_o1_;
			if (serverid != _o_.serverid) return false;
			if (connecttype != _o_.connecttype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += serverid;
		_h_ += (int)connecttype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(serverid).append(",");
		_sb_.append(connecttype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CReqEnterOtherServer _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = serverid - _o_.serverid;
		if (0 != _c_) return _c_;
		_c_ = connecttype - _o_.connecttype;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

