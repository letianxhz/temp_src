package knight.gsp;

import knight.gsp.activity.VerifyPhoneNumberManager;
import knight.gsp.activity.crossbigwild.PclearBigwildData;
import knight.gsp.activity.eggs.EggsManager;
import knight.gsp.activity.newservergift.NewserverGiftInfoWrapper;
import knight.gsp.activity.procedure.OnlinesTimesAwardManager;
import knight.gsp.activity.protectmilitaryvehicle.MilitaryVehicleManager;
import knight.gsp.activity.roleback.RolebackManager;
import knight.gsp.activity.shuangjie.ShuangjieManager;
import knight.gsp.activity.shuangjie.XueqiuManager;
import knight.gsp.activity.sologhost.SoloGhostManager;
import knight.gsp.activity.soulbless.PClearSoulBlessAwardData;
import knight.gsp.activity.soulbless.SoulblessManager;
import knight.gsp.activity.springfestival.giftbox.PCalcTreasureStealGiftBox;
import knight.gsp.activity.treasure.TreasureManager;
import knight.gsp.anniversary.Util;
import knight.gsp.camp.CampRole;
import knight.gsp.camp.PAddCampZhanli;
import knight.gsp.camp.PSetCurCampFuli;
import knight.gsp.counter.PCheckAndClearDaily;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.fuben.challenge.ChallengeManager;
import knight.gsp.fuben.dailyresource.Module;
import knight.gsp.imagechallenge.ImageChallengeManager;
import knight.gsp.item.PClearGainItemCounter;
import knight.gsp.item.SharedGiftManager;
import knight.gsp.msg.hongbao.HongbaoManager;
import knight.gsp.myzone.pro.PClearZoneDayData;
import knight.gsp.qixi.QiXiActivityManager;
import knight.gsp.shenqi.ShenQiManager;
import knight.gsp.shenqi.ShenQiRole;
import knight.gsp.state.StateManager;
import knight.gsp.team.PClearInviteStrangerInfo;
import knight.gsp.team.ghost.RoleGhostManager;
import knight.gsp.weiwang.PClearWeiWang;
import knight.gsp.wing.WingManager;
import xdb.Procedure;

/**
 * 清除角色每天的数据(上线时清除)
 * 
 * @author yangzhenyu
 * 
 *         2014-6-15 上午4:22:35
 */
public class PClearRoleDayDataWhileLogin extends Procedure {
	
	private long roleId;

	public PClearRoleDayDataWhileLogin(long roleId) {
		super();
		this.roleId = roleId;
	}

	@Override
	protected boolean process() throws Exception {
		if (LocalIds.isRemoteServerRole(roleId))
			return false;
		
		xbean.Properties prop = xtable.Properties.get(roleId);
		if (prop == null)
			return false;
		final long now = System.currentTimeMillis();
		
		prop.setLastcleardailydatatick(now); //记录下清除每日数据的时间
		
		try {
			FubenCommon.clearDirtyData(roleId, now, false);
			
			if (new CampRole(roleId, true).getStandCamp() > 0) {
				CampRole campRole = new CampRole(roleId, false);
				campRole.clearDailyRecord();
				xdb.Procedure.pexecuteWhileCommit(new PSetCurCampFuli(roleId));
				xdb.Procedure.pexecuteWhileCommit(new PAddCampZhanli(prop.getPower(), campRole.getStandCamp()));
			}
			
			// 清除钓鱼时间
			xtable.Fishing.remove(roleId);
			// 清除兑换功能的兑换次数
			xtable.Exchangeitem.remove(roleId);
			//清除当日兑换的威望值
			new PClearWeiWang(roleId, now).call();
			//
			ChallengeManager.getInstance().clearDirtyData(roleId, now);
			
			// 清除：道具在给定时间内的获得数量
			new PClearGainItemCounter(roleId).call();
			
			// 清除资源副本周日的特殊计数
			Module.getInstance().clearFubenCountSunday(roleId);
			//双节活动
			ShuangjieManager.getInstance().clearData(roleId, now);
			XueqiuManager.getInstance().clearData(roleId, now);
			//圣灵祝福
			SoulblessManager.getInstance().clearData(roleId, now);
			xdb.Procedure.pexecuteWhileCommit(new PClearSoulBlessAwardData(roleId, now));
			// 回流活动
			RolebackManager.getInstance().clearExpiredData(roleId, now);
			
			SharedGiftManager sharedGiftManager=new SharedGiftManager(roleId, false);
			sharedGiftManager.clearDailyData(now);
			sharedGiftManager.clearGiftData(now);
			
			RoleGhostManager roleGhostManager=new RoleGhostManager(roleId, false);
			roleGhostManager.clearDailyData(now);
			
			// 清除邀请陌生人组队信息
			new PClearInviteStrangerInfo(roleId).call();
			
			SoloGhostManager.getInstance().resetData(roleId);
			
			xbean.YjxrInfo yjxrInfo = xtable.Yjxrroles.get(roleId);
			if (yjxrInfo != null) {
				yjxrInfo.setTodayawardminute((short) 0);
				yjxrInfo.setTotalexp(0);
			}
			
			prop.setHasclickquestionsurvey(false);
			
			TreasureManager.getInstance().clearDailyData(roleId, now);
			
			WingManager.getInstance().clearDailyData(roleId, now);
			
			//复活节数据
			EggsManager.getInstance().clearEasterData(roleId, now);
			
			xbean.Pvp8MatchInfo matchInfo = xtable.Pvp8matchdata.get(roleId);
			if (matchInfo != null) {
				//清除8V8首胜
				matchInfo.setIsreachfirstwin(false);
				matchInfo.setIsloadrule(true);
				matchInfo.getBuynums().clear();
				matchInfo.setTodaygetpiontcard(0);
				matchInfo.setTodaygetintegral(0);
			}
			
			xbean.VoiceGuideRole vgr = xtable.Voiceguiderole.get(roleId);
			if (vgr != null) {
				vgr.getGuidedvoices().remove(CPlayVoiceGuide.LIN_YE_FENG_HUO_EVERY_DAY);
				vgr.getGuidedvoices().remove(CPlayVoiceGuide.FAMILY_GATHER_EVERYDAY);
				vgr.getGuidedvoices().remove(CPlayVoiceGuide.FAMILY_BATTLE_EVERYDAY);
				vgr.getGuidedvoices().remove(CPlayVoiceGuide.PVP8_EVERYDAY);
				vgr.getGuidedvoices().remove(CPlayVoiceGuide.APOLLO_FIGHT);
			}
			xbean.SwornMemberData sData = xtable.Swornmember.get(roleId);
			if (null != sData) {
				sData.getHonorinfos().clear();
			}
			try {
				VerifyPhoneNumberManager.getInstance().tryClearData(roleId, now);
			} catch (Throwable th) {
				th.printStackTrace();
			}
			// 新服独享
			NewserverGiftInfoWrapper newserverInfoWrapper = new NewserverGiftInfoWrapper(roleId, false);
			newserverInfoWrapper.checkDailyClear(System.currentTimeMillis());
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		//跨天要清空频道发言次数
		xtable.Channelspeekrecord.remove(roleId);
		
		xbean.BalrogFubenInfo balrogFubenInfo = xtable.Balrogfubeninfos.get(roleId);
		if (null != balrogFubenInfo) {
			balrogFubenInfo.setGetseedcount(0);
			balrogFubenInfo.setPasscount(0);
		}
		
		xbean.RoleFamilyRobberInfo robberRole = xtable.Familyrobberroles.get(roleId);
		if (robberRole != null) {
			robberRole.setEntercount((short) 0);
		}
		
		try {
			// 清理次数
			new PCheckAndClearDaily(roleId,true).call();
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		xbean.SpeedCompeteRole scr = xtable.Speedcompeteroles.get(roleId);
		if (scr != null) {
			scr.setTodaycount((short) 0);
		}
		
		xbean.ShenFaLeiTaiRole sTaiRole = xtable.Shenfaleitairoles.get(roleId);
		if (null != sTaiRole) {
			sTaiRole.setTodaycount((short)0);
		}
		
		xbean.CrossBossRole crossBossRole = xtable.Crossbossroles.get(roleId);
		if (crossBossRole != null) {
			crossBossRole.setTodayentercount((short) 0);
		}
		
		HongbaoManager.getInstance().clearRoleDailyData(roleId, now);
		
		xbean.SendAppleRole sendAppleRole = xtable.Sendappleroles.get(roleId);
		if (sendAppleRole != null) {
			sendAppleRole.setTodayreceivenum(0);
			sendAppleRole.getTodaysendnum().clear();
		}
		
		xbean.ShuangDanRole sdr = xtable.Shuangdanroles.get(roleId);
		if (sdr != null) {
			sdr.setTodaygathernum((short) 0);
			sdr.setTodayhaschallengeboss(false);
		}
		
		try {
			new PCalcTreasureStealGiftBox(roleId).call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		xbean.ShenMiDengLongRole smdlr = xtable.Smdlroles.get(roleId);
		if (smdlr != null) {
			smdlr.setTodayopennum((short) 0);
			smdlr.getAlreadyopen().clear();
			smdlr.getQuestionavailabletime().clear();
		}
		
		// 个人空间 每日数据清理
		try {
			new PClearZoneDayData(roleId).call();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			StateManager.logger.error("个人空间每日数据清理失败", e);
		}
		
		//清除满城烟火采集的礼包数
		xbean.FireworkRole fireWorkRole = xtable.Fireworkroles.get(roleId);
		if (fireWorkRole != null){
			fireWorkRole.setTodaygathernum((short)0);
		}
		
		xbean.BingJianZuoZhanRole bjzzr = xtable.Bjzzroles.get(roleId);
		if (bjzzr != null) {
			bjzzr.setTodaychallengenum((short) 0);
		}
		
		//清除勇者之塔今日挑战次数
		xbean.BraveTowerRole braveTowerRole = xtable.Bravetowerroles.get(roleId);
		if (null != braveTowerRole){
			braveTowerRole.setHasentertimes(0);
			//如果当前时间大于活动结束时间，说明本次活动已结束，清空所有挑战记录
			if (now > braveTowerRole.getActivityendtime()){
				braveTowerRole.setLayer(1);
				braveTowerRole.setLaststatus(0);
				braveTowerRole.setTransnpc(0);
				braveTowerRole.setLastquestionindex(0);
				braveTowerRole.getLastchallengenpc().clear();
				braveTowerRole.setShowlayer(1);
			}
		}
		
		xbean.YingXiongBuXiu yingXiongBuXiu = xtable.Yxburoles.get(roleId);
		if (null != yingXiongBuXiu)
			yingXiongBuXiu.setTodaychallengenum((short)0);
		try {
			new PclearBigwildData(roleId).call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			xbean.pukeInfos pukeInfos = xtable.Puke.get(roleId);
			if (null != pukeInfos) {
				pukeInfos.setFreetimes(0);
				pukeInfos.setTodayjifen(0);
				pukeInfos.setTodayresidueround(0);
				pukeInfos.setTodaybuytimes(0);
			}
		} catch (Throwable th) {
			th.printStackTrace();
		}
		//清理五一活动相关数据
		xbean.MayDayRole mdr = xtable.Maydayroles.get(roleId);
		if (mdr != null) {
			mdr.setHastakeliangjunkaoshangtask(false);
			mdr.setTodaygathernum((short) 0);
		}
		
		xbean.DuanWuJieBean dBean = xtable.Duanwujieinfos.get(roleId);
		if (null != dBean) {
			dBean.setHastakeliangjunkaoshangtask(false);
			dBean.setTodaygathernum((short) 0);
		}
		
		xbean.DaLuanDouRole dldr = xtable.Daluandouroles.get(roleId);
		if (dldr != null) {
			dldr.setIsreachfirstwin(false);
			dldr.setIsloadrule(true);
			dldr.setEnternum(0);
		}
		
		xbean.GuangYingRole gyRole = xtable.Guangyingroles.get(roleId);
		if (gyRole != null) {
			gyRole.setIsreachfirstwin(false);
			gyRole.setIsloadrule(true);
			gyRole.setEnternum(0);
		}
	
		//清除微信分享每日信息
		try {
			final xbean.User user = xtable.User.select(prop.getUserid());
			if (null != user) {
				xbean.Properties propTemp = null;
				boolean isFinish = false;
				for(long roleId : user.getIdlist()){
					propTemp = xtable.Properties.select(roleId);
					if (propTemp == null)
						continue;
					if (propTemp.getWeixinsharestatus() == 2)//当前用户下有角色完成了微信分享了，所有的角色都设置为完成了
						isFinish = true;
				}
				if (isFinish)
					prop.setWeixinsharestatus((short)2);
				PFirstShareAward.clearWeixinShareData(prop);
			}
		} catch(Throwable th) {
			th.printStackTrace();
		}
		
		OnlinesTimesAwardManager manager = OnlinesTimesAwardManager.getInstance();
		manager.clearRoleData(roleId);
		manager.refreshOnlinesInfos(roleId);
		manager.checkAndSendMorrowPresent(roleId);
		
		// 重置每天对单向好友发送聊天内容次数
		xbean.FriendGroups friendGroups = xtable.Friends.get(roleId);
		if (friendGroups != null) {
			friendGroups.setSendmsgnumforsinggriend(0);
		}
		ShenQiManager.getInstance().clearChenFuchouquData(roleId);
		Util.clearData(roleId, now,false);
		try {
			QiXiActivityManager.getInstance().sendProtocolWhileCrossDay(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		try {
			QiXiActivityManager.getInstance().clearData(roleId,now);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			//军需护送
			MilitaryVehicleManager.getInstance().clearData(roleId, now);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			ImageChallengeManager.getInstance().clearDailyData(roleId, now);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			xtable.Gotowildrolecachedata.remove(roleId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

}
