
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SRoleUpLevel__ extends xio.Protocol { }

/** 升级提示
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SRoleUpLevel extends __SRoleUpLevel__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786450;

	public int getType() {
		return 786450;
	}

	public int uplevel;
	public int hp; // 生命
	public int phyattack; // 物理攻击
	public int phydefend; // 物理防御
	public int magicattack; // 法术攻击
	public int magicdefend; // 法术防御

	public SRoleUpLevel() {
	}

	public SRoleUpLevel(int _uplevel_, int _hp_, int _phyattack_, int _phydefend_, int _magicattack_, int _magicdefend_) {
		this.uplevel = _uplevel_;
		this.hp = _hp_;
		this.phyattack = _phyattack_;
		this.phydefend = _phydefend_;
		this.magicattack = _magicattack_;
		this.magicdefend = _magicdefend_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(uplevel);
		_os_.marshal(hp);
		_os_.marshal(phyattack);
		_os_.marshal(phydefend);
		_os_.marshal(magicattack);
		_os_.marshal(magicdefend);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		uplevel = _os_.unmarshal_int();
		hp = _os_.unmarshal_int();
		phyattack = _os_.unmarshal_int();
		phydefend = _os_.unmarshal_int();
		magicattack = _os_.unmarshal_int();
		magicdefend = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SRoleUpLevel) {
			SRoleUpLevel _o_ = (SRoleUpLevel)_o1_;
			if (uplevel != _o_.uplevel) return false;
			if (hp != _o_.hp) return false;
			if (phyattack != _o_.phyattack) return false;
			if (phydefend != _o_.phydefend) return false;
			if (magicattack != _o_.magicattack) return false;
			if (magicdefend != _o_.magicdefend) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += uplevel;
		_h_ += hp;
		_h_ += phyattack;
		_h_ += phydefend;
		_h_ += magicattack;
		_h_ += magicdefend;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(uplevel).append(",");
		_sb_.append(hp).append(",");
		_sb_.append(phyattack).append(",");
		_sb_.append(phydefend).append(",");
		_sb_.append(magicattack).append(",");
		_sb_.append(magicdefend).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SRoleUpLevel _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = uplevel - _o_.uplevel;
		if (0 != _c_) return _c_;
		_c_ = hp - _o_.hp;
		if (0 != _c_) return _c_;
		_c_ = phyattack - _o_.phyattack;
		if (0 != _c_) return _c_;
		_c_ = phydefend - _o_.phydefend;
		if (0 != _c_) return _c_;
		_c_ = magicattack - _o_.magicattack;
		if (0 != _c_) return _c_;
		_c_ = magicdefend - _o_.magicdefend;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

