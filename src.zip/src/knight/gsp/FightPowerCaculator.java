/**
 * 
 */
package knight.gsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.script.ScriptEngine;
import javax.script.ScriptException;

import knight.gsp.camp.CampRole;
import knight.gsp.dragon.DragonColumn;
import knight.gsp.effect.SAttreffectrate;
import knight.gsp.fashion.FashionManager;
import knight.gsp.fightspirit.FightSpiritRole;
import knight.gsp.item.Equip;
import knight.gsp.item.Sequipscore;
import knight.gsp.item.Shiddenattribute;
import knight.gsp.item.forge.ForgeManager;
import knight.gsp.item.forge.ForgeRole;
import knight.gsp.item.juexing.JueXingRole;
import knight.gsp.item.suit.PRecorrectSuitProps;
import knight.gsp.main.ConfigManager;
import knight.gsp.mercenary.MercenaryEffectProvider;
import knight.gsp.mercenary.proc.Mercenary;
import knight.gsp.mercenary.proc.MercenaryColumn;
import knight.gsp.mercenary.proc.ZhenWeiSystemRole;
import knight.gsp.myzone.ZoneManager;
import knight.gsp.npc.SCombat;
import knight.gsp.paragonlevel.ParagonLevelRole;
import knight.gsp.ride.RideManager;
import knight.gsp.script.ScriptEngineService;
import knight.gsp.shenqi.ShenQiManager;
import knight.gsp.shenqi.ShenQiRole;
import knight.gsp.skill.SkillRole;
import knight.gsp.wing.Swinggrade;
import knight.gsp.wing.WingManager;
import xbean.CampSkillInfo;
import xbean.FamilyTotemBean;

/**
 * 计算人物战斗力
 * 
 * @author rake.zhai
 * @since 2014年6月10日
 */
public class FightPowerCaculator {
	
	/**
	 * 人物战斗力计算方法为：
	 * 人物身上的所有装备评分和+角色当前参战的龙的评分+角色当前参战佣兵评分总和+人物当前等级*等级参数+人物当前职业技能等级总和
	 * *职业技能等级参数+人物家族修练等级总和*家族技能等级参数+人物阵营技能等级总和*人物阵营技能等级参数
	 * 其中各等级参数在SAttreffectrate.xml表中配置，id=1为等级参数 id=2为家族修炼等级参数 id=3为阵营技能等级参数 id=4为职业技能等级参数
	 * 各参数由js公式实现，且需要配套的四个数据：
	 * totalskilllv=人物当前职业技能等级总和，totalfamilyskilllv=人物当前家族修炼技能等级总和，totalcampskilllv=人物当前阵营技能等级总和 
	 * 
	 */
	public static int getPower(long roleId, int level, int mercenaryFightType) {
		int power = 0;
		// 装备栏评分总和
		power += calcEquipScoreTotal(roleId);

		// 角色当前参战的龙的评分
		power += increaseFightDragonScore(roleId);

		// 角色当前参战佣兵评分总和
		power += increaseFightMercenaryScore(roleId, mercenaryFightType);
		
		power += increaseMercenaryAchievementPower(roleId);

		// 人物当前等级*等级参数
		String mathResult = "";
		javax.script.ScriptEngine engine =  ScriptEngineService.getScriptEngine();

		Map<Integer, SAttreffectrate> attrConfig = ConfigManager.getInstance().getConf(SAttreffectrate.class);
		SAttreffectrate config = attrConfig.get(1);
		if (config != null) {
			mathResult = "with(Math){" + config.getRate() + "}";
			engine.put("lv", level);
			power += toValue(engine, mathResult);
		}
		
		// 人物当前职业技能等级总和*职业技能等级参数
		List<Short> skillLvls = getSkillLevelTotal(roleId);
		config = attrConfig.get(4);
		if (config != null) {
			for (short slvl : skillLvls) {
				mathResult = "with(Math){" + config.getRate() + "}";
				engine.put("lv", slvl);
				power += toValue(engine, mathResult);
			}
		}

		// 人物家族修练等级总和*家族技能等级参数
		xbean.FamilyTotemListBean totemBeanList = xtable.Familytotemlist.select(roleId);
		int totemLevelTotal = 0;
		if (totemBeanList != null) {
			for (FamilyTotemBean bean : totemBeanList.getFamilytotemlist()) {
				totemLevelTotal += bean.getLevel();
			}
			config = attrConfig.get(2);
			if (config != null) {
				mathResult = "with(Math){" + config.getRate() + "}";
				engine.put("lv", totemLevelTotal);
				power += toValue(engine, mathResult);
			}
		}

		// 人物阵营技能等级总和*人物阵营技能等级参数
		CampRole campRole = new CampRole(roleId, true);
		int campSkilllevelTotal = 0;
		for (CampSkillInfo skillInfo : campRole.getAllCampSkillInfo().values()) {
			campSkilllevelTotal += skillInfo.getSkilllv();
		}
		config = attrConfig.get(3);
		if (config != null) {
			mathResult = "with(Math){" + config.getRate() + "}";
			engine.put("lv", campSkilllevelTotal);
			power += toValue(engine, mathResult);
		}

		// 套装属性
		xbean.ActivedSuit suits = xtable.Activedsuit.select(roleId);
		if (suits != null) {
			for (int id : suits.getSuits()) {
				Shiddenattribute cfg = ConfigManager.getInstance().getConf(Shiddenattribute.class).get(id);
				if (cfg == null) {
					continue;
				}

				for (String pair : cfg.atrribute.split(";")) {
					String[] attr = pair.split(",");

					int type = Integer.parseInt(attr[0]);
					float value = Float.parseFloat(attr[1]);
					Sequipscore scoreCfg = ConfigManager.getInstance().getConf(Sequipscore.class).get(type);
					if(scoreCfg == null) {
						continue;
					}
					
					if (cfg.getAttributetype() == PRecorrectSuitProps.STAR_SUIT) {
						// 星套
						power += Integer.parseInt(scoreCfg.getSuitscore().get(0)) * value / 100;
					} else if (cfg.getAttributetype() == PRecorrectSuitProps.EQUIP_SUIT) {
						// 装备套装
						power += Integer.parseInt(scoreCfg.getSuitscore().get(2)) * value / 100;
					} else if (cfg.getAttributetype() == PRecorrectSuitProps.GEM_SUIT) {
						// 宝石套
						power += Integer.parseInt(scoreCfg.getSuitscore().get(1)) * value / 100;
					} else if (cfg.getAttributetype() == PRecorrectSuitProps.EQUIP_GOLDEN_SUIT) {
						// 金装套.用跟装备套一样的权值去算
						power += Integer.parseInt(scoreCfg.getSuitscore().get(2)) * value / 100;
					}
				}
			}
		}
		
		// 翅膀
		xbean.Wing wing = xtable.Wing.select(roleId);
		if (wing != null && (wing.getActivewingid() != 0 || wing.getDefendwingid() != 0)) {
			Map<Integer, Float> effects = WingManager.getInstance().getWingBuffEffect(roleId);
			Iterator<Entry<Integer, Float>> iter = effects.entrySet().iterator();
			while (iter.hasNext()) {
				Entry<Integer, Float> entry = iter.next();
				Swinggrade cfg = ConfigManager.getInstance().getConf(Swinggrade.class).get(entry.getKey());
				if (cfg == null) {
					continue;
				}
				power += cfg.getWeight() * entry.getValue();
			}

			if (wing.getSkills().containsKey(wing.getActivewingid())) {
				power += wing.getSkills().get(wing.getActivewingid()) * 1500;
			}
		}
		
		//坐骑战力
		power += RideManager.getInstance().calculateRidePower(roleId);
		
		// 巅峰等级
		ParagonLevelRole paragonLevelRole = new ParagonLevelRole(roleId, true);
		Map<Integer, Float> _effects = paragonLevelRole.calcRoleAllAddingAttr();
		for (Entry<Integer, Float> entry : _effects.entrySet())
		{
			if (entry == null)
				continue;
			
			Sequipscore scoreCfg = ConfigManager.getInstance().getConf(Sequipscore.class).get(entry.getKey());
			if(scoreCfg == null)
				continue;
					
			power += Integer.parseInt(scoreCfg.getSuitscore().get(3)) * entry.getValue() / 100;
		}
		
		//时装评分
		power+=FashionManager.getInstance().getFashionTotalScore(roleId);
		
		//人气属性评分
		power+= ZoneManager.getInstance().getBuffScore(roleId);
		
		
		//神器评分
		power +=ShenQiManager.getShenQiScore(new ShenQiRole(roleId, true).calcAllProps());
		
		//熔炉 战力加成
		power +=ForgeManager.getInstance().getPowerByForge(new ForgeRole(roleId, true).calcAllProps());
		
		//装备觉醒加成
		power += new JueXingRole(roleId, true).getPower();
		
		//用兵核心符文战力加成
		
		power += MercenaryColumn.getMercenaryColumn(roleId, true).getAddRolePower();
		
		//佣兵阵位系统 战力加成
		power += new ZhenWeiSystemRole(roleId, true).getAddRolePower();
		
		//战魂系统 战力加成
		power += new FightSpiritRole(roleId, true).getAddRolePower();
		return power;
	}

	private static int calcEquipScoreTotal(long roleId) {
		Equip equip = new Equip(roleId, true);
		return equip.getEquipScoreTotal();
	}

	private static int increaseFightDragonScore(long roleId) {
		DragonColumn column = new DragonColumn(roleId, true);
		return column.scoreForRoleUp();
	}

	private static int increaseFightMercenaryScore(long roleId, int mercenaryFightType) {
		MercenaryColumn mc = MercenaryColumn.getMercenaryColumn(roleId, true);

		int result = 0;
		List<Integer> fighters = mc.getFightMercenaryIds(mercenaryFightType);
		if (fighters == null)
			return 0;

		for (Integer fighterid : fighters) {
			Mercenary mercenary = mc.getMercenaryByKey(fighterid);
			if (mercenary == null) {
				continue;
			}

			result += mercenary.getMercenaryInfo().getScore();
		}

		return result;
	}
	
	private static int increaseMercenaryAchievementPower(long roleId) {

		int result=0;
		Map<Integer, Float> attrs=MercenaryEffectProvider.calcMercenaryAchievementsAttrs(roleId);
		for(int attrid:attrs.keySet()){
			float attrvalue=attrs.get(attrid);
			SCombat sCombat=ConfigManager.getInstance().getConf(SCombat.class).get(attrid);
			if(sCombat==null){
				continue;
			}
			result+=(attrvalue*sCombat.weight)/100;
		}
		
		return result;
	}

	private static int toValue(ScriptEngine engine, String mathResult) {
		try {
			Object o = engine.eval(mathResult);
			if (o == null)
				return 0;
			if (o instanceof Double)
				return ((Double) o).intValue();
			if (o instanceof Integer)
				return (Integer) o;
		} catch (ScriptException e) {
			e.printStackTrace();
		}
		return 0;
	}

	private static List<Short> getSkillLevelTotal(long roleId) {
		List<Short> lvls = new ArrayList<Short>();
		
		Map<Integer, Short> lvmap = new HashMap<Integer, Short>();
		
		SkillRole skillRole = new SkillRole(roleId, true);
		xbean.SkillRole skillInfo = skillRole.getSrole();
		int schoolid = xtable.Properties.selectSchool(roleId);
		xbean.SchoolSkills skills = skillInfo.getSkills().get(SkillRole.getSkillDepartMentBySchool(schoolid));
		if (skills != null) {
			for (Map.Entry<Integer, xbean.SkillData> entery : skills.getNewskillinfo().entrySet()) {
				
				int skillid = SkillRole.getSkillId(schoolid, entery.getKey());
				lvmap.put(skillid, entery.getValue().getSkilllv());
			}
		}
		
		FashionManager.getInstance().attachPolishSKillLv(roleId, lvmap);
		
		lvls.addAll(lvmap.values());
		return lvls;
	}
	
}
