
package knight.gsp;

import knight.gsp.move.SChangeCamera;
import knight.gsp.scene.MapThreadProtocolParams;
import knight.gsp.scene.movable.Role;
import gnet.link.Onlines;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CSetCloseViewState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CSetCloseViewState extends __CSetCloseViewState__ {
	@Override
	protected void process() {
		final long roleId = Onlines.getInstance().findRoleid(this);
		if (roleId <= 0 || LocalIds.isRemoteServerRole(roleId))
			return;
		
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				xbean.Properties prop = xtable.Properties.get(roleId);
				if (prop == null)
					return false;
				
				if (newstate == 1) {
					prop.setOpencloseview(true);
				} else {
					prop.setOpencloseview(false);
				}
				
				GsClient.psend2RoleSceneWhileCommit(roleId, new xio.Protocol() {

					@Override
					public OctetsStream marshal(OctetsStream arg0) {
						return null;
					}

					@Override
					public OctetsStream unmarshal(OctetsStream arg0)
							throws MarshalException {
						return null;
					}

					@Override
					public int getType() {
						return 0;
					}

					@Override
					protected void process() {
						Role role = MapThreadProtocolParams.parseSceneRole(getSender());
						if (role == null)
							return;
						
						role.setOpenCloseView(newstate == 1);
						SChangeCamera snd = new SChangeCamera();
						if (role.openCloseView()) {
							snd.camera = role.getScene().getCameraCloseView(role);
						} else {
							snd.camera = role.getScene().getCamera(role);
						}
						snd.switchtime = 300;
						snd.backtodefault = 0;
						role.send(snd);
					}
					
				});
				
				xdb.Procedure.psendWhileCommit(roleId, new SSetCloseViewState((byte) (prop.getOpencloseview() ? 1 : 0)));
				
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786538;

	public int getType() {
		return 786538;
	}

	public byte newstate; // 0为关闭，1为打开

	public CSetCloseViewState() {
	}

	public CSetCloseViewState(byte _newstate_) {
		this.newstate = _newstate_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(newstate);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		newstate = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CSetCloseViewState) {
			CSetCloseViewState _o_ = (CSetCloseViewState)_o1_;
			if (newstate != _o_.newstate) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)newstate;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(newstate).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CSetCloseViewState _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = newstate - _o_.newstate;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

