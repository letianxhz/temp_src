package knight.gsp;

import xdb.Transaction;
import knight.gsp.scene.CreateSceneParams;
import knight.gsp.scene.GCreateDynamicSceneSignal;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.ICreateSceneCondition;
import knight.gsp.scene.MapThread;
import knight.gsp.scene.MapThreadManager;

/**
 * 逻辑上创建动态场景的类
 * 
 * @author yangzhenyu
 * 
 * @date 2015-9-16 下午2:00:03
 * 
 */
public class LogicalSceneEntry {

	/**
	 * 尝试创建一个动态场景
	 * 
	 * @param mapId 动态场景的地图id
	 * @param arg 相关参数.存活时间，场景空时是否销毁，以及其他自定义的参数等.没有则传null
	 * @param callback 场景创建成功之后的回调，可以初始化副本相关的，例如刷怪，NPC等.没有则传null
	 * @param cond 创建动态场景的预判，如果cond没判断听过，则不会创建场景.没有则传null
	 */
	public static void createDynamicScene(int mapId, CreateSceneParams arg, ICreateSceneCallback callback, ICreateSceneCondition cond) {
		MapThread mapThread = MapThreadManager.getInstance().getNextAvailableThread();
		
		GCreateDynamicSceneSignal signal = new GCreateDynamicSceneSignal();
		signal.arg = arg;
		signal.callback = callback;
		signal.preCondition = cond;
		signal.mapId = mapId;
		signal.mapThread = mapThread;
		
		if (Transaction.current() != null)
			xdb.Procedure.psendWhileCommit(mapThread.getThreadIndex(), signal);
		else
			mapThread.add(signal);
	}
}
