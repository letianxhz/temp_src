
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SRefreshPhy__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SRefreshPhy extends __SRefreshPhy__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786510;

	public int getType() {
		return 786510;
	}

	public int phy; // 当前体力，-1：无意义
	public int phymax; // 当前体力上限，-1：无意义

	public SRefreshPhy() {
		phy = -1;
		phymax = -1;
	}

	public SRefreshPhy(int _phy_, int _phymax_) {
		this.phy = _phy_;
		this.phymax = _phymax_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(phy);
		_os_.marshal(phymax);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		phy = _os_.unmarshal_int();
		phymax = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SRefreshPhy) {
			SRefreshPhy _o_ = (SRefreshPhy)_o1_;
			if (phy != _o_.phy) return false;
			if (phymax != _o_.phymax) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += phy;
		_h_ += phymax;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(phy).append(",");
		_sb_.append(phymax).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SRefreshPhy _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = phy - _o_.phy;
		if (0 != _c_) return _c_;
		_c_ = phymax - _o_.phymax;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

