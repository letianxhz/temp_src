
package knight.gsp;
import java.util.HashMap;
import java.util.Map;
import knight.gsp.StateCommon.UserLoginInfo;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CNotifyDeviceInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CNotifyDeviceInfo extends __CNotifyDeviceInfo__ {
	@Override
	protected void process() {
		final int userid = ((gnet.link.Dispatch) this.getContext()).userid;
		if (userid <= 0) {
			return;
		}

		// protocol handle
		new xdb.Procedure(){
			@Override
			public boolean process(){
				xbean.AUUserInfo userinfo = xtable.Auuserinfo.get(userid);
				Map<Integer, String> machineInfos = new HashMap<Integer, String>();
				for (UserInfoUnit uiu : info) {
					machineInfos.put(uiu.key, uiu.value);
				}
				
				String mac = "";
				String idfa = "";
				String udid = "";
				String model = "";
				String systemVersion="";
				String resolution="";
				if (userinfo != null){
					mac = machineInfos.get(UserInfoEnum.CLIENT_MAC);
					userinfo.setMac(mac == null ? "" : mac);
					udid = machineInfos.get(UserInfoEnum.CLIENT_UDID);
					userinfo.setUdid(udid == null ? "" : udid);
					idfa = machineInfos.get(UserInfoEnum.CLIENT_IDFA);
					userinfo.setIdfa(idfa == null ? "" : idfa);
					model = machineInfos.get(UserInfoEnum.MODEL);
					userinfo.setModel(model == null ? "0" : model);
					String systemType = machineInfos.get(UserInfoEnum.SYSTEM_TYPE);
					userinfo.setSystemtype(systemType == null ? 0 : Short.parseShort(systemType));
					systemVersion = machineInfos.get(UserInfoEnum.SYSTEM_VERSION);
					userinfo.setSystemversion(systemVersion == null ? "0" : systemVersion);
					resolution = machineInfos.get(UserInfoEnum.RESOLUTION);
					userinfo.setResolution(resolution == null ? "0" : resolution);
					String cpuName = machineInfos.get(UserInfoEnum.CPU_NAME);
					userinfo.setCpuname(cpuName == null ? "0" : cpuName);
					String cpuMaxFraq = machineInfos.get(UserInfoEnum.CPU_MAX_FRAQ);
					userinfo.setCpumaxfraq(cpuMaxFraq == null ? "0" : cpuMaxFraq);
					String cpuCount = machineInfos.get(UserInfoEnum.CPU_COUNT);
					userinfo.setCpucount(cpuCount == null ? 0 : Short.parseShort(cpuCount));
					String clientSource = machineInfos.get(UserInfoEnum.CLIENT_SOURCE);
					userinfo.setClientsource(clientSource == null ? "" : clientSource);
					String phoneNum = machineInfos.get(UserInfoEnum.PHONE_NUM);
					userinfo.setPhonenum(phoneNum == null ? 0 : Long.parseLong(phoneNum));
					String gprsInfo = machineInfos.get(UserInfoEnum.GPRSINFO);
					userinfo.setGprsimfo(gprsInfo == null ? "0" : gprsInfo);
//					String accessPoint = machineInfos.get(UserInfoEnum.ACCESS_POINT);
//					userinfo.setAccesspoint(accessPoint == null ? "" : accessPoint);
					String totalMemSize = machineInfos.get(UserInfoEnum.TOTAL_MEM_SIZE);
					userinfo.setTotalmemsize(totalMemSize == null ? 0 : Integer.parseInt(totalMemSize));
					String clientVersion = machineInfos.get(UserInfoEnum.CLIENT_VERSION);
					userinfo.setClientversion(clientVersion == null ? "0" : clientVersion);
				}
				
				UserLoginInfo userLoginInfo = StateCommon.userLoginInfo.get(userid);
				if (userLoginInfo == null) {
					userLoginInfo = new UserLoginInfo();
					StateCommon.userLoginInfo.put(userid, userLoginInfo);
				}
				userLoginInfo.idfa = idfa == null ? "" : idfa;
				userLoginInfo.mac = mac == null ? "" : mac;
				userLoginInfo.udid = udid == null ? "" : udid;
				
				//新增字段 机型、分辨率、系统版本、联网方式、运营商字段
				userLoginInfo.model = null== model ? "0" : model;
				userLoginInfo.resolution = null == resolution ? "0" : resolution;
				userLoginInfo.systemVersion = null == systemVersion ? "0" : systemVersion;
				String networkingMode = machineInfos.get(UserInfoEnum.NETWORKING_MODE);
				userLoginInfo.networkingMode = null ==  networkingMode? "" : networkingMode;
				String operatorField = machineInfos.get(UserInfoEnum.OPERATOR_FIELD);
				userLoginInfo.operatorField = null ==  operatorField? "" : operatorField;
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786487;

	public int getType() {
		return 786487;
	}

	public java.util.ArrayList<knight.gsp.UserInfoUnit> info;

	public CNotifyDeviceInfo() {
		info = new java.util.ArrayList<knight.gsp.UserInfoUnit>();
	}

	public CNotifyDeviceInfo(java.util.ArrayList<knight.gsp.UserInfoUnit> _info_) {
		this.info = _info_;
	}

	public final boolean _validator_() {
		for (knight.gsp.UserInfoUnit _v_ : info)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(info.size());
		for (knight.gsp.UserInfoUnit _v_ : info) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			knight.gsp.UserInfoUnit _v_ = new knight.gsp.UserInfoUnit();
			_v_.unmarshal(_os_);
			info.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CNotifyDeviceInfo) {
			CNotifyDeviceInfo _o_ = (CNotifyDeviceInfo)_o1_;
			if (!info.equals(_o_.info)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += info.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(info).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

