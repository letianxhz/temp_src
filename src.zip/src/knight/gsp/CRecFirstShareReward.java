
package knight.gsp;

import knight.gsp.PAddExpProc.EXP_TYPE;
import knight.gsp.award.AwardManager;
import knight.gsp.game.Sweixinpeizhi;
import knight.gsp.main.ConfigManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CRecFirstShareReward__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CRecFirstShareReward extends __CRecFirstShareReward__ {
	@Override
	protected void process() {
		// protocol handle
		final long roleId = gnet.link.Onlines.getInstance().findRoleid(this);
		if(roleId <= 0 || LocalIds.isRemoteServerRole(roleId))
			return;
		/*new xdb.Procedure() {
			@Override
			protected boolean process() throws Exception {
				//TODO 发放奖励
				xbean.Properties prop = xtable.Properties.get(roleId);
				if(prop.getWeixinsharestatus() == 0){
					knight.gsp.msg.Message.sendMsgNotify(roleId, 1039412);
					return false;
				}else if(prop.getWeixinsharestatus() == 2){
					//已经过今日分享奖励
					return false;
				}
				Sweixinpeizhi config = ConfigManager.getInstance().getConf(Sweixinpeizhi.class).get(1);
				AwardManager.getInstance().distributeAllAward(roleId, Integer.valueOf(config.getAwardid()), null, EXP_TYPE.WEIXIN_FIRSTSHARE, 0, "微信分享", false, true, true, true);
				
				prop.setWeixinsharestatus((short)2);
				
				SFirstShare send = new SFirstShare(firstsharetype,prop.getWeixinsharestatus());
				
				xdb.Procedure.psendWhileCommit(roleId, send);
				
				return true;
			}
		}.submit();*/
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786546;

	public int getType() {
		return 786546;
	}

	public final static int WEI_BO = 1; // 微博
	public final static int WEI_XIN = 2; // 微信

	public short firstsharetype; // 首次分享

	public CRecFirstShareReward() {
	}

	public CRecFirstShareReward(short _firstsharetype_) {
		this.firstsharetype = _firstsharetype_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(firstsharetype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		firstsharetype = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CRecFirstShareReward) {
			CRecFirstShareReward _o_ = (CRecFirstShareReward)_o1_;
			if (firstsharetype != _o_.firstsharetype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += firstsharetype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(firstsharetype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CRecFirstShareReward _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = firstsharetype - _o_.firstsharetype;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

