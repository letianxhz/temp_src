
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SServerOpenTime__ extends xio.Protocol { }

/** 给客户端发送开服时间，时间格式：yyyyMMddHHmmss
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SServerOpenTime extends __SServerOpenTime__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786503;

	public int getType() {
		return 786503;
	}

	public int zoneid; // 游戏服zoneId
	public long opentime; // 开服时间：时间格式：yyyyMMddHHmmss

	public SServerOpenTime() {
	}

	public SServerOpenTime(int _zoneid_, long _opentime_) {
		this.zoneid = _zoneid_;
		this.opentime = _opentime_;
	}

	public final boolean _validator_() {
		if (zoneid < 1) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(opentime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_int();
		opentime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SServerOpenTime) {
			SServerOpenTime _o_ = (SServerOpenTime)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (opentime != _o_.opentime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += zoneid;
		_h_ += (int)opentime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(opentime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SServerOpenTime _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(opentime - _o_.opentime);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

