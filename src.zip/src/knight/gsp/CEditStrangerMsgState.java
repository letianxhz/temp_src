
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CEditStrangerMsgState__ extends xio.Protocol { }

/** 系统设置
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CEditStrangerMsgState extends __CEditStrangerMsgState__ {
	@Override
	protected void process() {
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if (roleid < 0)
			return;
		
		knight.gsp.memory.RoleInMemoryManager manager = knight.gsp.memory.RoleInMemoryManager.getInstance();
		knight.gsp.memory.RoleInMemory roleInMemory = manager.getRoleInMemoryByID(roleid);
		if(roleInMemory == null) {
			roleInMemory = new knight.gsp.memory.RoleInMemory(roleid);
			manager.addRoleInMemory(roleInMemory);
		}
		roleInMemory.setStrangerMsgState(strangermsgstate);
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786463;

	public int getType() {
		return 786463;
	}

	public short strangermsgstate; // 陌生人消息设置 1接受 0拒绝

	public CEditStrangerMsgState() {
	}

	public CEditStrangerMsgState(short _strangermsgstate_) {
		this.strangermsgstate = _strangermsgstate_;
	}

	public final boolean _validator_() {
		if (strangermsgstate < 0 || strangermsgstate > 1) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(strangermsgstate);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		strangermsgstate = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CEditStrangerMsgState) {
			CEditStrangerMsgState _o_ = (CEditStrangerMsgState)_o1_;
			if (strangermsgstate != _o_.strangermsgstate) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += strangermsgstate;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(strangermsgstate).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CEditStrangerMsgState _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = strangermsgstate - _o_.strangermsgstate;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

