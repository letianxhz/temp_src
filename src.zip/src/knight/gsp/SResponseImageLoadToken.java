
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SResponseImageLoadToken__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SResponseImageLoadToken extends __SResponseImageLoadToken__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786533;

	public int getType() {
		return 786533;
	}

	public java.lang.String token;
	public java.lang.String filename;
	public int costmoney;

	public SResponseImageLoadToken() {
		token = "";
		filename = "";
	}

	public SResponseImageLoadToken(java.lang.String _token_, java.lang.String _filename_, int _costmoney_) {
		this.token = _token_;
		this.filename = _filename_;
		this.costmoney = _costmoney_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(token, "UTF-16LE");
		_os_.marshal(filename, "UTF-16LE");
		_os_.marshal(costmoney);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		token = _os_.unmarshal_String("UTF-16LE");
		filename = _os_.unmarshal_String("UTF-16LE");
		costmoney = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SResponseImageLoadToken) {
			SResponseImageLoadToken _o_ = (SResponseImageLoadToken)_o1_;
			if (!token.equals(_o_.token)) return false;
			if (!filename.equals(_o_.filename)) return false;
			if (costmoney != _o_.costmoney) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += token.hashCode();
		_h_ += filename.hashCode();
		_h_ += costmoney;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(token.length()).append(",");
		_sb_.append("T").append(filename.length()).append(",");
		_sb_.append(costmoney).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

