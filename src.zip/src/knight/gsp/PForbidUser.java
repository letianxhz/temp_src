/**
 * Class: PForbidUser.java
 * Package: knight.gsp
 *
 *
 *   ver     date      		author
 * ──────────────────────────────────
 *   		 2011-10-10 		yesheng
 *
 * Copyright (c) 2011, Perfect World All Rights Reserved.
 */

package knight.gsp;

import gnet.link.Onlines;
import gnet.link.User;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import knight.gsp.log.LogManager;
import knight.gsp.log.LogUtil;
import knight.gsp.log.RemoteLogParam;
import knight.gsp.msg.Message;
import knight.gsp.util.EncodeBase64;

import org.apache.log4j.Logger;

import xdb.Procedure;


/**
 * ClassName:PForbidUser Function: ADD FUNCTION HERE
 * 
 * @author yesheng
 * @version
 * @since
 * @Date 2011-10-10 下午03:58:52
 * 
 * @see
 */
public class PForbidUser extends Procedure {
	
	private static Map<Integer, Integer> extraProbMap = new ConcurrentHashMap<Integer, Integer>();
	
	private final int dstuserid;

	private final int gmuserid;

	@SuppressWarnings("unused")
	private final int gmlocalsid;

	private int forbid_time;// min

	private String reason;
	
	private int kickoutReason;

	private final boolean auForbid; // true 为发给au封禁,否则gs封禁
	
	static Logger logger = Logger.getLogger(PForbidUser.class);

	public PForbidUser(int dstuserid, int gmuserid, int gmlocalsid, int forbid_time, String reason, boolean auForbid,int kickoutReason) {

		super();
		this.dstuserid = dstuserid;
		this.gmlocalsid = gmlocalsid;
		this.gmuserid = gmuserid;
		this.forbid_time = forbid_time;
		this.reason = reason;
		this.kickoutReason = kickoutReason;
		this.auForbid = auForbid;
	}

	@Override
	protected boolean process() throws Exception {

		xbean.User user = xtable.User.select(dstuserid);
		if (user == null){
			logger.error("forbid failed.dstuserid didn't exist.dstuserid:"+dstuserid);
			return false;
		}
		final long roleid = user.getPrevloginroleid();
		xbean.UserPunish userpunish = xtable.Userpunish.get(dstuserid);
		if (userpunish == null) {
			userpunish = xbean.Pod.newUserPunish();
			xtable.Userpunish.insert(dstuserid, userpunish);
		}
		if (forbid_time == -5){//-5表示增加这个账号的反外挂几率
			Integer value = extraProbMap.get(dstuserid);
			if (value == null)
				extraProbMap.put(dstuserid, 1);
			else
				extraProbMap.put(dstuserid, value+1);
			return true;
		}
		kickoutReason = KickErrConst.ERR_FORBID_USER;
		if (forbid_time == -1){
			kickoutReason = KickErrConst.ERR_GACD_KICKOUT;
		}
		if (forbid_time == -2){//因为使用外挂被封禁
			userpunish.setWaiguatimes(userpunish.getWaiguatimes()+1);
			userpunish.setSendmsgtime(0);
			kickoutReason = KickErrConst.ERR_GACD_WAIGUA;
			if (userpunish.getWaiguatimes() == 1){
				forbid_time = 10;
				//reason = new Octets("你因第1次使用外挂类程序被踢下线，第2次使用将会被封停24小时，请珍惜自己的账号！".getBytes("UTF-16LE"));
			}else if (userpunish.getWaiguatimes()==2){
				forbid_time = 1440;//day
				//reason = new Octets("你因第2次使用外挂类程序被封停24小时，第3次使用将会被封停7天，请珍惜自己的账号！".getBytes("UTF-16LE"));
			}
			else if (userpunish.getWaiguatimes() == 3) {
				forbid_time = 10080;//week
				//reason = new Octets("你因第3次使用外挂类程序被封停7天！第4次使用将会被永久封停！请悬崖勒马，珍惜自己的账号及好友！！".getBytes("UTF-16LE"));
			}else {
				forbid_time = 5256000;//10 years
				//reason = new Octets("我们很遗憾的通知，你因累计使用4次外挂类程序被永久封停。如有疑问请联系客服。".getBytes("UTF-16LE"));
			}
		}
		if (forbid_time < 0){//小于0的情况使用我们自己的提示消息 
			Onlines.getInstance().kick(roleid, kickoutReason);
			User linkuser = Onlines.getInstance().getOnlineUsers().get(dstuserid);
			if (linkuser != null) {
				linkuser.kick(-1000);
			}
		}
		else {//否则使用发过来的提示消息
			if (reason == null)
				reason = "";
			Message.sendPopRole(roleid, reason);
//			Onlines.getInstance().send(roleid, new SGACDKickoutMsg1(reason));
			xdb.Executor.getInstance().schedule(new Runnable(){

				@Override
				public void run() {
					Onlines.getInstance().kick(roleid, -1000);
					User linkuser = Onlines.getInstance().getOnlineUsers().get(dstuserid);
					if (linkuser != null) {
						linkuser.kick(-1000);
					}
				}
				
			}, 5, TimeUnit.SECONDS);
			
		}
		if (forbid_time < 0)
			forbid_time = 0;
		if (auForbid) {
//			final gnet.GMKickoutUser send = new gnet.GMKickoutUser(gmuserid, gmlocalsid, dstuserid, forbid_time * 60,reason);
//			gnet.DeliveryManager.getInstance().send(send);
		}
		xbean.PunishRecord record = xbean.Pod.newPunishRecord();
		record.setGmuserid(gmuserid);
		record.setForbidtime(forbid_time * 60 * 1000L);
		record.setOptime(System.currentTimeMillis());
		record.setReason(reason);
		record.setRoleid(0);
		record.setType(xbean.PunishRecord.TYPE_FORBID_LOGIN);
		record.setUserid(dstuserid);
		userpunish.getRecords().add(record);
		//if (gmuserid == GACDManager.GM_ID && kickoutReason == KickErrConst.ERR_GACD_PUNISH)//只有gacd封单服的时候才用到releasetime,其他封禁不需要这个参数 
		if(!auForbid)//只有封单服时才保存时间   
			userpunish.setReleasetime(record.getOptime() + record.getForbidtime());
		//long now = System.currentTimeMillis();
		try {
			logger.info("forbid user.gmuserid:"+gmuserid+"userid:"+dstuserid+"time:"+forbid_time+reason);
			Map<String, Object> param = new HashMap<String, Object>();
			LogUtil.putRoleBasicInfo(roleid, param);
			param.put(RemoteLogParam.GMUSERID, gmuserid);
//			param.put(RemoteLogParam.FORBID_TIME, forbid_time);
			param.put(RemoteLogParam.REASON, new String(EncodeBase64.transform(reason.getBytes())));
			int kickoutType = 0;
			if (kickoutReason == KickErrConst.ERR_GACD_PUNISH) 
				kickoutType = 1;
			else if (kickoutReason == KickErrConst.ERR_GACD_WAIGUA) {
				kickoutType = 2;
			}else if (kickoutReason == KickErrConst.ERR_GM_KICKOUT) {
				kickoutType = 4;
			}else {
				kickoutType = 3;
			}
			param.put(RemoteLogParam.TYPE, kickoutType);
//			LogManager.getInstance().doLogWhileCommit(RemoteLogID.FORBIDUSER_LOCK, param);
		} catch (Exception e) {
			LogManager.logger.error(e);
		}
		return true;
	}

	public static int getExtraProb(int userid){
		if (extraProbMap.containsKey(userid)) 
			return extraProbMap.get(userid);
		return 0;
	}
}
