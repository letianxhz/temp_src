
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CEditGameMode__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CEditGameMode extends __CEditGameMode__ {
	@Override
	protected void process() {
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if (roleid < 0) {
			return;
		}
		knight.gsp.memory.RoleInMemoryManager manager = knight.gsp.memory.RoleInMemoryManager.getInstance();
		knight.gsp.memory.RoleInMemory roleInMemory = manager.getRoleInMemoryByID(roleid);
		if(roleInMemory == null) {
			roleInMemory = new knight.gsp.memory.RoleInMemory(roleid);
			manager.addRoleInMemory(roleInMemory);
		}
		roleInMemory.setGameMode(mode);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786466;

	public int getType() {
		return 786466;
	}

	public final static int PERFECT = 1; // 完美
	public final static int MIDDLE = 2; // 省电
	public final static int POOR = 3; // 极限省电

	public short mode; // 游戏模式

	public CEditGameMode() {
	}

	public CEditGameMode(short _mode_) {
		this.mode = _mode_;
	}

	public final boolean _validator_() {
		if (mode < 1 || mode > 3) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(mode);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		mode = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CEditGameMode) {
			CEditGameMode _o_ = (CEditGameMode)_o1_;
			if (mode != _o_.mode) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += mode;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(mode).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CEditGameMode _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = mode - _o_.mode;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

