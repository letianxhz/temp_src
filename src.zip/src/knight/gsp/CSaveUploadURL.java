
package knight.gsp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import knight.gsp.game.Sspecialpara;
import knight.gsp.log.LogUtil.MONEY_TYPE;
import knight.gsp.main.ConfigManager;
import knight.gsp.msg.Message;
import knight.gsp.util.GameProp;
import knight.gsp.util.QiniuSDKUtil;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CSaveUploadURL__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CSaveUploadURL extends __CSaveUploadURL__ {
	@Override
	protected void process() {
		// protocol handle
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if(roleid <= 0)
			return;
		
		final int freenum=getFreenumForImageUpload(roleid);
		
		final int costMoney = getCostMoneyForImageUpload(roleid);
		if(costMoney < 0){
			xdb.Trace.error("get image upload cost error...");
			return;
		}
		
		try {
			if(!new xdb.Procedure(){
				@Override
				protected boolean process() throws Exception {
					xbean.HeadImageInfo properties=xtable.Headimageinfo.get(roleid);
					if(freenum>0){
						Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(268);
						
						int killCount=properties.getHeadimagekillcount();
						killCount=killCount-cfg.para3;
						if(killCount<0){
							killCount=0;
						}
						
						properties.setHeadimagekillcount(killCount);
						SOpenImageLoadPanel sOpenImageLoadPanel=new SOpenImageLoadPanel(1, getFreenumForImageUpload(roleid));
						psendWhileCommit(roleid, sOpenImageLoadPanel);
						
						Message.psendMsgNotifyWhileCommit(roleid, 1039106,Arrays.asList(1+""));
					}else{
						knight.gsp.item.Bag bag = new knight.gsp.item.Bag(roleid, false);
						if (-costMoney != bag.subMoney(-costMoney, MONEY_TYPE.EXT, "上传头像")) {
							return false;
						}
						List<String> param = new ArrayList<String>();
						param.add(String.valueOf(costMoney));
						Message.psendMsgNotifyWhileCommit(roleid, 1038324, param);
						properties.getUploadcost().put(properties.getHeadimagedownloadcounter(), costMoney);
					}
					
					properties.setLastuploadtime(System.currentTimeMillis());
					
					return true;
				}
			}.submit().get().isSuccess()){
				return;
			}
		} catch (Exception e) {
			xdb.Trace.error("image upload cost error...");
			return;
		} 
		
		
		xdb.Executor.getInstance().schedule(new Thread(new Runnable() {
			@Override
			public void run(){
				int needCheckPorn = GameProp.getIntValue(ConfigManager.getInstance().getPropConf("sys"), "sys.net.needcheckporn");
				if(needCheckPorn == 0){
					new xdb.Procedure(){
						@Override
						public boolean process(){
							xbean.HeadImageInfo prop = xtable.Headimageinfo.get(roleid);
							if(prop == null)
								return true;
							
							int counter = prop.getHeadimagedownloadcounter();
							prop.setHeadimagedownloadcounter(counter+1);
							prop.setHeadimagefilepath(QiniuSDKUtil.getFilePathByRoleid(roleid));
							prop.getUploadcost().remove(Integer.valueOf(counter));
							
							SDownLoadloadURL loadURL = new SDownLoadloadURL();
							loadURL.imageurl = knight.gsp.main.ConfigManager.getImageDownloadUrlByDomain(prop.getHeadimagefilepath());
							loadURL.downloadcounter = prop.getHeadimagedownloadcounter();
							
							xdb.Procedure.psendWhileCommit(roleid, loadURL);
							
							return true;
						}
					}.submit();
				}else{
					QiniuSDKUtil.httpCheckPorn(roleid);
				}
			}
		}), 1, java.util.concurrent.TimeUnit.MINUTES);
		
	}
	
	public static int getCostMoneyForImageUpload(long roleid) {
		Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(268);
		if (cfg == null)
			return -1;
		
		if(knight.gsp.camp.Module.getCampTitle(roleid) > 0){
			return cfg.para2;
		}
		
		return cfg.para1;
	}
	
	public static int getFreenumForImageUpload(long roleid) {
		Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(268);
		if (cfg == null)
			return -1;
		
		Integer killcount=xtable.Headimageinfo.selectHeadimagekillcount(roleid);
		if(null == killcount)
			return 0;
		
		return killcount/cfg.para3;
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786534;

	public int getType() {
		return 786534;
	}


	public CSaveUploadURL() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CSaveUploadURL) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CSaveUploadURL _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

