package knight.gsp;

/**
 * 
 * @author yuhongyong
 * @date Mar 20, 2016 12:58:33 AM
 */
public class AddExpResult
{
	public long roleExp = 0;
	public long paragonExp = 0;
}
