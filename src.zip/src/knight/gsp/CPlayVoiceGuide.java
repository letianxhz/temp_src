
package knight.gsp;

import knight.gsp.main.ServerInfoProvider;
import global.rsp.GlobalClientManager;
import global.rsp.fuben.NotifyPlayVoiceGuide;
import gnet.link.Onlines;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CPlayVoiceGuide__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CPlayVoiceGuide extends __CPlayVoiceGuide__ {
	@Override
	protected void process() {
		final long roleId = Onlines.getInstance().findRoleid(this);
		if (roleId <= 0)
			return;
		else if (LocalIds.isRemoteServerRole(roleId)) {
			int dstServerId = ServerInfoProvider.roleid2zoneid(roleId);
			GlobalClientManager.getInstance().send(dstServerId, new NotifyPlayVoiceGuide(roleId, (byte)voiceid));
			return;
		}
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				xbean.VoiceGuideRole vgr = xtable.Voiceguiderole.get(roleId);
				if (vgr == null) {
					vgr = xbean.Pod.newVoiceGuideRole();
					xtable.Voiceguiderole.insert(roleId, vgr);
				}
				
				vgr.getGuidedvoices().add((short) voiceid);
				
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786542;

	public int getType() {
		return 786542;
	}

	public final static int DISCOUNT = 1; // 最低折扣语音引导
	public final static int SEVEN_DAY_GIFT = 2; // 引导七日好礼
	public final static int SAO_DANG_GUIDE = 3; // 引导扫荡
	public final static int CAMP_TASK = 4; // 阵营任务
	public final static int TREASURE_GUIDE = 5; // 藏宝图
	public final static int FIRST_CI_TAN = 6; // 刺探任务 获得第一个情报时
	public final static int LIN_YE_FENG_HUO_EVERY_DAY = 7; // 凛夜烽火 每天第一次进入 11111
	public final static int FIRST_QI_ZUI = 8; // 七罪副本 第一次进入副本
	public final static int FIRST_LIE_MO = 9; // 猎魔任务 第一次进入战斗
	public final static int ZHUAN_ZHI = 10; // 转职任务 25级进阶成功后
	public final static int ENTER_XIN_BING_SHI_LIAN_ENTER_FUBEN = 11; // 新兵上阵 进入新兵试炼地图后
	public final static int ENTER_XIN_BING_SHANG_ZHEN_PASS_FUBEN = 12; // 新兵上证 新兵上阵副本胜利后
	public final static int ENTER_XIN_BING_SHANG_ZHEN_COMMIT_TASK = 13; // 新兵上证 新兵上阵副本胜利后
	public final static int FAMILY_GATHER_EVERYDAY = 14; // 家族采集 每天第一次进入王者之地 11111
	public final static int FAMILY_BATTLE_EVERYDAY = 15; // 家族战 每天第一次进入家族战地图 11111
	public final static int PVP8_EVERYDAY = 16; // 家族战 每天第一次进入家族战地图 111111
	public final static int APOLLO_FIGHT = 17; // 太阳神 每天第一次进入太阳神战斗 111111

	public byte voiceid; // 语音引导的id

	public CPlayVoiceGuide() {
	}

	public CPlayVoiceGuide(byte _voiceid_) {
		this.voiceid = _voiceid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(voiceid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		voiceid = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CPlayVoiceGuide) {
			CPlayVoiceGuide _o_ = (CPlayVoiceGuide)_o1_;
			if (voiceid != _o_.voiceid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)voiceid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(voiceid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CPlayVoiceGuide _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = voiceid - _o_.voiceid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

