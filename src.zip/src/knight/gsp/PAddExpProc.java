package knight.gsp;

import global.rsp.GlobalClientManager;
import global.rsp.team.RefreshLevelInGlobalTeam;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;

import knight.gsp.event.CouldAddParagonExpEvent;
import knight.gsp.game.SServerLevelConfig;
import knight.gsp.game.Sspecialpara;
import knight.gsp.game.dailyexpmax;
import knight.gsp.log.ExpLogHelper;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.msg.Message;
import knight.gsp.paragonlevel.PAddExp;
import knight.gsp.role.SNextExp;
import knight.gsp.team.SRefreshTeamMemberLevel;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;
import knight.gsp.util.DateValidate;

import org.apache.log4j.Logger;

import xbean.TeamMember;
import xdb.Procedure;

/**
 * 经验增加或减少的处理逻辑
 * <li>经验增加，经验只保留最大级别所需经验数的倍数（此倍数可配置），多余量去掉
 * <li>经验减少，最多只能将当前级别的经验减到0，但不会降级
 * @author yuhongyong
 */
public class PAddExpProc extends Procedure
{
	private static final Logger	LOG = Logger.getLogger(PAddExpProc.class);
	
	/**
	 * 人物当前经验上限
	 */
	public final static long ROLE_MAX_CUREXP = 50000000000l;

	/**
	 * 人物总经验上限
	 */
	public final static long ROLE_MAX_ALLEXP = 99999999999L;

	/**	角色ID和要增加的经验 */
	long roleid,addExp;

	EXP_TYPE type;

	String reason;

	/** 是否显示获得经验提示 */
	private boolean showMsg = true;
	/** 是否显示经验已达上限无法获得的提示 */
	private boolean showOverflowMsg = true;
	
	//服务器等级经验加成
	public boolean serverLvExpAdd = false;
	
	public int serverLvAddExp = 0;
	
	public long initadd = 0;
	
	public long curExpOld = 0;
	
	public SServerLv serverLvAddExpInfo = null;
	
	public long reallyAddExp = 0;
	
	public boolean shouldPopExpMsg = true;
	
	public PAddExpProc(long roleid, long addExp, EXP_TYPE type, String reason)
	{
		this.roleid = roleid;
		this.addExp = addExp;
		this.type = type;
		this.reason = reason;
	}
	
	public PAddExpProc(long roleid, long addExp, EXP_TYPE type, String reason, boolean showMsg)
	{
		this.roleid = roleid;
		this.addExp = addExp;
		this.type = type;
		this.reason = reason;
		this.showMsg = showMsg;
	}
	
	public PAddExpProc(long roleid, long addExp, EXP_TYPE type, String reason, boolean showMsg, boolean showOverflowMsg)
	{
		this.roleid = roleid;
		this.addExp = addExp;
		this.type = type;
		this.reason = reason;
		this.showMsg = showMsg;
		this.showOverflowMsg = showOverflowMsg;
	}

	public void setServerLvExpAdd() {
		this.serverLvExpAdd = true;
	}
	
	@Override
	public boolean process()
	{
		if (addExp == 0) return false;

		final xbean.Properties prop = xtable.Properties.get(roleid);
		if (null == prop) return false;
		final long curExp_old = prop.getExp();
		curExpOld = curExp_old;
		int level = prop.getLevel();
		final int oldLevel = level;
		int maxLevel = PLevelUpProc.getMaxLevel();
		
		SNextExp levelExpCfg = ConfigManager.getInstance().getConf(SNextExp.class).get(level);
		if (levelExpCfg == null)
		{
			LOG.error("配置错误：无法获取级别-"+level+"所需经验配置");
			return false;
		}
		
		if (serverLvExpAdd && addExp > 0) {
			//服务器经验加成
			serverLvAddExpInfo = getServerExpAddInfo(roleid, Calendar.getInstance().getTimeInMillis());
			if (serverLvAddExpInfo != null) {
				//要上取整
				serverLvAddExp = (int) (Math.ceil(0.01f*addExp*serverLvAddExpInfo.exppct));
				addExp += serverLvAddExp;
			}
		}
		
		SNextExp maxLevelExpCfg = ConfigManager.getInstance().getConf(SNextExp.class).get(maxLevel);
		int factor = getStoredExpFactor();
		// 增加巅峰等级经验，巅峰经验目前没有减少的功能需求
		if (level >= maxLevel && addExp > 0)
		{
			// 注：巅峰等级经验的增加应该和人物经验互不影响，所以这里必须用pexecute
			CouldAddParagonExpEvent event = new CouldAddParagonExpEvent(roleid, addExp, type);
			knight.gsp.event.Poster.getPoster().dispatchEvent(event);
			/*	级别达到级别上限时，经验只保留最大级别所需经验数的倍数（此倍数可配置），多余量去掉	*/
			if(!canAddExp(roleid, level, curExp_old, maxLevelExpCfg, factor)){
				return new PAddExp(roleid, addExp, type, shouldPopExpMsg).call();
			}else{
				xdb.Procedure.pexecuteWhileCommit(new PAddExp(roleid, addExp, type, shouldPopExpMsg));
			}
		}	
		
		/*	防止溢出	*/
		long curExp_new = Math.min(Long.MAX_VALUE , (curExp_old + addExp));
		initadd = curExp_new;
		curExp_new = Math.max(0, curExp_new);// 防止当前级别经验为负数
		
		reallyAddExp = Math.max(0, curExp_new - curExp_old);
		
		if (reallyAddExp > 0) {
			//是获得经验
			xbean.GainLimitRole gainLimitRole = xtable.Gainlimitroles.get(roleid);
			if (gainLimitRole == null) {
				gainLimitRole = xbean.Pod.newGainLimitRole();
				xtable.Gainlimitroles.insert(roleid, gainLimitRole);
			}
			long now = System.currentTimeMillis();
			if (!DateValidate.inTheSameDay(now, gainLimitRole.getLastresettime())) {
				gainLimitRole.setLastresettime(now);
				gainLimitRole.setTodayaddexp(0L);
				gainLimitRole.getTodayaddyb().clear();
				gainLimitRole.getTodayawardids().clear();
				gainLimitRole.getTodaylibaouse().clear();
			}
			
			dailyexpmax lvExpLimitCfg = ConfigManager.getInstance().getConf(dailyexpmax.class).get(level);
			if (lvExpLimitCfg != null && ConfigManager.getInstance().getConf(Sspecialpara.class).get(388).para1 == 1) {
				if (gainLimitRole.getTodayaddexp() >= lvExpLimitCfg.expmax) {
					//今日获得经验已经达到上限
					Message.psendMsgNotify(roleid, 1030200, null);
					knight.gsp.log.Module.logger.error("roleId=" + roleid + "获得经验时，超出每日上限.alreadyGain=" + gainLimitRole.getTodayaddexp() + ",limit=" + lvExpLimitCfg.expmax);
					return false;
				}
			}

			gainLimitRole.setTodayaddexp(gainLimitRole.getTodayaddexp() + reallyAddExp);
		}
		
		//添加历史总经验
		final long allExp = prop.getAllexp();
		long newAllExp = reallyAddExp > 0 ? allExp+reallyAddExp : allExp;
		prop.setAllexp(newAllExp);
		
		/*	是否会升级	*/
		while (curExp_new >= levelExpCfg.exp && level < maxLevel)
		{
			curExp_new -= levelExpCfg.exp;
			if (!new PLevelUpProc(roleid).call())
				return false;
			level++;
			levelExpCfg = ConfigManager.getInstance().getConf(SNextExp.class).get(level);
		}
		
		/* 防止经验超过上限 */
		if (level == maxLevel)
		{
			if((long) maxLevelExpCfg.exp * factor < curExp_new && showOverflowMsg)
				Message.psendMsgNotify(roleid, 101301, null);
			curExp_new = Math.min((long) maxLevelExpCfg.exp * factor, curExp_new);
		}
		
		prop.setExp(curExp_new);
		if (curExp_new - curExp_old > 0)
		{
			if (showMsg) {
				if (serverLvAddExp > 0) {
					//1036006 <T t="你获得了$parameter1$点经验,"></T><SL t="【服务器繁荣】" exp="$parameter2$" serverlevel="$parameter3$" ></SL> <T t="加成$parameter4$点经验。"></T>
					Message.psendMsgNotifyWhileCommit(roleid, 1036006, Arrays.asList("" + (initadd - curExp_old), String.valueOf(serverLvAddExpInfo.exppct),
						String.valueOf(serverLvAddExpInfo.serverlv), String.valueOf(serverLvAddExp)));
				} else {
					// 你获得了XX点经验
					Message.psendMsgNotifyWhileCommit(roleid, 100154, Arrays.asList("" + (initadd - curExp_old)));
				}
			}
			
			ExpLogHelper.getInstance().doExpLog(roleid, initadd - curExp_old, curExp_old, type, reason);
			xdb.Procedure.psendWhileCommit(roleid, new SRefreshUserExp(prop.getExp(), (short) Math.max(0, prop.getLevel() - oldLevel)));
		}
		
		//刷新队伍界面的头像
		if (level != oldLevel) {
			freshTeamLv(roleid, (short) level);
			
			//同步最新的角色信息到global server
			ServerInfoProvider.syncRoleInfoToGlobal(roleid);
		}

		return true;
	}
	
	/**
	 * 获得角色服务器等级经验加成的信息
	 * 
	 * @param roleid
	 * @return
	 */
	public static SServerLv getServerExpAddInfo(final long roleId, long nowTick) {
		SServerLevelConfig sererLvCfg = ConfigManager.getInstance().getGsLevelCfg(nowTick);
		if (sererLvCfg == null)
			return null;
		
		int checkLv = 0;
		if (LocalIds.isRemoteServerRole(roleId)) {
			xbean.CrossRole crossRole = xtable.Crossroles.select(roleId);
			if (crossRole == null)
				return null;
			
			checkLv = crossRole.getLevel();
		} else {
			xbean.Properties prop = xtable.Properties.select(roleId);
			if (prop == null)
				return null;
			
			checkLv = prop.getLevel();
		}
		
		if (checkLv >= sererLvCfg.serverLevel || checkLv < sererLvCfg.minLevel || sererLvCfg.addRange == null)
			return null;
		
		int lvGap = sererLvCfg.serverLevel - checkLv;
		
		int addPct = -1;
		String[] lvRangeStrArr = sererLvCfg.addRange.split(";");
		for (String lvRangeStr : lvRangeStrArr) {
			String[] rangeArr = lvRangeStr.split(",");
			int startLv = Integer.valueOf(rangeArr[0]);
			int endLv = Integer.valueOf(rangeArr[1]);
			if (lvGap >= startLv && lvGap <= endLv) {
				addPct = Integer.valueOf(rangeArr[2]);
				break;
			}
		}
		
		if (addPct <= 0 || addPct > 100)
			return null;
		
		SServerLv snd = new SServerLv();
		snd.exppct = (byte) addPct;
		snd.serverlv = (short) sererLvCfg.serverLevel;
		
		return snd;
	}
	
	/**
	 * 是否可以获得经验
	 * @param factor 累积经验的倍数
	 */
	private boolean canAddExp(long roleId, int curLevel, long curExp, SNextExp maxLevelExpCfg, int factor)
	{
		int maxLevel = maxLevelExpCfg.id;
		long maxExp = maxLevelExpCfg.exp;
		if (curLevel == maxLevel)
		{
			if (curExp >= maxExp * factor)
			{
//				if (showOverflowMsg)
//					Message.psendMsgNotify(roleId, 101301, null);
				return false;
			}
		}

		return true;
	}

	/**
	 * 级别达到级别上限时，经验只保留最大级别所需经验数的倍数（此倍数可配置），多余量去掉 
	 */
	public static boolean canAddExp(long roleId)
	{
		xbean.Properties prop = xtable.Properties.select(roleId);
		if (prop == null)
			return false;

		int maxLevel = PLevelUpProc.getMaxLevel();
		SNextExp maxLevelExpCfg = ConfigManager.getInstance().getConf(SNextExp.class).get(maxLevel);
		int factor = getStoredExpFactor();
		long maxExp = maxLevelExpCfg.getExp();
		
		if (prop.getLevel() == maxLevel)
		{
			if (prop.getExp() >= maxExp * factor)
				return false;
		}

		return true;
	}
	
	public static void freshTeamLv(final long myRoleId, final short newLv) {
		//刷新队伍等级
		xdb.Procedure.pexecuteWhileCommit(new Procedure(){

			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.getTeamByRoleId(myRoleId);
				if (team == null)
					return false;
				lock(xtable.Locks.ROLELOCK, Arrays.asList(myRoleId));
				final SRefreshTeamMemberLevel sfreshteamlevel = new SRefreshTeamMemberLevel(myRoleId, (short) newLv);
				final RefreshLevelInGlobalTeam refreshLvInGlobalTeam = new RefreshLevelInGlobalTeam(team.teamId, myRoleId, (short)newLv);
				HashSet<Integer> otherZoneIdSet = new HashSet<Integer>();
				for(TeamMember member : team.getTeamMembers()){
					if(member.getRoleid() == myRoleId){
						member.setLevel(newLv);
						continue;
					}
					if(LocalIds.isRemoteServerRole(member.getRoleid())){
						otherZoneIdSet.add(member.getZoneid());
					} else {
						xdb.Procedure.psendWhileCommit(member.getRoleid(), sfreshteamlevel);
					}
				}
				for(int zoneId : otherZoneIdSet){
					GlobalClientManager.getInstance().send(zoneId, refreshLvInGlobalTeam);
				}
				return true;
			}
			
		});
	}

	/**
	 * 获取最大累积经验的倍数
	 * @return 默认1 即达到级别上限所需的经验后便不再增加经验
	 */
	public static int getStoredExpFactor()
	{
		Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(56);
		if (cfg == null)
			return 1;
		
		return Math.max(1, cfg.para1);
	}
	
	/**
	 * 没加经验之前，演算人物经验和巅峰经验分别可以 <b>增加</b> 多少经验
	 * </b>
	 * 特殊情况：
	 * <li>当人物经验达到最大储值所需的经验值小于传入方法的经验值时，此方法返回本传入方法的经验值
	 * <li>当人物巅峰经验达到最大储值所需的经验值小于传入方法的经验值时，此方法返回本传入方法的经验值
	 * 
	 * 这样有可能造成结算界面会略大于实际获得值，因为这个差值是不可估计的，所以没有必要追求那一点点的准确
	 */
	public static AddExpResult calcAddExpResult(final long roleId, final long addExp)
	{
		AddExpResult result = new AddExpResult();
		if (addExp <= 0)
			return result;
		
		int level = xtable.Properties.selectLevel(roleId);
		int maxLevel = PLevelUpProc.getMaxLevel();
		if (canAddExp(roleId))
		{
			result.roleExp = addExp;
		}
		if (level >= maxLevel && PAddExp.canAddExp(roleId))
		{
			result.paragonExp = addExp;
		}
		return result;
	}
	
	public static enum EXP_TYPE
	{
		TASK(0, "剧情任务"),
		FUBEN(1,"副本"),
		CAMP_TASK(2, "阵营任务"),
		ARENA(3, "竞技场"),
		GIFT(4, "礼包道具"),
		ACTIVITY(5, "活动"), 
		PVP(6, "角斗场"), 
		FAMILY_FIGHT(7, "家族战"),
		YONGBING(8,"佣兵传功"),
		OFFLINE_EXP(9,"离线经验"),
		YITIAOLONGADDITION(10,"一条龙加成"),
		PROTECT_CITY(11,"守卫凜夜城"),
		SEVENDAYS_GIFT(12, "七日礼包"),
		TREASURE(13, "宝图任务"),
		OPEN_TREASURE_BOX(14, "开宝箱"),
		FAMILY_GATHER(15, "家族采集"),
		RETRIEVE_REWARD(16, "找回奖励"),
		FAMILY_QUESTION(17, "家族答题"),
		WEIXIN_FIRSTSHARE(18, "微信每日分享"),
		CROSS_FAMILY_FIGHT(19, "跨服家族战"),
		CROSS_RESOURCE_FIGHT(20, "国庆资源争夺战"),
		GM(21, "GM指令"),
		CROSS_BOSS(22, "跨服boss"),
		GIFT_DROPS(23, "双节活动天降之礼"),
		ZUOQI_EXP(24, "兑换坐骑经验卷轴"),
		EXP_CONVERSION(25, "经验转化"),
		TREASURE_STEAL_GHOST(26, "盗宝精灵"),
		DRAGON_ADV(27, "宠物探险"),
		XUE_SE_SHOU_GE_BATTLE(28, "血色收割战"),
		SHENFU_CHOUKA(29, "神符抽卡"),
		DUANWUJIE(30, "端午节奖励拾取"),
		HERO_XILING(31, "佣兵吸灵"),
		IMAGE_CHALLENGE(32, "镜像挑战"),
		EXT(99, "其他");

		private int value;
		private String desc;

		private EXP_TYPE(int i, String desc)
		{
			this.value = i;
			this.desc = desc;
		}

		public int getValue()
		{
			return this.value;
		}

		public String getDesc()
		{
			return this.desc;
		}
	}
	
}
