
package knight.gsp;

import global.rsp.GlobalClientManager;
import global.rsp.item.RequestCheckGiftCard;
import knight.gsp.giftcard.CheckGiftCardThread;
import knight.gsp.giftcard.GiftCardModule;
import knight.gsp.giftcard.RequestGiftCard;
import knight.gsp.main.ConfigManager;



import knight.gsp.msg.Message;
import knight.gsp.util.DateValidate;
import knight.gsp.yuanbao.YuanbaoManager;




// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CUseGiftKey__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CUseGiftKey extends __CUseGiftKey__ {
	@Override
	protected void process() {
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if (roleid < 0) {
			return;
		}
		PropRole propRole = PropRole.getPropRole(roleid, true);
		if (null == propRole) 
			return;
		if (giftkey.length() >= 4 && giftkey.length() <= 12) {//新的礼品码逻辑走平台的,老的还是走原来的
			if (!GiftCardModule.getInstance().addRecord(roleid)) {
				Message.sendMsgNotify(roleid, 101596);
				return;
			}
			String plaString = propRole.getProperties().getNickname();
			CheckGiftCardThread.getInstance().add(new RequestGiftCard(roleid, giftkey, plaString));
			return;
		} 
		xbean.GiftCardInfo info = xtable.Giftcards.select(roleid);
		if (null != info) {
			//已经使用过该类型的礼品卡就不去请求global了
			if(info.getUsed().contains(GiftCardModule.getInstance().getGiftCardFatherType(giftkey))) {
				Message.sendMsgNotify(roleid, 101413, null);
				return;
			}
		}	
		if(giftkey != null && giftkey.length() > 5){
			String giftType = giftkey.substring(0, 5);
			if("bmaaa".equalsIgnoreCase(giftType)){// 360渠道的特殊码
				String[] sdk = propRole.getProperties().getUsername().split("\\$");
				String platString = null;
				if(sdk.length >= 2){
					platString = sdk[1];
				}
				if(platString != null && YuanbaoManager.QI_HO.equalsIgnoreCase(platString)){
					long startTime = DateValidate.parseDate("2016-08-22 00:00:00");
					long endTime = DateValidate.parseDate("2016-08-23 00:00:00");
					long roleCreateTime = propRole.getProperties().getCreatetime();
					if(startTime > roleCreateTime || roleCreateTime >= endTime){
						Message.sendMsgNotify(roleid, 1029048);//在8月22日创建角色的360渠道用户才能使用
						return;
					}
				} else {
					Message.sendMsgNotify(roleid, 101511, null);
					return;
				}
			}
		}
		RequestCheckGiftCard snd = new RequestCheckGiftCard();
		snd.roleid = roleid;
		snd.rolelevel = propRole.getLevel();
		snd.checkkey = giftkey;
		snd.username = propRole.getProperties().getUsername();
		snd.serverid = ConfigManager.getGsZoneId();
		GlobalClientManager.getInstance().send(snd);
		//new PUseGiftKey(roleid, giftkey).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786498;

	public int getType() {
		return 786498;
	}

	public java.lang.String giftkey; // 礼品卡

	public CUseGiftKey() {
		giftkey = "";
	}

	public CUseGiftKey(java.lang.String _giftkey_) {
		this.giftkey = _giftkey_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(giftkey, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		giftkey = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CUseGiftKey) {
			CUseGiftKey _o_ = (CUseGiftKey)_o1_;
			if (!giftkey.equals(_o_.giftkey)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += giftkey.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(giftkey.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

