
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SServerRoleInfos__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SServerRoleInfos extends __SServerRoleInfos__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786527;

	public int getType() {
		return 786527;
	}

	public java.util.HashMap<Integer,knight.gsp.ServerRoles> servers; // key为服务器id
	public byte opendlg; // 是否打开界面,1打开，0不打开

	public SServerRoleInfos() {
		servers = new java.util.HashMap<Integer,knight.gsp.ServerRoles>();
	}

	public SServerRoleInfos(java.util.HashMap<Integer,knight.gsp.ServerRoles> _servers_, byte _opendlg_) {
		this.servers = _servers_;
		this.opendlg = _opendlg_;
	}

	public final boolean _validator_() {
		for (java.util.Map.Entry<Integer, knight.gsp.ServerRoles> _e_ : servers.entrySet()) {
			if (!_e_.getValue()._validator_()) return false;
		}
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(servers.size());
		for (java.util.Map.Entry<Integer, knight.gsp.ServerRoles> _e_ : servers.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(opendlg);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			knight.gsp.ServerRoles _v_ = new knight.gsp.ServerRoles();
			_v_.unmarshal(_os_);
			servers.put(_k_, _v_);
		}
		opendlg = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SServerRoleInfos) {
			SServerRoleInfos _o_ = (SServerRoleInfos)_o1_;
			if (!servers.equals(_o_.servers)) return false;
			if (opendlg != _o_.opendlg) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += servers.hashCode();
		_h_ += (int)opendlg;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(servers).append(",");
		_sb_.append(opendlg).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

