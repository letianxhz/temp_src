package knight.gsp;

import gnet.link.Onlines;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import knight.gsp.map.RoleManager;

import com.goldhuman.Common.Marshal.MarshalException;
import com.goldhuman.Common.Marshal.OctetsStream;

import xio.Protocol;

public class ActivitySendProtocol extends Protocol {

	public Set<Long> roleids = new HashSet<Long>();
	
	@Override
	public OctetsStream marshal(OctetsStream arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OctetsStream unmarshal(OctetsStream arg0) throws MarshalException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getType() {
		return 0;
	}

	@Override
	protected void process() {
		final xio.Protocol activityState = ActivityStatusManager.getInstance().getActivityStatus();
		if (roleids == null || roleids.isEmpty()) {
			//给指定的角色发
			List<Long> roleids = RoleManager.getInstance().getRoleIds();
			Set<Long> roleidsSet = new HashSet<Long>(roleids);
			Onlines.getInstance().send(roleidsSet, activityState);
		} else {
			//给所有角色发
			Onlines.getInstance().send(roleids, activityState);
		}
	}
	
}
