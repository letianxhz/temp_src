
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SServerPassword__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SServerPassword extends __SServerPassword__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786529;

	public int getType() {
		return 786529;
	}

	public int serverid; // zoneid
	public java.lang.String ipstr; // ip
	public int statport; // startport
	public java.lang.String token; // relogin token

	public SServerPassword() {
		ipstr = "";
		token = "";
	}

	public SServerPassword(int _serverid_, java.lang.String _ipstr_, int _statport_, java.lang.String _token_) {
		this.serverid = _serverid_;
		this.ipstr = _ipstr_;
		this.statport = _statport_;
		this.token = _token_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(serverid);
		_os_.marshal(ipstr, "UTF-16LE");
		_os_.marshal(statport);
		_os_.marshal(token, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		serverid = _os_.unmarshal_int();
		ipstr = _os_.unmarshal_String("UTF-16LE");
		statport = _os_.unmarshal_int();
		token = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SServerPassword) {
			SServerPassword _o_ = (SServerPassword)_o1_;
			if (serverid != _o_.serverid) return false;
			if (!ipstr.equals(_o_.ipstr)) return false;
			if (statport != _o_.statport) return false;
			if (!token.equals(_o_.token)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += serverid;
		_h_ += ipstr.hashCode();
		_h_ += statport;
		_h_ += token.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(serverid).append(",");
		_sb_.append("T").append(ipstr.length()).append(",");
		_sb_.append(statport).append(",");
		_sb_.append("T").append(token.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

