
package knight.gsp;

import knight.gsp.dny.DongNanYaManager;
import knight.gsp.hg.HanGuoManager;
import knight.gsp.util.CheckName;
import knight.gsp.yuenan.YNManager;

import org.apache.log4j.Logger;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CCreateRole__ extends xio.Protocol { }

/** 客户端请求创建
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CCreateRole extends __CCreateRole__ {
	
	public static final Logger logger = Logger.getLogger(CCreateRole.class);
	
	@Override
	protected void process() {
		final int userID=((gnet.link.Dispatch)this.getContext()).userid;
		final xbean.User u = xtable.User.select(userID);
		int nameLen_max = NAMELEN_MAX;
		int nameLen_min = NAMELEN_MIN;
		if(HanGuoManager.getInstance().isHanGuoServer() || DongNanYaManager.getInstance().isDongNanYaServer()
				|| YNManager.getInstance().isYNServer()){
			nameLen_max = 16;
		}
		if (name.length() > nameLen_max){
			sendError(SCreateRole.CREATE_OVERLEN);
			logger.debug("名字长度太长");
			return;
		} else if (name.length() < nameLen_min){
			sendError(SCreateRole.CREATE_SHORTLEN);
			logger.debug("名字长度太短");
			return;
		}
		
		int resultCode = CheckName.checkValid(name);
		if(resultCode == CheckName.WORD_ILLEGALITY){
			sendError(SCreateRole.CREATE_INVALID);
			logger.debug("只能输入2-6个字母、汉字、数字并且不能含有非法字符");
			return;	
		}else if(resultCode == CheckName.SPECIAL_WORD_TOO_MANY){
			sendError(SCreateRole.CREATE_INVALID);
			logger.debug("特殊字符过多");
			return;
		}else if(resultCode == CheckName.NONE_CHARACTER){
			sendError(SCreateRole.CREATE_INVALID);
			logger.debug("命名必须包含一个汉字或者字母");
			return;
		}
		
		if(null != u){
			if(u.getIdlist().size() >= PCreateRole.maxRoleNum){
				sendError(SCreateRole.CREATE_OVERCOUNT);
				return;
			}
		}
		
		new PCreateRole(this,userID, connecttype).submit();
	}
	
	private boolean  sendError(int err){
		final SCreateRole res=new SCreateRole();
		res.error = err;
		res.newinfo.roleid = 1;  //假的roleid
		return gnet.link.Onlines.getInstance().sendResponse(this, res);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786435;

	public int getType() {
		return 786435;
	}

	public final static int NAMELEN_MAX = 6; // 名字的最大长度
	public final static int NAMELEN_MIN = 2; // 名字的最短长度

	public java.lang.String name;
	public int school; // 职业
	public byte connecttype; // 参考枚举ConnectType

	public CCreateRole() {
		name = "";
	}

	public CCreateRole(java.lang.String _name_, int _school_, byte _connecttype_) {
		this.name = _name_;
		this.school = _school_;
		this.connecttype = _connecttype_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(name, "UTF-16LE");
		_os_.marshal(school);
		_os_.marshal(connecttype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		name = _os_.unmarshal_String("UTF-16LE");
		school = _os_.unmarshal_int();
		connecttype = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CCreateRole) {
			CCreateRole _o_ = (CCreateRole)_o1_;
			if (!name.equals(_o_.name)) return false;
			if (school != _o_.school) return false;
			if (connecttype != _o_.connecttype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += name.hashCode();
		_h_ += school;
		_h_ += (int)connecttype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(name.length()).append(",");
		_sb_.append(school).append(",");
		_sb_.append(connecttype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

