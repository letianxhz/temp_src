
package knight.gsp;

import knight.gsp.friends.PSaveBlockStrangerTeamState;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CSystemSettingInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CSystemSettingInfo extends __CSystemSettingInfo__ {
	@Override
	protected void process() {
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if (roleid < 0) {
			return;
		}
		knight.gsp.memory.RoleInMemoryManager manager = knight.gsp.memory.RoleInMemoryManager.getInstance();
		knight.gsp.memory.RoleInMemory roleInMemory = manager.getRoleInMemoryByID(roleid);
		if(roleInMemory == null) {
			roleInMemory = new knight.gsp.memory.RoleInMemory(roleid);
			manager.addRoleInMemory(roleInMemory);
		}
		roleInMemory.setGameMode(mode);
		roleInMemory.setStrangerMsgState(strangermsg);
		roleInMemory.setStrangerTeamState(strangerteam);
		
		new PSaveBlockStrangerTeamState(roleid, strangerteam).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786467;

	public int getType() {
		return 786467;
	}

	public final static int PERFECT = 1; // 完美
	public final static int MIDDLE = 2; // 省电
	public final static int POOR = 3; // 极限省电

	public short mode; // 游戏模式
	public short strangermsg; // 陌生人消息设置 1接受 0拒绝
	public short strangerteam; // 陌生人组队设置 1接受 0拒绝

	public CSystemSettingInfo() {
	}

	public CSystemSettingInfo(short _mode_, short _strangermsg_, short _strangerteam_) {
		this.mode = _mode_;
		this.strangermsg = _strangermsg_;
		this.strangerteam = _strangerteam_;
	}

	public final boolean _validator_() {
		if (mode < 1 || mode > 3) return false;
		if (strangermsg < 0 || strangermsg > 1) return false;
		if (strangerteam < 0 || strangerteam > 1) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(mode);
		_os_.marshal(strangermsg);
		_os_.marshal(strangerteam);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		mode = _os_.unmarshal_short();
		strangermsg = _os_.unmarshal_short();
		strangerteam = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CSystemSettingInfo) {
			CSystemSettingInfo _o_ = (CSystemSettingInfo)_o1_;
			if (mode != _o_.mode) return false;
			if (strangermsg != _o_.strangermsg) return false;
			if (strangerteam != _o_.strangerteam) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += mode;
		_h_ += strangermsg;
		_h_ += strangerteam;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(mode).append(",");
		_sb_.append(strangermsg).append(",");
		_sb_.append(strangerteam).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CSystemSettingInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = mode - _o_.mode;
		if (0 != _c_) return _c_;
		_c_ = strangermsg - _o_.strangermsg;
		if (0 != _c_) return _c_;
		_c_ = strangerteam - _o_.strangerteam;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

