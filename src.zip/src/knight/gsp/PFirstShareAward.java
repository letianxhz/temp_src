package knight.gsp;

import java.util.Arrays;

import knight.gsp.log.LogUtil;
import knight.gsp.task.Module;
import knight.gsp.task.activelist.PlayActiveRole;
import knight.gsp.yuanbao.PAddYuanBao;
import xbean.Properties;
import xdb.Procedure;

public class PFirstShareAward extends Procedure {
	private final long roleid;
	private final int type;
	
	public final static int FIRST_AWARD_WEIBO = 200;

	public PFirstShareAward(long roleid, int type){
		this.roleid = roleid;
		this.type = type;
	}
	@Override
	public boolean process(){
		//因为加元宝的时候会锁user，为了遵循先大后小原则，这里手动锁住user
		lock(xtable.Locks.USERLOCK, Arrays.asList(xtable.Properties.selectUserid(roleid)));
		final xbean.Properties pro = xtable.Properties.get(roleid);
		if (null == pro) {
			Module.logger.error("角色： " + roleid + " 不存在...");
			return false;
		}
		final xbean.User u = xtable.User.get(pro.getUserid());
		if(u == null || u.getIdlist().isEmpty()){
			Module.logger.error("账号： " + pro.getUserid() + " 不存在");
			return false;
		}
		
		if(type == CFirstShare.WEI_BO) {
			if(isFirstShare(u, RoleInitFlag.FIRST_WEIBO)) {
				//微博首次分享
				setFirstShare4AllRole(pro.getUserid(), RoleInitFlag.FIRST_WEIBO);
				//给奖励
				return new PAddYuanBao(roleid, FIRST_AWARD_WEIBO, LogUtil.FIRST_SHARE_AWARD, 0).call();
			} else {
				Module.logger.error("您的账号： " + pro.getUserid() + " 已经分享过了");
				return false;
			}
		} else if(type == CFirstShare.WEI_XIN) {
			if(isFirstShare(u, RoleInitFlag.FIRST_WEIXIN)) {
				//微信首次分享
				pro.setWeixinsharestatus((short)1);
				setFirstShare4AllRole(pro.getUserid(), RoleInitFlag.FIRST_WEIXIN);
				
				SFirstShare firstShare = new SFirstShare(CFirstShare.WEI_XIN, pro.getWeixinsharestatus());
				xdb.Procedure.psendWhileCommit(roleid, firstShare);
				return true;
			} else {
				knight.gsp.task.Module.logger.error("您的账号： " + pro.getUserid() + " 已经分享过了");
				return false;
			}
		} else {
			Module.logger.error("类型type： " + type + " 不存在...");
			return false;
		}
	}
	
	//是否首次分享
	private boolean isFirstShare(xbean.User u, int type) {
		int states = u.getUserinitflag();
		if((states & type) != 0) {
			return false;
		}
		return true;
	}
	
	private void setFirstShare4AllRole(int userId, int type) {
		final xbean.User u = xtable.User.get(userId);
		if(u == null || u.getIdlist().isEmpty()){
			Module.logger.error("账号： " + userId + " 不存在");
			return ;
		}
		u.setUserinitflag(u.getUserinitflag() | type);
		//修改账号下的所有角色的状态
		for (int i=0; i<u.getIdlist().size(); i++){
			long roleid = u.getIdlist().get(i);
			final xbean.Properties pro = xtable.Properties.get(roleid);
			if(null == pro){
				continue;
			}
			
			//完成 各个角色的微信分享的每日任务
			PlayActiveRole activeRole = PlayActiveRole.getPlayActiveRole(roleid, false);
			activeRole.addActiveWithSp(PlayActiveRole.WEIXIN_SHARE, 1);
			
			pro.setRoleinitflag(pro.getRoleinitflag() | type);
		}
		
	}
	
	/**
	 * 清除 微信每日分享的数据  领取状态和任务完成标记位
	 * 同时同步更新账户USER信息
	 * @li 存储过程中调用
	 */
	public static void clearWeixinShareData(Properties prop){
		if(prop == null){
			return;
		}
		prop.setWeixinsharestatus((short)0);
		prop.setRoleinitflag(prop.getRoleinitflag() & 11); 
		
		final int userId = prop.getUserid();
		final xbean.User u = xtable.User.get(userId);
		if(u == null || u.getIdlist().isEmpty()){
			Module.logger.error("账号： " + userId + " 不存在");
			return ;
		}
		u.setUserinitflag(u.getUserinitflag() & 11);
	}
}
