package knight.gsp;

import java.util.Calendar;

import knight.gsp.activity.AwardState;
import knight.gsp.game.Slandbuqian;
import knight.gsp.log.LogUtil.MONEY_TYPE;
import knight.gsp.main.ConfigManager;
import knight.gsp.util.DateValidate;


/**
 * 封装对xtable.Properties 的操作 涉及的属性，都是非 buff影响的属性
 * 
 * @author DevUser
 * 
 */
public class PropRole
{
	private long roleid;
	private final xbean.Properties xprop;
	private boolean readonly;

	/**
	 * 获取PropRole的工厂方法
	 * 
	 * @param roleid
	 * @param readonly
	 * @return
	 */
	public static PropRole getPropRole(long roleid, boolean readonly) {
		xbean.Properties prop = null;
		if (readonly) {
			prop = xtable.Properties.select(roleid);
		} else {
			prop = xtable.Properties.get(roleid);
		}
		if (prop == null)
			return null;

		return new PropRole(roleid, prop, readonly);
	}
	
	
	private PropRole(long roleid, xbean.Properties prop, boolean readonly) {
		this.roleid = roleid;
		this.xprop = prop;
		this.readonly = readonly;
	}
	
	public PropRole(long roleid, boolean readonly) {
		this.roleid = roleid;
		this.readonly = readonly;

		if (readonly) {
			xprop = xtable.Properties.select(roleid);
		} else {
			xprop = xtable.Properties.get(roleid);
		}

		if (xprop == null) {
			// Module.logger.error("服务器找不到该角色：  " + roleid);
			throw new RuntimeException("Unexist this role:" + roleid);
		}

	}
	
	public xbean.Properties getProperties() {
		return xprop;
	}
	
	public long getRoleId() {
		return roleid;
	}
	
	/**
	 * 获得名称
	 * 
	 * @return
	 */
	public String getName()
	{
		return xprop.getRolename();
	}

	/**
	 * 
	 */
	public int getLevel()
	{
		return xprop.getLevel();
	}

	/**
	 * 获得当前血量
	 */
	public int getHp()
	{
		return xprop.getHp();
	}

	/**
	 * 获得当前法力
	 * 
	 * @return
	 */
	public int getMp()
	{
		return xprop.getMp();
	}

	/**
	 * 获得当前经验值
	 * 
	 * @return
	 */
	public long getCurExp()
	{
		return xprop.getExp();
	}
	
	/**
	 * 增加储备金,并通知客户端。
	 * 
	 * @param addnum
	 * @return
	 */
	public long addSmoney(final long addnum, boolean showMsg, final String hint, final int countertype, final int xiangguanid,boolean checkLimit)
	{
		if (readonly)
			throw new RuntimeException("Wrong invoke");
		knight.gsp.item.Bag bag = new knight.gsp.item.Bag(roleid, false);
		if(addnum >0){
			return  bag.addSysMoney(addnum, MONEY_TYPE.BUY,"加储备金转为加现金");
		}else{
			return bag.subMoney(addnum, MONEY_TYPE.BUY,"加储备金转为加现金");
		}
	}

	public long addSmoney(final long addnum, final String hint, final int countertype, final int xiangguanid )
	{
		return addSmoney(addnum, true, hint, countertype, xiangguanid );
	}

	public long addSmoney(final long addnum, boolean showMsg, final String hint, final int countertype, final int xiangguanid){
		return addSmoney(addnum, showMsg, hint, countertype, xiangguanid, true);
	}


	/**
	 * 获得角色的门派值
	 * 
	 * @return
	 */
	public int getSchool()
	{
		return xprop.getSchool();
	}

	public long getLastOfflineTime()
	{
		return xprop.getOfflinetime();
	}
	
	public int getUserid(){
		return xprop.getUserid();
	}
	
	/**
	 * 得到角色的最近离线时长（即最近多久没有上线了）
	 * 
	 * @return 如果目前正在线则返回-1
	 */
	public long getLastOfflineTimeSpace(){
		if(xprop.getOnlinetime() <= xprop.getOfflinetime()){
			return System.currentTimeMillis() - xprop.getOfflinetime();
		}else{
			return -1;
		}
	}
	
	/**
	 * 设置下线时间，将上次恢复体力时间记为下线时间
	 */
	public void setLastOfflineTime() {
		//战斗托管时已经设置过了，战斗托管结束时不再设置
		if (xprop.getOfflinetime() > xprop.getOnlinetime())
			return;
		
		long now = System.currentTimeMillis();
		xprop.setOfflinetime(now);
		xprop.setLastrecoverphytime(now);
		xprop.setTotalonlinetime(xprop.getTotalonlinetime() + 
				(int)((xprop.getOfflinetime() - xprop.getOnlinetime()) * 0.001));
		//当天累计在线时间
		if(DateValidate.inTheSameDay(xprop.getOnlinetime(), now)) {
			xprop.setTodayonlinetime(xprop.getTodayonlinetime() + 
					(int)((xprop.getOfflinetime() - xprop.getOnlinetime()) * 0.001));
		} else {
			long zero = DateValidate.getDayFirstSecond(now);
			long todayOnline = now - zero > 0 ? now - zero : 0;
			xprop.setTodayonlinetime((int) (todayOnline * 0.001));
		}
	}
	
	/**
	 * 累计在线时间(秒)
	 * @return
	 */
	public int getTotalOnlineTime() {
		if(xprop.getOfflinetime() > xprop.getOnlinetime()) {
			//不在线
			return xprop.getTotalonlinetime();
		}
		return (int) (xprop.getTotalonlinetime() + (System.currentTimeMillis() - xprop.getOnlinetime()) * 0.001);
	}
	
	/***
	 * 升级时间点
	 * @return
	 */
	public long getLevelUpTime() {
		return xprop.getLeveluptime();
	}
	
	public void addPhyMax(int addPhyMax){
		int oldPhyMax=xprop.getMaxphy();
		int newPhyMax=oldPhyMax+addPhyMax;
		xprop.setMaxphy(newPhyMax);
		
		SRefreshPhy sp=new SRefreshPhy();
		sp.phymax=xprop.getMaxphy();
		xdb.Procedure.psendWhileCommit(roleid, sp);
	}
	
	public void addPhy(int addPhy,boolean recover){
		int oldPhy=xprop.getPhy();
		int newPhy=oldPhy+addPhy;
		if(recover && newPhy>xprop.getMaxphy()){
			if(oldPhy<xprop.getMaxphy()){
				newPhy=xprop.getMaxphy();
			}else{
				newPhy=oldPhy;
			}
		}
		if(newPhy<0){
			newPhy=0;
		}
		xprop.setPhy(newPhy);
		
		SRefreshPhy sp=new SRefreshPhy();
		sp.phy=xprop.getPhy();
		xdb.Procedure.psendWhileCommit(roleid, sp);
	}
	public void addPhy(int addPhy){
		addPhy(addPhy,false);
	}
	
	public int getPhyMax(){
		return xprop.getMaxphy();
	}
	
	public int getPhy(){
		return xprop.getPhy();
	}
	/*
	 * lch 增加该角色是不是可以进行补签的判断
	 */
	public boolean isBuqian(xbean.LoginActivityBean bean)
	{
		//补签数量已经达到上限，直接返回false
		int buqiantimes=ConfigManager.getInstance().getConf(Slandbuqian.class).size();
		if(bean.getBuqiantimes()>=buqiantimes)
			return false;
		Calendar currentTime = Calendar.getInstance();
		Calendar createTime = Calendar.getInstance();
		createTime.setTimeInMillis(this.getProperties().getCreatetime());
		/*
		 * 判断创建角色和当期是不是在一个月
		 */
		int totalday =0;
		if (currentTime.get(Calendar.YEAR) == createTime.get(Calendar.YEAR)
				&& currentTime.get(Calendar.MONTH) == createTime.get(Calendar.MONTH)) {
			// 创建角色的当前月
			int day = createTime.get(Calendar.DAY_OF_MONTH);// 第几天创建的角色
			int curday = currentTime.get(Calendar.DAY_OF_MONTH);// 今天是该月的第几天
			totalday = curday - day + 1;// 角色在游戏在当月存在的天数。
		} else {
			//非创建该角色的当月
			totalday=currentTime.get(Calendar.DAY_OF_MONTH);// 今天是该月的第几天;
		}
		// 该月的第几天
		if (totalday - bean.getLogindays() >= 2) {
			return true;
		} else if (totalday - bean.getLogindays() == 1) {
			// 今天已经签到，并且签到的天数还小于totalday
			if (!(bean.getLoginawardmap().get(bean.getLogindays() + 1) == AwardState.CAN_GET)) {
				return true;
			}
		}
		return false;
	}
}
