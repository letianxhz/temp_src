
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SServerLv__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SServerLv extends __SServerLv__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786522;

	public int getType() {
		return 786522;
	}

	public short serverlv; // 服务器等级服务器等级
	public byte exppct; // 0~100 经验加成百分比

	public SServerLv() {
	}

	public SServerLv(short _serverlv_, byte _exppct_) {
		this.serverlv = _serverlv_;
		this.exppct = _exppct_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(serverlv);
		_os_.marshal(exppct);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		serverlv = _os_.unmarshal_short();
		exppct = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SServerLv) {
			SServerLv _o_ = (SServerLv)_o1_;
			if (serverlv != _o_.serverlv) return false;
			if (exppct != _o_.exppct) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += serverlv;
		_h_ += (int)exppct;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(serverlv).append(",");
		_sb_.append(exppct).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SServerLv _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = serverlv - _o_.serverlv;
		if (0 != _c_) return _c_;
		_c_ = exppct - _o_.exppct;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

