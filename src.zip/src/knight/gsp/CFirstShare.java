
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CFirstShare__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CFirstShare extends __CFirstShare__ {
	@Override
	protected void process() {
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if (roleid < 0)
			return;
		
		new PFirstShareAward(roleid, firstsharetype).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786465;

	public int getType() {
		return 786465;
	}

	public final static int WEI_BO = 1; // 微博
	public final static int WEI_XIN = 2; // 微信

	public short firstsharetype; // 首次分享

	public CFirstShare() {
	}

	public CFirstShare(short _firstsharetype_) {
		this.firstsharetype = _firstsharetype_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(firstsharetype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		firstsharetype = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CFirstShare) {
			CFirstShare _o_ = (CFirstShare)_o1_;
			if (firstsharetype != _o_.firstsharetype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += firstsharetype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(firstsharetype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CFirstShare _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = firstsharetype - _o_.firstsharetype;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

