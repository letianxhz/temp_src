
package knight.gsp;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import xio.Protocol;
import knight.gsp.activesn.ActiveSnModule;
import knight.gsp.main.ConfigManager;
import knight.gsp.msg.Message;
import knight.gsp.msg.SSendMsgNotify;
import gnet.link.Dispatch;
import gnet.link.Kick;
import gnet.link.Onlines;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CRoleList__ extends xio.Protocol { }

/** 客户端发给服务器，请求已有角色列表
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CRoleList extends __CRoleList__ {
	@Override
	protected void process() {
		// protocol handle
		final int userID = ((gnet.link.Dispatch) this.getContext()).userid;
		if (userID <= 0) {
			kickUser(-1000);
			return;
		}

		knight.gsp.main.ConfigManager manager = knight.gsp.main.ConfigManager.getInstance();
		//登陆限制，白名单，黑名单功能
		if(manager.getLoginLimitType() != knight.gsp.log.Module.LIMIT_NORMAL_MODE && manager.getUserIDList().size() != 0){
			if(manager.getLoginLimitType() == knight.gsp.log.Module.LIMIT_BLACLIST_MODE){
				if(manager.getUserIDList().contains(userID)){
					sendError(manager.getErrorType());	
					kickUser(-1000);
					return;
				}
			}else if(manager.getLoginLimitType() == knight.gsp.log.Module.LIMIT_WHITELIST_MODE){
				if(!manager.getUserIDList().contains(userID)){
					sendError(manager.getErrorType());	
					kickUser(-1000);
					return;
				}
			}
		}

		final Protocol p = this;
		String infos = null;
		try {
			infos = knight.gsp.userserver.Module.getInstance().getServerInfoByUserId(userID);
		} catch (Exception ex) {
			infos = null;
		}
		
		if (infos != null && !"".equals(infos)) {
			String[] details = infos.split("#\\$@");

			if (!details[1].matches("\\d+") || Integer.parseInt(details[1]) != ConfigManager.getGsZoneId()) {

				final SSendMsgNotify notify = Message.getMsgNotify(101928, 0, Arrays.asList(details[0]));
				gnet.link.Onlines.getInstance().sendResponse(this, notify);

				xdb.Executor.getInstance().schedule(new Runnable() {

					@Override
					public void run() {
						gnet.link.Onlines.getInstance().sendResponse(p, notify);
					}
				}, 2, TimeUnit.SECONDS);

				xdb.Executor.getInstance().schedule(new Runnable() {

					@Override
					public void run() {
						gnet.link.Onlines.getInstance().sendResponse(p, notify);
					}
				}, 4, TimeUnit.SECONDS);
			}
		}
		// XXX added by rake.zhai 将激活码功能去掉，防止误操作
		//登陆限制，激活码功能
//		if (manager.isNeedActive()) {
//			if (!dealWithActiveSn(userID)) {
//				return;
//			}
//		}
		long curTime = System.currentTimeMillis();
		xbean.UserPunish userPunish = xtable.Userpunish.select(userID);
		if (userPunish!=null){
			if (curTime<userPunish.getReleasetime()){
				if (!userPunish.getRecords().isEmpty()) {
					try {
						int remainTime=(int)Math.ceil((userPunish.getReleasetime()-curTime)/(60 * 1000.0));
						String reason = userPunish.getRecords().get(userPunish.getRecords().size()-1).getReason();
//						gnet.link.Onlines.getInstance().sendResponse(this, new SGACDKickoutMsg(new Octets(reason.getBytes("UTF-16LE"))));
						final SSendMsgNotify notify = Message.getMsgNotify(1039239, 0, Arrays.asList(String.valueOf(remainTime),reason));
						gnet.link.Onlines.getInstance().sendResponse(this, notify);
					} catch (Exception e) {
						knight.gsp.log.Module.logger.error("send kickoutmsg error", e);
					}
				}
				kickUser(-1000);
				return;
			}
		}
		
		if (selectroleid > 0) {
			new xdb.Procedure() {

				@Override
				protected boolean process() throws Exception {
					xbean.User userInfo = xtable.User.get(userID);
					if (userInfo == null) {
						kickUser(-1000);
						return false;
					}
					
					if (userInfo.getIdlist().contains(selectroleid)) {
						userInfo.setPrevloginroleid(selectroleid);
					}
					
					gnet.link.Onlines.getInstance().getOnlineUsers().online(p);
					
					return true;
				}
				
			}.submit();
		} else {
			gnet.link.Onlines.getInstance().getOnlineUsers().online(this);
		}
	}
	
	private boolean sendError(int err){
		final SCreateRole res=new SCreateRole();
		res.error = err;
		res.newinfo.roleid = 1;  //假的roleid
		return gnet.link.Onlines.getInstance().sendResponse(this, res);
	}
	
	private void kickUser(int error) {
		Kick p1 = new Kick();
		p1.linksid = ((Dispatch)this.getContext()).linksid;
		p1.action = Kick.A_QUICK_CLOSE;
		p1.error = error;
		Onlines.sendProtocl(p1, this.getConnection());
	}

	/**
	 * checkUserAccount:(这里用一句话描述这个方法的作用)
	 *
	 * @param userID
	 * @return    
	 * boolean    
	 * @throws 
	 * @since  　
	*/
	
	private boolean checkUserAccount(int userID) {
		if (xdb.util.UniqName.exist("activeuser", String.valueOf(userID)) != xdb.util.UniqName.RPC_NOT_EXISTS){ 
			//存在说明已经激活,可以直接进入游戏
			return true;
		}
		return false;
	}
	
	@SuppressWarnings("unused")
	private boolean dealWithActiveSn(int userID) {
		boolean isClose = ConfigManager.getServerCloseTime() < System.currentTimeMillis() ? true : false;
		if (!checkUserAccount(userID)) {
			if(isClose) {
				kickUser(-999);
				return false;
			} else {
				//需要激活的角色
				xbean.AUUserInfo auUserInfo = xtable.Auuserinfo.select(userID);
				if(auUserInfo == null) {
					return false;
				}
				String url = ActiveSnModule.getUrlByQudaoName(auUserInfo.getPlatform()) ;
				if(url == null) {
					url = "";
				}
				SUserNeedActive sUserNeedActive = new SUserNeedActive((byte) SUserNeedActive.NEED_ACTIVE, url);
				gnet.link.Onlines.getInstance().sendResponse(this, sUserNeedActive);	
			}
			return false;
		} else {
			//已激活
			String sn = ActiveSnModule.getSnByUserId(userID);
			if(System.currentTimeMillis() <ConfigManager.getServerOpenTime()) {
				//服务器未开启
				if(!ActiveSnModule.snInWhiteSet(sn)) {
					//未开服
					SUserNeedActive sUserNeedActive = new SUserNeedActive((byte) SUserNeedActive.HAS_ACTIVED, "");
					gnet.link.Onlines.getInstance().sendResponse(this, sUserNeedActive);
					return false;
				}
			} else if(isClose) {
				if(!ActiveSnModule.snInWhiteSet(sn)) {
					SUserNeedActive sUserNeedActive = new SUserNeedActive((byte) SUserNeedActive.SERVER_CLOSE, "");
					gnet.link.Onlines.getInstance().sendResponse(this, sUserNeedActive);
					return false;
				}
				
			}
			return true;
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786433;

	public int getType() {
		return 786433;
	}

	public long selectroleid; // 默认选中角色id

	public CRoleList() {
	}

	public CRoleList(long _selectroleid_) {
		this.selectroleid = _selectroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(selectroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		selectroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CRoleList) {
			CRoleList _o_ = (CRoleList)_o1_;
			if (selectroleid != _o_.selectroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)selectroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(selectroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CRoleList _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(selectroleid - _o_.selectroleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

