
package knight.gsp;

import java.util.concurrent.ExecutionException;

import knight.gsp.main.ConfigManager;
import knight.gsp.map.MapConfig;
import knight.gsp.map.Role;
import knight.gsp.map.RoleManager;
import knight.gsp.map.SceneManager;
import knight.gsp.move.SceneType;
import knight.gsp.msg.Message;
import knight.gsp.team.PQuitTeam;
import xbean.FamilyMemberBean;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CWorldMapTeleport__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CWorldMapTeleport extends __CWorldMapTeleport__ {
	@Override
	protected void process() {
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if (roleid < 0)
			return;

		MapConfig cfg = ConfigManager.getInstance().getConf(MapConfig.class).get((int)sceneid);
		if (null == cfg)
			return;
		if (cfg.sceneType == SceneType.FAMILY) {
			// 是否有家族
			FamilyMemberBean member = xtable.Familymember.select(roleid);
			if (member == null) {
				Message.sendMsgNotify(roleid, 1037612, null);
				return;
			}
		}
		Role role = RoleManager.getInstance().getRoleByID(roleid);
		if (role == null)
			return;
		
		if (role.getScene() == sceneid) {
			Message.sendMsgNotify(roleid, 101313);
			return;
		}
		if (cfg.sceneType == SceneType.BIG_WILD && role.getCurMapConfig().sceneType != SceneType.WILD) {
			if (xtable.Properties.selectLevel(roleid) < 80) 
				return;
			boolean succ = false;
			if (xtable.Roleid2teamid.select(roleid) != null) {
				try {
					succ = new PQuitTeam(roleid).submit().get().isSuccess();
					if (!succ)
						return;
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ExecutionException e) {
					e.printStackTrace();
				}
			}
		}
		SceneManager.getInstance().gotoScene(roleid, sceneid, unstopflow == 1);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786485;

	public int getType() {
		return 786485;
	}

	public int sceneid; // 场景ID
	public byte unstopflow; // 为1代表不打断跟随队长的状态,0代表打断

	public CWorldMapTeleport() {
		unstopflow = 0;
	}

	public CWorldMapTeleport(int _sceneid_, byte _unstopflow_) {
		this.sceneid = _sceneid_;
		this.unstopflow = _unstopflow_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(sceneid);
		_os_.marshal(unstopflow);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		sceneid = _os_.unmarshal_int();
		unstopflow = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CWorldMapTeleport) {
			CWorldMapTeleport _o_ = (CWorldMapTeleport)_o1_;
			if (sceneid != _o_.sceneid) return false;
			if (unstopflow != _o_.unstopflow) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += sceneid;
		_h_ += (int)unstopflow;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(sceneid).append(",");
		_sb_.append(unstopflow).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CWorldMapTeleport _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = sceneid - _o_.sceneid;
		if (0 != _c_) return _c_;
		_c_ = unstopflow - _o_.unstopflow;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

