package knight.gsp;

import xdb.Procedure;

/**
 * @author 作者:wxh
 * @version 创建时间 :2018年1月4日 
 * 类说明
 */
public class PSendConfirmGoToWildScene extends Procedure{
	private long roleId;
	public PSendConfirmGoToWildScene(long roleId) {
		this.roleId = roleId;
	}
	
	@Override
	protected boolean process() throws Exception {
		Long state = xtable.Gotowildrolecachedata.select(roleId);
		if (null == state || state == 0){
			xdb.Procedure.psendWhileCommit(roleId, new SConfirmGoToWildScene());
		}
		return true;
	}

}
