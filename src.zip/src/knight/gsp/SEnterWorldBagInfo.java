
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SEnterWorldBagInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SEnterWorldBagInfo extends __SEnterWorldBagInfo__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786512;

	public int getType() {
		return 786512;
	}

	public java.util.HashMap<Integer,knight.gsp.Bag> baginfo; // key是bagid,value是包裹的详细信息

	public SEnterWorldBagInfo() {
		baginfo = new java.util.HashMap<Integer,knight.gsp.Bag>();
	}

	public SEnterWorldBagInfo(java.util.HashMap<Integer,knight.gsp.Bag> _baginfo_) {
		this.baginfo = _baginfo_;
	}

	public final boolean _validator_() {
		for (java.util.Map.Entry<Integer, knight.gsp.Bag> _e_ : baginfo.entrySet()) {
			if (!_e_.getValue()._validator_()) return false;
		}
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(baginfo.size());
		for (java.util.Map.Entry<Integer, knight.gsp.Bag> _e_ : baginfo.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			knight.gsp.Bag _v_ = new knight.gsp.Bag();
			_v_.unmarshal(_os_);
			baginfo.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SEnterWorldBagInfo) {
			SEnterWorldBagInfo _o_ = (SEnterWorldBagInfo)_o1_;
			if (!baginfo.equals(_o_.baginfo)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += baginfo.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(baginfo).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

