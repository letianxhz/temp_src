
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CRequestImageLoadToken__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CRequestImageLoadToken extends __CRequestImageLoadToken__ {
	@Override
	protected void process() {
		// protocol handle
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if(roleid <= 0)
			return;
		
		int isOpen = knight.gsp.util.GameProp.getIntValue(knight.gsp.main.ConfigManager.getInstance().getPropConf("sys"), "sys.net.uploadheadimage");
		if(isOpen == 0)
			return;
		
		xbean.HeadImageInfo prop = xtable.Headimageinfo.select(roleid);
		if(prop == null){
			prop = xbean.Pod.newHeadImageInfo();
		}
		
		knight.gsp.game.Sspecialpara cdCfg = knight.gsp.main.ConfigManager.getInstance().getConf(knight.gsp.game.Sspecialpara.class).get(268);
		if(cdCfg == null){
			xdb.Trace.error("上传头像的cd时间配置为空...");
			return;
		}
		long cd = Integer.parseInt(cdCfg.para4)*60*60*1000L;
		if(System.currentTimeMillis() < (prop.getLastuploadtime()+cd)){
			knight.gsp.msg.Message.sendMsgNotify(roleid, 1039597);
			return;
		}
		
		final SResponseImageLoadToken imageLoadToken = new SResponseImageLoadToken();
		imageLoadToken.costmoney = CSaveUploadURL.getCostMoneyForImageUpload(roleid);
		if(imageLoadToken.costmoney < 0)
			return;
		
		if(prop.getImagetokentimeout() == 0 || (prop.getImagetokentimeout() - System.currentTimeMillis())
				< 600*1000){
			refreshImageDownloadToken(roleid, imageLoadToken);
		}else{
			String filePath = knight.gsp.util.QiniuSDKUtil.getFilePathByRoleid(roleid);
			imageLoadToken.filename = filePath;
			imageLoadToken.token = prop.getImagedowntoken();
			gnet.link.Onlines.getInstance().send(roleid, imageLoadToken);
		}
		
	}

	private void refreshImageDownloadToken(final long roleid, final SResponseImageLoadToken imageLoadToken) {
		new xdb.Procedure(){
			@Override
			public boolean process(){
				String token = knight.gsp.util.QiniuSDKUtil.uploadImageTokenWithDeadline(roleid);
				long timeout = System.currentTimeMillis() + knight.gsp.main.ConfigManager.TIMEOUT*1000;
				
				xbean.HeadImageInfo prop = xtable.Headimageinfo.get(roleid);
				if(prop == null){
					prop = xbean.Pod.newHeadImageInfo();
					xtable.Headimageinfo.insert(roleid, prop);
				}
				prop.setImagedowntoken(token);
				prop.setImagetokentimeout(timeout);
				imageLoadToken.filename = knight.gsp.util.QiniuSDKUtil.getFilePathByRoleid(roleid);
				imageLoadToken.token = token;
				xdb.Procedure.psendWhileCommit(roleid, imageLoadToken);
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786532;

	public int getType() {
		return 786532;
	}


	public CRequestImageLoadToken() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CRequestImageLoadToken) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CRequestImageLoadToken _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

