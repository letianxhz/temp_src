package knight.gsp;

import gnet.DataBetweenAuAnyAndGS;

public abstract class DataBetweenAuAnyAndGSHandler {
	protected DataBetweenAuAnyAndGSHandler successor;
	
	public abstract void handleReq(DataBetweenAuAnyAndGS data);
	
	public void setSuccessor(DataBetweenAuAnyAndGSHandler successor) {
		this.successor = successor;
	}
}
