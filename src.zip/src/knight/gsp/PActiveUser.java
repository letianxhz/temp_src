package knight.gsp;

import gnet.link.Onlines;
import knight.gsp.activesn.ActiveSnModule;
import knight.gsp.main.ConfigManager;
import knight.gsp.yuanbao.YuanbaoManager;
import xbean.AUUserInfo;
import xdb.Procedure;
import xdb.util.UniqName;

/**
 * ClassName:PActiveUser
 */
public class PActiveUser extends Procedure {

	private final int userid;
	private final String snString;
	private final xio.Protocol protocol;
	
	public PActiveUser(int userid, String snString,xio.Protocol protocol) {

		super();
		this.userid = userid;
		this.snString = snString;
		this.protocol = protocol;
	}
	@Override
	protected boolean process() throws Exception {
		long curTime = System.currentTimeMillis();
		xbean.TimeLimitInfo timeLimitInfo = xtable.Operatortime4user.get(userid);
		xbean.AUUserInfo userinfo = xtable.Auuserinfo.get(userid);
		if(userinfo == null) {
			return false;
		}
		if (timeLimitInfo == null){
			timeLimitInfo = xbean.Pod.newTimeLimitInfo();
			xtable.Operatortime4user.insert(userid, timeLimitInfo);
		}
		
		Long lastTime = timeLimitInfo.getActiveuser();
		if (lastTime != null && curTime - lastTime < 1000) {
			return true;
		}
        timeLimitInfo.setActiveuser(curTime);
        
        //服务器是否开启
        boolean serverStart = System.currentTimeMillis() >= ConfigManager.getServerOpenTime() ? true : false;
        String snString = this.snString.toLowerCase();
        
        //验证激活码和平台是否匹配
        boolean match = true;
        if(ActiveSnModule.snInWhiteSet(snString)) {
        	match = true;
        } else if(!ActiveSnModule.snIn360SnSet(snString) && !ActiveSnModule.snInCommonSnSet(snString)) {
        	//不在任何激活码set中
        	match = false;
        } else {
        	if(is360(userinfo.getPlatform()) && !ActiveSnModule.snIn360SnSet(snString)) {
            	//360平台用户,但是激活码不是360平台的激活码
            	match = false;
            } 
            if(!is360(userinfo.getPlatform()) && !ActiveSnModule.snInCommonSnSet(snString)) {
            	//非360平台用户,但是激活码也不是通用平台的激活码
            	match = false;
            } 
        }
        if(!match) {
        	Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.SN_WRONG, ""));	
			return false;
        }
        if(serverStart) {
        	//服务器开启了
        	return activeAndEnter(snString, userinfo);
        } else {
        	if(ActiveSnModule.snInWhiteSet(snString)) {
            	//白名单中的激活码
        		return activeAndEnter(snString, userinfo);
            } else {
            	return justActive(snString, userinfo);
            } 
        }
	}
	
	private boolean activeAndEnter(String sn, AUUserInfo userinfo) {
		//存在说明已经激活,可以直接进入游戏
        if (UniqName.exist("activeuser", String.valueOf(userid))!= UniqName.RPC_NOT_EXISTS){
			Onlines.getInstance().getOnlineUsers().online(protocol);
			return true;
		}
		
        //如果激活码已经被使用
		if (UniqName.exist("cdkey", sn)!= UniqName.RPC_NOT_EXISTS){
			Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.SN_USED, ""));	
			return false;
		}
		
		if(is360(userinfo.getPlatform())){
			if (UniqName.allocate("activeuser", String.valueOf(userid))) {
				Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.ACTIVE_AND_ENTER, ""));
				Onlines.getInstance().getOnlineUsers().online(protocol);
				//记录激活码
				ActiveSnModule.putUsedSnToSnMap(userid, sn, userinfo);
				
				return true;
			}else{
				return false;
			}
		}
		
		if (!is360(userinfo.getPlatform()) && UniqName.allocate("cdkey", sn)) {
			if (UniqName.allocate("activeuser", String.valueOf(userid))) {
				Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.ACTIVE_AND_ENTER, ""));
				Onlines.getInstance().getOnlineUsers().online(protocol);
				//记录激活码
				ActiveSnModule.putUsedSnToSnMap(userid, sn, userinfo);
				
				return true;
			}
		}else {
			//激活失败,可能在同时被其他人用了
			return false;
		}
		return false;
	}
	
	private boolean justActive(String sn, AUUserInfo userinfo) {
		//存在说明已经激活,可以直接进入游戏
        if (UniqName.exist("activeuser", String.valueOf(userid))!= UniqName.RPC_NOT_EXISTS){
        	Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.HAS_ACTIVED, ""));
			return false;
		}
		
        //如果激活码已经被使用
		if (UniqName.exist("cdkey", sn)!= UniqName.RPC_NOT_EXISTS){
			Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.SN_USED, ""));	
			return false;
		}
		
		if(is360(userinfo.getPlatform())){
			if (UniqName.allocate("activeuser", String.valueOf(userid))) {
				Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.JUST_ACTIVE, ""));
				//记录激活码
				ActiveSnModule.putUsedSnToSnMap(userid, sn, userinfo);
				
				return true;
			}else{
				return false;
			}
		}
		
		//360激活码可以重复使用
		
		if (!is360(userinfo.getPlatform()) && UniqName.allocate("cdkey", sn)) {
			if (UniqName.allocate("activeuser", String.valueOf(userid))) {
				Onlines.getInstance().sendResponse(protocol, new SUserNeedActive((byte) SUserNeedActive.JUST_ACTIVE, ""));
				//记录激活码
				ActiveSnModule.putUsedSnToSnMap(userid, sn, userinfo);
				
				return true;
			}
		}else {
			//激活失败,可能在同时被其他人用了
			return false;
		}
		return false;
	}
	/**
	 * 是否为360平台
	 * @param platform
	 * @return
	 */
	private boolean is360(String platform) {
		if(YuanbaoManager.QI_HO.equals(platform)) {
			return true;
		}
		return false;
	}
	
//	private void kickUser(int error) {
//		Kick p1 = new Kick();
//		p1.linksid = ((Dispatch)protocol.getContext()).linksid;
//		p1.action = Kick.A_QUICK_CLOSE;
//		p1.error = error;
//		Onlines.sendProtocl(p1, protocol.getConnection());
//	}
}

