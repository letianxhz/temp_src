
package knight.gsp;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import org.json.JSONObject;
import knight.gsp.item.EmailBox;
import knight.gsp.main.ConfigManager;
import knight.gsp.msg.Message;
import gnet.link.Onlines;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CBindWeixinSucc__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CBindWeixinSucc extends __CBindWeixinSucc__ {
	@Override
	protected void process() {
		final long roleId = Onlines.getInstance().findRoleid(this);
		if (roleId <= 0 || LocalIds.isRemoteServerRole(roleId))
			return;
		xbean.Properties rprop = xtable.Properties.select(roleId);
		if (rprop == null || rprop.getHasgetweixinbindaward())
			return;
		
		HttpURLConnection connection = null;
		try {
			String url = "http://wx.ledo.com/ledo/business/checkBindInfo";
			String params = "gameId=11&roleId=" + roleId +"&serverId=" + ConfigManager.getGsZoneId() + "&rolename=" + rprop.getRolename();
			byte[] entity = params.getBytes("UTF-8");// 得到实体数据
			connection = (HttpURLConnection) new URL(url).openConnection();
			connection.setConnectTimeout(5000);
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);// 允许对外输入数据
			connection.setDoInput(true);
			connection.setUseCaches(false);
			// 设置请求的请求头
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			connection.setRequestProperty("Content-Length", entity.length + "");
			connection.connect();
			DataOutputStream out = new DataOutputStream(connection.getOutputStream());// 获取输出流对象
			out.write(entity);// 数据并没有开始写给服务器，只有企图得到服务器返回的响应的某个数据时才会开始发送数据请求服务器
			out.close();
			String result = null;
			if (connection.getResponseCode() == 200) {
				final InputStream is = connection.getInputStream();
				InputStreamReader in = new InputStreamReader(is, "UTF-8");
				BufferedReader buffer = new BufferedReader(in, 4096);
				StringBuilder resultDataBuilder = new StringBuilder();
				int linenum = 0;
				int maxlinenum = 0;
				while( true) {
					final String line = buffer.readLine();
					if( null == line)
						break;
					resultDataBuilder.append( line);
					linenum++;
					if(maxlinenum > 0 && linenum >= maxlinenum)
						break;
				}
				
				result = resultDataBuilder.toString();
				
				is.close();
			} else {
				return;
			}
			
			JSONObject jsonObj = new JSONObject(result);
			if (result == null)
				return;
			
			if (jsonObj != null) {
				String retCode = jsonObj.getString("ret_code");
				if (!retCode.equals("0")) {
					knight.gsp.log.Module.logger.error("角色" + roleId + "微信绑定结果：" + retCode);
					return;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			connection.disconnect();
			return;
		}
		
		
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				xbean.Properties prop = xtable.Properties.get(roleId);
				if (prop == null || prop.getHasgetweixinbindaward())
					return false;
				
				prop.setHasgetweixinbindaward(true);
				EmailBox emailBox = new EmailBox(roleId, false);
				emailBox.sendMail(153);
				
				List<xbean.EmailDetail> mails = emailBox.setMailStateByTemplateId(158);
				if (mails.size() > 0)
				{
					for (xbean.EmailDetail detail : mails) {
						byte tabType = (byte) EmailBox.calcTab(detail.getMailtype());
						emailBox.rmMail(tabType, detail.getKey(), EmailBox.DEL_ONE, EmailBox.DEL_AUTO);
					}
				}
				
				Message.psendMsgNotify(roleId, 1039472);
				
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786545;

	public int getType() {
		return 786545;
	}


	public CBindWeixinSucc() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CBindWeixinSucc) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CBindWeixinSucc _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

