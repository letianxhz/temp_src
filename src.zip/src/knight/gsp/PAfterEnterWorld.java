package knight.gsp;


import gnet.link.Onlines;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import knight.gsp.activity.ActivityModule;
import knight.gsp.activity.AnswerQuestionManger;
import knight.gsp.activity.AnswerQuestionWrapper;
import knight.gsp.activity.AwardState;
import knight.gsp.activity.LevelUpAward;
import knight.gsp.activity.LoginAwardManger;
import knight.gsp.activity.PInitSevenDaysGift;
import knight.gsp.activity.SOPenWeaterMelonPanel;
import knight.gsp.activity.VerifyPhoneNumberManager;
import knight.gsp.activity.activeness.ActivenessManager;
import knight.gsp.activity.aprilfoolsday.AprilFoolsDayManager;
import knight.gsp.activity.daluandou.DaLuanDouManager;
import knight.gsp.activity.daluandou.PClearDaLuanDouOldScore;
import knight.gsp.activity.guangyingduijue.GuangYingManager;
import knight.gsp.activity.guangyingduijue.PClearGuangYingOldData;
import knight.gsp.activity.guoqing.GuoqingManager;
import knight.gsp.activity.guoqing.PClearOldActivityData;
import knight.gsp.activity.jdcard.PGiveJdCardDirectly;
import knight.gsp.activity.newservergift.NewServerGiftManager;
import knight.gsp.activity.phonenumreward.SPhoneNumRewardState;
import knight.gsp.activity.phonenumreward.SUpdatePhoneRewardEnable;
import knight.gsp.activity.procedure.OnlinesTimesAwardManager;
import knight.gsp.activity.procedure.PQiandaoTimesStatistics;
import knight.gsp.activity.retrievereward.RetrieveRewardRole;
import knight.gsp.activity.sologhost.SoloGhostManager;
import knight.gsp.activity.springfestival.jjsf.JinJiSongFuManager;
import knight.gsp.activity.springfestival.pray.PRemoveNewYearPrayTask;
import knight.gsp.activity.summerday.SummerDayManager;
import knight.gsp.activity.treasure.TreasureManager;
import knight.gsp.anniversary.AnniversaryActivityManager;
import knight.gsp.anniversary.PCheckAndResetAnHeiBi;
import knight.gsp.anniversary.PSendQianmingStatus;
import knight.gsp.anniversary.Util;
import knight.gsp.camp.CampLearder;
import knight.gsp.camp.CampRole;
import knight.gsp.camp.SCampLeader;
import knight.gsp.family.crossfamilybattle.PSendCrossFightMsg;
import knight.gsp.fightspirit.FightSpiritSystemManager;
import knight.gsp.friends.POfflineMsgSender;
import knight.gsp.fuben.FubenRole;
import knight.gsp.fuben.SSetAutoFanpai;
import knight.gsp.fuben.SSetAutoRecoverState;
import knight.gsp.fuben.challenge.ChallengeManager;
import knight.gsp.fuben.pvp4.PClearPvp4OldScore;
import knight.gsp.fuben.pvp4.Pvp4Manager;
import knight.gsp.fuben.pvp8.PClearPvp8OldScore;
import knight.gsp.fuben.ragnarok.RagnarokManager;
import knight.gsp.game.Slandreward;
import knight.gsp.game.Sspecialpara;
import knight.gsp.game.sguajipos;
import knight.gsp.giftbag.dayfirst.DayFirstCashColumn;
import knight.gsp.giftbag.dayfirst.DayFirstCashManager;
import knight.gsp.giftbag.daygift.DayCashManager;
import knight.gsp.giftbag.daygift.DayConsumeManager;
import knight.gsp.giftbag.daygift.DaysConsumeManager;
import knight.gsp.giftbag.daygift.EveryDayConsumeColumn;
import knight.gsp.giftbag.daygift.EveryDayPayColumn;
import knight.gsp.giftbag.daygift.MiniCashColumn;
import knight.gsp.giftbag.daygift.MiniCashManager;
import knight.gsp.giftbag.daygift.PlatDaysConsumeManager;
import knight.gsp.giftbag.daygift.PlatEveryChargeColumn;
import knight.gsp.giftbag.daygift.PlatEveryChargeManager;
import knight.gsp.giftbag.ffl.FFLManager;
import knight.gsp.giftbag.handler.ChargeGift2Handler;
import knight.gsp.giftbag.handler.ChargeGiftHandler;
import knight.gsp.giftbag.handler.PlatChargeGiftHandler;
import knight.gsp.giftbag.lianliankan.LLKanManager;
import knight.gsp.giftbag.sjq.SjqManager;
import knight.gsp.imagechallenge.ImageChallengeManager;
import knight.gsp.item.BagTypes;
import knight.gsp.item.PMoveExtraEquipToBag;
import knight.gsp.item.PResizeBagCapacity;
import knight.gsp.item.SAddItemsToForge;
import knight.gsp.item.SSendForgeInfo;
import knight.gsp.item.forge.ForgeRole;
import knight.gsp.item.juexing.JueXingRole;
import knight.gsp.item.shop.PLimitShop;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.mercenary.proc.FaZhenSystemMangager;
import knight.gsp.msg.Message;
import knight.gsp.msg.PSetFrameState;
import knight.gsp.ranklist.RankType;
import knight.gsp.ranklist.flower.FlowerScoreShopManager;
import knight.gsp.ride.RideEquips;
import knight.gsp.ride.RideManager;
import knight.gsp.shenqi.ShenQiRole;
import knight.gsp.skill.SkillManager;
import knight.gsp.spvp.pspvp.PSPvPManager;
import knight.gsp.spvp.pspvp.pcocedure.PSendPvpBetReturn;
import knight.gsp.state.StateManager;
import knight.gsp.sworn.SwornManager;
import knight.gsp.task.activelist.PlayActiveRole;
import knight.gsp.team.STipoffMessageSenderTimes;
import knight.gsp.team.ghost.TeamGhostManager;
import knight.gsp.title.Title;
import knight.gsp.util.DateValidate;
import knight.gsp.util.Misc;
import knight.gsp.wed.SCoupleInfo;
import knight.gsp.wed.WedManager;
import knight.gsp.yuanbao.GoodsCashType;
import knight.gsp.yuanbao.PRefreshChargeGuide;
import knight.gsp.yuanbao.YuanbaoManager;
import knight.gsp.yuyin.RoomManager;
import xdb.Procedure;


// 进入游戏
public class PAfterEnterWorld extends Procedure {

	private final int userId;

	private final long roleId;

	public PAfterEnterWorld(int userID, long roleid) {
		this.userId = userID;
		this.roleId = roleid;
	}
	
	/* (non-Javadoc)
	 * @see xdb.Procedure#process()
	 */
	protected boolean process() {
		xbean.User user = xtable.User.get(userId);
		if (user == null) {
			// 没有找到该USERID
			StateManager.logger.error("没有找到该USERID=" + userId);
			return false;
		}
		user.setPrevloginroleid(roleId);
		try {
			knight.gsp.event.Poster.getPoster().dispatchEvent(new knight.gsp.event.EnterWorldEvent(roleId));
		}
		catch(Exception e){
			StateManager.logger.error("EnterWorldEvent错误：" , e);
		}
		try {// 发送玩家的元宝信息
			final knight.gsp.yuanbao.YbNum ybNum = new knight.gsp.yuanbao.YbNum(roleId,false);
			ybNum.clearDayCash(System.currentTimeMillis());
			final knight.gsp.yuanbao.Vip vip = new knight.gsp.yuanbao.Vip(roleId, false);
			//改为上线不单独发送元宝刷新消息了，元宝数量放在RoleDetail里面了
			//YuanbaoManager.refreshRoleYuanbao(roleId, ybNum);
			YuanbaoManager.refreshRoleVip(roleId, vip,ybNum);
			new Procedure(){
				public boolean process() throws Exception{
					vip.checkAndRefreshBuyTime(System.currentTimeMillis());
					vip.sendSBuyTimes();
					return true;
				}
			}.call();
		}catch (Exception e) {
			StateManager.logger.error("刷新元宝个数错误：" , e);
		}
		try{
			new PLimitShop(roleId,System.currentTimeMillis()).call();
		}catch (Exception e){
			StateManager.logger.error("刷新限时商品购买：" , e);
		}
		try {// 发送新手引导
			final knight.gsp.SShowedBeginnerTips sendTips = new knight.gsp.SShowedBeginnerTips();
			final xbean.BeginnerTip bt = xtable.Beginnertip.select(roleId);
			if (bt != null) {
				for (final Map.Entry<Integer, Integer> e : bt.getTips().entrySet()) {
					if (e.getValue() == 1) {
						sendTips.tipid.add(e.getKey());
					}
				}
			}
			xdb.Procedure.psendWhileCommit(roleId, sendTips);
		}
		catch(Exception e){
			StateManager.logger.error("发送新手引导错误：" , e);
		}
		try {
			xtable.Repurchase.remove(roleId);
		} catch (Exception e) {
			StateManager.logger.error("删除回购栏错误：" , e);
		}
		
		try {
			xdb.Procedure.psendWhileCommit(roleId, ActivityStatusManager.getInstance().getActivityStatus(roleId));
		} catch (Exception e){
			StateManager.logger.error("获取活动开关状态失败：" , e);
		}
		
		//语音开关
		try {
			xdb.Procedure.psendWhileCommit(roleId, RoomManager.getInstance().sendSSwitchStatus2Role(roleId));
		} catch (Exception e){
			StateManager.logger.error("发送语音开关状态失败：" , e);
		}
		// 刷新充值引导
		try
		{
			new PRefreshChargeGuide(roleId, true).call();
		}
		catch (Exception e)
		{
			StateManager.logger.error("上线处理充值引导",e);
		}
		//处理登陆活动信息
		try{
			xbean.LoginActivityBean bean = xtable.Loginactivity.get(roleId);
			
			if (bean == null) {
				//判断是否为首次登陆
				Calendar cal = Calendar.getInstance();
				int currMonth = cal.get(Calendar.MONTH) + 1;
				
				//初始化bean
				bean = xbean.Pod.newLoginActivityBean();
				Slandreward monthCfg = LoginAwardManger.getInstance().getLoginCfgById(currMonth);
				for(int i = 0; i < monthCfg.getItems().size(); i++) {
					bean.getLoginawardmap().put(i + 1, AwardState.NOT_FINISH);
				}
				xtable.Loginactivity.insert(roleId, bean);
			}
			if (bean.getState() == LoginAwardManger.INIT_STATE) {
				bean.setState(LoginAwardManger.FIRST_ENTER_STATE);
				new PQiandaoTimesStatistics(roleId, LoginAwardManger.MSG_IMAGE_LIGHT, true).call();
			} else if(bean.getState() == LoginAwardManger.FIRST_ENTER_STATE) {
				bean.setState(LoginAwardManger.NON_FIRST_ENTER_STATE);
				new PQiandaoTimesStatistics(roleId, LoginAwardManger.MSG_OPEN_PANEL, false).call();
			} else {
				new PQiandaoTimesStatistics(roleId, LoginAwardManger.MSG_OPEN_PANEL, false).call();
			}
			
		} catch (Throwable th) {
			StateManager.logger.error("登陆活动处理失败：" , th);
		}
		
		//处理答题信息
		try{
			AnswerQuestionWrapper wrapper = new AnswerQuestionWrapper(roleId, false);
			if(!DateValidate.inTheSameDay(wrapper.getStartTime(), System.currentTimeMillis()) || 
					(!AnswerQuestionManger.getInstance().isInAnswerTime() && wrapper.isAnswering())) {
				//重置答题信息
				wrapper.reset();
			}
		} catch (Exception e) {
			StateManager.logger.error("登陆活动处理失败：" , e);
		}
		
		//发送聊天常用语
		try {
			Message.sendFrequentlyMsg(roleId);
		} catch (Exception e) {
			StateManager.logger.error("发送聊天常用语失败：" , e);
		}
		
		//在线礼包信息
		try{
			OnlinesTimesAwardManager.getInstance().refreshOnlinesInfos(roleId);
			OnlinesTimesAwardManager.getInstance().checkAndSendMorrowPresent(roleId);
		} catch (Exception e) {
			StateManager.logger.error("在线礼包活动处理失败：" , e);
		}
		//升级奖励
		try{
			LevelUpAward award = new LevelUpAward(roleId,true);
			award.onLevelChange(xtable.Properties.selectLevel(roleId).shortValue());
			award.sendLevelAwards();
		}catch(Exception e){
			StateManager.logger.error("冲级奖励处理失败：" , e);
		}
		
		try{
			ChallengeManager.getInstance().refreshChallengeDataWhileEnterWorld(roleId);
		}catch(Exception e){
			StateManager.logger.error("上线巴别塔信息失败：" , e);
		}
		try {
			byte autoRecoverState = 0;
			xbean.AutoBattleItemUseRole autoBattleItemUseRole = xtable.Autobattleitemuseroles.select(roleId);
			if (autoBattleItemUseRole != null && autoBattleItemUseRole.getIsautorecover())
				autoRecoverState = 1;
			
			xdb.Procedure.psendWhileCommit(roleId, new SSetAutoRecoverState(autoRecoverState));
			if (autoBattleItemUseRole != null && autoBattleItemUseRole.getIsautofanpai())
				xdb.Procedure.psendWhileCommit(roleId, new SSetAutoFanpai((byte) 1));
		} catch (Exception e) {
			StateManager.logger.error("上线发送自动战斗自动复活状态异常：" , e);
		}
		
		try {
			ChargeGiftHandler handler = (ChargeGiftHandler)knight.gsp.giftbag.GiftBagModule.getInstance().getGiftEventHandlerByType((short)xbean.Gift.CHARGE_GIFT);
			handler.sendChargeGiftInfo(roleId);
		} catch (Exception e) {
			StateManager.logger.error("首冲礼包：" , e);
		}
		try {
			ChargeGift2Handler handler = (ChargeGift2Handler)knight.gsp.giftbag.GiftBagModule.getInstance().getGiftEventHandlerByType((short)xbean.Gift.CHARGE_GIFT2);
			handler.sendChargeGiftInfo(roleId);
		} catch (Exception e) {
			StateManager.logger.error("充值送礼2：" , e);
		}
		try {
			PlatChargeGiftHandler platHander = (PlatChargeGiftHandler)knight.gsp.giftbag.GiftBagModule.getInstance().getGiftEventHandlerByType((short)xbean.Gift.PLAT_CHARGE_GIFT);
			platHander.sendChargeGiftInfo(roleId);
		} catch (Exception e) {
			StateManager.logger.error("首冲礼包：" , e);
		}
		
		try {
			xdb.Procedure.pexecuteWhileCommit(new POfflineMsgSender(roleId));
		} catch (Throwable e) {
			StateManager.logger.error("执行离线消息错误：" , e);
		}
		
		try {
			xdb.Procedure.pexecuteWhileCommit(new PSendCrossFightMsg(roleId));
		}  catch (Throwable e) {
			StateManager.logger.error("执行跨服家族战按钮状态离线消息错误：", e);
		}
		
		try{
			knight.gsp.yuanbao.CreditReturnManager.acceptCreditReturnTask(roleId, userId);
		} catch (Throwable e){
			StateManager.logger.error("接受充值返还任务失败" , e);
		}
		try{
			knight.gsp.yuanbao.LMZZAwardManager.acceptLMZZAwardTask(roleId);
		} catch (Throwable e){
			StateManager.logger.error("接受黎明之战奖励任务失败" , e);
		}
		
		
		try{
			knight.gsp.giftbag.lsbz.LsbzManager.sendInAc(roleId);
			new knight.gsp.giftbag.lsbz.LsbzColumn(roleId, false).clearDayData(System.currentTimeMillis());
		}catch(Throwable e){
			StateManager.logger.error("发送龙神宝藏" , e);
		}
		
		try{
			new knight.gsp.yuanbao.PSendYbWithMail(roleId,GoodsCashType.MONTHCARD).call();
		}catch(Throwable e){
			StateManager.logger.error("上线月卡钻石返还发送失败",e);
		}
		
		try{
			new knight.gsp.yuanbao.PSendYbWithMail(roleId,GoodsCashType.JUNXUCARD).call();
		}catch(Throwable e){
			StateManager.logger.error("上线军需卡钻石返还发送失败",e);
		}
		
		try{
			new knight.gsp.yuanbao.PSendYbWithMail(roleId,GoodsCashType.ENDNESSCARD).call();
		}catch(Throwable e){
			StateManager.logger.error("上线永久月卡钻石返还发送失败",e);
		}
		
		try{
			EveryDayPayColumn day = new EveryDayPayColumn(roleId, false);
			day.refresh(System.currentTimeMillis());
			DayCashManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("上线发送每日充值活动失败");
		}
		try{
			PlatEveryChargeColumn day = new PlatEveryChargeColumn(roleId, false);
			day.refresh(System.currentTimeMillis());
			PlatEveryChargeManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("上线发送每次充值活动失败");
		}
		try{
			MiniCashColumn mini = new MiniCashColumn(roleId, false);
			mini.exchangeProToProNum();
			mini.refresh(System.currentTimeMillis());
			MiniCashManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("上线发送每日充值活动失败");
		}
		try{
			EveryDayConsumeColumn day = new EveryDayConsumeColumn(roleId, false);
			day.refresh(System.currentTimeMillis());
			DayConsumeManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("上线发送每日消费活动失败");
		}
		try{
			DaysConsumeManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("上线发送累计消费活动失败");
		}
		try{
			PlatDaysConsumeManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("上线发送平台累计消费活动失败");
		}
		try{
			DayFirstCashColumn column = new DayFirstCashColumn(roleId, false);
			column.cleanDay(System.currentTimeMillis());
			DayFirstCashManager.sendAllMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("每日首充消费活动失败");
		}
		try {
			NewServerGiftManager.sendPioneerMsgAfterEnterWold(roleId);
		} catch (Throwable e) {
			StateManager.logger.error("上线发送新服独享活动失败");
		}
		try{
			//手机号收集活动信息
			Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(ActivityModule.PHONE_NUM_REWARD_SPECIAL_PARA_ID);
			if(cfg != null) {
				if(cfg.para1 == 0) {
					//活动关闭了
					SUpdatePhoneRewardEnable stateMsg = new SUpdatePhoneRewardEnable((byte)0);
					xdb.Procedure.psendWhileCommit(roleId, stateMsg);
				} else {
					final long now = System.currentTimeMillis();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					final long start = sdf.parse(cfg.para4).getTime();
					final long end = sdf.parse(cfg.para5).getTime();
					if(now >= start && now <= end) {
						SPhoneNumRewardState newstate = new SPhoneNumRewardState();
						newstate.lefttime = (int) ((end - now) / 1000);
						xbean.PhoneNumRewardBean bean = xtable.Phonenumreward.select(roleId);
						if(bean == null) {
							newstate.hasgot = 0;
						} else {
							newstate.hasgot = (byte) bean.getState();
						}
						xdb.Procedure.psendWhileCommit(roleId, newstate);
					}
				}
			}
		} catch(Throwable e){
			StateManager.logger.error("上线发送手机号收集活动信息失败");
		}

		new PSetFrameState(roleId, PSetFrameState.ACTION_CLEAR).call();
		
		try{
			//清空老的情人节活动送花收花数据
			xbean.FlowersInfo flowersInfo = xtable.Flowersinfo.get(roleId);
			if(flowersInfo != null) {
				xbean.FlowersInfoDetail reciveInfo = flowersInfo.getAllflowersinfo().get(RankType.QIXI_RECIVE_FLOWER_RANK);
				if(reciveInfo != null) {
					//是否为同一轮的七夕活动
					if(FlowerScoreShopManager.getInstance().getActivityStartTime() > reciveInfo.getLastinsertdata()) {
						reciveInfo.setGivenum(0);
						reciveInfo.setHastakenumaward((short) 0);
						reciveInfo.setReceivenum(0);
						reciveInfo.setLastinsertdata(System.currentTimeMillis());
					}
				}
				xbean.FlowersInfoDetail sendInfo = flowersInfo.getAllflowersinfo().get(RankType.QIXI_SEND_FLOWER_RANK);
				if(sendInfo != null) {
					//是否为同一轮的七夕活动
					if(FlowerScoreShopManager.getInstance().getActivityStartTime() > sendInfo.getLastinsertdata()) {
						sendInfo.setGivenum(0);
						sendInfo.setReceivenum(0);
						sendInfo.setHastakenumaward((short) 0);
						sendInfo.setLastinsertdata(System.currentTimeMillis());
					}
				}
			}
		}catch(Throwable e){
			StateManager.logger.error("清空老的情人节活动送花收花数据失败");
		}
		
		try{
			//清空老的情人节活动送花收花数据
			xbean.FlowersInfo flowersInfo = xtable.Flowersinfo.get(roleId);
			if(flowersInfo != null) {
				xbean.FlowersInfoDetail reciveInfo = flowersInfo.getAllflowersinfo().get(RankType.VALENTINE_RECIVE_FLOWER_RANK);
				if(reciveInfo != null) {
					//是否为同一轮的情人节活动
					if(DateValidate.getDays(System.currentTimeMillis(), reciveInfo.getLastinsertdata()) > 30) {
						reciveInfo.setGivenum(0);
						reciveInfo.setReceivenum(0);
						reciveInfo.setLastinsertdata(System.currentTimeMillis());
					}
				}
				xbean.FlowersInfoDetail sendInfo = flowersInfo.getAllflowersinfo().get(RankType.VALENTINE_SEND_FLOWER_RANK);
				if(sendInfo != null) {
					//是否为同一轮的情人节活动
					if(DateValidate.getDays(System.currentTimeMillis(), sendInfo.getLastinsertdata()) > 30) {
						sendInfo.setGivenum(0);
						sendInfo.setReceivenum(0);
						sendInfo.setLastinsertdata(System.currentTimeMillis());
					}
				}
			}
		}catch(Throwable e){
			StateManager.logger.error("清空老的情人节活动送花收花数据失败");
		}
		
		try{
			RideManager.getInstance().initJinHuaInfo(roleId);
			RideManager.getInstance().sendRidePanelInfo(roleId);
			RideEquips rideEquips = new RideEquips(roleId,true);
			rideEquips.sendAllRides();
			RideManager.getInstance().sendSkillPanel(roleId, false);
		}catch(Throwable e){
			StateManager.logger.error("发送坐骑装备失败", e);
		}
		
		try{
			FFLManager manager = knight.gsp.yuanbao.Module.getInstance().getFFflManager();
			FFLManager.sendAllMsg(roleId, manager.getReadyToOpen(System.currentTimeMillis()));
		}catch(Throwable e){
			StateManager.logger.error("翻翻乐" + e);
		}
		try{
			LLKanManager manager = knight.gsp.yuanbao.Module.getInstance().getLlkanManager();
			LLKanManager.sendAllMsg(roleId, manager.getReadyToOpen(System.currentTimeMillis()));
		}catch(Throwable e){
			StateManager.logger.error("连连看" + e);
		}
		try{
			SjqManager manager = knight.gsp.yuanbao.Module.getInstance().getSjqManager();
			manager.sendOpenSjqMsg(roleId, 0);
		}catch(Throwable e){
			StateManager.logger.error("水晶球" + e);
		}
		xdb.Procedure.pexecuteWhileCommit(new PSendPvpBetReturn(roleId));
		try {
			//验证手机号上线发送,yangzhenyu
			VerifyPhoneNumberManager.getInstance().roleOnline(roleId);
		} catch (Throwable th) {
			StateManager.logger.error("验证手机号" + th);
		}
		xdb.Procedure.pexecuteWhileCommit(new PGiveJdCardDirectly(roleId));
		new PInitSevenDaysGift(roleId).call();
		SkillManager.getInstance().checkAndSendSchoolAdvanceTaskState(roleId);
		
		TeamGhostManager.onRoleEnterWorld(roleId);
		
		RagnarokManager.getInstance().onRoleEnterWord(roleId);
		
		try {
			if (xtable.Properties.selectLevel(roleId) >= 28 && xtable.Sologhost.select(roleId) == null) {
				int posId = Misc.getRandom(ConfigManager.getInstance().getConf(sguajipos.class).keySet());
				SoloGhostManager.getInstance().giveNextMonster(roleId, posId);
			}
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		pexecuteWhileCommit(new Procedure(){
			@Override
			protected boolean process() throws Exception {
				CampRole campRole = new CampRole(roleId, false);
				int camp = campRole.getStandCamp();
				if(camp > 0){
					CampLearder leader = new CampLearder(camp, false);
					SCampLeader sCampLeader=leader.getSCampLeader();
					if(sCampLeader!=null){
						psendWhileCommit(roleId, sCampLeader);
					}
				}
				return true;
			}
		});
		
		pexecuteWhileCommit(new PMoveExtraEquipToBag(roleId));
		
		TreasureManager.getInstance().onRoleEnterWorld(roleId);
		
		PlayActiveRole.getPlayActiveRole(roleId, false).sendActivityAward();
		
		new FubenRole(roleId, true).sendSharedHelpcount();
		
		try {
			//进入游戏时发送神器数据
			new ShenQiRole(roleId, true).onRoleEnterWorld();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			new RetrieveRewardRole(roleId, false).onAfterEnterWorld();
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		//夏日清凉活动
		try{
			if (SummerDayManager.getInstance().isOpen()) {
				SummerDayManager.getInstance().clearOldactData(roleId);
				xbean.SummerDay xSummerDay = xtable.Summerday.select(roleId);
				if (xSummerDay == null) 
					xSummerDay = xbean.Pod.newSummerDay();
				SOPenWeaterMelonPanel msg = new SOPenWeaterMelonPanel();
				msg.isswon = xSummerDay.getIsswon();
				msg.dree = xSummerDay.getDegree();
				msg.reapaward = xSummerDay.getReapaward();
				Onlines.getInstance().send(roleId, msg);
				}
		}catch (Throwable th) {
			th.printStackTrace();
		}

		try {
			Title title = new Title(roleId, false);
			List<Integer> removeTitleIds = new ArrayList<Integer>();
			for (int titleid : SwornManager.getAllSwornTitleId()) {
				if (title.roleHasTitle(titleid)) {
					removeTitleIds.add(titleid);
				}
			}
			int szie = removeTitleIds.size();
			if (szie > 1) {//将多余的结拜称谓删掉
				Collections.sort(removeTitleIds);
				removeTitleIds.remove(szie - 1);
				for (int rmid : removeTitleIds) {
					title.removeTitle(rmid);
				}
			}
		} catch(Throwable e){
			StateManager.logger.error("清空结拜称谓失败", e);
		}
		//同步活跃度排行奖励领取状态
		try{
			ActivenessManager.getInstance().sendRankRewardStatus(roleId);
		}catch(Throwable th ){
			th.printStackTrace();
		}
		
		new PResizeBagCapacity(roleId, Arrays.asList(BagTypes.FASHION_BAG)).call();
		
		PSPvPManager.getInstance().notifyShowIcon(roleId);
		//上线的时候同步一下数据
		ServerInfoProvider.syncRoleInfoToGlobal(roleId);
		
		xbean.ChatTipoff bean = xtable.Chattipoffs.select(roleId);
		Sspecialpara para = ConfigManager.getInstance().getConf(Sspecialpara.class).get(298);
		int tipoffTimes = 0;
		if(bean != null){
			tipoffTimes = bean.getTimes();
		}
		Onlines.getInstance().send(roleId, new STipoffMessageSenderTimes(para.para1 - tipoffTimes));
		
		FlowerScoreShopManager.getInstance().sendStatusWhileLogin(roleId);
		
		try {
			// 欢乐抽奖入口
			xdb.Procedure.pexecuteWhileCommit(new knight.gsp.item.joylotto.PSendJoyLottoEntrance(roleId));
			xbean.RoleJoyLottoBean roleJoyLottoBean = xtable.Rolejoylotto.select(roleId);
			if (roleJoyLottoBean != null && roleJoyLottoBean.getWinperiod() > 0)
				xdb.Procedure.pexecuteWhileCommit(new knight.gsp.item.joylotto.PSendJoyLottoTrumpet(roleId));
		} catch (Exception e) {
			StateManager.logger.error("发送欢乐抽奖入口失败", e);
		}
		
		try {
			xdb.Procedure.pexecuteWhileCommit(new xdb.Procedure() {
				@Override
				protected boolean process() throws Exception {
					Pvp4Manager.getInstance().sendPvp4sportsOpenWhileOnline(roleId);
					Pvp4Manager.getInstance().sendRolePvp4BattleActState(roleId);
					return true;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Pvp4Manager.getInstance().sendPvp4BattleActStateWhileRoleOnlie(roleId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			xdb.Procedure.pexecuteWhileCommit(new PClearPvp4OldScore(roleId));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			StateManager.logger.error("诸神之王老数据清理失败", e);
		}
		
		try {
			xdb.Procedure.pexecuteWhileCommit(new PClearPvp8OldScore(roleId));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			StateManager.logger.error("太阳神之墓老数据清理失败", e);
		}
		
		try {
			new PClearDaLuanDouOldScore(roleId, DaLuanDouManager.getInstance().getSeasonEndTick()).call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		try {
			new PClearGuangYingOldData(roleId, GuangYingManager.getInstance().getSeasonEndTick()).call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			xdb.Procedure.pexecuteWhileCommit(new xdb.Procedure() {
				@Override
				protected boolean process() throws Exception {
					xbean.WedMemberData xData = xtable.Wedmember.select(roleId);
					if (null == xData)
						return false;
					xbean.WedBeanData xWedBeanData = xtable.Wedsdata.select(xData.getWedid());
					if (null == xWedBeanData) 
						return false;
					SCoupleInfo snd = new SCoupleInfo();
					snd.coupleinfo = WedManager.getInstance().getCoupleInfo(roleId, xWedBeanData);
					xdb.Procedure.psendWhileCommit(roleId, snd);
					return true;
				}
			});
		} catch (Exception e) {
			StateManager.logger.error("通知祝福按钮失败", e);
		}
		
		try {
			JinJiSongFuManager.getInstance().sendProtocolWhileEnterWorld(roleId);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		try {
			new PRemoveNewYearPrayTask(roleId).call();
		} catch (Exception e) {
			StateManager.logger.error("活动结束清理新春祈福任务失败", e);
		}
		try {
			AprilFoolsDayManager.getInstance().sendProtocolWhileEnterWorld(roleId);
		} catch (Throwable th) {
			th.printStackTrace();
		}
		Onlines.getInstance().send(roleId, new SZoneInfo(ConfigManager.getGsZoneId()));
		/*try {
			xtable.Gotowildrolecachedata.remove(roleId);
		} catch (Throwable th) {
			th.printStackTrace();
		}*/
		xdb.Procedure.pexecuteWhileCommit(new PCheckAndResetAnHeiBi(roleId));
		try{
			Util.sendMsg(roleId);
		}catch(Throwable e){
			StateManager.logger.error("周年活动时间", e);
		}
		if(AnniversaryActivityManager.getInstance().inActivityPeriod()){
			xdb.Procedure.pexecuteWhileCommit(new PSendQianmingStatus(roleId,false));
		}
		try {
			ForgeRole forgeRole = new ForgeRole(roleId, false);
			SSendForgeInfo snd = new SSendForgeInfo();
			snd.level = forgeRole.getLevel();
			snd.progress = forgeRole.getProgress();
			xdb.Procedure.psendWhileCommit(roleId,snd);
			xdb.Procedure.psendWhileCommit(roleId,new SAddItemsToForge(forgeRole.getMeltVal()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new JueXingRole(roleId, true).sendMsgWhileRoleEnterWord();
		try {
			GuoqingManager.getInstance().sendProtocolWhileEnterWorld(roleId);
			new PClearOldActivityData(roleId).call();
		} catch (Throwable th) {
			th.printStackTrace();
		}
		try {
			if(FaZhenSystemMangager.isOpen(roleId)){
				FaZhenSystemMangager.getInstance().sendZhenWeiSystemInfo(roleId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {// 战魂系统信息上线推送
			FightSpiritSystemManager.sendFightSpiritSystemInfo(roleId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try{
			ShenQiRole sRole = new ShenQiRole(roleId, false);
			sRole.fixShenfuNum();
		}catch(Exception e) {
			e.printStackTrace();
		}
		try {
			ImageChallengeManager.sendImageChallengeInfo(roleId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Long state = xtable.Gotowildrolecachedata.select(roleId);
			SConfirmGoToWildScene snd = new SConfirmGoToWildScene();
			snd.status = 0;
			if (state != null && state == 1){
				snd.status = 1;
			}
			xdb.Procedure.psendWhileCommit(roleId, snd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
}
