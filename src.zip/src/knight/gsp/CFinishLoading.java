
package knight.gsp;

import java.util.Arrays;

import gnet.link.Onlines;
import knight.gsp.activity.treasure.TreasureManager;
import knight.gsp.family.familyrobber.FamilyRobberManager;
import knight.gsp.fuben.OfflineFubenUtil;
import knight.gsp.fuben.PFubenFirstPassAward;
import knight.gsp.fuben.ragnarok.PRagnarokFinishLoading;
import knight.gsp.giftbag.handler.ShowGiftProcedure;
import knight.gsp.msg.Message;
import knight.gsp.ride.PRideShow;
import knight.gsp.scene.GFinsiLoading;
import knight.gsp.team.ghost.PGhostFinishLoading;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CFinishLoading__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CFinishLoading extends __CFinishLoading__ {
	@Override
	protected void process() {
		final long roleId = Onlines.getInstance().findRoleid(this);
		if (roleId <= 0)
			return;
		
		GsClient.psend2RoleSceneWhileCommit(roleId, new GFinsiLoading());
		//静态地图，弹出各种礼包
		final knight.gsp.map.Role role = knight.gsp.map.RoleManager.getInstance().getRoleByID(roleId);
		if(role == null) return;
		final long curSceneId = role.getScene();
		if(!role.isInDynamicScene() && !OfflineFubenUtil.checkInGS(roleId) && !role.isInBabelScene()){ 
			
			new xdb.Procedure(){
				protected boolean process() throws Exception {
					new ShowGiftProcedure(roleId).call();
					
					new knight.gsp.msg.PSendHuanjingHelpMsg(roleId).call();
					
					new PFubenFirstPassAward(roleId).call();
					
					pexecuteWhileCommit(new PGhostFinishLoading(roleId));
					
					pexecuteWhileCommit(new PRagnarokFinishLoading(roleId));
					
					TreasureManager.getInstance().onFinishLoading(roleId);
					
					if (curSceneId == 1017) {
						xbean.Rides rides = xtable.Rides.select(roleId);
						if (rides != null && rides.getOnrideid() > 0 && !rides.getIsshow()) {
							new PRideShow(roleId, (byte) 1).call();
						}
					}
					
					return true;
				};
			}.submit();
		}
		
		if (FamilyRobberManager.getInstance().isActPeriod()) {
			//家族强盗期间
			if (role.getMapId() == DynamicMapID.QST_FAMILY || role.getMapId() == DynamicMapID.XDH_FAMILY) {
				//进入家族
				xbean.FamilyMemberBean familyMem = xtable.Familymember.select(roleId);
				if (familyMem != null) {
					xbean.FamilyRobberInfo familyRobberInfo = xtable.Familyrobberinfos.select(familyMem.getFamilykey());
					if (familyRobberInfo != null && familyRobberInfo.getPosid2robberkey().size() > 0) {
						Message.sendMsgNotify(roleId, 1039573, Arrays.asList(String.valueOf(familyRobberInfo.getPosid2robberkey().size())));
					}
				}
			}
		}
		
		int offlineFubenId= OfflineFubenUtil.getCurrentOfflineFubenId(roleId);
		if(offlineFubenId>0){
			//进入离线副本
			TreasureManager.getInstance().onFinishEnterOfflineFuben(roleId,offlineFubenId);
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786493;

	public int getType() {
		return 786493;
	}


	public CFinishLoading() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CFinishLoading) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CFinishLoading _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

