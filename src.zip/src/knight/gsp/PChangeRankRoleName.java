package knight.gsp;

import java.util.ArrayList;
import java.util.List;

import knight.gsp.ranklist.RankType;
import knight.gsp.ranklist.proc.Constant;
import xbean.MarshalCampRecord;
import xbean.MarshalDragonRecord;
import xbean.MarshalMentalityRecord;
import xbean.MarshalMercenaryRecord;
import xbean.MarshalRoseRecord;
import xbean.RolePropertyRankList;
import xbean.RolePropertyRankRecord;

/**
 * 修改排行榜中的角色名称
 * @author dongfang
 *
 */
public class PChangeRankRoleName extends xdb.Procedure{
	private long roleId;
	private String newRoleName;

	public PChangeRankRoleName(long roleId, String newRoleName) {
		super();
		this.roleId = roleId;
		this.newRoleName = newRoleName;
	}

	@Override
	protected boolean process() throws Exception {
		//鲜花榜
		List<Integer> roseLocks = new ArrayList<Integer>();
		roseLocks.add(RankType.FLOWER_YESTERDAY_RANK);
		roseLocks.add(RankType.FLOWERDAY_TODAY_RANK);
		roseLocks.add(RankType.FLOWER_WEEK_RANK);
		xdb.Lockeys.lock(xtable.Locks.ROSELIST, roseLocks);
		xbean.RoseRankList yesterdayRank = xtable.Roselist.get(RankType.FLOWER_YESTERDAY_RANK);
		if(yesterdayRank != null){
			for(MarshalRoseRecord rec : yesterdayRank.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		xbean.RoseRankList todayRank = xtable.Roselist.get(RankType.FLOWERDAY_TODAY_RANK);
		if(todayRank != null){
			for(MarshalRoseRecord rec : todayRank.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		xbean.RoseRankList weekRank = xtable.Roselist.get(RankType.FLOWER_WEEK_RANK);
		if(weekRank != null){
			for(MarshalRoseRecord rec : weekRank.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		
		//智力排行榜
		List<Integer> menLocks = new ArrayList<Integer>();
		menLocks.add(Constant.WITCHALLENGE_RANK_BACK);
		menLocks.add(Constant.WITCHALLENGE_RANK);
		xdb.Lockeys.lock(xtable.Locks.MENTALITYRANK, menLocks);
		xbean.MentalityRankList mentalityRankBackList = xtable.Mentalityrank.get(Constant.WITCHALLENGE_RANK_BACK);
		if(mentalityRankBackList != null) {
			for(MarshalMentalityRecord rec : mentalityRankBackList.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		xbean.MentalityRankList mentalityRankList = xtable.Mentalityrank.get(Constant.WITCHALLENGE_RANK);
		if(mentalityRankList != null) {
			for(MarshalMentalityRecord rec : mentalityRankList.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		
		//等级排行榜
		RolePropertyRankList levelRank = xtable.Rolepropertyrank.get(RankType.LEVEL_RANK);
		if(levelRank != null) {
			for(RolePropertyRankRecord rec : levelRank.getRecords()) {
				if(rec.getMarshaldata().getRoleid() == roleId) {
					rec.getMarshaldata().setRolename(newRoleName);
					break;
				}
			}
		}
		//装备排行榜
		RolePropertyRankList equipRank = xtable.Rolepropertyrank.get(RankType.EQUIP_RANK);
		if(equipRank != null) {
			for(RolePropertyRankRecord rec : equipRank.getRecords()) {
				if(rec.getMarshaldata().getRoleid() == roleId) {
					rec.getMarshaldata().setRolename(newRoleName);
					break;
				}
			}
		}
		
		xbean.ServantScoreRankList scoreRankList = xtable.Servantrank.get(1);
		if(scoreRankList != null) {
			//佣兵榜
			List<MarshalMercenaryRecord> mercenaryRankList = scoreRankList.getMercenaryrecords();
			if(mercenaryRankList != null) {
				for(MarshalMercenaryRecord rec : mercenaryRankList) {
					if(rec.getRoleid() == roleId) {
						rec.setRolename(newRoleName);
						break;
					}
				}
			}
			//龙榜
			List<MarshalDragonRecord> dragonRankList = scoreRankList.getDragonrecords();
			if(dragonRankList != null) {
				for(MarshalDragonRecord rec : dragonRankList) {
					if(rec.getRoleid() == roleId) {
						rec.setRolename(newRoleName);
						break;
					}
				}
			}
		}
		//装备排行榜
		RolePropertyRankList powerRank = xtable.Rolepropertyrank.get(RankType.POWER_RANK);
		if(powerRank != null) {
			for(RolePropertyRankRecord rec : powerRank.getRecords()) {
				if(rec.getMarshaldata().getRoleid() == roleId) {
					rec.getMarshaldata().setRolename(newRoleName);
					break;
				}
			}
		}
		
		//兄弟会榜
		xbean.CampShenwangRankList xiongdihuiCampList = xtable.Camprank.get(RankType.XIONG_DI_HUI_RANK);
		if(xiongdihuiCampList != null) {
			for(MarshalCampRecord rec : xiongdihuiCampList.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		//十字军榜
		xbean.CampShenwangRankList shizijunCampList = xtable.Camprank.get(RankType.SHI_ZI_JUN_RANK);
		if(shizijunCampList != null) {
			for(MarshalCampRecord rec : shizijunCampList.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		
		//历史得花榜
		xbean.RoseRankList historyFlowerRank = xtable.Roselist.get(RankType.FLOWERDAY_HISTORY_RANK);
		if(historyFlowerRank != null){
			for(MarshalRoseRecord rec : historyFlowerRank.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		//周得花榜备份
		xbean.RoseRankList weekFlowerRankBak = xtable.Roselist.get(RankType.FLOWER_WEEK_RANK_BAK);
		if(weekFlowerRankBak != null){
			for(MarshalRoseRecord rec : weekFlowerRankBak.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		//幻境24宫排行榜
		xbean.HuanjingRankList huanjingRank = xtable.Huanjingrank.get(1);
		if(huanjingRank != null){
			for(xbean.MarshalHuanjingRank rec : huanjingRank.getRecords()) {
				if(rec.getRoleid() == roleId) {
					rec.setName(newRoleName);
					break;
				}
			}
		}
		xbean.ShiDeZhiRankList shiDeZhiRankList = xtable.Roleshidelist.get(1);
		if(shiDeZhiRankList!=null){
			for(xbean.MasterRankRecord xMasterRankRecord:shiDeZhiRankList.getRecords()){
				if(xMasterRankRecord.getRoleid()==roleId){
					xMasterRankRecord.setRolename(newRoleName);
				}
			}
		}
		return true;
	}
}
