package knight.gsp;

import gnet.link.Onlines;

import java.util.Collection;
import java.util.List;

import knight.gsp.activity.ActivityStatus;
import knight.gsp.activity.SNotifyActivityStatus;
import knight.gsp.activity.activeness.ActivenessManager;
import knight.gsp.activity.aprilfoolsday.AprilFoolsDayManager;
import knight.gsp.activity.binbinhaoli.BinbinhaoliManager;
import knight.gsp.activity.bjzz.BingJianZuoZhanManager;
import knight.gsp.activity.daluandou.DaLuanDouManager;
import knight.gsp.activity.dragonboat.DragonBoatManager;
import knight.gsp.activity.eggs.EggsManager;
import knight.gsp.activity.guoqing.GuoqingManager;
import knight.gsp.activity.huandujiajie.HuanDuJiaJieManager;
import knight.gsp.activity.protectmilitaryvehicle.MilitaryVehicleManager;
import knight.gsp.activity.qixi.QixiManager;
import knight.gsp.activity.resourcefight.ResourceFightManager;
import knight.gsp.activity.shuangdan.ShuangdanManager;
import knight.gsp.activity.soulbless.SoulblessManager;
import knight.gsp.activity.springfestival.firecracker.FirecrackerManager;
import knight.gsp.activity.springfestival.giftbox.NewYearGiftBoxManager;
import knight.gsp.activity.springfestival.jjsf.JinJiSongFuManager;
import knight.gsp.activity.springfestival.pray.PrayForNewYearManager;
import knight.gsp.activity.springfestival.smdl.ShenMiDengLongManager;
import knight.gsp.activity.summerday.SummerDayManager;
import knight.gsp.activity.thanksgivingday.ThanksGivingDayManager;
import knight.gsp.activity.zhongqiujie.ZhongqiuManager;
import knight.gsp.anniversary.AnniversaryActivityManager;
import knight.gsp.anniversary.XuKongShopManager;
import knight.gsp.camp.CampRole;
import knight.gsp.camp.lmzz.LmzzManager;
import knight.gsp.family.familygather.FamilyGatherManager;
import knight.gsp.fuben.challenge.ChallengeManager;
import knight.gsp.fuben.protectgoddess.ProtectGoddessManager;
import knight.gsp.fuben.ragnarok.RagnarokManager;
import knight.gsp.game.Sspecialpara;
import knight.gsp.main.ConfigManager;
import knight.gsp.mayday.MayDayManager;
import knight.gsp.qixi.QiXiActivityManager;
import knight.gsp.scene.CommonThread;
import knight.gsp.spvp.SPvPManager;
import knight.gsp.util.DateValidate;
import knight.gsp.wed.WedManager;
import knight.gsp.yuanbao.RechargeBackJDCardManager;

/**
 * 活动状态管理器
 * 
 * @author yangzhenyu
 * 
 *         2014-3-24 下午2:03:43
 */
public class ActivityStatusManager {
	
	private static ActivityStatusManager instance = new ActivityStatusManager();
	
	private ActivityStatusManager() {}
	
	public static ActivityStatusManager getInstance() {
		return instance;
	}
	
	public SActivityStatus getActivityStatus() {
		return getActivityStatus(0);
	}

	public SActivityStatus getActivityStatus(long roleId) {
		SActivityStatus snd = new SActivityStatus();
		if (roleId > 0) {
			xbean.Properties prop = xtable.Properties.select(roleId);
			if (ProtectGoddessManager.getInstance().isActivityPeriod() && prop.getLevel() >= ProtectGoddessManager.MIN_LEVEL)
				snd.status.put((byte) SActivityStatus.PROTECT_GODDESS, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.PROTECT_GODDESS, (byte) 0);
			
			if (LmzzManager.getInstance().inActivityPeriod())
				snd.status.put((byte) SActivityStatus.LI_MING_ZHI_ZHAN, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.LI_MING_ZHI_ZHAN, (byte) 0);
			
			if (SPvPManager.getInstance().inActivityPeriod())
				snd.status.put((byte) SActivityStatus.PVP_FIGHT, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.PVP_FIGHT, (byte) 0);
			if (ChallengeManager.getInstance().inActivityPeriod())
				snd.status.put((byte) SActivityStatus.CHALLENGE, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.CHALLENGE, (byte) 0);
			
			if (prop.getLevel() >= AnniversaryActivityManager.MIN_LV) {
				snd.status.put((byte)SActivityStatus.ANNIVERSARY, AnniversaryActivityManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
			}
			if (prop.getLevel() >= QiXiActivityManager.MIN_LV) {
				snd.status.put((byte)SActivityStatus.QIXI, QiXiActivityManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
			}
			
		} else {
			if (ProtectGoddessManager.getInstance().isActivityPeriod())
				snd.status.put((byte) SActivityStatus.PROTECT_GODDESS, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.PROTECT_GODDESS, (byte) 0);
			
			if (LmzzManager.getInstance().inActivityPeriod())
				snd.status.put((byte) SActivityStatus.LI_MING_ZHI_ZHAN, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.LI_MING_ZHI_ZHAN, (byte) 0);
			
			if (SPvPManager.getInstance().inActivityPeriod())
				snd.status.put((byte) SActivityStatus.PVP_FIGHT, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.PVP_FIGHT, (byte) 0);
			if (ChallengeManager.getInstance().inActivityPeriod())
				snd.status.put((byte) SActivityStatus.CHALLENGE, (byte) 1);
			else
				snd.status.put((byte) SActivityStatus.CHALLENGE, (byte) 0);
			
			snd.status.put((byte)SActivityStatus.ANNIVERSARY, AnniversaryActivityManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
			snd.status.put((byte)SActivityStatus.QIXI, QiXiActivityManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
		}
		snd.status.put((byte) SActivityStatus.EGGS, (byte) (EggsManager.getInstance().inActivityPeriod() ? 1 : 0));
		snd.status.put((byte) SActivityStatus.DRAGON_BOAT, DragonBoatManager.getInstance().isOpen() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.BINGBINGHAOLI, BinbinhaoliManager.getInstance().isOpen() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.LEDO_JD_CARD, RechargeBackJDCardManager.getInstance().showMainPageIcon()?(byte) 1:(byte) 0);
		snd.status.put((byte) SActivityStatus.SUMMER_DAY, SummerDayManager.getInstance().isOpen() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.RAGNAROK_RANK, RagnarokManager.getInstance().isOpenRankData() ? (byte) 1 : (byte) 0);
		
//		snd.status.put((byte) SActivityStatus.QIXI, QixiManager.getInstance().isStart() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.QIXI_TASK, QixiManager.getInstance().isQixiTaskStart() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.QIXI_FLOWER_RANK_OPEN, QixiManager.getInstance().isFlowerRankOpenStart() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.QIXI_FLOWER_RANK_AWARD, QixiManager.getInstance().isFlowerRankAwardStart() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.QIXI_CATCH_THEIF, QixiManager.getInstance().isCatchTheifStart() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.ACTIVENESS_RANK_OPEN, ActivenessManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.ACTIVENESS_RANK_REWARD, ActivenessManager.getInstance().isCanGetAward() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.ZhONGQIU_ICON, ZhongqiuManager.getInstance().inActivityPeriod() ||  
				ZhongqiuManager.getInstance().flowerRankIsStart() || ZhongqiuManager.getInstance().flowerRankReward()? (byte) 1 : (byte) 0);
		//snd.status.put((byte) SActivityStatus.ZHONGQIU, ZhongqiuManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.ZHONGQIU_FLOWER, ZhongqiuManager.getInstance().flowerRankIsStart()|| 
				ZhongqiuManager.getInstance().flowerRankReward() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.GUOQING, GuoqingManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.GUOQING_RESOURCE_FIGHT, ResourceFightManager.getInstance().isInActivityPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.GUOQING_LOGIN_REWARD, GuoqingManager.getInstance().loginRewardIsOpen() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.THANKSGIVINGDAY, ThanksGivingDayManager.getInstance().isOpen() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.SHUANG_JIE_JING_SU, ShuangdanManager.getInstance().isShuangDanSpeedCompetePeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.TIAN_JIANG_ZHI_LI, ShuangdanManager.getInstance().isTianJiangGiftPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte) SActivityStatus.SHOU_HU_SHENG_DAN, (byte) (ShuangdanManager.getInstance().isShuangDanBossPeriod() ? 1 : 0));
		snd.status.put((byte)SActivityStatus.WA_ZI_LI_BAO, ShuangdanManager.getInstance().isChristmasGiftPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.DENG_LONG_LI_BAO, ShuangdanManager.getInstance().isNewyearGiftPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.PING_PING_AN_AN, ShuangdanManager.getInstance().isPingPingAnAnPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.LA_BA_NUAN_ZHOU, ShuangdanManager.getInstance().isLaBaGiftPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.XUN_BAO_QI_BING, ShuangdanManager.getInstance().isXunBaoQiBingPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.PRAY_FOR_NEW_YEAR, PrayForNewYearManager.getInstance().isRunning()? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.SURPRISE_FIRECRACKER, FirecrackerManager.getInstance().isRunning()? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.TREASURE_STEAL_GHOST, NewYearGiftBoxManager.getInstance().isOn()? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.GOLD_CHICKEN_BENEFITS, JinJiSongFuManager.getInstance().isInPeriod()? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.MYSTERIOUS_LANTERN, ShenMiDengLongManager.getInstance().isInPeriod()? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.FESTIVAL_GIFT, JinJiSongFuManager.getInstance().isInFestivalShopPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.Yan_HUA_MAN_CHENG, HuanDuJiaJieManager.getInstance().isFireworkPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.SHI_GUANG_BAO_XIANG, HuanDuJiaJieManager.getInstance().isTimeBoxPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.JIA_JIE_HAO_LI, HuanDuJiaJieManager.getInstance().isJiaJieHaoLiPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.BING_JIAN_ZUO_ZHAN, BingJianZuoZhanManager.getInstance().isInActPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.QING_REN_HAO_LI, HuanDuJiaJieManager.getInstance().isQingRenHaoLiPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.APRI_FOOLS_DAY, AprilFoolsDayManager.getInstance().isOpen() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.MAY_DAY, MayDayManager.getInstance().isActPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.IS_DA_LUAN_DOU_SEASON, DaLuanDouManager.getInstance().isDaLuanDouSeasonPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.XUKONG_SHOP, XuKongShopManager.getInstance().inActivityPeriod() ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.MILITARY_VEHICLE, MilitaryVehicleManager.getInstance().inBigActivityPeriod ? (byte) 1 : (byte) 0);
		snd.status.put((byte)SActivityStatus.MILITARY_VEHICLE_BATTLE, MilitaryVehicleManager.getInstance().isInActivityPeriod() ? (byte) 1 : (byte) 0);
		return snd;
	}
	
	/**
	 * 统一调用这个方法来给全服角色发活动状态
	 * 
	 * @param roleids
	 */
	public void sendAll(Collection<Long> roleids) {
		//roleids为空则给所有人发
		ActivitySendProtocol protocol = new ActivitySendProtocol();
		if (roleids != null && roleids.size() > 0)
			protocol.roleids.addAll(roleids);
		CommonThread.getInstance().add(protocol);
	}
	
	/**
	 * 有活动开始或者结束的时候，广播
	 * 
	 * @param actId
	 * @param openOrClose
	 * @param param
	 */
	public void broadcastActivityState(int actId, byte openOrClose, Object param) {
		
		SNotifyActivityStatus snd = new SNotifyActivityStatus();
		
		if (actId == SNotifyActivityStatus.QUAN_MIN_CI_TAN) {
			byte camp = (Byte) param;
			ActivityStatus status = new ActivityStatus();
			status.activitystatus = (byte) (openOrClose == 1 ? 1 : 0);
			if (openOrClose == 1) {
				status.endtime = SoulblessManager.getInstance().getCampQuanMinCiTanEndTick(camp);
			}
			snd.activitystate.put(SNotifyActivityStatus.QUAN_MIN_CI_TAN, status);
			List<Long> roleids = Onlines.getInstance().getRoleIds();
			for (long roleId : roleids) {
				CampRole campRole = new CampRole(roleId, true);
				if (campRole.getStandCamp() != camp)
					continue;
				
				Onlines.getInstance().send(roleId, snd);
			}
		} else if (actId == SNotifyActivityStatus.FAMILY_GATHER) {
			long familyKey = (Long) param;
			xbean.FamilyInfoBean family = xtable.Families.select(familyKey);
			if (family == null)
				return;
			
			ActivityStatus status = FamilyGatherManager.getInstance().getActStatus(familyKey);
			if (status != null) {
				snd.activitystate.put(SNotifyActivityStatus.FAMILY_GATHER, status);
			} else {
				snd.activitystate.put(SNotifyActivityStatus.FAMILY_GATHER, new ActivityStatus());
			}
			for (long memberId : family.getMembers()) {
				Onlines.getInstance().send(memberId, snd);
			}
		} else if (actId == SNotifyActivityStatus.WEDDING) {
			ActivityStatus status = new ActivityStatus();
			status.activitystatus = (byte) (openOrClose == 1 ? 1 : 0);
			if (openOrClose == 1)
				status.endtime = System.currentTimeMillis() + DateValidate.hourMills;
			snd.activitystate.put(SNotifyActivityStatus.WEDDING, status);
			List<Long> roleids = Onlines.getInstance().getRoleIds();
			for (long roleId : roleids) {
				Onlines.getInstance().send(roleId, snd);
			}
		} else if (actId == SNotifyActivityStatus.JXHS_BATTLE) {
			ActivityStatus status = new ActivityStatus();
			status.activitystatus = (byte) (openOrClose == 1 ? 1 : 0);
			if (openOrClose == 1)
				status.endtime = System.currentTimeMillis() + DateValidate.hourMills;
			snd.activitystate.put(SNotifyActivityStatus.JXHS_BATTLE, status);
			List<Long> roleids = Onlines.getInstance().getRoleIds();
			for (long roleId : roleids) {
				Onlines.getInstance().send(roleId, snd);
			}
		}
	}

	public void checkSendActStatusWhileEnterWorld(long roleId) {
		SNotifyActivityStatus snd = new SNotifyActivityStatus();
		CampRole campRole = new CampRole(roleId, true);
		byte camp = campRole.getStandCamp();
		if (camp > 0) {
			//全民刺探
			if (SoulblessManager.getInstance().isCampQuanMinCiTanPeriod(camp)) {
				ActivityStatus status = new ActivityStatus();
				status.activitystatus = 1;
				status.endtime = SoulblessManager.getInstance().getCampQuanMinCiTanEndTick(camp);
				snd.activitystate.put(SNotifyActivityStatus.QUAN_MIN_CI_TAN, status);
			}
		}
		
		xbean.FamilyMemberBean famillyMem = xtable.Familymember.select(roleId);
		if (famillyMem != null) {
			ActivityStatus status = FamilyGatherManager.getInstance().getActStatus(famillyMem.getFamilykey());
			if (status != null) {
				snd.activitystate.put(SNotifyActivityStatus.FAMILY_GATHER, status);
			}
		}
		
		if (WedManager.getInstance().getWeddingPartyRoles().size() > 0 || WedManager.getInstance().getWeddingCarRoles().size() > 0) {
			ActivityStatus status = new ActivityStatus();
			status.activitystatus = 1;
			status.endtime = System.currentTimeMillis() + DateValidate.hourMills;
			snd.activitystate.put(SNotifyActivityStatus.WEDDING, status);
		}
		
		if (MilitaryVehicleManager.getInstance().isInActivityPeriod()) {
			ActivityStatus status = new ActivityStatus();
			status.activitystatus = 1;
			status.endtime = System.currentTimeMillis() + DateValidate.hourMills;
			snd.activitystate.put(SNotifyActivityStatus.JXHS_BATTLE, status);
		}
		
		if (snd.activitystate.size() > 0) {
			Onlines.getInstance().send(roleId, snd);
		}
	}
	
	public boolean isSpringFestivalActOpen() {
		Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(396);
		if (cfg == null || cfg.para4 == null || cfg.para4.trim().equals(""))
			return true;
		
		int zoneId = ConfigManager.getGsZoneId();
		String[] zoneIdStrArr = cfg.para4.split(";");
		for (String zoneIdStr : zoneIdStrArr) {
			if (zoneId == Integer.valueOf(zoneIdStr))
				return true;
		}
		
		return false;
	}
}
