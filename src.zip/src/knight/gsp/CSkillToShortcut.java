
package knight.gsp;
import global.rsp.GlobalClientManager;
import global.rsp.GsCrossSkillToShortcut;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.skill.SkillRole;




// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CSkillToShortcut__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CSkillToShortcut extends __CSkillToShortcut__ {
	@Override
	protected void process() {
		final long roleid  = gnet.link.Onlines.getInstance().findRoleid(this);
		if(roleid <= 0)
			return;
		if (LocalIds.isRemoteServerRole(roleid)) {
			int zoneId = ServerInfoProvider.roleid2zoneid(roleid);
			GsCrossSkillToShortcut snd = new GsCrossSkillToShortcut();
			snd.battlegs = ConfigManager.getGsZoneId();
			snd.fromroleid = roleid;
			snd.skillid = skillid;
			snd.shortcut2id = shortcutid;
			GlobalClientManager.getInstance().send(zoneId, snd);
			return;
		}
		new xdb.Procedure(){
			@Override
			public boolean process(){
				return new SkillRole(roleid, false).skillToShortcut(0, skillid, shortcutid);
			}
		}.submit();
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786452;

	public int getType() {
		return 786452;
	}

	public int skillid;
	public short shortcutid;

	public CSkillToShortcut() {
	}

	public CSkillToShortcut(int _skillid_, short _shortcutid_) {
		this.skillid = _skillid_;
		this.shortcutid = _shortcutid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(skillid);
		_os_.marshal(shortcutid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		skillid = _os_.unmarshal_int();
		shortcutid = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CSkillToShortcut) {
			CSkillToShortcut _o_ = (CSkillToShortcut)_o1_;
			if (skillid != _o_.skillid) return false;
			if (shortcutid != _o_.shortcutid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += skillid;
		_h_ += shortcutid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(skillid).append(",");
		_sb_.append(shortcutid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CSkillToShortcut _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = skillid - _o_.skillid;
		if (0 != _c_) return _c_;
		_c_ = shortcutid - _o_.shortcutid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

