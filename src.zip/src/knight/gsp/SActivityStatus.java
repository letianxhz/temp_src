
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SActivityStatus__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SActivityStatus extends __SActivityStatus__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786468;

	public int getType() {
		return 786468;
	}

	public final static int PROTECT_GODDESS = 1; // 保卫女神
	public final static int LI_MING_ZHI_ZHAN = 2; // 黎明之战
	public final static int SHUANG_JIE_HUO_DONG = 3; // 双节活动
	public final static int XUE_QIU_SUBMIT = 4; // 雪球兑换
	public final static int PVP_FIGHT = 5; // 角斗场开赛了
	public final static int CHALLENGE = 6; // 巴别塔
	public final static int VALENTINE = 7; // 情人节活动
	public final static int DRAGON_BOAT = 8; // 端午节活动
	public final static int QIXI = 9; // 七夕节活动
	public final static int EGGS = 10; // 彩蛋活动
	public final static int BINGBINGHAOLI = 11; // 冰冰豪礼
	public final static int LEDO_JD_CARD = 12; // 乐道京东卡
	public final static int SUMMER_DAY = 13; // 夏日活动
	public final static int RAGNAROK_RANK = 14; // 神之黄昏玩法排行榜
	public final static int QIXI_TASK = 15; // 七夕节任务（真爱之旅）
	public final static int QIXI_FLOWER_RANK_OPEN = 16; // 七夕鲜花榜开启
	public final static int QIXI_FLOWER_RANK_AWARD = 17; // 七夕鲜花榜领取奖励
	public final static int QIXI_CATCH_THEIF = 18; // 七夕抓盗宝贼
	public final static int ACTIVENESS_RANK_OPEN = 19; // 活跃度排行开启
	public final static int ACTIVENESS_RANK_REWARD = 20; // 活跃度排行奖励
	public final static int ZhONGQIU_ICON = 21; // 中秋活动图标
	public final static int ZHONGQIU = 22; // 中秋活动 除鲜花榜
	public final static int ZHONGQIU_FLOWER = 23; // 中秋鲜花榜
	public final static int GUOQING = 24; // 国庆活动
	public final static int GUOQING_RESOURCE_FIGHT = 25; // 国庆资源争夺活动
	public final static int GUOQING_LOGIN_REWARD = 26; // 国庆七天乐活动
	public final static int THANKSGIVINGDAY = 27; // 感恩节活动
	public final static int PING_PING_AN_AN = 28; // 平平安安,平安夜送苹果
	public final static int SHUANG_JIE_JING_SU = 29; // 双节竞速
	public final static int TIAN_JIANG_ZHI_LI = 30; // 天降之礼
	public final static int SHOU_HU_SHENG_DAN = 31; // 守护圣诞
	public final static int WA_ZI_LI_BAO = 32; // 袜子礼包
	public final static int DENG_LONG_LI_BAO = 33; // 灯笼礼包
	public final static int XUN_BAO_QI_BING = 34; // 平寻宝奇兵
	public final static int LA_BA_NUAN_ZHOU = 35; // 喇叭暖粥
	public final static int GOLD_CHICKEN_BENEFITS = 36; // 金鸡送福
	public final static int FESTIVAL_GIFT = 37; // 佳节好礼
	public final static int MYSTERIOUS_LANTERN = 38; // 神秘灯笼
	public final static int PRAY_FOR_NEW_YEAR = 39; // 新年祈福
	public final static int SURPRISE_FIRECRACKER = 40; // 惊喜爆竹
	public final static int TREASURE_STEAL_GHOST = 41; // 盗宝精灵
	public final static int Yan_HUA_MAN_CHENG = 42; // 烟花满城
	public final static int BING_JIAN_ZUO_ZHAN = 43; // 并肩作战
	public final static int SHI_GUANG_BAO_XIANG = 44; // 时光宝箱
	public final static int SHOU_HUA_BANG = 45; // 收花榜
	public final static int SONG_HUA_BANG = 46; // 送花榜
	public final static int JIA_JIE_HAO_LI = 47; // 嘉节豪礼（元宵好礼）
	public final static int QING_REN_HAO_LI = 48; // 情人好礼
	public final static int APRI_FOOLS_DAY = 49; // 愚人节
	public final static int MAY_DAY = 50; // 五一节
	public final static int IS_DA_LUAN_DOU_SEASON = 51; // 是否为荆棘战场赛季,控制组队平台页签显示
	public final static int XUKONG_SHOP = 52; // 虚空商城
	public final static int ANNIVERSARY = 53; // 周年庆活动
	public final static int MILITARY_VEHICLE = 54; // 军需护送
	public final static int MILITARY_VEHICLE_BATTLE = 55; // 军需护送战斗中

	public java.util.HashMap<Byte,Byte> status; // value 1代表开启

	public SActivityStatus() {
		status = new java.util.HashMap<Byte,Byte>();
	}

	public SActivityStatus(java.util.HashMap<Byte,Byte> _status_) {
		this.status = _status_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(status.size());
		for (java.util.Map.Entry<Byte, Byte> _e_ : status.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			byte _k_;
			_k_ = _os_.unmarshal_byte();
			byte _v_;
			_v_ = _os_.unmarshal_byte();
			status.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SActivityStatus) {
			SActivityStatus _o_ = (SActivityStatus)_o1_;
			if (!status.equals(_o_.status)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += status.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(status).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

