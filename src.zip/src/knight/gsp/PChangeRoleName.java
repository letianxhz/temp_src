package knight.gsp;

import knight.gsp.activity.woldboss.WorldBossManager;
import knight.gsp.dny.DongNanYaManager;
import knight.gsp.hg.HanGuoManager;
import knight.gsp.item.Bag;
import knight.gsp.log.LogUtil;
import knight.gsp.log.LogUtil.COST_ITEM_TYPE;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.msg.Message;
import knight.gsp.team.SRefreshTeamMemberName;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;
import knight.gsp.util.CheckName;
import knight.gsp.yuanbao.PAddYuanBao;
import knight.gsp.yuenan.YNManager;
import knight.msp.GChangeRoleName;
import xdb.Procedure;
import xdb.util.UniqName;

public class PChangeRoleName extends xdb.Procedure
{
	private long roleId;
	private String newRoleName;

	public static final int COST_DIAMOND = 999;	//消耗的元宝
	public static final int CHANGE_NAME_CARD = 361031;//改名卡道具
	
	public static final int NAME_DUPLICATED = 100315;	//名字已经存在
	public static final int NAME_ILLEGAL = 100316;		//名字含有非法字符
	public static final int CHANGE_NAME_SUCC = 101272;	//名字 修改成功
	public static final int NAME_NULL = 100314;	//名字为空
	public static final int NAME_TOO_SHORT = 100772;	//名字太短
	public static final int NAME_TOO_LONG = 100317;	//名字太长
	
	public PChangeRoleName(long roleId, String newRoleName) {
		super();
		this.roleId = roleId;
		this.newRoleName = newRoleName;
	}

	@Override
	protected boolean process() throws Exception {
		if(newRoleName == null || newRoleName.length() == 0) {
			Message.psendMsgNotify(roleId, NAME_NULL, null);
			return false;
		}
		int nameLen_max = 6;
		int nameLen_min = 2;
		if(HanGuoManager.getInstance().isHanGuoServer() || DongNanYaManager.getInstance().isDongNanYaServer()
				|| YNManager.getInstance().isYNServer()){
			nameLen_max = 16;
		}
		if(newRoleName.length() < nameLen_min) {
			Message.psendMsgNotify(roleId, NAME_TOO_SHORT, null);
			return false;
		}
		if(newRoleName.length() > nameLen_max) {
			Message.psendMsgNotify(roleId, NAME_TOO_LONG, null);
			return false;
		}
		
		xbean.Properties pro = xtable.Properties.get(roleId);
		if(pro == null) {
			return false;
		}
		if(pro.getRolename().equals(newRoleName)) {
			Message.psendMsgNotify(roleId, NAME_DUPLICATED, null);
			return false;
		}
		
		//验证屏蔽字
		int aimCheckResult = knight.gsp.util.CheckName.checkValid(newRoleName);
		if(aimCheckResult == CheckName.WORD_ILLEGALITY){
			Message.psendMsgNotify(roleId, NAME_ILLEGAL, null);
			return false;	
		}else if(aimCheckResult == CheckName.SPECIAL_WORD_TOO_MANY){
			Message.psendMsgNotify(roleId, NAME_ILLEGAL, null);
			return false;
		}else if(aimCheckResult == CheckName.NONE_CHARACTER){
			Message.psendMsgNotify(roleId, NAME_ILLEGAL, null);
			return false;
		}
		// 检查角色名是否已经用过
		String lowerCaseName = newRoleName.toLowerCase();
		if (!UniqName.allocate("role", lowerCaseName)) {
			// 告诉客户端说角色名已重复
			Message.psendMsgNotify(roleId, NAME_DUPLICATED, null);
			return false;
		}
		
		if (xtable.Name2role.select(newRoleName) != null) {
			Message.psendMsgNotify(roleId, NAME_DUPLICATED, null);
			return false;
		}
		if (1 != new Bag(roleId, false).removeItemById(CHANGE_NAME_CARD, 1, COST_ITEM_TYPE.USE, "改名卡")) {
			if (!new PAddYuanBao(roleId, -COST_DIAMOND, LogUtil.CHANGE_NAME).call()) 
				return false;
		} 
		//修改name2role表
		xtable.Name2role.remove(pro.getRolename());
		xtable.Name2role.insert(newRoleName, roleId);
		
		pro.setRolename(newRoleName);
		/***修改其他用到角色名称的地方 */
		xdb.Executor.getInstance().execute(new Runnable() {
			@Override
			public void run() {
				new PChangeRankRoleName(roleId, newRoleName).submit();
			}
		});
		
		//通知场景模块
		GChangeRoleName msg = new GChangeRoleName();
		msg.roleid = roleId;
		msg.newname = newRoleName;
		GsClient.psend2RoleSceneWhileCommit(roleId, msg);
		
		//通知队友
		xdb.Procedure.pexecuteWhileCommit(new Procedure(){
			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.selectTeamByRoleId(roleId);
				if (team == null)
					return false;
				
				SRefreshTeamMemberName msg = new SRefreshTeamMemberName(roleId, newRoleName);
				for (long rid : team.getAllMemberIds()) {
					if (rid == roleId)
						continue;
					
					xdb.Procedure.psendWhileCommit(rid, msg);
				}
				
				return true;
			}
		});
		
		Message.psendMsgNotifyWhileCommit(roleId, CHANGE_NAME_SUCC, null);
		
		//同步最新的角色信息到global server
		ServerInfoProvider.syncRoleInfoToGlobal(roleId);
		
		WorldBossManager.getInstance().freshRoleNameWhileChangeName(roleId, newRoleName);
		
		return true;
	}
}
