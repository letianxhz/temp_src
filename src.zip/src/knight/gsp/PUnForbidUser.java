/**
 * Class: PUnForbidUser.java
 * Package: knight.gsp
 *
 *
 *   ver     date      		author
 * ──────────────────────────────────
 *   		 2011-10-10 		yesheng
 *
 * Copyright (c) 2011, Perfect World All Rights Reserved.
 */

package knight.gsp;

import java.util.HashMap;
import java.util.Map;

import knight.gsp.log.LogManager;
import knight.gsp.log.LogUtil;
import knight.gsp.log.RemoteLogParam;
import xdb.Procedure;

import com.goldhuman.Common.Octets;

/**
 * ClassName:PUnForbidUser Function: ADD FUNCTION HERE
 * 
 * @author yesheng
 * @version
 * @since
 * @Date 2011-10-10 下午04:26:38
 * 
 * @see
 */
public class PUnForbidUser extends Procedure {

	private final int dstuserid;

	private final int gmuserid;
	
	private final int gmlocalsid;
	
	private final Octets reason;
	
	private final boolean auForbid;

	public PUnForbidUser(int dstuserid, int gmuserid,int gmlocalsid,Octets reason,boolean auForbid) {

		super();
		this.dstuserid = dstuserid;
		this.gmuserid = gmuserid;
		this.gmlocalsid = gmlocalsid;
		this.reason = reason;
		this.auForbid = auForbid;
	}

	@Override
	protected boolean process() throws Exception {
		if (auForbid){ 
		gnet.GMKickoutUser send = new gnet.GMKickoutUser(gmuserid, gmlocalsid, dstuserid, 1, reason);
		gnet.DeliveryManager.getInstance().send(send);
		}
		xbean.UserPunish userpunish = xtable.Userpunish.get(dstuserid);
		if (userpunish == null) {
			userpunish = xbean.Pod.newUserPunish();
			xtable.Userpunish.insert(dstuserid, userpunish);
		}
		xbean.PunishRecord record = xbean.Pod.newPunishRecord();
		record.setGmuserid(gmuserid);
		record.setForbidtime(0);
		record.setOptime(System.currentTimeMillis());
		record.setReason(reason.getString("UTF-16LE"));
		record.setRoleid(0);
		record.setType(xbean.PunishRecord.TYPE_UNFORBID_LOGIN);
		record.setUserid(dstuserid);
		userpunish.getRecords().add(record);
		userpunish.setReleasetime(0);

		try {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(RemoteLogParam.GMUSERID, gmuserid);
			xbean.User user = xtable.User.select(dstuserid);
			LogUtil.putRoleBasicInfo(user.getPrevloginroleid(), param);
			
            param.put(RemoteLogParam.TYPE, 0);
			LogManager.logger.info("unforbid user.gmuserid:"+gmuserid+"userid:"+dstuserid+reason.getString("UTF-16LE"));
//			LogManager.getInstance().doLogWhileCommit(RemoteLogID.FORBIDUSER_UNLOCK, param);
		} catch (Exception e) {
			LogManager.logger.error(e);
		}

		return true;
	}

}
