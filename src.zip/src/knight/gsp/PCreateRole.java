package knight.gsp;


import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import knight.gsp.game.SPhyset;
import knight.gsp.item.BasicItem;
import knight.gsp.item.Equip;
import knight.gsp.item.Module;
import knight.gsp.item.equip.EquipFactory;
import knight.gsp.log.LogUtil;
import knight.gsp.log.LogUtil.ADD_ITEM_TYPE;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.mercenary.MercenaryFightType;
import knight.gsp.message.Squickchat;
import knight.gsp.role.RoleConfig;
import knight.gsp.skill.SkillRole;
import knight.gsp.util.InetAddressUtil;

import org.apache.log4j.Logger;

import xdb.util.UniqName;

public class PCreateRole extends xdb.Procedure {
	static private final Logger logger = Logger.getLogger(PCreateRole.class);
	// 新生成的角色ID long类型
	private long newRoleID;
	
	// 每个用户最多可创建的角色数目
	public static int maxRoleNum = 4;
	
	// 创建角色时对应的客户端发送的协议
	private final xio.Protocol thisProtocol;
	
	// 创建角色需要的基本数据
	private final int userID;
	private final String name;
	private final int school;
	private byte connectType;
	
	public PCreateRole(CCreateRole protocol, int userID, byte connectType) {
		this.userID = userID;
		this.name = protocol.name;
		this.thisProtocol = protocol;
		this.school = protocol.school;
		this.connectType = connectType;
	}

	public long getNewRoleID() {
		return newRoleID;
	}

	private boolean  sendError(int err){
		final SCreateRole res=new SCreateRole();
		res.error=err;
		res.newinfo.roleid = 1;  //假的roleid
		return gnet.link.Onlines.getInstance().sendResponse(thisProtocol, res);
	}
	
	@Override
	public boolean process() {
		if (!PReqNameByQianTong.checkValidateSchool(school))
			return false;
		
		final SCreateRole snd = new SCreateRole();
	
		
		
		// 检查角色名是否已经用过
		String lowerCaseName = name.toLowerCase();
		if (!UniqName.allocate("role", lowerCaseName)) {
			// 告诉客户端说角色名已重复
			sendError(SCreateRole.CREATE_DUPLICATED);
			return false;
		}
		
		if (xtable.Name2role.select(name) != null) {
			sendError(SCreateRole.CREATE_DUPLICATED);
			return false;
		}
		
		xbean.User u = xtable.User.get(userID);
		final long now = java.util.Calendar.getInstance().getTimeInMillis();
		final xbean.Properties pro = xbean.Pod.newProperties();
		pro.setCreatetime(now);
		pro.setOnlinetime(now);
		pro.setOfflinetime(now);
		pro.setRolename(name);
		pro.setSchool(school);
		// 计算人物属性
		pro.getDir().setX(1);
		pro.getDir().setZ(1);
		pro.setLevel(1);
		pro.setLeveluptime(now);
		pro.setIsfirstenterword(true);
		pro.setUserid(userID);
		// 渠道名临时保存到properties表
		xbean.AUUserInfo auUserInfo = xtable.Auuserinfo.select(userID);
		if (auUserInfo == null)
		{
			logger.error("创建角色时无法获得AUUserInfo,userId:"+userID);
			return false;
		}
		pro.setNickname(auUserInfo.getNickname());
		pro.setUsername(auUserInfo.getUsername());
		pro.setSubplat(auUserInfo.getSubplat());
		pro.setOs(auUserInfo.getOs());
		String[] pseArr = pro.getUsername().split("\\$");
		if (pseArr.length >= 2) {
			pro.setPlatformuid(pseArr[0]);
		} else {
			pro.setPlatformuid(auUserInfo.getUsername());
		}
		
		String model = auUserInfo.getModel();
		if (model.toLowerCase().contains("ipad")) {
			//用Ipad创建的信号，默认设置为远视角
			pro.setOpencloseview(false);
		} else {
			pro.setOpencloseview(true);
		}
		
		//初始化战斗属性
		initBasicFighterProperties(pro);
		
		SPhyset phyCfg = ConfigManager.getInstance().getConf(SPhyset.class).get(1);
		// 初始体力值
		pro.setPhy(phyCfg.getAddphy());
		// 初始体力上限
		pro.setMaxphy(phyCfg.getAddphylimit());
		
		final long newRoleID = xtable.Properties.insert(pro);
		if (null == u) {
			u = xbean.Pod.newUser();
			u.setCreatetime(now);
			xtable.User.insert(userID, u);
			LogUtil.doUserCreataeLog(userID, "xx");
		}
		
		u.setPrevloginroleid(newRoleID);
		u.getIdlist().add(newRoleID);
		logger.info("创建角色 :\t" + name + "\troleID:" + newRoleID + "\tuserID:" + userID);
		
		// 插入名字->ID的映射表中
		xtable.Name2role.insert(name, Long.valueOf(newRoleID));
		
		snd.newinfo.roleid = newRoleID;
		snd.newinfo.rolename = name;
		snd.newinfo.level = 1;
		snd.newinfo.school = school;
		snd.error = SCreateRole.CREATE_OK;
		
		RoleConfig config = ConfigManager.getInstance().getConf(RoleConfig.class).get(pro.getSchool());
		// 添加赠送物品
		if(config != null && config.presents != null && config.presents.size() != 0) {
			knight.gsp.item.Bag bag = new knight.gsp.item.Bag(newRoleID, false);
			if ( config.presents.size() == config.nums.size() ) {
				for ( int i = 0; i < config.presents.size(); i++ ) {
					bag.addItem( config.presents.get(i), config.nums.get(i), ADD_ITEM_TYPE.EXT, "物品赠送", false);
				}
			} else {
				knight.gsp.item.Module.getInstance().getLogger().error( 
						"人物职业配置表id="+school+"出错,赠送物品和数量不匹配" );
			}
		}
		
		//初始化装备栏
		initEquip(newRoleID, config);

		// 初始化一下技能
		new SkillRole(newRoleID, false);
		
		//初始化聊天常用语
		initFrequentlyMsg(newRoleID);
		
		// ///////////////////////////////////////////////////
		// 角色初始化数据请放在上面，下面要计算战斗力
		// ///////////////////////////////////////////////////
		int power = FightPowerCaculator.getPower(newRoleID, pro.getLevel(), MercenaryFightType.DEFAULT);
		pro.setPower(power);
		
		//日志相关
		LogUtil.doRoleCreateLog(newRoleID);
		
		ServerInfoProvider.syncRoleInfoToGlobal(newRoleID, pro.getUsername());
		
		pro.setOs(auUserInfo.getOs());
		pro.setMac(auUserInfo.getMac());
		pro.setUdid(auUserInfo.getUdid());
		pro.setIdfa(auUserInfo.getIdfa());
		pro.setPeer(InetAddressUtil.ipInt2String(auUserInfo.getLoginip()));
		
		return new PEnterWrold(thisProtocol, newRoleID, true, connectType).call();
	}
	
	private void initEquip(long roleid, RoleConfig config) {
		Equip equip = new Equip(roleid, false);
		int pos = 0;
		for (Integer itemid : config.equipini) {
			pos++;
			if (itemid == 0)
				continue;
			BasicItem bi = Module.getInstance().getItemManager().genBasicItem(itemid, 1);
			EquipFactory.getFactinroy().genEquipBaseAttr(bi, config.equipfrom);
			equip.addItem(bi, pos, ADD_ITEM_TYPE.EXT, "出生装备");
		}
	}

	private void initFrequentlyMsg(long roleid) {
		xbean.FrequentlyMsg msgInfo = xtable.Frequentlymsg.get(roleid);
		if(msgInfo == null){
			msgInfo = xbean.Pod.newFrequentlyMsg();
			xtable.Frequentlymsg.insert(roleid, msgInfo);
		}else{
			msgInfo.getMsgmap().clear();
		}
		
		Map<Integer, Squickchat> msgConfig = ConfigManager.getInstance().getConf(Squickchat.class);
		Iterator<Entry<Integer, Squickchat>> iterator = msgConfig.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<Integer, Squickchat> current = iterator.next();
			msgInfo.getMsgmap().put(current.getKey(), current.getValue().getTips());
		}
		
	}

	public void initBasicFighterProperties(xbean.Properties pro) {
		// 初始血量
		pro.setHp(10000);
		// 初始蓝量
		pro.setMp(10000);
		
	}
}
