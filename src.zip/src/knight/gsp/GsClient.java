/**
 * Class: Global.java
 * Package: knight.gsp
 *
 *
 *   ver     date      		author
 * ──────────────────────────────────
 *   		 2011-5-6 		liuchen & yangzhenyu
 *
 * Copyright (c) 2011, Perfect World All Rights Reserved.
*/

package knight.gsp;

import knight.gsp.scene.CommonThread;
import knight.gsp.scene.MapThreadManager;
import knight.gsp.scene.MapThreadProtocolParams;
import knight.msp.GGetSceneRoles;
import xdb.Procedure;
import xdb.Transaction;
import xdb.Procedure.Task;

/**
 * ClassName:Global
 * Function: ADD FUNCTION HERE
 *
 * @author   liuchen & yangzhenyu
 * @version  
 * @since    
 * @Date	 2011-5-6		上午11:52:01
 *
 * @see 	 
 */
public class GsClient {
	
	public static class SendToScene extends Task {
		private xio.Protocol p;
		private long sceneId;

		public SendToScene(long sceneId, xio.Protocol p) {
			this.p = p;
			this.sceneId = sceneId;
		}


		@Override
		public void run() 
		{
			sendToScene(sceneId, p);
		}
	}

	/**
	 * sendToScene: 将协议发送到场景
	 * 
	 * @param sceneId
	 * @param p
	 */
	public static void sendToScene(long sceneId, xio.Protocol p)
	{
		Object object = p.getSender();
		MapThreadProtocolParams params = null;
		if (object == null) {
			params = new MapThreadProtocolParams();
			p.setSender(params);
		} else {
			params = (MapThreadProtocolParams) object;
		}
		params.sceneId = sceneId;
		int threadId = MapThreadManager.getInstance().sceneId2MapThreadId(sceneId);
		params.threadIndex = threadId;
		knight.gsp.scene.MapThreadManager.getInstance().add(sceneId, p);
	}
	
	/**
	 * 向场景上发送协议
	 * 
	 * @param sceneId
	 * @param p
	 */
	public static boolean pSendWhileCommit(long sceneId, xio.Protocol p)
	{
		Object object = p.getSender();
		MapThreadProtocolParams params = null;
		if (object == null) {
			params = new MapThreadProtocolParams();
			p.setSender(params);
		} else {
			params = (MapThreadProtocolParams) object;
		}
		params.sceneId = sceneId;
		int threadId = MapThreadManager.getInstance().sceneId2MapThreadId(sceneId);
		params.threadIndex = threadId;
		
		if(null != Transaction.current()) {
			if (threadId <= 0) return false;
			Procedure.psendWhileCommit(threadId, p);//.ppostWhileCommit(new SendToScene(p));
		} else {
			knight.gsp.scene.MapThreadManager.getInstance().add(sceneId, p);
		}
		
		return true;
	}
	
	public static void send2RoleScene(long roleId, xio.Protocol p) {
		knight.gsp.map.Role mapRole = knight.gsp.map.RoleManager.getInstance().getRoleByID(roleId);
		
		long sceneId = -1;
		if (mapRole != null)
			sceneId = mapRole.getScene();
		
		Object object = p.getSender();
		MapThreadProtocolParams params = null;
		if (object == null) {
			params = new MapThreadProtocolParams();
			p.setSender(params);
		} else {
			params = (MapThreadProtocolParams) object;
		}
		params.roleId = roleId;
		params.sceneId = sceneId;
		
		sendToScene(sceneId, p);
	}
	
	public static boolean psend2RoleSceneWhileCommit(long roleId, xio.Protocol p) {
		knight.gsp.map.Role mapRole = knight.gsp.map.RoleManager.getInstance().getRoleByID(roleId);
		
		long sceneId = -1;
		if (mapRole != null)
			sceneId = mapRole.getScene();
		
		Object object = p.getSender();
		MapThreadProtocolParams params = null;
		if (object == null) {
			params = new MapThreadProtocolParams();
			p.setSender(params);
		} else {
			params = (MapThreadProtocolParams) object;
		}
		params.roleId = roleId;
		params.sceneId = sceneId;
		
		return pSendWhileCommit(sceneId, p);
	}
	
	public static boolean psend2threadWhileCommit(int threadId, xio.Protocol p) {
		Object object = p.getSender();
		MapThreadProtocolParams params = null;
		if (object == null) {
			params = new MapThreadProtocolParams();
			p.setSender(params);
		} else {
			params = (MapThreadProtocolParams) object;
		}
		
		params.threadIndex = threadId;
		
		Procedure.psendWhileCommit(threadId, p); //.ppostWhileCommit(new SendToScene(p));
		return true;
	}
	
	public static boolean psend2CommonThreadWhileCommit(xio.Protocol p) {
		if(null != Transaction.current()) {
			Procedure.psendWhileCommit(CommonThread.IDENTIFY_ID, p); //.ppostWhileCommit(new SendToScene(p));
		} else {
			return CommonThread.getInstance().add(p);
		}
		
		return true;
	}
	
	/**
	 * 去场景线程获取到所有的角色id,回调是在逻辑层处理的
	 * 
	 * @param sceneId
	 * @param callBack
	 */
	public static void getSceneRoles(long sceneId, IGetSceneRoleCallback callBack) {
		GsClient.pSendWhileCommit(sceneId, new GGetSceneRoles(sceneId, callBack));
	}
}

