
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BeanImport2__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BeanImport2 extends __BeanImport2__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 787430;

	public int getType() {
		return 787430;
	}

	public knight.gsp.move.SceneType b10;
	public knight.gsp.task.TaskStatus b23;
	public knight.gsp.move.FightSceneType b41;
	public knight.gsp.camp.CampValue b47;
	public knight.gsp.family.FamilyPositionType b51;
	public knight.gsp.mercenary.MercenaryFightType b55;
	public knight.gsp.npc.NpcAdditionInfoKey b59;
	public knight.gsp.item.GiftType b60;
	public knight.gsp.move.SpriteComponents b31;
	public knight.gsp.Bag b32;
	public knight.gsp.move.FighterStandCamp b64;

	public BeanImport2() {
		b10 = new knight.gsp.move.SceneType();
		b23 = new knight.gsp.task.TaskStatus();
		b41 = new knight.gsp.move.FightSceneType();
		b47 = new knight.gsp.camp.CampValue();
		b51 = new knight.gsp.family.FamilyPositionType();
		b55 = new knight.gsp.mercenary.MercenaryFightType();
		b59 = new knight.gsp.npc.NpcAdditionInfoKey();
		b60 = new knight.gsp.item.GiftType();
		b31 = new knight.gsp.move.SpriteComponents();
		b32 = new knight.gsp.Bag();
		b64 = new knight.gsp.move.FighterStandCamp();
	}

	public BeanImport2(knight.gsp.move.SceneType _b10_, knight.gsp.task.TaskStatus _b23_, knight.gsp.move.FightSceneType _b41_, knight.gsp.camp.CampValue _b47_, knight.gsp.family.FamilyPositionType _b51_, knight.gsp.mercenary.MercenaryFightType _b55_, knight.gsp.npc.NpcAdditionInfoKey _b59_, knight.gsp.item.GiftType _b60_, knight.gsp.move.SpriteComponents _b31_, knight.gsp.Bag _b32_, knight.gsp.move.FighterStandCamp _b64_) {
		this.b10 = _b10_;
		this.b23 = _b23_;
		this.b41 = _b41_;
		this.b47 = _b47_;
		this.b51 = _b51_;
		this.b55 = _b55_;
		this.b59 = _b59_;
		this.b60 = _b60_;
		this.b31 = _b31_;
		this.b32 = _b32_;
		this.b64 = _b64_;
	}

	public final boolean _validator_() {
		if (!b10._validator_()) return false;
		if (!b23._validator_()) return false;
		if (!b41._validator_()) return false;
		if (!b47._validator_()) return false;
		if (!b51._validator_()) return false;
		if (!b55._validator_()) return false;
		if (!b59._validator_()) return false;
		if (!b60._validator_()) return false;
		if (!b31._validator_()) return false;
		if (!b32._validator_()) return false;
		if (!b64._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(b10);
		_os_.marshal(b23);
		_os_.marshal(b41);
		_os_.marshal(b47);
		_os_.marshal(b51);
		_os_.marshal(b55);
		_os_.marshal(b59);
		_os_.marshal(b60);
		_os_.marshal(b31);
		_os_.marshal(b32);
		_os_.marshal(b64);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		b10.unmarshal(_os_);
		b23.unmarshal(_os_);
		b41.unmarshal(_os_);
		b47.unmarshal(_os_);
		b51.unmarshal(_os_);
		b55.unmarshal(_os_);
		b59.unmarshal(_os_);
		b60.unmarshal(_os_);
		b31.unmarshal(_os_);
		b32.unmarshal(_os_);
		b64.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BeanImport2) {
			BeanImport2 _o_ = (BeanImport2)_o1_;
			if (!b10.equals(_o_.b10)) return false;
			if (!b23.equals(_o_.b23)) return false;
			if (!b41.equals(_o_.b41)) return false;
			if (!b47.equals(_o_.b47)) return false;
			if (!b51.equals(_o_.b51)) return false;
			if (!b55.equals(_o_.b55)) return false;
			if (!b59.equals(_o_.b59)) return false;
			if (!b60.equals(_o_.b60)) return false;
			if (!b31.equals(_o_.b31)) return false;
			if (!b32.equals(_o_.b32)) return false;
			if (!b64.equals(_o_.b64)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += b10.hashCode();
		_h_ += b23.hashCode();
		_h_ += b41.hashCode();
		_h_ += b47.hashCode();
		_h_ += b51.hashCode();
		_h_ += b55.hashCode();
		_h_ += b59.hashCode();
		_h_ += b60.hashCode();
		_h_ += b31.hashCode();
		_h_ += b32.hashCode();
		_h_ += b64.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(b10).append(",");
		_sb_.append(b23).append(",");
		_sb_.append(b41).append(",");
		_sb_.append(b47).append(",");
		_sb_.append(b51).append(",");
		_sb_.append(b55).append(",");
		_sb_.append(b59).append(",");
		_sb_.append(b60).append(",");
		_sb_.append(b31).append(",");
		_sb_.append(b32).append(",");
		_sb_.append(b64).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

