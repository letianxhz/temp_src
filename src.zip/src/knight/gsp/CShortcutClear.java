
package knight.gsp;
import knight.gsp.skill.SkillRole;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CShortcutClear__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CShortcutClear extends __CShortcutClear__ {
	@Override
	protected void process() {
		// protocol handle
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if(roleid <= 0 || LocalIds.isRemoteServerRole(roleid))
			return;
		
		new xdb.Procedure(){
			@Override
			public boolean process(){
				return new SkillRole(roleid, false).shortcutClear(shortcutid);
			}
		}.submit();
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786454;

	public int getType() {
		return 786454;
	}

	public short shortcutid;

	public CShortcutClear() {
	}

	public CShortcutClear(short _shortcutid_) {
		this.shortcutid = _shortcutid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(shortcutid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		shortcutid = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CShortcutClear) {
			CShortcutClear _o_ = (CShortcutClear)_o1_;
			if (shortcutid != _o_.shortcutid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += shortcutid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(shortcutid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CShortcutClear _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = shortcutid - _o_.shortcutid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

