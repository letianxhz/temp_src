package knight.gsp;

import java.util.Arrays;

import gnet.link.Onlines;
import knight.gsp.dny.DongNanYaManager;
import knight.gsp.dragon.Dragon;
import knight.gsp.dragon.DragonAttrCalculator;
import knight.gsp.dragon.DragonColumn;
import knight.gsp.dragon.Module;
import knight.gsp.dragon.SDragonRefreshExpLevel;
import knight.gsp.dragon.SRefreshDragon;
import knight.gsp.dragon.SRefreshDragonAttr;
import knight.gsp.event.DragonUpgradeEvent;
import knight.gsp.event.Poster;
import knight.gsp.gat.GATManager;
import knight.gsp.hg.HanGuoManager;
import knight.gsp.msg.Message;
import knight.gsp.msg.MsgType;
import knight.gsp.msg.SPlayEffectID;
import knight.gsp.msg.SSendChatMsg;
import knight.gsp.ranklist.proc.PServantScoreRanklist;
import knight.gsp.ranklist.proc.RankListManager;
import knight.gsp.yuenan.YNManager;
import xdb.Procedure;

public class PAddDragonExpProc extends Procedure {
	
	long roleid;
	
	long dragonUid;
	
	final int addExp;
	public PAddDragonExpProc(long roleid, long dragonUid,int addExp) {
		this.roleid = roleid;
		this.dragonUid = dragonUid;
		this.addExp = addExp;
	}

	@Override
	public boolean process(){
		if (addExp <= 0)
			return false;
		final xbean.Properties prop = xtable.Properties.get(roleid);
		if (null == prop)
			return false;
		final DragonColumn dragoncol = new DragonColumn(roleid, false);
		knight.gsp.dragon.Dragon dragon = dragoncol.getDragonByUniqid(dragonUid);
		if(null == dragon)
			return false;
		if(dragon.getLevel() >= prop.getLevel()){
			Message.psendMsgNotify(roleid, 1029267, null);
			return false;
		}
		final int oldLevel = dragon.getLevel();
		int level = dragon.getLevel();
		int addExpForCal = addExp;
		if (addExpForCal > 0) {
			int needExp = knight.gsp.dragon.Module.getInstance().getSdragonExpBylevel(level);
			while (dragon.getExp() + addExpForCal > needExp && level < prop.getLevel()) {
				addExpForCal -= (needExp - dragon.getExp()) ;
					level ++;
					needExp = knight.gsp.dragon.Module.getInstance().getSdragonExpBylevel(level);
					dragon.setExp(0);
			}
		}
		if(oldLevel != level){
			xdb.Procedure.psendWhileCommit(roleid,new knight.gsp.msg.SPlayEffectID((byte)SPlayEffectID.PLAY_TYPE_COMMON, Dragon.DRAGON_ADD_EXP_UP));
			
			Poster.getPoster().dispatchEvent(new DragonUpgradeEvent(roleid, 1));
		}
		dragon.setLevel(level);
		dragon.setExp(dragon.getExp() + addExpForCal);
		//刷新龙
		SRefreshDragon refreshDragon = new SRefreshDragon();
		refreshDragon.dragon = dragon.getProtocolDragon();
		xdb.Procedure.psendWhileCommit(roleid, refreshDragon);
		//刷新显示
		int leftFosterTimes = dragon.getDragonCanFosterTimes() - dragon.getDragonInfo().getFostertimes();
		int canFosterTimes = leftFosterTimes > 0 ? leftFosterTimes : 0;
		SDragonRefreshExpLevel refresh = new SDragonRefreshExpLevel(dragonUid, level, (int)dragon.getExp(), Module.getInstance().getSdragonExpBylevel(level), canFosterTimes);
		xdb.Procedure.psendWhileCommit(roleid, refresh);
		
		//刷新最终属性
		SRefreshDragonAttr attrsRefresh = new SRefreshDragonAttr();
		attrsRefresh.dragonuid = dragon.getUniqid();
		attrsRefresh.attrparam.putAll(DragonAttrCalculator.getAttrs(xtable.Properties.selectSchool(roleid),dragon.getDragonInfo()));
		if(GATManager.getInstance().isGATServer() || HanGuoManager.getInstance().isHanGuoServer() || DongNanYaManager.getInstance().isDongNanYaServer()
				|| YNManager.getInstance().isYNServer()){
			Message.sendMsgNotify(roleid, 1030491, Arrays.asList(dragon.getName(), addExp+""));
		} else {
			//提示
			final SSendChatMsg snd = new SSendChatMsg();
			snd.msg = "<T t=\""+dragon.getName()+"获得 " + addExp + " 经验\"/>";
			snd.level = prop.getLevel();
			snd.power = prop.getPower();
			snd.msgtype = MsgType.CHANNEL_SCREEN;
			snd.school = (short) prop.getSchool();
			Onlines.getInstance().send(roleid, snd);
		}
		
		//刷新人物属性
		//刷新人物的战斗力
		if(dragoncol.isInFightOrDefence(dragonUid)){
			dragoncol.refreshRoleAttr();
			xdb.Procedure.pexecuteWhileCommit(new PFightPowerChangeCallback(roleid));
		}
		xdb.Procedure.pexecuteWhileCommit(new PServantScoreRanklist(roleid, dragoncol.scoreForRank()));
		
		RankListManager.getInstance().tryAddPlatDragonRank(roleid, dragoncol.scoreForRank());
		
		return true;
	}
	
}
