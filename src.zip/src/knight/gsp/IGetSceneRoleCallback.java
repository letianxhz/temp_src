package knight.gsp;

import java.util.Set;

public interface IGetSceneRoleCallback {

	public void handle(Set<Long> sceneRoles);
	
}
