
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SMayDayActivity__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SMayDayActivity extends __SMayDayActivity__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786552;

	public int getType() {
		return 786552;
	}

	public byte liangjunkaoshang; // 是否显示两军犒赏小红点，1显示，0不显示
	public byte jingjizhanchang; // 是否在荆棘战场活动期间内
	public byte jierijiajiang; // 是否在节日嘉奖活动期间内

	public SMayDayActivity() {
	}

	public SMayDayActivity(byte _liangjunkaoshang_, byte _jingjizhanchang_, byte _jierijiajiang_) {
		this.liangjunkaoshang = _liangjunkaoshang_;
		this.jingjizhanchang = _jingjizhanchang_;
		this.jierijiajiang = _jierijiajiang_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(liangjunkaoshang);
		_os_.marshal(jingjizhanchang);
		_os_.marshal(jierijiajiang);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		liangjunkaoshang = _os_.unmarshal_byte();
		jingjizhanchang = _os_.unmarshal_byte();
		jierijiajiang = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SMayDayActivity) {
			SMayDayActivity _o_ = (SMayDayActivity)_o1_;
			if (liangjunkaoshang != _o_.liangjunkaoshang) return false;
			if (jingjizhanchang != _o_.jingjizhanchang) return false;
			if (jierijiajiang != _o_.jierijiajiang) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)liangjunkaoshang;
		_h_ += (int)jingjizhanchang;
		_h_ += (int)jierijiajiang;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(liangjunkaoshang).append(",");
		_sb_.append(jingjizhanchang).append(",");
		_sb_.append(jierijiajiang).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SMayDayActivity _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = liangjunkaoshang - _o_.liangjunkaoshang;
		if (0 != _c_) return _c_;
		_c_ = jingjizhanchang - _o_.jingjizhanchang;
		if (0 != _c_) return _c_;
		_c_ = jierijiajiang - _o_.jierijiajiang;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

