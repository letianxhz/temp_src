package knight.gsp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.goldhuman.Common.Marshal.OctetsStream;

public class ProtocolStatics {
	
	public final static Logger logger = Logger.getLogger(ProtocolStatics.class);
	
	private static Map<String,Long> sendProtocolNumMap = new ConcurrentHashMap<String,Long>(1000);
	
	private static Map<String,Long> sendProtocolSizeMap = new ConcurrentHashMap<String,Long>(1000); 
	
	private static Map<String,Long> receiveProtocolNumMap = new ConcurrentHashMap<String,Long>(1000);
	
	private static Map<String,Long> receiveProtocolSizeMap = new ConcurrentHashMap<String,Long>(1000);
	
	public static final int PRINT_INFO_SIZE = 50;
	
	/**
	 * 发送一个协议
	 * 
	 * @param p
	 */
	public static void sendProtocol(xio.Protocol p) {
		String className = p.getClass().getName();
		Long num = sendProtocolNumMap.get(className);
		if (num == null)
			num = 0L;
		
		sendProtocolNumMap.put(className, num + 1);
		
		
		Long size = sendProtocolSizeMap.get(className);
		if (size == null)
			size = 0L;
		
		sendProtocolSizeMap.put(className, size + new OctetsStream().marshal(p).size());
	}
	
	/**
	 * 接收一个协议
	 * 
	 * @param p
	 */
	public static void receiveProtocol(xio.Protocol p) {
		String className = p.getClass().getName();
		Long num = receiveProtocolNumMap.get(className);
		if (num == null)
			num = 0L;
		
		receiveProtocolNumMap.put(className, num + 1);
		
		
		Long size = receiveProtocolSizeMap.get(className);
		if (size == null)
			size = 0L;
		
		receiveProtocolSizeMap.put(className, size + new OctetsStream().marshal(p).size());
	}
	
	public static void print() {
		List<PInfo> list1 = sortProtocolMap(sendProtocolNumMap);
		List<PInfo> list2 = sortProtocolMap(sendProtocolSizeMap);
		List<PInfo> list3 = sortProtocolMap(receiveProtocolNumMap);
		List<PInfo> list4 = sortProtocolMap(receiveProtocolSizeMap);
		logger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		logger.info("static data for send protocol num:  ");
		for (int i = 0; i < list1.size() ; i ++) {
			PInfo info = list1.get(i);
			logger.info("protocol name:          " + info.protocolName + "            sendTotalNum:   " + info._n);
		}
		logger.info("static data for send protocol size:  ");
		for (int i = 0; i < list2.size() ; i ++) {
			PInfo info = list2.get(i);
			logger.info("protocol name:          " + info.protocolName + "            sendTotalSize:   " + info._n);
		}
		logger.info("static data for receive protocol num:  ");
		for (int i = 0; i < list3.size() ; i ++) {
			PInfo info = list3.get(i);
			logger.info("protocol name:          " + info.protocolName + "            receiveTotalNum:   " + info._n);
		}
		logger.info("static data for receive protocol size:  ");
		for (int i = 0; i < list4.size() ; i ++) {
			PInfo info = list4.get(i);
			logger.info("protocol name:          " + info.protocolName + "            receiveTotalSize:   " + info._n);
		}
		logger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
	}
	
	public static final class PInfo {
		
		public PInfo(String protocolName, long _n) {
			super();
			this.protocolName = protocolName;
			this._n = _n;
		}

		public String protocolName;
		
		public long _n;
		
	}

	private static List<PInfo> sortProtocolMap(Map<String,Long> pmap) {
		List<PInfo> result = new ArrayList<PInfo>(1000);
		
		for (Map.Entry<String, Long> entry : pmap.entrySet()) {
			String className = entry.getKey();
			long _n = entry.getValue();
			result.add(new PInfo(className, _n));
		}
		
		Collections.sort(result, new Comparator<PInfo>() {

			@Override
			public int compare(PInfo o1, PInfo o2) {
				return o1._n - o2._n > 0 ? -1 : 1;
			}
		});
		
		return result;
	}
}
