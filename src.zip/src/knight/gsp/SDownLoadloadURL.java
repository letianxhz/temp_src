
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SDownLoadloadURL__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SDownLoadloadURL extends __SDownLoadloadURL__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786535;

	public int getType() {
		return 786535;
	}

	public java.lang.String imageurl;
	public int downloadcounter; // 因为需要覆盖上传，所以玩家的头像下载地址都是一样的，用计数器来标示是否需要重新下载

	public SDownLoadloadURL() {
		imageurl = "";
	}

	public SDownLoadloadURL(java.lang.String _imageurl_, int _downloadcounter_) {
		this.imageurl = _imageurl_;
		this.downloadcounter = _downloadcounter_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(imageurl, "UTF-16LE");
		_os_.marshal(downloadcounter);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		imageurl = _os_.unmarshal_String("UTF-16LE");
		downloadcounter = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SDownLoadloadURL) {
			SDownLoadloadURL _o_ = (SDownLoadloadURL)_o1_;
			if (!imageurl.equals(_o_.imageurl)) return false;
			if (downloadcounter != _o_.downloadcounter) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += imageurl.hashCode();
		_h_ += downloadcounter;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(imageurl.length()).append(",");
		_sb_.append(downloadcounter).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

