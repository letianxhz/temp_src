package knight.gsp;

import java.util.Arrays;

import knight.gsp.msg.Message;
import knight.gsp.ranklist.RankType;
import knight.gsp.title.PAddTitleProc;
import knight.gsp.title.PRemoveTitleProc;
import xbean.RolePropertyRankList;
import xdb.Procedure;

/**
 * 00:05 处理服务器全局数据
 * 
 * @author yangzhenyu
 *
 * @date 2016年4月11日 下午7:24:09
 *
 */
public class PCalcServerData extends Procedure {

	@Override
	protected boolean process() throws Exception {
		
		long powerNewTitleRole = -1L;
		RolePropertyRankList powerRank = xtable.Rolepropertyrank.select(RankType.POWER_RANK);
		String titleRoleName = "";
		if (powerRank != null && powerRank.getRecords().size() > 0) {
			//给综合实力最高的玩家一个称谓，最强王者
			powerNewTitleRole = powerRank.getRecords().get(0).getMarshaldata().getRoleid();
			titleRoleName = xtable.Properties.selectRolename(powerNewTitleRole);
			Message.sendSystemMsg(1038121, Arrays.asList(titleRoleName));
		}
		
		xbean.ServerData serverData = xtable.Serverdata.get(1);
		if (serverData == null) {
			serverData = xbean.Pod.newServerData();
			xtable.Serverdata.insert(1, serverData);
		}
		
		if (serverData.getMergeserverroles().size() > 0) {
			for (long rid : serverData.getMergeserverroles()) {
				if (powerNewTitleRole != rid) {
					xdb.Procedure.pexecuteWhileCommit(new PRemoveTitleProc(rid, 84));
				}
			}
			
			if (powerNewTitleRole > 0 && !serverData.getMergeserverroles().contains(powerNewTitleRole)) {
				xdb.Procedure.pexecuteWhileCommit(new PAddTitleProc(powerNewTitleRole, 84, "", -1, true, true));
			}
			serverData.getMergeserverroles().clear();
		} else {
			if (powerNewTitleRole > 0 && powerNewTitleRole != serverData.getPowertitlerole()) {
				xdb.Procedure.pexecuteWhileCommit(new PAddTitleProc(powerNewTitleRole, 84, "", -1, true, true));
				if (serverData.getPowertitlerole() > 0) {
					xdb.Procedure.pexecuteWhileCommit(new PRemoveTitleProc(serverData.getPowertitlerole(), 84));
				}
			}
		}
		if (powerNewTitleRole > 0) {
			serverData.setPowertitlerole(powerNewTitleRole);
		}
		
		
		return true;
	}
	
}
