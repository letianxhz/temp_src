
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SGetSchoolAdvanceTaskState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SGetSchoolAdvanceTaskState extends __SGetSchoolAdvanceTaskState__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786519;

	public int getType() {
		return 786519;
	}

	public java.util.ArrayList<knight.gsp.UnCommitTasks> uncommittasks; // 未经完成的任务id

	public SGetSchoolAdvanceTaskState() {
		uncommittasks = new java.util.ArrayList<knight.gsp.UnCommitTasks>();
	}

	public SGetSchoolAdvanceTaskState(java.util.ArrayList<knight.gsp.UnCommitTasks> _uncommittasks_) {
		this.uncommittasks = _uncommittasks_;
	}

	public final boolean _validator_() {
		for (knight.gsp.UnCommitTasks _v_ : uncommittasks)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(uncommittasks.size());
		for (knight.gsp.UnCommitTasks _v_ : uncommittasks) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			knight.gsp.UnCommitTasks _v_ = new knight.gsp.UnCommitTasks();
			_v_.unmarshal(_os_);
			uncommittasks.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SGetSchoolAdvanceTaskState) {
			SGetSchoolAdvanceTaskState _o_ = (SGetSchoolAdvanceTaskState)_o1_;
			if (!uncommittasks.equals(_o_.uncommittasks)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += uncommittasks.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(uncommittasks).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

