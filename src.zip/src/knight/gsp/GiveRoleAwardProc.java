package knight.gsp;

import knight.gsp.PAddExpProc.EXP_TYPE;
import knight.gsp.award.AwardManager;
import xdb.Procedure;

/**
 * 给单个角色发奖的存储过程
 * 
 * @author yangzhenyu
 * 
 *         2014-6-17 上午3:11:03
 */
public class GiveRoleAwardProc extends Procedure {
	
	private long roleId;
	
	private int awardId;

	public GiveRoleAwardProc(long roleId, int awardId) {
		super();
		this.roleId = roleId;
		this.awardId = awardId;
	}

	@Override
	protected boolean process() throws Exception {
		AwardManager.getInstance().distributeAllAward(roleId, awardId, null, EXP_TYPE.EXT, 0, "阵营排行榜奖励", true, true);
		return true;
	}
	
}
