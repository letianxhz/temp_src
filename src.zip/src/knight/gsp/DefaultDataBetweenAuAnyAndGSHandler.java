package knight.gsp;

import xdb.Transaction;
import gnet.DataBetweenAuAnyAndGS;

public class DefaultDataBetweenAuAnyAndGSHandler extends
		DataBetweenAuAnyAndGSHandler {

	@Override
	public void handleReq(DataBetweenAuAnyAndGS data) {
		if(null == Transaction.current()) {
			new knight.gsp.yuanbao.PReceiveDataFromAuany(data).submit();
		} else {
			new knight.gsp.yuanbao.PReceiveDataFromAuany(data).call();
		}
	}
}
