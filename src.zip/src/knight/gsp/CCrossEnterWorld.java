
package knight.gsp;

import java.util.Arrays;

import global.rsp.GSceneDoesnotExist;
import global.rsp.GlobalClientManager;
import global.rsp.fuben.ClearCrossState;
import gnet.link.Dispatch;
import gnet.link.Onlines;
import gnet.link.SetLogin;
import gnet.link.User;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.map.SceneManager;
import knight.gsp.state.StateManager;







// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CCrossEnterWorld__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CCrossEnterWorld extends __CCrossEnterWorld__ {
	@Override
	protected void process() {
		StateManager.logger.info("CCrossEnterWorld: 角色（Id = " + roleid + "）开始进入世界");

		if (Onlines.getInstance().getOnlineUsers().online(this, true) == null) {
			// 踢下线
			gnet.link.Onlines.getInstance().kick(roleid, KickErrConst.ERR_GM_KICKOUT);
			knight.gsp.state.StateManager.logger.error("角色（Id = " + roleid + "）上线失败。 ");
		}
		Dispatch ctx = (Dispatch) getContext();
		final int userId = ctx.userid;
		new SetLogin(ctx.linksid, SetLogin.eLogin, -1).send(getConnection());
		
		final xio.Protocol enterWorldProtocol = this;
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				
				int myServerId = ServerInfoProvider.roleid2zoneid(roleid);
				if (ConfigManager.getGsZoneId() != myServerId) {
					
					xbean.CrossRole crossRole = xtable.Crossroles.select(roleid);
					
					//去跨服，发现跨服没有保留数据了，则清除原服的跨服状态
					xbean.CrossGenterWorld crossEnterWorld = null;
					if (crossRole != null) {
						
						//先锁 user lock
						lock(xtable.Locks.USERLOCK, Arrays.asList(crossRole.getUserid()));
						
						//锁 rolelock
						crossEnterWorld = xtable.Crossgenterworld.get(roleid);
					}
					long sceneId = -1;
					boolean isSceneExist = false;
					if(crossEnterWorld != null){
						sceneId = crossEnterWorld.getGenterworld().mapinfo.sceneid;
						isSceneExist = knight.gsp.map.SceneManager.getInstance().isSceneExist(sceneId);
					}
					if (crossRole == null || crossEnterWorld == null || isSceneExist == false) {
						if (myServerId > 0) {
							if(!isSceneExist && SceneManager.getInstance().isFamilyGatherScene(sceneId)){
								GlobalClientManager.getInstance().send(new GSceneDoesnotExist(GSceneDoesnotExist.FAMILY_GATHER, sceneId, roleid, ConfigManager.getGsZoneId(), myServerId));
							}
							GlobalClientManager.getInstance().send(myServerId, new ClearCrossState(roleid));
							knight.gsp.log.Module.logger.error("跨服角色:" + roleid + "登陆时，数据异常。清除跨服状态.serverId=" + myServerId);
						} else {
							knight.gsp.log.Module.logger.error("跨服角色:" + roleid + "登陆时，数据异常。无法清除跨服状态");
						}
						
						User user = Onlines.getInstance().getOnlineUsers().get(userId);
						if (user != null) {
							user.kick(-999);
						}
						
						return true;
					}
				} else {
					//从跨服回到原服
					xbean.Properties prop = xtable.Properties.select(roleid);
					if (prop == null)
						return false;
					
					//先锁 user lock
					lock(xtable.Locks.USERLOCK, Arrays.asList(prop.getUserid()));
					
					//防止因为ClearCrossState这个协议时序问题，导致玩家从跨服回到原服后又立马被重定向到跨服去了
					xtable.Crossstate.remove(roleid);
				}
				
				return new PEnterWrold(enterWorldProtocol, roleid, false, connecttype).call();
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786475;

	public int getType() {
		return 786475;
	}

	public long roleid;
	public byte connecttype; // 参考枚举ConnectType

	public CCrossEnterWorld() {
	}

	public CCrossEnterWorld(long _roleid_, byte _connecttype_) {
		this.roleid = _roleid_;
		this.connecttype = _connecttype_;
	}

	public final boolean _validator_() {
		if (roleid < 1) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(connecttype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		connecttype = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CCrossEnterWorld) {
			CCrossEnterWorld _o_ = (CCrossEnterWorld)_o1_;
			if (roleid != _o_.roleid) return false;
			if (connecttype != _o_.connecttype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)connecttype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(connecttype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CCrossEnterWorld _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = connecttype - _o_.connecttype;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

