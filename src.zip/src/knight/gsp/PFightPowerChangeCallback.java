package knight.gsp;

import knight.gsp.attr.AttrType;
import knight.gsp.attr.SRefreshRoleData;
import knight.gsp.camp.CampRole;
import knight.gsp.camp.PAddCampZhanli;
import knight.gsp.event.Poster;
import knight.gsp.event.ZhanLiEvent;
import knight.gsp.friends.Constant;
import knight.gsp.master.MasterApprentManager;
import knight.gsp.mercenary.MercenaryFightType;
import knight.gsp.ranklist.RankType;
import knight.gsp.ranklist.proc.PCampRanklistPro;
import knight.gsp.ranklist.proc.PTryAddPlatRolePropertyRank;
import knight.gsp.ranklist.proc.RankListManager;
import knight.msp.GUpdateRolePower;
import xdb.Procedure;
import knight.gsp.activity.newservergift.NewServerGiftManager;

public class PFightPowerChangeCallback extends Procedure {
	
	long roleid;
	@SuppressWarnings("unused")
	private boolean addEquip;
	
	public PFightPowerChangeCallback(long roleid) {
		this.roleid = roleid;
	}
	
	public PFightPowerChangeCallback(long roleid, boolean addEquip) {
		this.roleid = roleid;
		this.addEquip = addEquip;
	}
	
	@Override
	public boolean process() {
		xbean.Properties rolePro = xtable.Properties.select(roleid);
		if (rolePro == null)
			return false;

		int oldPower = rolePro.getPower();

		int powerValue = FightPowerCaculator.getPower(roleid, rolePro.getLevel(), MercenaryFightType.DEFAULT);

		new PTryAddRolepropertyRank(roleid, powerValue, RankType.POWER_RANK, oldPower >= Constant.ROLE_POWER_MIN_LEVEL).call();

		if (RankListManager.getInstance().canAddPlatRank(rolePro.getNickname(), RankType.PLAT_POWER_RANK)) {
			new PTryAddPlatRolePropertyRank(roleid, powerValue, RankType.PLAT_POWER_RANK, oldPower >= Constant.ROLE_POWER_MIN_LEVEL,
					rolePro.getNickname()).call();
		}
		
		CampRole campRole = new CampRole(roleid, true);
		xdb.Procedure.pexecuteWhileCommit(new PCampRanklistPro(campRole.getCampSw(), roleid, campRole.getCampLevel()));

		//优化一下强弱阵营
		if(campRole.getStandCamp() > 0){
			if(powerValue > oldPower){
				xdb.Procedure.pexecuteWhileCommit(new PAddCampZhanli(powerValue - oldPower,campRole.getStandCamp()));
			}
		}
		
		SRefreshRoleData refreshRoleData = new SRefreshRoleData();
		refreshRoleData.datas.put(AttrType.POWER_MAX, (float) powerValue);

		xdb.Procedure.psendWhileCommit(roleid, refreshRoleData);

		GsClient.psend2RoleSceneWhileCommit(roleid, new GUpdateRolePower(roleid, powerValue));

		// 目前策划要求不仅仅只显示装备的，所有的都要显示，所以交给客户端处理吧，服务器不发这个协议了，以后如果有需要再处理吧
		// if (addEquip && powerValue > oldPower) {
		// xdb.Procedure.psendWhileCommit(roleid, new SFightPowerChanged(powerValue - oldPower));
		// }

		Poster.getPoster().dispatchEvent(new ZhanLiEvent(roleid, powerValue));
		
		// 在最后设置战力
		xtable.Properties.get(roleid).setPower(powerValue);
		NewServerGiftManager.refreshRedNotice(2, roleid,false);
		
		
		MasterApprentManager.handleApprentAchive(roleid, MasterApprentManager.ACHIEVE_TYPE_JPZB,powerValue-oldPower);

		
		return true;
	}
}
