
package knight.gsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SJuBaoPenBindState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SJuBaoPenBindState extends __SJuBaoPenBindState__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786561;

	public int getType() {
		return 786561;
	}

	public int flag; // 当前状态 0=未认证 1=短信码等待中 2=短信码认证中  3=认证成功
	public java.lang.String phonenumber; // 电话号
	public long remiantime; // 剩余冷却时间

	public SJuBaoPenBindState() {
		phonenumber = "";
	}

	public SJuBaoPenBindState(int _flag_, java.lang.String _phonenumber_, long _remiantime_) {
		this.flag = _flag_;
		this.phonenumber = _phonenumber_;
		this.remiantime = _remiantime_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(flag);
		_os_.marshal(phonenumber, "UTF-16LE");
		_os_.marshal(remiantime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		flag = _os_.unmarshal_int();
		phonenumber = _os_.unmarshal_String("UTF-16LE");
		remiantime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SJuBaoPenBindState) {
			SJuBaoPenBindState _o_ = (SJuBaoPenBindState)_o1_;
			if (flag != _o_.flag) return false;
			if (!phonenumber.equals(_o_.phonenumber)) return false;
			if (remiantime != _o_.remiantime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += flag;
		_h_ += phonenumber.hashCode();
		_h_ += (int)remiantime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(flag).append(",");
		_sb_.append("T").append(phonenumber.length()).append(",");
		_sb_.append(remiantime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

