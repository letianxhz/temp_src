package knight.gsp;

import java.util.HashMap;
import java.util.Map;
import knight.gsp.attr.AttrType;
import knight.gsp.buff.PGetBuffInfos;
import knight.gsp.scene.battle.BattleField;
import knight.gsp.scene.calc.CalcInstanceManager;
import knight.gsp.scene.effect.InitAttr;
import knight.gsp.scene.effect.Module;
import knight.msp.SceneBuffInit;
import knight.msp.SingleBuffInit;

/**
 * 计算角色属性的工具类
 * 
 * @author yangzhenyu
 * 
 * @date:2015-10-23 下午3:45:36
 */
public class AttrCalactor {
	
	public static Map<Integer,Float> calcRoleProperties(long roleId) {
		if (LocalIds.isRemoteServerRole(roleId))
			return null;
		
		Map<Integer,Float> result = new HashMap<Integer,Float>();
		
		SceneBuffInit init = null;
		try {
			init = PGetBuffInfos.getInitBuff(roleId);
		} catch (Exception e) {
			e.printStackTrace();
			return result;
		}
		
		xbean.Properties prop = xtable.Properties.select(roleId);
		
		Map<Integer,Float> buffEffects = new HashMap<Integer,Float>();
		for (Map.Entry<Integer,SingleBuffInit> buffEntry : init.buffinfo.entrySet()) {
			SingleBuffInit buffInit = buffEntry.getValue();
			for (Map.Entry<Integer,Float> effectEntry : buffInit.effects.entrySet()) {
				int effectId = effectEntry.getKey();
				float effect = effectEntry.getValue();
				Float oldEffect = buffEffects.get(effectId);
				if (oldEffect == null)
					oldEffect = 0f;
				
				buffEffects.put(effectId, oldEffect + effect);
			}
		}
		
		for (int i = 0; i < Module.fightAttrTypeIds.length; i++) {
			
			int attrId = Module.fightAttrTypeIds[i];
			
			//体力，血，蓝等 是不能参与计算的，它们只是一个标量，没有反应玩家战斗能力
			if (!isAbilityAttr(attrId))
				continue;
			
			Float newValue = null;
			if (isLevel1Attr(attrId))
				newValue = calcLevel1Attr(attrId, init.attrinit, buffEffects);  //一级属性
			else
				newValue = calcFinalAttr(attrId, prop.getSchool(), init.attrinit, buffEffects); //二级属性，要用一级属性来算
			
			if (newValue.floatValue() == 0f)
				continue;
			
			result.put(attrId, newValue);
		}
		
		return result;
	}
	
	private static boolean isAbilityAttr(int attrId) {
		switch (attrId) {
		case AttrType.EXP:
		case AttrType.HP:
		case AttrType.MP:
		case AttrType.LEVEL:
		case AttrType.CONBO:
		case AttrType.ATTR_TYPE_MAX:
			return false;
		}
		return true;
	}
	
	private static boolean isLevel1Attr(int attrId) {
		switch (attrId) {
			case AttrType.CONS:
			case AttrType.STR:
			case AttrType.ENDU:
			case AttrType.AGI:
			case AttrType.IQ:
				return true;
			default: 
				return false;
		}
	}
	
	private static float calcLevel1Attr(int attrId, Map<Integer,Float> initAttrs, Map<Integer,Float> buffEffects) {
		return calcEffectBonus(attrId, initAttrs.get(attrId), buffEffects);
	}
	
	private static float calcEffectBonus(int attrType, float attrValue, Map<Integer,Float> buffEffects) {
		Float abl = buffEffects.get(attrType + 1);
		if (abl == null)
			abl = 0f;
		
		Float pct = buffEffects.get(attrType + 2);
		if (pct == null)
			pct = 0f;
		
		float value = (float) ((attrValue + abl) * (1 +  pct));
		return makePositiveVal(value);
	}
	
	private static float makePositiveVal(float val) {
		return Math.max(0, val);
	}
	
	private static float calcFinalAttr(int attrId, int school, Map<Integer,Float> level1Attrs, Map<Integer,Float> buffEffects) {
		String expression = knight.gsp.scene.effect.Module.getInstance().getAttr2ExpressionBySchool(school, attrId);
		Float val = 0f;
		if (expression != null) {
			try {
				
				Map<String,Object> params = new HashMap<String,Object>();
				params.put(knight.gsp.scene.effect.Module.getInstance().getAttrNameById(AttrType.CONS), level1Attrs.get(AttrType.CONS));
				params.put(knight.gsp.scene.effect.Module.getInstance().getAttrNameById(AttrType.IQ), level1Attrs.get(AttrType.IQ));
				params.put(knight.gsp.scene.effect.Module.getInstance().getAttrNameById(AttrType.STR), level1Attrs.get(AttrType.STR));
				params.put(knight.gsp.scene.effect.Module.getInstance().getAttrNameById(AttrType.ENDU), level1Attrs.get(AttrType.ENDU));
				params.put(knight.gsp.scene.effect.Module.getInstance().getAttrNameById(AttrType.AGI), level1Attrs.get(AttrType.AGI));
				
				val = CalcInstanceManager.getInstance().getAttrModCalcUtil().invokeSchoolInitAttrScript(school, attrId, params);
			} catch (Exception e) {
				knight.gsp.scene.effect.Module.logger.error("school=" + school + "的属性计算公式" + attrId + "计算有误");
			}
		}
		
		return calcEffectBonus(attrId, val + getInitVal(attrId, school), buffEffects);
	}
	
	private static float getInitVal(int attrId, int school) {
		InitAttr initAttr = Module.getInstance().getInitValueByAttrId(attrId);
		if (initAttr == null)
			return 0f;
		
		switch (BattleField.getCommonSchoolBySchoolId(school)) {
		case 1:
			return initAttr.getZhanShiVal();
		case 2:
			return initAttr.getFaShiVal();
		case 3:
			return initAttr.getGongJianShouVal();
		case 4:
			return initAttr.getMuShiVal();
		case 5:
			return initAttr.getShashouVal();
		}
		
		return 0f;
	}

}
