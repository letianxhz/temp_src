
package knight.gsp;

import knight.gsp.main.ConfigManager;
import global.rsp.GlobalClientManager;
import global.rsp.ReqServerInfoRoles;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CReqServerRoleInfos__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CReqServerRoleInfos extends __CReqServerRoleInfos__ {
	@Override
	protected void process() {
		final int userID = ((gnet.link.Dispatch) this.getContext()).userid;
		if (userID <= 0) {
			return;
		}
		
		GlobalClientManager.getInstance().send(new ReqServerInfoRoles(userID, userID, ConfigManager.getGsZoneId(), opendlg));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786526;

	public int getType() {
		return 786526;
	}

	public byte opendlg; // 是否打开界面,1打开，0不打开

	public CReqServerRoleInfos() {
	}

	public CReqServerRoleInfos(byte _opendlg_) {
		this.opendlg = _opendlg_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(opendlg);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		opendlg = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CReqServerRoleInfos) {
			CReqServerRoleInfos _o_ = (CReqServerRoleInfos)_o1_;
			if (opendlg != _o_.opendlg) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)opendlg;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(opendlg).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CReqServerRoleInfos _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = opendlg - _o_.opendlg;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

