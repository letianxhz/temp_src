package knight.gsp;

import gnet.link.User;

import java.util.List;

import knight.gsp.main.ConfigManager;
import knight.gsp.role.RoleConfig;
import knight.gsp.util.Misc;
import knight.gsp.util.NameRepository;
import xdb.Procedure;
import xdb.util.UniqName;

/**
 * 创建随机名字的存储过程
 * 
 * @author yangzhenyu
 * 
 *         2014-4-11 下午4:35:55
 */
public class PReqNameByQianTong extends Procedure {
	
	private int userID;
	
	private int schoolId;
	
	private xio.Protocol protocol;
	
	public PReqNameByQianTong(int userId, int schoolId, xio.Protocol protocol) {
		this.userID = userId;
		this.schoolId = schoolId;
		this.protocol = protocol;
	}

	@Override
	protected boolean process() throws Exception {

		long curTime = System.currentTimeMillis();
		Long lastTime = xtable.Qiantong.select(userID);
		if (lastTime!=null&&curTime - lastTime < 1000)
			return true;
		xtable.Qiantong.remove(userID);
		xtable.Qiantong.insert(userID, curTime);
	    
		String name = genARandomName(schoolId);
		if (name!=null&&name.length()>0){
			SGiveNameByQianTong sGiveNameByQianTong = new SGiveNameByQianTong(name);
			if (protocol != null)
				gnet.link.Onlines.getInstance().sendResponse(protocol, sGiveNameByQianTong);
			else {
				User user = gnet.link.Onlines.getInstance().getOnlineUsers().get(userID);
				if (user != null)
					user.send(sGiveNameByQianTong);
			}
		}
		
		return true;
	}
	
	/**
	 * genARandomName:用姓名库随机生成一个名字,最多循环一百次,如果还找不到,就返回null,让玩家再点击一次申请吧
	 *
	 * @return    
	 * String    
	 * @throws 
	 * @since  　
	*/
	
	public String genARandomName(int schoolId) {
		if (!checkValidateSchool(schoolId))
			return null;
       RoleConfig roleCfg = ConfigManager.getInstance().getConf(RoleConfig.class).get(schoolId);
       if (roleCfg == null)
    	   return null;
       boolean isMethod1 = Misc.checkRatePercent(50);  //是否是第一种取名方案
       boolean isMale = roleCfg.sex == 1;
       
       String namestrwhilenoavailable = "";  //分配名字失败时的显示
       for (int i = 0; i < 1000; i++) {
    	   StringBuilder result = new StringBuilder();
    	   String tmpName = null;
    	   if (isMale)
    		   tmpName = NameRepository.maleNameList.get(Misc.getRandomBetween(0, NameRepository.maleNameListSize - 1));
    	   else
    		   tmpName = NameRepository.femaleNameList.get(Misc.getRandomBetween(0, NameRepository.femaleNameListSize - 1));
    	   String part1 = null;
    	   String part2 = null;
    	   if (isMethod1) {
    		   ListPair pair = getPart1List(schoolId);
    		   part1 = pair.nameList.get(Misc.getRandomBetween(0, pair.size - 1));
    		   part2 = tmpName;
    	   } else {
    		   ListPair pair = getPart2List(schoolId);
    		   part1 = tmpName;
    		   part2 = pair.nameList.get(Misc.getRandomBetween(0, pair.size - 1));
    	   }
    	           
    	   result.append(part1).append(part2);
           
           if (result.length() >= NameRepository.NAME_MAX_SIZE)
        	   continue;  //名字的最大
           
           namestrwhilenoavailable = result.toString();
           
           //查询名字是否重复
           if(UniqName.exist("role", result.toString())==UniqName.RPC_NOT_EXISTS){
        	   return result.toString();
           }else{//如果名字有重复,则加上字符
        	   List<StringBuilder> resultList = NameRepository.addSymbols(new StringBuilder(part1), new StringBuilder(part2), 1);
        	   if (resultList.size()>0)
        		   return resultList.get(0).toString();
           }
	   }
       
       return namestrwhilenoavailable;
	}
	
	public static boolean checkValidateSchool(int school) {
		return school == 101 || school == 102 || school == 103 || school == 104 || school == 105;
	}
	
	public ListPair getPart1List(int school) {
		switch(school) {
		case 101:
			return new ListPair(NameRepository.zhanshiFNameList, NameRepository.zhanshiFNameListSize);
		case 102:
			return new ListPair(NameRepository.fashiFNameList, NameRepository.fashiFNameListSize);
		case 103:
			return new ListPair(NameRepository.gongjianshouFNameList, NameRepository.gongjianshouFNameListSize);
		case 104:
			return new ListPair(NameRepository.mushiFNameList, NameRepository.mushiFNameListSize);
		case 105:
			return new ListPair(NameRepository.shashouFNameList, NameRepository.shashouFNameListSize);
		default :return null;
		}
	}
	
	public ListPair getPart2List(int school) {
		switch(school) {
		case 101:
			return new ListPair(NameRepository.zhanshiLNameList, NameRepository.zhanshiLNameListSize);
		case 102:
			return new ListPair(NameRepository.fashiLNameList, NameRepository.fashiLNameListSize);
		case 103:
			return new ListPair(NameRepository.gongjianshouLNameList, NameRepository.gongjianshouLNameListSize);
		case 104:
			return new ListPair(NameRepository.mushiLNameList, NameRepository.mushiLNameListSize);
		case 105:
			return new ListPair(NameRepository.shashouLNameList, NameRepository.shashouLNameListSize);
		default :return null;
		}
	}
	
	private final class ListPair {
		
		List<String> nameList;
		
		int size;

		public ListPair(List<String> nameList, int size) {
			super();
			this.nameList = nameList;
			this.size = size;
		}
		
	}
	
}
