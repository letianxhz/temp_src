package knight.gsp;

import gnet.link.Onlines;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import knight.gsp.achievement.PSendAchievementList;
import knight.gsp.activity.LevelUpAward;
import knight.gsp.activity.SGuangYingBattleState;
import knight.gsp.activity.guangyingduijue.GuangYingManager;
import knight.gsp.activity.newservergift.NewServerGiftManager;
import knight.gsp.activity.retrievereward.RetrieveRewardRole;
import knight.gsp.activity.sologhost.SoloGhostManager;
import knight.gsp.activity.springfestival.giftbox.NewYearGiftBoxManager;
import knight.gsp.activity.springfestival.giftbox.PCalcTreasureStealGiftBox;
import knight.gsp.activity.springfestival.treasuresteal.TreasureStealGhostManager;
import knight.gsp.anniversary.AnniversaryActivityManager;
import knight.gsp.attr.AttrType;
import knight.gsp.camp.CampRole;
import knight.gsp.dny.DongNanYaManager;
import knight.gsp.dragon.DragonColumn;
import knight.gsp.event.LevelupEvent;
import knight.gsp.event.Poster;
import knight.gsp.friends.PReceiveOrGivePhysical;
import knight.gsp.friends.RecommendedRoleInfo;
import knight.gsp.friends.SRecommendRoleList;
import knight.gsp.friends.SRefreshFriendLevelAndSchool;
import knight.gsp.fuben.FubenConfig;
import knight.gsp.fuben.SendFubenListTask;
import knight.gsp.fuben.protectgoddess.ProtectGoddessManager;
import knight.gsp.game.SAchievementConfig;
import knight.gsp.game.SFriendrecommend;
import knight.gsp.game.SPhyset;
import knight.gsp.game.SServerLevelConfig;
import knight.gsp.game.Sspecialpara;
import knight.gsp.game.sguajipos;
import knight.gsp.gat.GATManager;
import knight.gsp.giftbag.event.PowerGift;
import knight.gsp.hg.HanGuoManager;
import knight.gsp.imagechallenge.ImageChallengeManager;
import knight.gsp.item.EmailBox;
import knight.gsp.item.PEquipProc;
import knight.gsp.log.LogUtil;
import knight.gsp.log.LogUtil.PHY_CHANGE_TYPE;
import knight.gsp.main.ConfigManager;
import knight.gsp.map.RoleManager;
import knight.gsp.master.MasterApprentManager;
import knight.gsp.mercenary.proc.FaZhenSystemMangager;
import knight.gsp.mercenary.proc.MercenaryColumn;
import knight.gsp.msg.Message;
import knight.gsp.myzone.MyZoneRoleData;
import knight.gsp.myzone.ZoneManager;
import knight.gsp.paragonlevel.ParagonLevelRole;
import knight.gsp.qixi.QiXiActivityManager;
import knight.gsp.ranklist.RankType;
import knight.gsp.ranklist.proc.PTryAddPlatRolePropertyRank;
import knight.gsp.ranklist.proc.RankListManager;
import knight.gsp.ride.RideManager;
import knight.gsp.ride.Sridetianfu;
import knight.gsp.role.Saddpoint;
import knight.gsp.role.Sserverlevelcap;
import knight.gsp.scene.effect.EffectRoleImpl;
import knight.gsp.skill.SkillRole;
import knight.gsp.task.DailyTaskProcessor;
import knight.gsp.task.activelist.PlayActiveRole;
import knight.gsp.team.ghost.RoleGhostManager;
import knight.gsp.util.Misc;
import knight.gsp.wing.WingManager;
import knight.gsp.yuanbao.PRefreshChargeGuide;
import knight.gsp.yuanbao.YuanbaoManager;
import knight.gsp.yuenan.YNManager;
import knight.msp.GRoleLvUp;

import org.apache.log4j.Logger;

import xbean.BlackGroups;
import xbean.FriendGroups;
import xbean.Properties;
import xdb.Procedure;
import xdb.Transaction;

/**
 * 角色升级
 * 
 * @author yangzhenyu
 * 
 *         2014-1-18 下午4:49:01
 */
public class PLevelUpProc extends Procedure {
	
	public static final Logger logger = Logger.getLogger(PLevelUpProc.class);

	private final long roleId;

	public PLevelUpProc(long roleId) {
		super();
		this.roleId = roleId;
	}

	@Override
	protected boolean process() throws Exception {
		xbean.Properties prop = xtable.Properties.get(roleId);
		int oldLv = prop.getLevel();
		//等级上限
		int levellimit = getMaxLevel();
		
		if(oldLv >= levellimit)
		{//等级死限制
			Message.psendMsgNotify(roleId, 100881, Message.getStringList(levellimit));
			return false;
		}
		
		final int newLv = oldLv + 1;
		// 升到最大级通知客户端
		if (levellimit == newLv)
			new ParagonLevelRole(roleId, false).reachedMaxRoleLv();
		prop.setLevel(newLv);
		
		Saddpoint addpoint = ConfigManager.getInstance().getConf(Saddpoint.class).get(prop.getSchool());
		if (addpoint == null) {
			logger.error("school=" + prop.getSchool() + "没有对应的升级潜能点分配规则.升级失败!roleId=" + roleId);
			return false;
		}
		
		float cons = EffectRoleImpl.getInitVal(AttrType.CONS, prop.getSchool()) + (newLv - 1) * Float.parseFloat(addpoint.cons);
		float iq = EffectRoleImpl.getInitVal(AttrType.IQ, prop.getSchool()) + (newLv - 1) * Float.parseFloat(addpoint.iq);
		float str = EffectRoleImpl.getInitVal(AttrType.STR, prop.getSchool()) + (newLv - 1) * Float.parseFloat(addpoint.str);
		float agi = EffectRoleImpl.getInitVal(AttrType.AGI, prop.getSchool()) + (newLv - 1) * Float.parseFloat(addpoint.agi);
		float endu = EffectRoleImpl.getInitVal(AttrType.ENDU, prop.getSchool()) + (newLv - 1) * Float.parseFloat(addpoint.spirit);
		
		

		GRoleLvUp gsnd = new GRoleLvUp();
		gsnd.roleid = roleId;
		gsnd.level1attrs.put(AttrType.CONS, cons);
		gsnd.level1attrs.put(AttrType.STR, str);
		gsnd.level1attrs.put(AttrType.IQ, iq);
		gsnd.level1attrs.put(AttrType.AGI, agi);
		gsnd.level1attrs.put(AttrType.ENDU, endu);

		
		GsClient.psend2RoleSceneWhileCommit(roleId, gsnd);
		
		
		SPhyset phyCfg = ConfigManager.getInstance().getConf(SPhyset.class).get(newLv);
		if (phyCfg == null)
		{
			logger.error("级别="+newLv+"，没有升级体力上限配置.升级失败!roleId=" + roleId);
			return false;
		}
		int maxPhyAdding = phyCfg.addphylimit;// 注意这里是体力上限要增加的值
		int phyAdding = phyCfg.addphy;// 注意这里是体力要增加的值
		PropRole propRole=new PropRole(roleId, false);
		propRole.addPhyMax(maxPhyAdding);
		propRole.addPhy(phyAdding);
		// 体力日志
		if (phyAdding > 0)
		{
			LogUtil.doPhyChangeLog(roleId, (int)phyAdding, propRole.getPhy(), PHY_CHANGE_TYPE.LVUP);
		}
		
		
		Poster.getPoster().dispatchEvent(new LevelupEvent(roleId, newLv));
		
		xdb.Procedure.pexecuteWhileCommit(new PTryAddRolepropertyRank(roleId, newLv, RankType.LEVEL_RANK, false));
		
		if (RankListManager.getInstance().canAddPlatRank(prop.getNickname(), RankType.PLAT_LEVEL_RANK)) {
			xdb.Procedure.pexecuteWhileCommit(new PTryAddPlatRolePropertyRank(roleId, newLv, RankType.PLAT_LEVEL_RANK, false, prop.getNickname()));
		}
		
		//判断是否是刚好达到守卫女神活动参加等级
		ProtectGoddessManager.getInstance().checkRoleCanJoin(roleId, newLv);
		
		//自动携带更多佣兵
		MercenaryColumn column = MercenaryColumn.getMercenaryColumn(roleId, false);
		column.onLevelUp(newLv);
		
		new SkillRole(roleId, false).onRoleLevelUp(newLv);
		
		// 刷新人物的战斗力
		xdb.Procedure.pexecuteWhileCommit(new PFightPowerChangeCallback(roleId));
		NewServerGiftManager.refreshRedNotice(1, roleId,false);
		//刷新好友等级
		SRefreshFriendLevelAndSchool friendLevelAndSchool = new SRefreshFriendLevelAndSchool(roleId, (short)prop.getSchool(), newLv);
		FriendGroups groups = xtable.Friends.select(roleId);
		if(groups != null){
			xdb.Procedure.psendWhileCommit(groups.getFriendsmap().keySet(), friendLevelAndSchool);
		}
		
		
		
		//检查发送渠道评价界面
		checkAndSendChannelAppraise(prop, prop.getNickname().substring(0,4));
		
		//提示好友推荐
		//放到单独的存储过程中，需要检查其他玩家的级别，防止死锁
		xdb.Procedure.pexecuteWhileCommit(new xdb.Procedure(){
			@Override
			public boolean process(){
				checkAndRecommendRole();
				return true;
			}
		});
		
		// 检查是否发送邮件
		EmailBox emailBox = new EmailBox(roleId, false);
		emailBox.sendMailOnLvUp(newLv);
		
		int needTime = (int) ((System.currentTimeMillis() - prop.getLeveluptime()) * 0.001);
		prop.setLeveluptime(System.currentTimeMillis());
		LogUtil.doLevelUpLog(roleId, needTime);
		
		if (newLv == 50) {
			new PRefreshChargeGuide(roleId).call();
		} 
		if (newLv == 28) {
			int posId = Misc.getRandom(ConfigManager.getInstance().getConf(sguajipos.class).keySet());
			SoloGhostManager.getInstance().giveNextMonster(roleId, posId);
		} 
		if (newLv == knight.gsp.camp.Module.CAMP_WILD_TASK_LV) {
			knight.gsp.camp.Module.getInstance().checkAddNewplayerCampGuideTask(roleId, (byte) 0, knight.gsp.camp.Module.CAMP_WILD_TASK_LV);
		} 
		if (newLv == AnniversaryActivityManager.MIN_LV) {
			if (AnniversaryActivityManager.getInstance().inActivityPeriod()) {
				xdb.Procedure.psendWhileCommit(roleId, ActivityStatusManager.getInstance().getActivityStatus(roleId));
			}
		}
		if (newLv == QiXiActivityManager.MIN_LV) {
			if (QiXiActivityManager.getInstance().inActivityPeriod()) {
				xdb.Procedure.psendWhileCommit(roleId, ActivityStatusManager.getInstance().getActivityStatus(roleId));
		    }
		}
		if (newLv == GuangYingManager.MIN_LV) {
			if (GuangYingManager.getInstance().isGuangYingSeasonPeriod()){
				if (!LocalIds.isRemoteServerRole(roleId)){
					SGuangYingBattleState snd = new SGuangYingBattleState();
					snd.gyactstate = (byte) (GuangYingManager.getInstance().isOpen() ? 1 : 0);
					Onlines.getInstance().send(roleId, snd);
				}
			}
		}
		// 达到 法阵解锁等级 发送法阵数据
		if(newLv == FaZhenSystemMangager.MIN_LV){
			FaZhenSystemMangager.getInstance().sendZhenWeiSystemInfo(roleId);
		}
		// 达到 镜像挑战的 开放等级 时 发送下镜像挑战数据
		if(newLv == ImageChallengeManager.getOpenLv()){
			ImageChallengeManager.sendImageChallengeInfo(roleId);
		}
		
		//战力礼包
		knight.gsp.giftbag.GiftPoster.getPoster().dispatchEvent(new PowerGift(roleId, newLv));
		
		//是否显示光环
		knight.gsp.yuanbao.GrowFound growFound = new knight.gsp.yuanbao.GrowFound(roleId,true);
		if(growFound.haveFoundAwardToGet(newLv)){
			gnet.link.Onlines.getInstance().send(roleId,new knight.gsp.yuanbao.SNoticeToFound());
		}
		
		//龙相关解锁
		DragonColumn col = new DragonColumn(roleId, false);
		col.unLock(newLv);
		
		xdb.Procedure.psendWhileCommit(roleId, new SRoleLevelUp((short) newLv));
		
		//坐骑装备刷新
		if(oldLv < RideManager.EQUIP_MIN_LEVEL && newLv >= RideManager.EQUIP_MIN_LEVEL){
			RideManager.getInstance().refreshBuffEffect(roleId);
		}
		
		SPhyset oldLevelPhySet = ConfigManager.getInstance().getConf(SPhyset.class).get(oldLv);
		SPhyset newLevelPhySet = ConfigManager.getInstance().getConf(SPhyset.class).get(newLv);
		if(oldLevelPhySet.getFriendgetphytime() != newLevelPhySet.getFriendgetphytime()){
			PReceiveOrGivePhysical.refreshAllFriendPhysicalState(roleId);
		}
		Map<Integer, FubenConfig> fubenConfigMap= knight.gsp.fuben.Module.getInstance().getAllFubenCfgs();
		for(FubenConfig fubenCfg : fubenConfigMap.values()){
			if(fubenCfg.unlockNewFubenWhileLevelUp() && fubenCfg.minlv == newLv){
				xdb.Procedure.pexecuteWhileCommit(new SendFubenListTask(roleId));
				break;
			}
		}
		
		try {
			//等级提升了，要重新发送经验加成信息
			SServerLv serverLvInfo = PAddExpProc.getServerExpAddInfo(roleId, Calendar.getInstance().getTimeInMillis());
			if (serverLvInfo != null) {
				xdb.Procedure.psendWhileCommit(roleId, serverLvInfo);
			} else {
				SServerLevelConfig lvCfg = ConfigManager.getInstance().getGsLevelCfg(Calendar.getInstance().getTimeInMillis());
				if (lvCfg != null && prop.getLevel() == lvCfg.serverLevel) {
					xdb.Procedure.psendWhileCommit(roleId, new SServerLv((short) lvCfg.getServerLevel(), (byte) 0));
				}
			}
		} catch (Throwable th) {
			th.printStackTrace();
		}
		
		PEquipProc.accceptUnsealTask(roleId);
		if(needToSendAllAchievements(newLv)){
			new PSendAchievementList(roleId, false).call();
		}
		
		new RoleGhostManager(roleId, false).onLvUp(newLv);
		
		DailyTaskProcessor.refreshDailyTaskOnLvUp(roleId);
		
		PlayActiveRole.getPlayActiveRole(roleId, false).sendActivityAward();
		
		//冲级奖励
		LevelUpAward award = new LevelUpAward(roleId,false);
		award.onLevelChange((short)newLv);
		
		new RetrieveRewardRole(roleId, false).onLvUp();
		
		MasterApprentManager.onRoleLvUp(roleId,newLv);
		
		Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(333);
		if (newLv == cfg.para1) {
			xbean.Rides rides = xtable.Rides.get(roleId);
			if (rides != null) {
				for(xbean.Ride ride : rides.getRides().values()){
					int rideid = ride.getId();
					Sridetianfu config = ConfigManager.getInstance().getConf(Sridetianfu.class).get(rideid);
					if(ride.getTalentskillid() <= 0){
						ride.setTalentskillid(config.getSkillid());
					}
				}
				
				RideManager.getInstance().refreshBuffEffect(roleId);
				RideManager.getInstance().sendRidePanelInfo(roleId);
			}
			
		}
		
		WingManager.getInstance().onRoleLvUp(roleId, newLv);
		if(NewYearGiftBoxManager.getInstance().isOn() && newLv == TreasureStealGhostManager.getInstance().minLevel()){
			// 玩家在盗宝精灵活动期间，升级到活动要求的最低等级
			try {
				new PCalcTreasureStealGiftBox(roleId).call();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		//50级 解锁空间，加上空间人气属性Buff
		ZoneManager.getInstance().addZoneBuff(roleId, new MyZoneRoleData(roleId, true).getBean().getPopularvalue());
		return true;
	}
	
	public boolean needToSendAllAchievements(final int newLevel){
		Map<Integer, SAchievementConfig> configMap = ConfigManager.getInstance().getConf(SAchievementConfig.class);
		for(SAchievementConfig cfg : configMap.values()){
			if(cfg.needlevel == newLevel){
				return true;
			}
		}
		return false;
	}
	
	public static void refreshRecommendRole(long roleId, boolean isTrigger, boolean isHuanYiPi){
		xbean.FriendGroups groups = xtable.Friends.select(roleId);
//		if(groups != null && DateValidate.inTheSameDay(System.currentTimeMillis(), groups.getLastcloserecommend()))
//			return;
		
		int level = xtable.Properties.selectLevel(roleId);
		SFriendrecommend recCgf = ConfigManager.getInstance().getConf(SFriendrecommend.class).get(level);
		if(recCgf == null)
			return;
		
		if(isTrigger && recCgf.triggercase != 1 && recCgf.triggercase != 3)
			return;
		
		int levMin = (level-recCgf.differlv) < 0 ? 0 : (level-recCgf.differlv);
		int levMax = level+recCgf.differlv;
		xbean.BlackGroups blackGroups = xtable.Blacks.select(roleId);
		List<RecommendedRoleInfo> recommendedRoles = getRecommendedRoles(levMin, levMax, groups, roleId, blackGroups, isHuanYiPi);
		if(isTrigger && recommendedRoles.size() == 0)
			return;
		SRecommendRoleList roleList = new SRecommendRoleList();
		roleList.roleinfolist.addAll(recommendedRoles);
		
		xdb.Procedure.psendWhileCommit(roleId, roleList);
	}
	
	private void checkAndRecommendRole() {
		refreshRecommendRole(roleId, true, false);
	}

	private static List<RecommendedRoleInfo> getRecommendedRoles(int levMin, int levMax, FriendGroups groups, final long roleId, BlackGroups blackGroups, boolean isHuanYiPi) {
		List<Long> roleids = RoleManager.getInstance().getRoleIds();
		
		List<Long> friendids = new ArrayList<Long>();
		
		if (isHuanYiPi) {
			xdb.Procedure clearProc = new xdb.Procedure() {

				@Override
				protected boolean process() throws Exception {
					//换一批需要把最近参战推荐的人给清除
					xtable.Recentteammates.remove(roleId);
					return true;
				}
				
			};
			
			if (Transaction.current() != null) {
				xdb.Procedure.pexecuteWhileCommit(clearProc);
			} else {
				clearProc.submit();
			}
		} else {
			xbean.RecentTeamMates recentTeamMates = xtable.Recentteammates.select(roleId);
			if (recentTeamMates != null) {
				for (long rid : recentTeamMates.getMates()) {
					if (blackGroups != null && blackGroups.getBlacks().contains(rid))
						continue;
					
					friendids.add(rid);
				}
			}
		}
		
		
		List<Long> levelFitRoles = new ArrayList<Long>();
		for (Long rid : roleids) {
			Integer level = xtable.Properties.selectLevel(rid);
			if(level == null)
				continue;
			if(levMin > level || levMax < level || (groups != null &&
					groups.getFriendsmap().containsKey(rid)) || (blackGroups != null && blackGroups.getBlacks().contains(rid)))
				continue;
			if(rid == roleId)
				continue;
			
			if (friendids.contains(rid))
				continue; //以免出现两个重复的推荐好友
			
			levelFitRoles.add(rid);
		}
		
		if (friendids.size() < 8) {
			int appendNum = 8 - friendids.size();
			if (levelFitRoles.size() > appendNum){
				List<Integer> tmp = Misc.getRandomValues(0, levelFitRoles.size()-1, appendNum);
				for(Integer index : tmp){
					friendids.add(levelFitRoles.get(index));
				}
			}else{
				for (int i = 0; i < appendNum; i ++) {
					if (levelFitRoles.size() <= i)
						break;
					
					friendids.add(levelFitRoles.get(i));
				}
			}
		}
		
		
		List<RecommendedRoleInfo> result = new ArrayList<RecommendedRoleInfo>();
		for(Long roleid : friendids){
			RecommendedRoleInfo info = new RecommendedRoleInfo();
			xbean.Properties prop = xtable.Properties.select(roleid);
			info.campid = new CampRole(roleid,true).getCampInfo().camp;
			info.level = prop.getLevel();
			info.msgid = 101248;
			info.power = prop.getPower();
			info.roleid = roleid;
			info.rolename = prop.getRolename();
			info.schoolid = (short)prop.getSchool();
			result.add(info);
		}
		
		return result;
	}

	private void checkAndSendChannelAppraise(Properties prop, String channelType) {
		Sspecialpara cfg = ConfigManager.getInstance().getConf(Sspecialpara.class).get(322);
		if (cfg == null || cfg.para1 != 1)
			return;
		if(GATManager.getInstance().isGATServer()){
			if(!channelType.equals(YuanbaoManager.APP_STORE) && !channelType.equals(YuanbaoManager.YIFANDA_HK_IOS) && !channelType.equals(YuanbaoManager.YIFANDA_TW_IOS))
				return;
		} else if(HanGuoManager.getInstance().isHanGuoServer()){
			if(!YuanbaoManager.EFUN_AND.equals(channelType) && !YuanbaoManager.EFUN_IOS.equals(channelType) && !YuanbaoManager.EFUN_TSTORE.equals(channelType))
				return;
		} else if(DongNanYaManager.getInstance().isDongNanYaServer()){
			if(!YuanbaoManager.SQWAN_DONGNANYA_IOS.equals(channelType))
				return;
		} else if(YNManager.getInstance().isYNServer()) {
			if (!YuanbaoManager.VIETNAM_IOS.equals(channelType))
				return;
		} else if(!channelType.equals(YuanbaoManager.APP_STORE) && !channelType.equals(YuanbaoManager.LEDO))
			return;
		int newLevel = prop.getLevel();
		if(newLevel != 20 && newLevel != 30 && newLevel != 40)
			return;
		if((prop.getRoleinitflag() & RoleInitFlag.APPRAISE_ALREADY) == RoleInitFlag.APPRAISE_ALREADY)
			return;
		xdb.Procedure.psendWhileCommit(roleId, new SShowEvalueAlert());
	}

	public static int getMaxLevel(){
		int levellimit = DataInit.ROLE_LEVEL_MAX;
		Sserverlevelcap levelcfg = ConfigManager.getInstance().getConf(knight.gsp.role.Sserverlevelcap.class).get(ConfigManager.getGsZoneId());
		if(levelcfg != null)
			levellimit = levelcfg.levellimit;
		else
		{
			Sserverlevelcap defaultlevelcfg = ConfigManager.getInstance().getConf(knight.gsp.role.Sserverlevelcap.class).get(1);
			if(defaultlevelcfg != null)
				levellimit = defaultlevelcfg.levellimit;
			else
				levellimit = DataInit.ROLE_LEVEL_MAX;
		}
		return levellimit;
	}
	
	
}
