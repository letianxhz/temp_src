
package knight.gsp;
import global.rsp.GlobalClientManager;
import global.rsp.GsCrossShortcutToShortcut;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.skill.SkillRole;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CShortcutToShortcut__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CShortcutToShortcut extends __CShortcutToShortcut__ {
	@Override
	protected void process() {
		// protocol handle
		final long roleid = gnet.link.Onlines.getInstance().findRoleid(this);
		if(roleid <= 0)
			return;
		
		if (LocalIds.isRemoteServerRole(roleid)) {
			int zoneId = ServerInfoProvider.roleid2zoneid(roleid);
			GsCrossShortcutToShortcut snd = new GsCrossShortcutToShortcut();
			snd.battlegs = ConfigManager.getGsZoneId();
			snd.fromroleid = roleid;
			snd.shortcut1id = shortcut1id;
			snd.shortcut2id = shortcut2id;
			GlobalClientManager.getInstance().send(zoneId, snd);
			return;
		}
		
		new xdb.Procedure(){
			@Override
			public boolean process(){
				return new SkillRole(roleid, false).shortcutToShortcut(0, shortcut1id, shortcut2id);
			}
		}.submit();
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 786453;

	public int getType() {
		return 786453;
	}

	public short shortcut1id;
	public short shortcut2id;

	public CShortcutToShortcut() {
	}

	public CShortcutToShortcut(short _shortcut1id_, short _shortcut2id_) {
		this.shortcut1id = _shortcut1id_;
		this.shortcut2id = _shortcut2id_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(shortcut1id);
		_os_.marshal(shortcut2id);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		shortcut1id = _os_.unmarshal_short();
		shortcut2id = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CShortcutToShortcut) {
			CShortcutToShortcut _o_ = (CShortcutToShortcut)_o1_;
			if (shortcut1id != _o_.shortcut1id) return false;
			if (shortcut2id != _o_.shortcut2id) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += shortcut1id;
		_h_ += shortcut2id;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(shortcut1id).append(",");
		_sb_.append(shortcut2id).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CShortcutToShortcut _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = shortcut1id - _o_.shortcut1id;
		if (0 != _c_) return _c_;
		_c_ = shortcut2id - _o_.shortcut2id;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

