package knight.gsp;

import java.util.Arrays;

/**
 * 进入游戏世界
 * 
 * @author yangzhenyu
 * 
 * @date 2015-9-12 下午3:34:40
 * 
 */
public class PEnterWrold extends xdb.Procedure {

	private xio.Protocol protocol;
	
	private long roleId;
	
	private byte connectType;
	
	public PEnterWrold(xio.Protocol protocol, long roleId, boolean isFirstEnterword, byte connectType) {
		this.protocol = protocol;
		this.roleId = roleId;
		this.connectType = connectType;
	}

	@Override
	protected boolean process() throws Exception {
		
		boolean isCrossPlayer = LocalIds.isRemoteServerRole(roleId);
		if (isCrossPlayer) {
			xbean.CrossRole crossRole = xtable.Crossroles.select(roleId);
			if (crossRole == null)
				return false;
			
			//先锁 user lock
			lock(xtable.Locks.USERLOCK, Arrays.asList(crossRole.getUserid()));
		} else {
			xbean.Properties prop = xtable.Properties.select(roleId);
			if (prop == null)
				return false;
			
			//先锁 user lock
			lock(xtable.Locks.USERLOCK, Arrays.asList(prop.getUserid()));
		}
		
		xtable.Connecttypes.remove(roleId);
		xbean.ConnectType connectTypeInfo = xbean.Pod.newConnectType();
		if (connectType == ConnectType.TYPE_MOBILE) {
			//移动网络
			connectTypeInfo.setConntype(connectType);
		} else if (connectType == ConnectType.TYPE_GAMEX) {
			//gamex
			connectTypeInfo.setConntype(connectType);
		} else {
			//wifi
			connectTypeInfo.setConntype((short) ConnectType.TYPE_WIFI);
		}
		xtable.Connecttypes.add(roleId, connectTypeInfo);
		
		final int userID = ((gnet.link.Dispatch) protocol.getContext()).userid;
		gnet.link.Onlines.getInstance().insert(protocol, roleId, isCrossPlayer);
		// 加入新的角色,这一句必须放在角色进入场景前
		knight.gsp.state.StateManager.logger.info("CEnterWorld: 角色（Id = " + roleId + "）link已经加入。");

		xdb.Procedure p = null;
		if (!isCrossPlayer) {
			p = new knight.gsp.state.PRoleOnline(userID, roleId);
		} else {
			p = new knight.gsp.state.PCrosserOnline(roleId);
		}

		p.call();

		if (p.isSuccess()) {
			return true;
		}

		// 踢下线
		gnet.link.Onlines.getInstance().kick(roleId, KickErrConst.ERR_GM_KICKOUT);
		knight.gsp.state.StateManager.logger.error("角色（Id = " + roleId + "）上线失败。 ");

		return true;
	}
}
