package knight;

import knight.gsp.game.Sforbiddeninterface;
import knight.gsp.main.ConfigManager;

public class FunctionOpenManager {
	private static class SingletonHolder {
		private static FunctionOpenManager INSTANCE = new FunctionOpenManager();
	}

	public static FunctionOpenManager getInstance() {
		return SingletonHolder.INSTANCE;
	}
	
	public boolean isForbidden(ForbiddenType type){
		Sforbiddeninterface forbiddenConf = ConfigManager.getInstance().getConf(Sforbiddeninterface.class).get(type.getId());
		if(forbiddenConf != null && forbiddenConf.getJudge() == 1)
			return true;
		return false;
	}
	
	
	public enum ForbiddenType{
		YONGBING_TIANFU(1,"佣兵天赋"),
		RIDE_EQUIP(2,"坐骑装备"),
		RIDE_EQUIP_CUILIAN(3,"坐骑装备淬炼"),
		RIDE_EQUIP_MOHUA(4,"坐骑装备魔化"),
		RIDE_SKILL(5,"坐骑技能"),
		RIDE_SKILL_FENJIE(6,"坐骑技能分解"),
		RIDE_BAOZANG(7,"坐骑宝藏"),
		
		RIDE_JINHUA(9,"坐骑进化"),
		WING_LINGYU(10,"灵羽"),
		WING_CHIP_FENJIE(11,"翅膀分解"),
		WING_SHOUHU(12,"翅膀守护"),
		WING_JUEXING(13,"翅膀觉醒"),
		WING_RONGHE(14,"翅膀融合"),
		YUANSU_FUWEN(15,"符文"),
		YUANSU_FUWENZUHE(16,"符文组合"),
		YUANSU_FUWENZHUANYI(17,"符文转移"),
		YUANSU_QIANGHUA(18,"强化"),
		YUANSU_GUANZHU(19,"灌注"),
		YUANSU_FENJIE(20,"分解"),
		
		FAIRY_EQUIP(21,"精灵装备"),
		FAIRY_LINGZHUANG(22,"装备灵装"),
		FAIRY_LINGLIAN(23,"装备灵炼"),
		FAIRY_LINGQI(24,"装备灵祈"),
		FAIRY_JISI(25,"装备祭祀"),
		FAIRY_QIEHUANXINGTAI(26,"切换形态"),
		FAIRY_SILING(27,"精灵互动"),
		FAIRY_ZHULING(28,"注灵"),
		FAIRY_SKILL(29,"技能"),
		
		
		SHENQI_SHENQI(30,"神器召唤"),
		SHENQI_SHENYOU(31,"神佑"),
		SHENQI_SHENZHU(32,"神铸"),
		SHENQI_SHENJI(33,"神技"),
		SHENQI_SKILL_UP(34,"技能升级"),
		SHENQI_SKILL_TALENTUU(35,"天赋升级"),
		SHENQI_SHENCHI(36,"神池"),
		SHENQI_DIANSHUFENPEI(37,"点数分配"),
		SHENQI_KUOJIAN(38,"扩建"),
		;
		
		private int id;
		private String name;
		
		ForbiddenType(int id,String name){
			this.id = id;
			this.name = name;
		}
		public String getName(){
			return name; 
		}
		
		public int getId(){
			return id;
		}
	}
}
