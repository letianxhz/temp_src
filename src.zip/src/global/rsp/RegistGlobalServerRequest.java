
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RegistGlobalServerRequest__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RegistGlobalServerRequest extends __RegistGlobalServerRequest__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924504;

	public int getType() {
		return 924504;
	}

	public int zoneid;
	public java.lang.String ip;
	public java.lang.String gamexloginip;
	public int linknum; // link的数量
	public java.util.HashSet<Integer> serverlocalids; // 所有的localid
	public int startport;

	public RegistGlobalServerRequest() {
		ip = "";
		gamexloginip = "";
		serverlocalids = new java.util.HashSet<Integer>();
	}

	public RegistGlobalServerRequest(int _zoneid_, java.lang.String _ip_, java.lang.String _gamexloginip_, int _linknum_, java.util.HashSet<Integer> _serverlocalids_, int _startport_) {
		this.zoneid = _zoneid_;
		this.ip = _ip_;
		this.gamexloginip = _gamexloginip_;
		this.linknum = _linknum_;
		this.serverlocalids = _serverlocalids_;
		this.startport = _startport_;
	}

	public final boolean _validator_() {
		if (zoneid < 0) return false;
		if (startport <= 0) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(ip, "UTF-16LE");
		_os_.marshal(gamexloginip, "UTF-16LE");
		_os_.marshal(linknum);
		_os_.compact_uint32(serverlocalids.size());
		for (Integer _v_ : serverlocalids) {
			_os_.marshal(_v_);
		}
		_os_.marshal(startport);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_int();
		ip = _os_.unmarshal_String("UTF-16LE");
		gamexloginip = _os_.unmarshal_String("UTF-16LE");
		linknum = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			serverlocalids.add(_v_);
		}
		startport = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RegistGlobalServerRequest) {
			RegistGlobalServerRequest _o_ = (RegistGlobalServerRequest)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (!ip.equals(_o_.ip)) return false;
			if (!gamexloginip.equals(_o_.gamexloginip)) return false;
			if (linknum != _o_.linknum) return false;
			if (!serverlocalids.equals(_o_.serverlocalids)) return false;
			if (startport != _o_.startport) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += zoneid;
		_h_ += ip.hashCode();
		_h_ += gamexloginip.hashCode();
		_h_ += linknum;
		_h_ += serverlocalids.hashCode();
		_h_ += startport;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append("T").append(ip.length()).append(",");
		_sb_.append("T").append(gamexloginip.length()).append(",");
		_sb_.append(linknum).append(",");
		_sb_.append(serverlocalids).append(",");
		_sb_.append(startport).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

