
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BroadcastGMCommand__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BroadcastGMCommand extends __BroadcastGMCommand__ {
	@Override
	protected void process() {
		// protocol handle
		knight.gsp.gm.CSendCommand command = new knight.gsp.gm.CSendCommand();
		command.setGloableBroadcast(1);
		command.cmd = gmcommand + " " + param.replaceAll(",", " ");
		command.run();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924527;

	public int getType() {
		return 924527;
	}

	public java.lang.String gmcommand; // gm命令名字
	public java.lang.String param; // gm命令参数  param1,param2,.....
	public java.util.ArrayList<Integer> serverlist; // 广播的服务器列表，如果为空就是所有服务器

	public BroadcastGMCommand() {
		gmcommand = "";
		param = "";
		serverlist = new java.util.ArrayList<Integer>();
	}

	public BroadcastGMCommand(java.lang.String _gmcommand_, java.lang.String _param_, java.util.ArrayList<Integer> _serverlist_) {
		this.gmcommand = _gmcommand_;
		this.param = _param_;
		this.serverlist = _serverlist_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(gmcommand, "UTF-16LE");
		_os_.marshal(param, "UTF-16LE");
		_os_.compact_uint32(serverlist.size());
		for (Integer _v_ : serverlist) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		gmcommand = _os_.unmarshal_String("UTF-16LE");
		param = _os_.unmarshal_String("UTF-16LE");
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			serverlist.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BroadcastGMCommand) {
			BroadcastGMCommand _o_ = (BroadcastGMCommand)_o1_;
			if (!gmcommand.equals(_o_.gmcommand)) return false;
			if (!param.equals(_o_.param)) return false;
			if (!serverlist.equals(_o_.serverlist)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += gmcommand.hashCode();
		_h_ += param.hashCode();
		_h_ += serverlist.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(gmcommand.length()).append(",");
		_sb_.append("T").append(param.length()).append(",");
		_sb_.append(serverlist).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

