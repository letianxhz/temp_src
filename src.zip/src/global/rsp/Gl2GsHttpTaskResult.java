
package global.rsp;

import xbean.HeadImageInfo;
import knight.gsp.item.Bag;
import knight.gsp.SDownLoadloadURL;
import knight.gsp.ledo.auth.PUpDateLedoAuthProc;
import knight.gsp.log.LogUtil.MONEY_TYPE;
import knight.gsp.msg.Message;
import knight.gsp.util.OctetsUtil;
import knight.gsp.util.QiniuSDKUtil;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __Gl2GsHttpTaskResult__ extends xio.Protocol { }

/** Global向Gs返回HTTP任务结果
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class Gl2GsHttpTaskResult extends __Gl2GsHttpTaskResult__ {
	@Override
	protected void process() {
		// protocol handle
		if (roleid <= 0)
			return;
		if (operation == JUBP_LOGIN) {
			java.util.Map<String, String> stringData = new java.util.HashMap<String, String>();
			OctetsUtil.convert(stringData, data, true);
			new PUpDateLedoAuthProc(roleid, stringData).submit();
			return;
		}
		new xdb.Procedure(){
			@Override
			public boolean process(){
				xbean.HeadImageInfo prop = xtable.Headimageinfo.get(roleid);
				if(prop == null)
					return true;
				
				GlobalClientManager.logger.info("鉴黄结果： " + operation);
				switch (operation) {
					case PASS:
					case FAILED:
						prop.setHeadimagedownloadcounter(prop.getHeadimagedownloadcounter()+1);
						prop.setHeadimagefilepath(QiniuSDKUtil.getFilePathByRoleid(roleid));
						prop.getUploadcost().remove(Integer.valueOf(counter));
						
						SDownLoadloadURL loadURL = new SDownLoadloadURL();
						loadURL.imageurl = knight.gsp.main.ConfigManager.getImageDownloadUrlByDomain(prop.getHeadimagefilepath());
						loadURL.downloadcounter = prop.getHeadimagedownloadcounter();
						
						xdb.Procedure.psendWhileCommit(roleid, loadURL);
						
						return true;
		
					case NEEDREVIEW:
						sendSysmessageAndRepay(1039214, prop);
						break;
						
					case PORNOGRAPHY:
						sendSysmessageAndRepay(1039213, prop);
						break;
					default:
						break;
				}
				return true;
			}
		}.submit();
		
	}

	private boolean sendSysmessageAndRepay(int id, HeadImageInfo prop) {
		Integer costMoney = prop.getUploadcost().get(Integer.valueOf(counter));
		if(costMoney == null){
			prop.setHeadimagekillcount(prop.getHeadimagekillcount()+1);
		}else{
			Bag bag = new Bag(roleid, false);
			if(bag.addSysMoney(costMoney, MONEY_TYPE.EXT, "头像上传失败返还") != costMoney)
				return false;
		}
		
		prop.setHeadimagefilepath("");
		
		Message.sendSystemMessageToRole(roleid, id, null);
		
		prop.getUploadcost().remove(Integer.valueOf(counter));
		
		return true;
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924529;

	public int getType() {
		return 924529;
	}

	public final static int PASS = 0;
	public final static int FAILED = 1;
	public final static int NEEDREVIEW = 2;
	public final static int PORNOGRAPHY = 3;
	public final static int DEL_SUCCESS = 4;
	public final static int DEL_FAILED = 5;
	public final static int JUBP_GETREGISTERCODE = 1001;
	public final static int JUBP_LOGIN = 1002;

	public long zoneid;
	public long roleid;
	public int operation;
	public int counter;
	public java.util.HashMap<com.goldhuman.Common.Octets,com.goldhuman.Common.Octets> data; // 数据

	public Gl2GsHttpTaskResult() {
		data = new java.util.HashMap<com.goldhuman.Common.Octets,com.goldhuman.Common.Octets>();
	}

	public Gl2GsHttpTaskResult(long _zoneid_, long _roleid_, int _operation_, int _counter_, java.util.HashMap<com.goldhuman.Common.Octets,com.goldhuman.Common.Octets> _data_) {
		this.zoneid = _zoneid_;
		this.roleid = _roleid_;
		this.operation = _operation_;
		this.counter = _counter_;
		this.data = _data_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(roleid);
		_os_.marshal(operation);
		_os_.marshal(counter);
		_os_.compact_uint32(data.size());
		for (java.util.Map.Entry<com.goldhuman.Common.Octets, com.goldhuman.Common.Octets> _e_ : data.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_long();
		roleid = _os_.unmarshal_long();
		operation = _os_.unmarshal_int();
		counter = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			com.goldhuman.Common.Octets _k_;
			_k_ = _os_.unmarshal_Octets();
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			data.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof Gl2GsHttpTaskResult) {
			Gl2GsHttpTaskResult _o_ = (Gl2GsHttpTaskResult)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (roleid != _o_.roleid) return false;
			if (operation != _o_.operation) return false;
			if (counter != _o_.counter) return false;
			if (!data.equals(_o_.data)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)zoneid;
		_h_ += (int)roleid;
		_h_ += operation;
		_h_ += counter;
		_h_ += data.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(operation).append(",");
		_sb_.append(counter).append(",");
		_sb_.append(data).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

