
package global.rsp.team;
import java.util.ArrayList;

import global.rsp.GlobalClientManager;
import knight.gsp.LocalIds;
import knight.gsp.friends.PFriendsInfoInit;
import knight.gsp.friends.SStrangerMessageToRole;
import knight.gsp.friends.StrangerMessageBean;
import knight.gsp.msg.ShowInfo;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendChatMsgToGlobalTeamMember__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendChatMsgToGlobalTeamMember extends __SendChatMsgToGlobalTeamMember__ {
	@Override
	protected void process() {
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				if(LocalIds.isRemoteServerRole(senderid)){
					return false;
				}
				SStrangerMessageToRole strangerMsg = new SStrangerMessageToRole();
				StrangerMessageBean mb = new StrangerMessageBean();
				
				mb.friendinfobean = PFriendsInfoInit.toInfoBean(receiverid, senderid, null, null);
				mb.friendinfobean.online = 1;
				mb.content = content;
				ArrayList<ShowInfo> showInfoMsgs = new ArrayList<ShowInfo>();
				if(showinfos != null){
					for(com.goldhuman.Common.Octets octets : showinfos){
						ShowInfo showInfo = new ShowInfo();
						showInfo.marshal(OctetsStream.wrap(octets));
						showInfoMsgs.add(showInfo);
					}
				}
				mb.showinfos = showInfoMsgs;
				// 聊天消息验证没有通过
				if (mb.details == null || mb.details.size() != mb.showinfos.size())
				{
					return false;
				}
				strangerMsg.strangermessage = mb;
				GlobalClientManager.getInstance().sendToRole(tozoneid, receiverid, strangerMsg);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925533;

	public int getType() {
		return 925533;
	}

	public long senderid; // 发送消息的玩家id
	public long receiverid; // 接受消息的玩家id
	public int tozoneid; // 发出请求的玩家服务器id
	public java.lang.String content;
	public java.util.ArrayList<com.goldhuman.Common.Octets> details; // 展示品信息
	public java.util.ArrayList<com.goldhuman.Common.Octets> showinfos; // 展示的物品key与type

	public SendChatMsgToGlobalTeamMember() {
		content = "";
		details = new java.util.ArrayList<com.goldhuman.Common.Octets>();
		showinfos = new java.util.ArrayList<com.goldhuman.Common.Octets>();
	}

	public SendChatMsgToGlobalTeamMember(long _senderid_, long _receiverid_, int _tozoneid_, java.lang.String _content_, java.util.ArrayList<com.goldhuman.Common.Octets> _details_, java.util.ArrayList<com.goldhuman.Common.Octets> _showinfos_) {
		this.senderid = _senderid_;
		this.receiverid = _receiverid_;
		this.tozoneid = _tozoneid_;
		this.content = _content_;
		this.details = _details_;
		this.showinfos = _showinfos_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(senderid);
		_os_.marshal(receiverid);
		_os_.marshal(tozoneid);
		_os_.marshal(content, "UTF-16LE");
		_os_.compact_uint32(details.size());
		for (com.goldhuman.Common.Octets _v_ : details) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(showinfos.size());
		for (com.goldhuman.Common.Octets _v_ : showinfos) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		senderid = _os_.unmarshal_long();
		receiverid = _os_.unmarshal_long();
		tozoneid = _os_.unmarshal_int();
		content = _os_.unmarshal_String("UTF-16LE");
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			details.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			showinfos.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendChatMsgToGlobalTeamMember) {
			SendChatMsgToGlobalTeamMember _o_ = (SendChatMsgToGlobalTeamMember)_o1_;
			if (senderid != _o_.senderid) return false;
			if (receiverid != _o_.receiverid) return false;
			if (tozoneid != _o_.tozoneid) return false;
			if (!content.equals(_o_.content)) return false;
			if (!details.equals(_o_.details)) return false;
			if (!showinfos.equals(_o_.showinfos)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)senderid;
		_h_ += (int)receiverid;
		_h_ += tozoneid;
		_h_ += content.hashCode();
		_h_ += details.hashCode();
		_h_ += showinfos.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(senderid).append(",");
		_sb_.append(receiverid).append(",");
		_sb_.append(tozoneid).append(",");
		_sb_.append("T").append(content.length()).append(",");
		_sb_.append(details).append(",");
		_sb_.append(showinfos).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

