
package global.rsp.team;
import java.util.Arrays;
import xbean.TeamMember;
import knight.gsp.msg.Message;
import knight.gsp.team.PDisMissTeam;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RemoveGlobalMemberBroast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RemoveGlobalMemberBroast extends __RemoveGlobalMemberBroast__ {
	@Override
	protected void process() {
		/*
		 * 一、先判断newleaderid是否为-1,如果是则说明队伍解散，发送通知给该队伍所有在线的人
		 * 二、如果不是-1,则比较和现在队伍中的leaderid是否一样，一样则说明是其他队员离开
		 * 三、如果不一样，则说明队长换了。要么队长掉线了，其他人代替了，要么队长主动离开了
		 */
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.getTeamByTeamID(teamid);
				if (team == null || !team.isGlobalTeam())
					return false;
				
				/*
				 * 队伍解散啦
				 */
				if (newleaderid == -1L) {
					// 没人做队长了，直接把队伍解散
					boolean disMissResult = new PDisMissTeam(team.teamId)
							.call();
					if (!disMissResult)
						return false;
				} else {
					TeamMember member = team.getMemBean(removeid);
					String removename = null;
					if (member != null){
						removename=member.getName();
					} else {
						Team.logger.error("被移除的队伍成员不存在：team [" + team.getAllMemberIdsToString() + "] removeId=" + removeid);
					}
					if (newleaderid == team.getTeamLeaderId()) {
						//新的队长id和当前的队长id是一致的，说明队长没发生变化
						if (!team.removeGlobalTeamMemberWithSp(removeid))
							return false;
						//通知队员离线
						if(removename!=null)
						Message.psendMsgNotifyWhileCommit(team.getAllOnlineMemberID(),
								100062,
								Arrays.asList(removename));
					} else {
						//说明是老队长离队了，并且有一个新的队长
						if (!team.removeGlobalteamLeadderWitshSp(removeid, newleaderid))
							return false;
						//通知队长离线
						if(removename!=null)
							Message.psendMsgNotifyWhileCommit(team.getAllOnlineMemberID(),
									100062,
									Arrays.asList(removename));
						// 有新的队员来做队长
						Message.psendMsgNotifyWhileCommit(team.getAllOnlineMemberID(),100185, Arrays.asList(team.getMemBean(team.getTeamLeaderId()).getName()));
					}
				}
				// 你退出了队伍
				Message.psendMsgNotifyWhileCommit(removeid, 100048);
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925516;

	public int getType() {
		return 925516;
	}

	public long removeid; // 要离开成员的id
	public long teamid; // 队伍id
	public long newleaderid; // global选出的队长的id,如果离开后队伍为空了，此值为null

	public RemoveGlobalMemberBroast() {
	}

	public RemoveGlobalMemberBroast(long _removeid_, long _teamid_, long _newleaderid_) {
		this.removeid = _removeid_;
		this.teamid = _teamid_;
		this.newleaderid = _newleaderid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(removeid);
		_os_.marshal(teamid);
		_os_.marshal(newleaderid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		removeid = _os_.unmarshal_long();
		teamid = _os_.unmarshal_long();
		newleaderid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RemoveGlobalMemberBroast) {
			RemoveGlobalMemberBroast _o_ = (RemoveGlobalMemberBroast)_o1_;
			if (removeid != _o_.removeid) return false;
			if (teamid != _o_.teamid) return false;
			if (newleaderid != _o_.newleaderid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)removeid;
		_h_ += (int)teamid;
		_h_ += (int)newleaderid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(removeid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(newleaderid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(RemoveGlobalMemberBroast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(removeid - _o_.removeid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(newleaderid - _o_.newleaderid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

