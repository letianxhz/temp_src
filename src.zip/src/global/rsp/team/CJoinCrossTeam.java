
package global.rsp.team;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CJoinCrossTeam__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CJoinCrossTeam extends __CJoinCrossTeam__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924716;

	public int getType() {
		return 924716;
	}

	public int groupid;
	public long roleid;
	public long crossteamid;
	public java.lang.String name;
	public int level;
	public int school;
	public int zoneid; // 服务器ID

	public CJoinCrossTeam() {
		name = "";
	}

	public CJoinCrossTeam(int _groupid_, long _roleid_, long _crossteamid_, java.lang.String _name_, int _level_, int _school_, int _zoneid_) {
		this.groupid = _groupid_;
		this.roleid = _roleid_;
		this.crossteamid = _crossteamid_;
		this.name = _name_;
		this.level = _level_;
		this.school = _school_;
		this.zoneid = _zoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(groupid);
		_os_.marshal(roleid);
		_os_.marshal(crossteamid);
		_os_.marshal(name, "UTF-16LE");
		_os_.marshal(level);
		_os_.marshal(school);
		_os_.marshal(zoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		groupid = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		crossteamid = _os_.unmarshal_long();
		name = _os_.unmarshal_String("UTF-16LE");
		level = _os_.unmarshal_int();
		school = _os_.unmarshal_int();
		zoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CJoinCrossTeam) {
			CJoinCrossTeam _o_ = (CJoinCrossTeam)_o1_;
			if (groupid != _o_.groupid) return false;
			if (roleid != _o_.roleid) return false;
			if (crossteamid != _o_.crossteamid) return false;
			if (!name.equals(_o_.name)) return false;
			if (level != _o_.level) return false;
			if (school != _o_.school) return false;
			if (zoneid != _o_.zoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += groupid;
		_h_ += (int)roleid;
		_h_ += (int)crossteamid;
		_h_ += name.hashCode();
		_h_ += level;
		_h_ += school;
		_h_ += zoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(groupid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(crossteamid).append(",");
		_sb_.append("T").append(name.length()).append(",");
		_sb_.append(level).append(",");
		_sb_.append(school).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

