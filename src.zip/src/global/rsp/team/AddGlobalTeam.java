
package global.rsp.team;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __AddGlobalTeam__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class AddGlobalTeam extends __AddGlobalTeam__ {
	@Override
	protected void process() {
		new PAddGlobalTeam(teamid, teamleader, platid, members, zoneid).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925507;

	public int getType() {
		return 925507;
	}

	public long teamid; // 队伍id
	public long teamleader; // 队长
	public int platid; // 组队平台
	public java.util.LinkedList<global.rsp.team.TeamMemberBasic> members; // 所有队员信息
	public int zoneid; // 队伍所在服务器

	public AddGlobalTeam() {
		members = new java.util.LinkedList<global.rsp.team.TeamMemberBasic>();
	}

	public AddGlobalTeam(long _teamid_, long _teamleader_, int _platid_, java.util.LinkedList<global.rsp.team.TeamMemberBasic> _members_, int _zoneid_) {
		this.teamid = _teamid_;
		this.teamleader = _teamleader_;
		this.platid = _platid_;
		this.members = _members_;
		this.zoneid = _zoneid_;
	}

	public final boolean _validator_() {
		for (global.rsp.team.TeamMemberBasic _v_ : members)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(teamleader);
		_os_.marshal(platid);
		_os_.compact_uint32(members.size());
		for (global.rsp.team.TeamMemberBasic _v_ : members) {
			_os_.marshal(_v_);
		}
		_os_.marshal(zoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		teamleader = _os_.unmarshal_long();
		platid = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.team.TeamMemberBasic _v_ = new global.rsp.team.TeamMemberBasic();
			_v_.unmarshal(_os_);
			members.add(_v_);
		}
		zoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof AddGlobalTeam) {
			AddGlobalTeam _o_ = (AddGlobalTeam)_o1_;
			if (teamid != _o_.teamid) return false;
			if (teamleader != _o_.teamleader) return false;
			if (platid != _o_.platid) return false;
			if (!members.equals(_o_.members)) return false;
			if (zoneid != _o_.zoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += (int)teamleader;
		_h_ += platid;
		_h_ += members.hashCode();
		_h_ += zoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(teamleader).append(",");
		_sb_.append(platid).append(",");
		_sb_.append(members).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

