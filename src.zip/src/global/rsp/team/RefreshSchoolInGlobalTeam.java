
package global.rsp.team;
import java.util.ArrayList;
import java.util.List;

import knight.gsp.LocalIds;
import knight.gsp.team.SRefreshTeamMemberSchool;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RefreshSchoolInGlobalTeam__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RefreshSchoolInGlobalTeam extends __RefreshSchoolInGlobalTeam__ {
	@Override
	protected void process() {
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				xbean.TeamInfo teamInfo = xtable.Team.get(teamid);
				if(teamInfo == null){
					return false;
				}
				List<Long> noticeIds = new ArrayList<Long>();
				for(xbean.TeamMember member : teamInfo.getMembers()){
					if(member.getRoleid() == refreshid){
						member.setLevel(school);
					}
					if(!LocalIds.isRemoteServerRole(member.getRoleid())){
						noticeIds.add(member.getRoleid());
					}
				}
				psendWhileCommit(noticeIds, new SRefreshTeamMemberSchool(refreshid, school));
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925534;

	public int getType() {
		return 925534;
	}

	public long teamid; // 队伍id
	public long refreshid; // 被更新的玩家id
	public int school; // 被更新玩家的新职业

	public RefreshSchoolInGlobalTeam() {
	}

	public RefreshSchoolInGlobalTeam(long _teamid_, long _refreshid_, int _school_) {
		this.teamid = _teamid_;
		this.refreshid = _refreshid_;
		this.school = _school_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(refreshid);
		_os_.marshal(school);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		refreshid = _os_.unmarshal_long();
		school = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RefreshSchoolInGlobalTeam) {
			RefreshSchoolInGlobalTeam _o_ = (RefreshSchoolInGlobalTeam)_o1_;
			if (teamid != _o_.teamid) return false;
			if (refreshid != _o_.refreshid) return false;
			if (school != _o_.school) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += (int)refreshid;
		_h_ += school;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(refreshid).append(",");
		_sb_.append(school).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(RefreshSchoolInGlobalTeam _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(refreshid - _o_.refreshid);
		if (0 != _c_) return _c_;
		_c_ = school - _o_.school;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

