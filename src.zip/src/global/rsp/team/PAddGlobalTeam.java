package global.rsp.team;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import knight.gsp.team.TeamManager;
import xdb.Procedure;

public class PAddGlobalTeam extends Procedure {

	private long teamid; // 队伍id
	
	private long teamleader; // 队长
	
	private int platid; // 组队平台
	
	private List<global.rsp.team.TeamMemberBasic> members; // 所有队员信息
	
	private int zoneId;// 队伍服务器id

	public PAddGlobalTeam(long teamid, long teamleader, int platid, List<TeamMemberBasic> members, int zoneId) {
		super();
		this.teamid = teamid;
		this.teamleader = teamleader;
		this.platid = platid;
		this.members = members;
		this.zoneId = zoneId;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected boolean process() throws Exception {
		
		xdb.TTable<Long, xbean.TeamInfo> teamTable = (xdb.TTable<Long, xbean.TeamInfo>) xdb.Xdb.getInstance().getTables().getTable("team");
		if (teamTable.get(teamid) != null) {
			TeamManager.logger.error("增加跨服队伍时，已经有了旧的队伍数据了.teamId=" + teamid);
			return false;
		}
		
		if (platid > 0) {
			xbean.TeamPlatForm platForm = xtable.Teamplatforms.get(platid);
			if (platForm == null) {
				platForm = xbean.Pod.newTeamPlatForm();
				xtable.Teamplatforms.insert(platid, platForm);
			}
			
			//team plat lock
			platForm.getTeams().put(teamid, (short) members.size());
		}
		
		Set<Long> lockRoles = new HashSet<Long>();
		xbean.TeamInfo teamInfo = xbean.Pod.newTeamInfo();
		teamInfo.setIscrossteam(true);
		teamInfo.setPlatid(platid);
		teamInfo.setTeamleaderid(teamleader);
		teamInfo.setServerid(zoneId);
		for (global.rsp.team.TeamMemberBasic tmb : members) {
			xbean.TeamMember member = xbean.Pod.newTeamMember();
			member.setLevel(tmb.level);
			member.setName(tmb.rolename);
			member.setRoleid(tmb.roleid);
			member.setSchool(tmb.hero);
			member.setState(tmb.state);
			member.setZoneid(tmb.zoneid);
			member.setCurzoneid(tmb.zoneid);
			member.setUserid(tmb.userid);
			teamInfo.getMembers().add(member);
			
			lockRoles.add(tmb.roleid);
		}
		
		//team lock
		teamTable.insertUncheckedAutoKey(teamid, teamInfo);
		
		lock(xtable.Locks.ROLELOCK, lockRoles);
		for (long roleId : lockRoles) {
			xtable.Roleid2teamid.add(roleId, teamid);
		}
		
		TeamManager.logger.debug("收到来自全局服务器的新增全局队伍数据。teamId=" + teamid);
		
		return true;
	}

	
}
