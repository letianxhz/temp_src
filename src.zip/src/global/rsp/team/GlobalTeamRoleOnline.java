
package global.rsp.team;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlobalTeamRoleOnline__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlobalTeamRoleOnline extends __GlobalTeamRoleOnline__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925523;

	public int getType() {
		return 925523;
	}

	public long roleid; // 掉线的id
	public long teamid; // 队伍id
	public int setzoneid; // 在哪个服上线

	public GlobalTeamRoleOnline() {
	}

	public GlobalTeamRoleOnline(long _roleid_, long _teamid_, int _setzoneid_) {
		this.roleid = _roleid_;
		this.teamid = _teamid_;
		this.setzoneid = _setzoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(teamid);
		_os_.marshal(setzoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		teamid = _os_.unmarshal_long();
		setzoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlobalTeamRoleOnline) {
			GlobalTeamRoleOnline _o_ = (GlobalTeamRoleOnline)_o1_;
			if (roleid != _o_.roleid) return false;
			if (teamid != _o_.teamid) return false;
			if (setzoneid != _o_.setzoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)teamid;
		_h_ += setzoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(setzoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlobalTeamRoleOnline _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = setzoneid - _o_.setzoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

