
package global.rsp.team;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqGlobalTeamDataWhileGsStart__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqGlobalTeamDataWhileGsStart extends __ReqGlobalTeamDataWhileGsStart__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925528;

	public int getType() {
		return 925528;
	}

	public int myzoneid; // 我的服务器id

	public ReqGlobalTeamDataWhileGsStart() {
	}

	public ReqGlobalTeamDataWhileGsStart(int _myzoneid_) {
		this.myzoneid = _myzoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(myzoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		myzoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqGlobalTeamDataWhileGsStart) {
			ReqGlobalTeamDataWhileGsStart _o_ = (ReqGlobalTeamDataWhileGsStart)_o1_;
			if (myzoneid != _o_.myzoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += myzoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(myzoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(ReqGlobalTeamDataWhileGsStart _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = myzoneid - _o_.myzoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

