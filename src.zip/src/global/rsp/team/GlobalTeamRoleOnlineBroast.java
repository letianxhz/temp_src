
package global.rsp.team;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlobalTeamRoleOnlineBroast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlobalTeamRoleOnlineBroast extends __GlobalTeamRoleOnlineBroast__ {
	@Override
	protected void process() {
		new xdb.Procedure() {
			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.getTeamByTeamID(teamid);
				if (team == null)
					return false;
				
				//锁所有的角色锁,因为后面 请求队友血量可能会拿锁
				lock(xtable.Locks.ROLELOCK, team.getAllMemberIds());
				
				if (team.getTeamLeaderId() == newleaderid) {
					/*
					 * 没有换队长
					 */
					if(!team.globalTeamRoleOnilne(roleid, null))
						return false;
				} else {
					/*
					 * 换队长了
					 */
					if(!team.globalTeamRoleOnilne(roleid, newleaderid))
						return false;
				}
				
				team.getMemBean(roleid).setCurzoneid(setzoneid);
					
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925524;

	public int getType() {
		return 925524;
	}

	public long roleid; // 掉线的id
	public long teamid; // 队伍id
	public long newleaderid; // 离线后的新队长
	public int setzoneid; // 在哪个服上线

	public GlobalTeamRoleOnlineBroast() {
	}

	public GlobalTeamRoleOnlineBroast(long _roleid_, long _teamid_, long _newleaderid_, int _setzoneid_) {
		this.roleid = _roleid_;
		this.teamid = _teamid_;
		this.newleaderid = _newleaderid_;
		this.setzoneid = _setzoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(teamid);
		_os_.marshal(newleaderid);
		_os_.marshal(setzoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		teamid = _os_.unmarshal_long();
		newleaderid = _os_.unmarshal_long();
		setzoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlobalTeamRoleOnlineBroast) {
			GlobalTeamRoleOnlineBroast _o_ = (GlobalTeamRoleOnlineBroast)_o1_;
			if (roleid != _o_.roleid) return false;
			if (teamid != _o_.teamid) return false;
			if (newleaderid != _o_.newleaderid) return false;
			if (setzoneid != _o_.setzoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)teamid;
		_h_ += (int)newleaderid;
		_h_ += setzoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(newleaderid).append(",");
		_sb_.append(setzoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlobalTeamRoleOnlineBroast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(newleaderid - _o_.newleaderid);
		if (0 != _c_) return _c_;
		_c_ = setzoneid - _o_.setzoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

