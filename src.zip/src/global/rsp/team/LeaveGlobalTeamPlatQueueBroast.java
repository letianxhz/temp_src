package global.rsp.team;

import knight.gsp.team.PRemoveTeamFromPlatform;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __LeaveGlobalTeamPlatQueueBroast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class LeaveGlobalTeamPlatQueueBroast extends
		__LeaveGlobalTeamPlatQueueBroast__ {
	@Override
	protected void process() {
		// protocol handle
		new xdb.Procedure() {
			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.selectTeamByTeamID(teamid);
				if (team == null)
					return false;
				int platid = team.getPlatId();
				if (platid <= 0)
					return false;
				if (!new PRemoveTeamFromPlatform(teamid, platid, isactive == 1, true).call())
					return false;
				return true;
			}

		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925520;

	public int getType() {
		return 925520;
	}

	public long teamid; // 队伍id
	public int platid; // 队伍的平台id
	public int isactive; // 0-队伍主动离开平台，1-进入副本，主要是用来控制客户端提示信息

	public LeaveGlobalTeamPlatQueueBroast() {
	}

	public LeaveGlobalTeamPlatQueueBroast(long _teamid_, int _platid_, int _isactive_) {
		this.teamid = _teamid_;
		this.platid = _platid_;
		this.isactive = _isactive_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(platid);
		_os_.marshal(isactive);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		platid = _os_.unmarshal_int();
		isactive = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof LeaveGlobalTeamPlatQueueBroast) {
			LeaveGlobalTeamPlatQueueBroast _o_ = (LeaveGlobalTeamPlatQueueBroast)_o1_;
			if (teamid != _o_.teamid) return false;
			if (platid != _o_.platid) return false;
			if (isactive != _o_.isactive) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += platid;
		_h_ += isactive;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(platid).append(",");
		_sb_.append(isactive).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(LeaveGlobalTeamPlatQueueBroast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = platid - _o_.platid;
		if (0 != _c_) return _c_;
		_c_ = isactive - _o_.isactive;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}
