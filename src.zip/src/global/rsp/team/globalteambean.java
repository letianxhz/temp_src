
package global.rsp.team;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __globalteambean__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class globalteambean extends __globalteambean__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925505;

	public int getType() {
		return 925505;
	}

	public global.rsp.team.TeamMemberState import1;
	public global.rsp.team.TeamMemberBasic import2;

	public globalteambean() {
		import1 = new global.rsp.team.TeamMemberState();
		import2 = new global.rsp.team.TeamMemberBasic();
	}

	public globalteambean(global.rsp.team.TeamMemberState _import1_, global.rsp.team.TeamMemberBasic _import2_) {
		this.import1 = _import1_;
		this.import2 = _import2_;
	}

	public final boolean _validator_() {
		if (!import1._validator_()) return false;
		if (!import2._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(import1);
		_os_.marshal(import2);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		import1.unmarshal(_os_);
		import2.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof globalteambean) {
			globalteambean _o_ = (globalteambean)_o1_;
			if (!import1.equals(_o_.import1)) return false;
			if (!import2.equals(_o_.import2)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += import1.hashCode();
		_h_ += import2.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(import1).append(",");
		_sb_.append(import2).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

