
package global.rsp.team;
import java.util.Arrays;

import knight.gsp.msg.Message;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __DeleteGlobalMemberBroast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class DeleteGlobalMemberBroast extends __DeleteGlobalMemberBroast__ {
	@Override
	protected void process() {
		// protocol handle
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.getTeamByTeamID(teamid);
				if (team == null || !team.isGlobalTeam())
					return false;
				else {
					/*
					 * 在传过来之前已经判断多删除的人是队长，被删的人在队里了，这里就不再你判断了
					 */
					String leaderName=team.getMemBean(team.getTeamLeaderId()).getName();
					String removeName=team.getMemBean(removeid).getName();
					boolean success = team.removeGlobalTeamMemberWithSp(removeid);
					if (!success)
						return false;
					/*
					 * 通知被请离的队员，你被请离了队伍
					 * 告诉在线的队员，谁被请离了队伍
					 */
					if(leaderName!=null)
					Message.psendMsgNotify(removeid, 100193, Arrays.asList(leaderName));
					if(removeName!=null)
					Message.psendMsgNotify(team.getAllOnlineMemberID(), 100199, Arrays.asList(removeName));
					
				}
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925518;

	public int getType() {
		return 925518;
	}

	public long removeid; // 要踢的成员的id
	public long teamid; // 队伍id

	public DeleteGlobalMemberBroast() {
	}

	public DeleteGlobalMemberBroast(long _removeid_, long _teamid_) {
		this.removeid = _removeid_;
		this.teamid = _teamid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(removeid);
		_os_.marshal(teamid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		removeid = _os_.unmarshal_long();
		teamid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof DeleteGlobalMemberBroast) {
			DeleteGlobalMemberBroast _o_ = (DeleteGlobalMemberBroast)_o1_;
			if (removeid != _o_.removeid) return false;
			if (teamid != _o_.teamid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)removeid;
		_h_ += (int)teamid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(removeid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(DeleteGlobalMemberBroast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(removeid - _o_.removeid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

