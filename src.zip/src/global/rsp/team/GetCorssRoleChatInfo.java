
package global.rsp.team;
import global.rsp.GlobalClientManager;
import knight.gsp.LocalIds;
import knight.gsp.friends.PFriendsInfoInit;
import knight.gsp.friends.SRequestUpdateRoleInfo;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GetCorssRoleChatInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GetCorssRoleChatInfo extends __GetCorssRoleChatInfo__ {
	@Override
	protected void process() {
		if(LocalIds.isRemoteServerRole(roleid)){
			return;
		}
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				SRequestUpdateRoleInfo send = new SRequestUpdateRoleInfo();
				send.friendinfobean = PFriendsInfoInit.toInfoBean(fromroleid, roleid, null, null);
				send.friendinfobean.online = 1;
				GlobalClientManager.getInstance().sendToRole(fromzoneid, fromroleid, send);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925532;

	public int getType() {
		return 925532;
	}

	public long roleid; // 被请求玩家id
	public long fromroleid; // 发出请求的玩家id
	public int fromzoneid; // 发出请求的玩家服务器id

	public GetCorssRoleChatInfo() {
	}

	public GetCorssRoleChatInfo(long _roleid_, long _fromroleid_, int _fromzoneid_) {
		this.roleid = _roleid_;
		this.fromroleid = _fromroleid_;
		this.fromzoneid = _fromzoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fromroleid);
		_os_.marshal(fromzoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fromroleid = _os_.unmarshal_long();
		fromzoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GetCorssRoleChatInfo) {
			GetCorssRoleChatInfo _o_ = (GetCorssRoleChatInfo)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fromroleid != _o_.fromroleid) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)fromroleid;
		_h_ += fromzoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fromroleid).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GetCorssRoleChatInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(fromroleid - _o_.fromroleid);
		if (0 != _c_) return _c_;
		_c_ = fromzoneid - _o_.fromzoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

