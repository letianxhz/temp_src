
package global.rsp.team;
import java.util.Arrays;

import knight.gsp.main.ConfigManager;
import knight.gsp.msg.Message;
import knight.gsp.team.SSetTeamLeader;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SetTeamleaderBroadcast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SetTeamleaderBroadcast extends __SetTeamleaderBroadcast__ {
	@Override
	protected void process() {
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				
				Team team = TeamManager.getTeamByTeamID(teamid);
				if (team == null || !team.isInTeam(newleader))
					return false;
				team.getTeamInfo().setTeamleaderid(newleader);
				
				lock(xtable.Locks.ROLELOCK, team.getAllMemberIds());
				String newLeaderName = null;
				for(xbean.TeamMember member : team.getTeamInfo().getMembers()){
					if(member.getRoleid() == newleader){
						newLeaderName = member.getName();
						break;
					}
				}
				for (xbean.TeamMember member : team.getTeamInfo().getMembers()) {
					if (member.getCurzoneid() != ConfigManager.getGsZoneId())
						continue;
					
					if (member.getState() != TeamMemberState.eTeamNormal)
						continue;
					if(newleader == member.getRoleid()){
						//MSG 担任队长成功
						Message.psendMsgNotify(newleader, 100275, null);
					} else {
						if (newLeaderName != null){
							Message.psendMsgNotify(member.getRoleid(), 100276, Arrays.asList(newLeaderName));
						}
					}
					xdb.Procedure.psendWhileCommit(member.getRoleid(), new SSetTeamLeader(newleader));
				}
				team.onTeamStructureChanged(newleader, 0, 0);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925514;

	public int getType() {
		return 925514;
	}

	public long teamid; // 队伍id
	public long newleader; // 想要设置的新成员id

	public SetTeamleaderBroadcast() {
	}

	public SetTeamleaderBroadcast(long _teamid_, long _newleader_) {
		this.teamid = _teamid_;
		this.newleader = _newleader_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(newleader);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		newleader = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SetTeamleaderBroadcast) {
			SetTeamleaderBroadcast _o_ = (SetTeamleaderBroadcast)_o1_;
			if (teamid != _o_.teamid) return false;
			if (newleader != _o_.newleader) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += (int)newleader;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(newleader).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SetTeamleaderBroadcast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(newleader - _o_.newleader);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

