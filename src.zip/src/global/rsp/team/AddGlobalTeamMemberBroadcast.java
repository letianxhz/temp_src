
package global.rsp.team;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;
import xdb.Procedure;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __AddGlobalTeamMemberBroadcast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class AddGlobalTeamMemberBroadcast extends __AddGlobalTeamMemberBroadcast__ {
	@Override
	protected void process() {
		new Procedure(){

			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.getTeamByTeamID(teamid);
				if (team == null||team.isFull())
					return false;
				lock(xtable.Locks.ROLELOCK, team.getAllMemberIds());
				boolean succ= team.addMemberToGlobalTeam(newmember);
				if(!succ)
					return false;
				
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925510;

	public int getType() {
		return 925510;
	}

	public long teamid; // 队伍id
	public global.rsp.team.TeamMemberBasic newmember; // 加入的新成员

	public AddGlobalTeamMemberBroadcast() {
		newmember = new global.rsp.team.TeamMemberBasic();
	}

	public AddGlobalTeamMemberBroadcast(long _teamid_, global.rsp.team.TeamMemberBasic _newmember_) {
		this.teamid = _teamid_;
		this.newmember = _newmember_;
	}

	public final boolean _validator_() {
		if (!newmember._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(newmember);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		newmember.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof AddGlobalTeamMemberBroadcast) {
			AddGlobalTeamMemberBroadcast _o_ = (AddGlobalTeamMemberBroadcast)_o1_;
			if (teamid != _o_.teamid) return false;
			if (!newmember.equals(_o_.newmember)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += newmember.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(newmember).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

