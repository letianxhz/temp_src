
package global.rsp.team;
import knight.gsp.team.PGlobalTeamMemberOffline;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlobalTeamRoleOfflineBroast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlobalTeamRoleOfflineBroast extends __GlobalTeamRoleOfflineBroast__ {
	@Override
	protected void process() {
		new PGlobalTeamMemberOffline(teamid, roleid, newstate, newleaderid).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925522;

	public int getType() {
		return 925522;
	}

	public long roleid; // 掉线的id
	public long teamid; // 队伍id
	public int newstate; // 离线后的新状态，不在副本中是2，在是3
	public long newleaderid; // 离线后的新队长

	public GlobalTeamRoleOfflineBroast() {
	}

	public GlobalTeamRoleOfflineBroast(long _roleid_, long _teamid_, int _newstate_, long _newleaderid_) {
		this.roleid = _roleid_;
		this.teamid = _teamid_;
		this.newstate = _newstate_;
		this.newleaderid = _newleaderid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(teamid);
		_os_.marshal(newstate);
		_os_.marshal(newleaderid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		teamid = _os_.unmarshal_long();
		newstate = _os_.unmarshal_int();
		newleaderid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlobalTeamRoleOfflineBroast) {
			GlobalTeamRoleOfflineBroast _o_ = (GlobalTeamRoleOfflineBroast)_o1_;
			if (roleid != _o_.roleid) return false;
			if (teamid != _o_.teamid) return false;
			if (newstate != _o_.newstate) return false;
			if (newleaderid != _o_.newleaderid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)teamid;
		_h_ += newstate;
		_h_ += (int)newleaderid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(newstate).append(",");
		_sb_.append(newleaderid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlobalTeamRoleOfflineBroast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = newstate - _o_.newstate;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(newleaderid - _o_.newleaderid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

