
package global.rsp;
import java.util.HashMap;
import java.util.Map;
import knight.gsp.LocalIds;
import knight.gsp.yuanbao.PCreditYuBao;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyGsAddMoney__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyGsAddMoney extends __NotifyGsAddMoney__ {
	@Override
	protected void process() {
		if (roleid <= 0 || LocalIds.isRemoteServerRole(roleid))
			return;
		Map<String, String> var = new HashMap<String, String>();
		var.put("midasbillno", midasbillno);
		new PCreditYuBao(roleid, costmoney, var).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918213;

	public int getType() {
		return 918213;
	}

	public long roleid; // 角色id
	public int costmoney; // 玩家消费的人民币
	public int goldnum; // 需要发放的钻石
	public java.lang.String midasbillno; // 米大师订单号

	public NotifyGsAddMoney() {
		midasbillno = "";
	}

	public NotifyGsAddMoney(long _roleid_, int _costmoney_, int _goldnum_, java.lang.String _midasbillno_) {
		this.roleid = _roleid_;
		this.costmoney = _costmoney_;
		this.goldnum = _goldnum_;
		this.midasbillno = _midasbillno_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(costmoney);
		_os_.marshal(goldnum);
		_os_.marshal(midasbillno, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		costmoney = _os_.unmarshal_int();
		goldnum = _os_.unmarshal_int();
		midasbillno = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyGsAddMoney) {
			NotifyGsAddMoney _o_ = (NotifyGsAddMoney)_o1_;
			if (roleid != _o_.roleid) return false;
			if (costmoney != _o_.costmoney) return false;
			if (goldnum != _o_.goldnum) return false;
			if (!midasbillno.equals(_o_.midasbillno)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += costmoney;
		_h_ += goldnum;
		_h_ += midasbillno.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(costmoney).append(",");
		_sb_.append(goldnum).append(",");
		_sb_.append("T").append(midasbillno.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

