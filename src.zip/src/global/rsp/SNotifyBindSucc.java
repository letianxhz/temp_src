
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SNotifyBindSucc__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SNotifyBindSucc extends __SNotifyBindSucc__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918229;

	public int getType() {
		return 918229;
	}

	public long roleid; // 角色id
	public java.lang.String acc; // 聚宝盆uid
	public java.lang.String ledouid; // 乐道uid
	public int zoneid; // 服务器id
	public java.lang.String phonenum; // bind成功电话号不为空

	public SNotifyBindSucc() {
		acc = "";
		ledouid = "";
		phonenum = "";
	}

	public SNotifyBindSucc(long _roleid_, java.lang.String _acc_, java.lang.String _ledouid_, int _zoneid_, java.lang.String _phonenum_) {
		this.roleid = _roleid_;
		this.acc = _acc_;
		this.ledouid = _ledouid_;
		this.zoneid = _zoneid_;
		this.phonenum = _phonenum_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(acc, "UTF-16LE");
		_os_.marshal(ledouid, "UTF-16LE");
		_os_.marshal(zoneid);
		_os_.marshal(phonenum, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		acc = _os_.unmarshal_String("UTF-16LE");
		ledouid = _os_.unmarshal_String("UTF-16LE");
		zoneid = _os_.unmarshal_int();
		phonenum = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SNotifyBindSucc) {
			SNotifyBindSucc _o_ = (SNotifyBindSucc)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!acc.equals(_o_.acc)) return false;
			if (!ledouid.equals(_o_.ledouid)) return false;
			if (zoneid != _o_.zoneid) return false;
			if (!phonenum.equals(_o_.phonenum)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += acc.hashCode();
		_h_ += ledouid.hashCode();
		_h_ += zoneid;
		_h_ += phonenum.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append("T").append(acc.length()).append(",");
		_sb_.append("T").append(ledouid.length()).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append("T").append(phonenum.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

