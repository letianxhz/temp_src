
package global.rsp;

import java.util.List;
import knight.gsp.item.BagTypes;
import knight.gsp.item.CGetOtherRoleEquipBag;
import knight.gsp.item.ItemColumn;
import knight.gsp.item.Module;
import knight.gsp.item.SGetOtherRoleEquipBag;
import knight.gsp.item.SGetOtherRoleEquipBagLua;
import knight.gsp.item.SRepEquipSetProps;
import knight.gsp.item.suit.PRecorrectSuitProps;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GetOtherRoleEquipBag__ extends xio.Protocol { }

/** 请求查看玩家装备
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GetOtherRoleEquipBag extends __GetOtherRoleEquipBag__ {
	@Override
	protected void process() {
		xbean.Properties prop = xtable.Properties.select(targetroleid);
		if (null == prop) {
			// 玩家不在这个服
			return;
		}
		
		final SendOtherRoleEquipBag res = new SendOtherRoleEquipBag();
		
		final ItemColumn bag = Module.getInstance().getItemColumn(targetroleid, BagTypes.EQUIP, true);
		final SGetOtherRoleEquipBag p1 = CGetOtherRoleEquipBag.getProtocol1(targetroleid, bag);
		final SGetOtherRoleEquipBagLua p2 = CGetOtherRoleEquipBag.getProtocol2(targetroleid, bag);
		final List<Integer> suits = PRecorrectSuitProps.getSuitPropConf(targetroleid);
		SRepEquipSetProps p3 = new SRepEquipSetProps();
		p3.roleid = targetroleid;
		p3.gots.addAll(suits);
		Integer jueXingSuitId = xtable.Juexing.selectJuexingsuitid(targetroleid);
		if (null != jueXingSuitId)
			p3.juexingsuitid = jueXingSuitId;
		p3.schoolid = xtable.Properties.selectSchool(targetroleid);
		OctetsStream os1 = new OctetsStream();
		os1.marshal(p1);
		
		OctetsStream os2 = new OctetsStream();
		os2.marshal(p2);
		
		OctetsStream os3 = new OctetsStream();
		os3.marshal(p3);
		
		res.fromroleid = fromroleid;
		res.roleid = targetroleid;
		res.octs1 = os1;
		res.octs2 = os2;
		res.octs3 = os3;

		GlobalClientManager.getInstance().send(fromzoneid, res);
	}
	
	

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924512;

	public int getType() {
		return 924512;
	}

	public int fromzoneid; // 源服务器zoneid
	public long fromroleid;
	public long targetroleid;

	public GetOtherRoleEquipBag() {
	}

	public GetOtherRoleEquipBag(int _fromzoneid_, long _fromroleid_, long _targetroleid_) {
		this.fromzoneid = _fromzoneid_;
		this.fromroleid = _fromroleid_;
		this.targetroleid = _targetroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fromzoneid);
		_os_.marshal(fromroleid);
		_os_.marshal(targetroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fromzoneid = _os_.unmarshal_int();
		fromroleid = _os_.unmarshal_long();
		targetroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GetOtherRoleEquipBag) {
			GetOtherRoleEquipBag _o_ = (GetOtherRoleEquipBag)_o1_;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (fromroleid != _o_.fromroleid) return false;
			if (targetroleid != _o_.targetroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += fromzoneid;
		_h_ += (int)fromroleid;
		_h_ += (int)targetroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(fromroleid).append(",");
		_sb_.append(targetroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GetOtherRoleEquipBag _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = fromzoneid - _o_.fromzoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(fromroleid - _o_.fromroleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(targetroleid - _o_.targetroleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

