
package global.rsp;
import knight.gsp.main.Gs;

import org.apache.log4j.Logger;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlobalBroadcast2__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlobalBroadcast2 extends __GlobalBroadcast2__ {
	
	private static final Logger logger = Logger.getLogger(GlobalBroadcast2.class);
	
	@Override
	public void dispatch(Stub stub) throws Exception {
		try {
			Stub stub2 = ((Coder) (getManager().getCoder()))
					.getStub(this.ptype);
			xio.Protocol p = stub2.newInstance();
			OctetsStream octstram = OctetsStream.wrap(this.pdata);
			p.unmarshal(octstram);
			p.setConnection(this.getConnection());
			p.setContext(this);
			if(Gs.isShutDown.get())
				return; //如果正在关闭，则不接受任何协议了
			
			p.dispatch(stub);
			return;
		} catch (Exception e) {
			logger.error("接收来自全局服务器的协议失败.message=" + e.getMessage());
			e.printStackTrace();
		} 
	}

	@Override
	protected void process() {
		throw new UnsupportedOperationException();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924510;

	public int getType() {
		return 924510;
	}

	public java.util.LinkedList<Integer> serverlist;
	public int ptype;
	public com.goldhuman.Common.Octets pdata; // 协议的数据

	public GlobalBroadcast2() {
		serverlist = new java.util.LinkedList<Integer>();
		pdata = new com.goldhuman.Common.Octets();
	}

	public GlobalBroadcast2(java.util.LinkedList<Integer> _serverlist_, int _ptype_, com.goldhuman.Common.Octets _pdata_) {
		this.serverlist = _serverlist_;
		this.ptype = _ptype_;
		this.pdata = _pdata_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(serverlist.size());
		for (Integer _v_ : serverlist) {
			_os_.marshal(_v_);
		}
		_os_.marshal(ptype);
		_os_.marshal(pdata);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			serverlist.add(_v_);
		}
		ptype = _os_.unmarshal_int();
		pdata = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlobalBroadcast2) {
			GlobalBroadcast2 _o_ = (GlobalBroadcast2)_o1_;
			if (!serverlist.equals(_o_.serverlist)) return false;
			if (ptype != _o_.ptype) return false;
			if (!pdata.equals(_o_.pdata)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += serverlist.hashCode();
		_h_ += ptype;
		_h_ += pdata.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(serverlist).append(",");
		_sb_.append(ptype).append(",");
		_sb_.append("B").append(pdata.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

