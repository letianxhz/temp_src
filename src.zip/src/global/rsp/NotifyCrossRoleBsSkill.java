
package global.rsp;
import knight.gsp.GsClient;
import knight.msp.GUpdateRoleSkillInfos;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyCrossRoleBsSkill__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyCrossRoleBsSkill extends __NotifyCrossRoleBsSkill__ {
	@Override
	protected void process() {
		xio.Protocol snd = new GUpdateRoleSkillInfos();
		OctetsStream octetsStream = OctetsStream.wrap(octs1);
		try {
			snd.unmarshal(octetsStream);
		} catch (MarshalException e) {
			e.printStackTrace();
		}
		GsClient.send2RoleScene(roleid, snd);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918223;

	public int getType() {
		return 918223;
	}

	public long roleid;
	public com.goldhuman.Common.Octets octs1;

	public NotifyCrossRoleBsSkill() {
		octs1 = new com.goldhuman.Common.Octets();
	}

	public NotifyCrossRoleBsSkill(long _roleid_, com.goldhuman.Common.Octets _octs1_) {
		this.roleid = _roleid_;
		this.octs1 = _octs1_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(octs1);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		octs1 = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyCrossRoleBsSkill) {
			NotifyCrossRoleBsSkill _o_ = (NotifyCrossRoleBsSkill)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!octs1.equals(_o_.octs1)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += octs1.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append("B").append(octs1.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

