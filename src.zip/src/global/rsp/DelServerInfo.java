
package global.rsp;
import knight.gsp.main.ServerInfoProvider;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __DelServerInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class DelServerInfo extends __DelServerInfo__ {
	@Override
	protected void process() {
		ServerInfoProvider.delServerInfos(serverinfo);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918221;

	public int getType() {
		return 918221;
	}

	public global.rsp.ServerInfo serverinfo;

	public DelServerInfo() {
		serverinfo = new global.rsp.ServerInfo();
	}

	public DelServerInfo(global.rsp.ServerInfo _serverinfo_) {
		this.serverinfo = _serverinfo_;
	}

	public final boolean _validator_() {
		if (!serverinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(serverinfo);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		serverinfo.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof DelServerInfo) {
			DelServerInfo _o_ = (DelServerInfo)_o1_;
			if (!serverinfo.equals(_o_.serverinfo)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += serverinfo.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(serverinfo).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

