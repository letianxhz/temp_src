
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SReqAccBindState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SReqAccBindState extends __SReqAccBindState__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918227;

	public int getType() {
		return 918227;
	}

	public long roleid; // 角色id
	public java.lang.String acc; // 聚宝盆uid
	public int zoneid; // 服务器id

	public SReqAccBindState() {
		acc = "";
	}

	public SReqAccBindState(long _roleid_, java.lang.String _acc_, int _zoneid_) {
		this.roleid = _roleid_;
		this.acc = _acc_;
		this.zoneid = _zoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(acc, "UTF-16LE");
		_os_.marshal(zoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		acc = _os_.unmarshal_String("UTF-16LE");
		zoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SReqAccBindState) {
			SReqAccBindState _o_ = (SReqAccBindState)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!acc.equals(_o_.acc)) return false;
			if (zoneid != _o_.zoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += acc.hashCode();
		_h_ += zoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append("T").append(acc.length()).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

