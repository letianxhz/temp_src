
package global.rsp.item;
import java.util.Arrays;
import knight.gsp.giftcard.PUseGiftKeyNew;
import knight.gsp.msg.Message;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ResponseCheckGiftCard__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ResponseCheckGiftCard extends __ResponseCheckGiftCard__ {
	@Override
	protected void process() {
		switch (checkstate) {
		case Unreal:
			//无效的兑换码
			Message.sendMsgNotify(roleid, 101412, null);
			break;
		case OutOfDate:
			String[] data = responsedata.split("#");
			if (data.length < 3) 
				return;
			Message.sendMsgNotify(roleid, 101410, Arrays.asList(data[0], data[1], data[2]));
			break;
		case NotArriveTime:
			String[] rpdata = responsedata.split("#");
			if (rpdata.length < 3) 
				return;
			Message.sendMsgNotify(roleid, 101409, Arrays.asList(rpdata[0], rpdata[1], rpdata[2]));
			break;
		case NotThisServer:
			Message.sendMsgNotify(roleid, 101414, null);
			break;
		case NotThisPlant:
			Message.sendMsgNotify(roleid, 101511, null);
			break;
		case NotArriveLevel:
			Message.sendMsgNotify(roleid, 101415, Arrays.asList(responsedata));
			break;
		case OutOfLevel:
			Message.sendMsgNotify(roleid, 101416, Arrays.asList(responsedata));
			break;
		case AcquiredGift:
			Message.sendMsgNotify(roleid, 101413, null);
			break;
		case HadBeenUse:
			Message.sendMsgNotify(roleid, 101408, null);
			break;
		case Succeed:
			new PUseGiftKeyNew(roleid, giftkey, Integer.parseInt(responsedata.trim())).submit();
			break;
		default:
			break;
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925807;

	public int getType() {
		return 925807;
	}

	public final static int Unreal = 1; // 激活码不存在
	public final static int OutOfDate = 2; // 激活码已过期  返回参数；xx年#xx月xx日
	public final static int NotArriveTime = 3; // 激活码未到使用时间  返回参数；xx年#xx月xx日
	public final static int NotThisServer = 4; // 激活码无法在当前服务器使用
	public final static int NotThisPlant = 5; // 激活码无法在当前渠道使用
	public final static int NotArriveLevel = 6; // 未达到限制等级 返回参数；xx等级
	public final static int OutOfLevel = 7; // 超过限制等级	返回参数；xx等级
	public final static int AcquiredGift = 8; // 已获得同类型的礼包
	public final static int HadBeenUse = 9; // 该兑换码已经被使用
	public final static int Succeed = 10; // 校验成功 返回参数；物品Id

	public byte checkstate; // 返回状态
	public long roleid; // 角色id
	public java.lang.String responsedata; // 返回参数 :失败时的提示数据, 成功时发送给玩家的物品id
	public java.lang.String giftkey; // 兑换码

	public ResponseCheckGiftCard() {
		responsedata = "";
		giftkey = "";
	}

	public ResponseCheckGiftCard(byte _checkstate_, long _roleid_, java.lang.String _responsedata_, java.lang.String _giftkey_) {
		this.checkstate = _checkstate_;
		this.roleid = _roleid_;
		this.responsedata = _responsedata_;
		this.giftkey = _giftkey_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(checkstate);
		_os_.marshal(roleid);
		_os_.marshal(responsedata, "UTF-16LE");
		_os_.marshal(giftkey, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		checkstate = _os_.unmarshal_byte();
		roleid = _os_.unmarshal_long();
		responsedata = _os_.unmarshal_String("UTF-16LE");
		giftkey = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ResponseCheckGiftCard) {
			ResponseCheckGiftCard _o_ = (ResponseCheckGiftCard)_o1_;
			if (checkstate != _o_.checkstate) return false;
			if (roleid != _o_.roleid) return false;
			if (!responsedata.equals(_o_.responsedata)) return false;
			if (!giftkey.equals(_o_.giftkey)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)checkstate;
		_h_ += (int)roleid;
		_h_ += responsedata.hashCode();
		_h_ += giftkey.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(checkstate).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append("T").append(responsedata.length()).append(",");
		_sb_.append("T").append(giftkey.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

