
package global.rsp.item;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendEmailCallBack__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendEmailCallBack extends __SendEmailCallBack__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925810;

	public int getType() {
		return 925810;
	}

	public int sendstate; // 发送状态 1:成功 0:失败
	public int itemid; // 京东卡道具id
	public java.lang.String jdcardinfo; // 京东卡信息

	public SendEmailCallBack() {
		jdcardinfo = "";
	}

	public SendEmailCallBack(int _sendstate_, int _itemid_, java.lang.String _jdcardinfo_) {
		this.sendstate = _sendstate_;
		this.itemid = _itemid_;
		this.jdcardinfo = _jdcardinfo_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(sendstate);
		_os_.marshal(itemid);
		_os_.marshal(jdcardinfo, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		sendstate = _os_.unmarshal_int();
		itemid = _os_.unmarshal_int();
		jdcardinfo = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendEmailCallBack) {
			SendEmailCallBack _o_ = (SendEmailCallBack)_o1_;
			if (sendstate != _o_.sendstate) return false;
			if (itemid != _o_.itemid) return false;
			if (!jdcardinfo.equals(_o_.jdcardinfo)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += sendstate;
		_h_ += itemid;
		_h_ += jdcardinfo.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(sendstate).append(",");
		_sb_.append(itemid).append(",");
		_sb_.append("T").append(jdcardinfo.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

