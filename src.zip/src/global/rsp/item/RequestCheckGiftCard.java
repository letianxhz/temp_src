
package global.rsp.item;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RequestCheckGiftCard__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RequestCheckGiftCard extends __RequestCheckGiftCard__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925806;

	public int getType() {
		return 925806;
	}

	public long roleid; // 角色id
	public int rolelevel; // 角色等级
	public java.lang.String checkkey; // 兑换码
	public java.lang.String username; // 渠道id$渠道名
	public int serverid; // 服务器id

	public RequestCheckGiftCard() {
		checkkey = "";
		username = "";
	}

	public RequestCheckGiftCard(long _roleid_, int _rolelevel_, java.lang.String _checkkey_, java.lang.String _username_, int _serverid_) {
		this.roleid = _roleid_;
		this.rolelevel = _rolelevel_;
		this.checkkey = _checkkey_;
		this.username = _username_;
		this.serverid = _serverid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(rolelevel);
		_os_.marshal(checkkey, "UTF-16LE");
		_os_.marshal(username, "UTF-16LE");
		_os_.marshal(serverid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		rolelevel = _os_.unmarshal_int();
		checkkey = _os_.unmarshal_String("UTF-16LE");
		username = _os_.unmarshal_String("UTF-16LE");
		serverid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RequestCheckGiftCard) {
			RequestCheckGiftCard _o_ = (RequestCheckGiftCard)_o1_;
			if (roleid != _o_.roleid) return false;
			if (rolelevel != _o_.rolelevel) return false;
			if (!checkkey.equals(_o_.checkkey)) return false;
			if (!username.equals(_o_.username)) return false;
			if (serverid != _o_.serverid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += rolelevel;
		_h_ += checkkey.hashCode();
		_h_ += username.hashCode();
		_h_ += serverid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(rolelevel).append(",");
		_sb_.append("T").append(checkkey.length()).append(",");
		_sb_.append("T").append(username.length()).append(",");
		_sb_.append(serverid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

