
package global.rsp.item;
import java.util.Map.Entry;
import xbean.AutoBattleItemUseRole;
import knight.gsp.LocalIds;
import knight.gsp.PAddExpProc;
import knight.gsp.PAddExpProc.EXP_TYPE;
import knight.gsp.item.Bag;
import knight.gsp.item.BasicItem;
import knight.gsp.item.EquipItem;
import knight.gsp.item.Module;
import knight.gsp.item.equip.EquipFactory;
import knight.gsp.log.LogUtil;
import knight.gsp.log.LogUtil.COST_ITEM_TYPE;
import knight.gsp.log.LogUtil.MONEY_TYPE;
import knight.gsp.util.DateValidate;
import knight.gsp.yuanbao.PAddYuanBao;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendItemListToOriginalServer__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendItemListToOriginalServer extends __SendItemListToOriginalServer__ {
	@Override
	protected void process() {
		if (LocalIds.isRemoteServerRole(roleid))
			return;
		
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				if (exp > 0) {
					new PAddExpProc(roleid, exp, EXP_TYPE.FUBEN, String.valueOf("fuben"), false, false).call();
				}
				if (costofflineexp > 0) {
					xbean.Properties prop = xtable.Properties.get(roleid);
					prop.setOfflineexp(Math.max(0, prop.getOfflineexp() - costofflineexp));
				}
				Bag bag = new Bag(roleid, false);
				if (fubenresult == 1){
					if (money > 0) {
						bag.addSysMoney(money, MONEY_TYPE.AWARD, "副本掉落金钱");
					}
					for (global.rsp.item.ItemData itemData : itemlist) {
						
						int itemId = itemData.itemid;
						
						BasicItem bi = Module.getInstance().getItemManager().genBasicItem(itemId, itemData.num);
						
						bi.getDataItem().setEmailmsg(itemData.emailmsg);
						bi.getDataItem().getEmailparam().addAll(itemData.emailparam);
						
						if (EquipFactory.getFactinroy().isEquip(itemData.itemid)) {
							OctetsStream extOs = new OctetsStream(itemData.extdata);
							xbean.Equip equip = xbean.Pod.newEquip();
							equip.unmarshal(extOs);
							
							((EquipItem) bi).setExtinfo(equip);
						}
						bag.moveIn(bi, -1, true);
					}
				}
				
				if (costmoney > 0) {
					bag.subMoney(-costmoney, MONEY_TYPE.FUBEN, "fuben fanpai");
				}
				
				if (costyb > 0) {
					new PAddYuanBao(roleid, -costyb, LogUtil.FB_FAN_PAI, 0, false, "fuben fanpai").call();
				}
				if(costitemlist.size() > 0){
					for(Entry<Integer, Integer> entry : costitemlist.entrySet()){
						bag.removeItemById(entry.getKey(), entry.getValue(), COST_ITEM_TYPE.FUWEN_CONSUME, "跨服副本");
					}
				}
				if(autobattleinfo != null){
					AutoBattleItemUseRole autoBattleItemUseRole = xtable.Autobattleitemuseroles.get(roleid);
					if(autoBattleItemUseRole == null){
						autoBattleItemUseRole = xbean.Pod.newAutoBattleItemUseRole();
						xtable.Autobattleitemuseroles.insert(roleid, autoBattleItemUseRole);
					}
					autoBattleItemUseRole.setDefaultautobattle(autobattleinfo.defaultautobattle == 1);
					autoBattleItemUseRole.setIsautofanpai(autobattleinfo.isautofanpai == 1);
					autoBattleItemUseRole.setIsautorecover(autobattleinfo.isautorecover == 1);
					autoBattleItemUseRole.setLastusetime(autobattleinfo.lastusetime);
					autoBattleItemUseRole.setTimeouttime(autobattleinfo.timeouttime);
					autoBattleItemUseRole.setUsednum(autobattleinfo.usednum);
				}
				xbean.GainLimitRole gainLimitRole = xtable.Gainlimitroles.get(roleid);
				if (null == gainLimitRole) {
					gainLimitRole = xbean.Pod.newGainLimitRole();
					xtable.Gainlimitroles.insert(roleid, gainLimitRole);
				}
				if (!DateValidate.inTheSameDay(gainLimitRole.getLastresettime(), lastresettime)) {
					gainLimitRole.setLastresettime(lastresettime);
					gainLimitRole.setTodayaddexp(0L);
					gainLimitRole.getTodayaddyb().clear();
					gainLimitRole.getTodayawardids().clear();
				} 
				gainLimitRole.getTodayawardids().putAll(todayawardids);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925805;

	public int getType() {
		return 925805;
	}

	public int fubenresult; // 副本结果0-表示失败，1-胜利
	public int crosssvrid; // 跨服服务器id
	public long roleid;
	public long money;
	public long exp;
	public java.util.ArrayList<global.rsp.item.ItemData> itemlist;
	public long costmoney; // 在跨服消耗的钱
	public int costyb; // 在跨服消耗的钻
	public java.util.HashMap<Integer,Integer> costitemlist; // 跨服消耗的道具(包括自动战斗道具和自动战斗券)
	public global.rsp.fuben.AutobattleInfo autobattleinfo; // 自动战斗信息
	public int costofflineexp; // 折算的离线经验部分
	public long lastresettime; // 上一次重新设置的时间
	public java.util.HashMap<Integer,Integer> todayawardids; // 今日获得已经调用的奖励id次数

	public SendItemListToOriginalServer() {
		itemlist = new java.util.ArrayList<global.rsp.item.ItemData>();
		costitemlist = new java.util.HashMap<Integer,Integer>();
		autobattleinfo = new global.rsp.fuben.AutobattleInfo();
		todayawardids = new java.util.HashMap<Integer,Integer>();
	}

	public SendItemListToOriginalServer(int _fubenresult_, int _crosssvrid_, long _roleid_, long _money_, long _exp_, java.util.ArrayList<global.rsp.item.ItemData> _itemlist_, long _costmoney_, int _costyb_, java.util.HashMap<Integer,Integer> _costitemlist_, global.rsp.fuben.AutobattleInfo _autobattleinfo_, int _costofflineexp_, long _lastresettime_, java.util.HashMap<Integer,Integer> _todayawardids_) {
		this.fubenresult = _fubenresult_;
		this.crosssvrid = _crosssvrid_;
		this.roleid = _roleid_;
		this.money = _money_;
		this.exp = _exp_;
		this.itemlist = _itemlist_;
		this.costmoney = _costmoney_;
		this.costyb = _costyb_;
		this.costitemlist = _costitemlist_;
		this.autobattleinfo = _autobattleinfo_;
		this.costofflineexp = _costofflineexp_;
		this.lastresettime = _lastresettime_;
		this.todayawardids = _todayawardids_;
	}

	public final boolean _validator_() {
		for (global.rsp.item.ItemData _v_ : itemlist)
			if (!_v_._validator_()) return false;
		if (!autobattleinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fubenresult);
		_os_.marshal(crosssvrid);
		_os_.marshal(roleid);
		_os_.marshal(money);
		_os_.marshal(exp);
		_os_.compact_uint32(itemlist.size());
		for (global.rsp.item.ItemData _v_ : itemlist) {
			_os_.marshal(_v_);
		}
		_os_.marshal(costmoney);
		_os_.marshal(costyb);
		_os_.compact_uint32(costitemlist.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : costitemlist.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(autobattleinfo);
		_os_.marshal(costofflineexp);
		_os_.marshal(lastresettime);
		_os_.compact_uint32(todayawardids.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : todayawardids.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fubenresult = _os_.unmarshal_int();
		crosssvrid = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		money = _os_.unmarshal_long();
		exp = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.item.ItemData _v_ = new global.rsp.item.ItemData();
			_v_.unmarshal(_os_);
			itemlist.add(_v_);
		}
		costmoney = _os_.unmarshal_long();
		costyb = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			costitemlist.put(_k_, _v_);
		}
		autobattleinfo.unmarshal(_os_);
		costofflineexp = _os_.unmarshal_int();
		lastresettime = _os_.unmarshal_long();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			todayawardids.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendItemListToOriginalServer) {
			SendItemListToOriginalServer _o_ = (SendItemListToOriginalServer)_o1_;
			if (fubenresult != _o_.fubenresult) return false;
			if (crosssvrid != _o_.crosssvrid) return false;
			if (roleid != _o_.roleid) return false;
			if (money != _o_.money) return false;
			if (exp != _o_.exp) return false;
			if (!itemlist.equals(_o_.itemlist)) return false;
			if (costmoney != _o_.costmoney) return false;
			if (costyb != _o_.costyb) return false;
			if (!costitemlist.equals(_o_.costitemlist)) return false;
			if (!autobattleinfo.equals(_o_.autobattleinfo)) return false;
			if (costofflineexp != _o_.costofflineexp) return false;
			if (lastresettime != _o_.lastresettime) return false;
			if (!todayawardids.equals(_o_.todayawardids)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += fubenresult;
		_h_ += crosssvrid;
		_h_ += (int)roleid;
		_h_ += (int)money;
		_h_ += (int)exp;
		_h_ += itemlist.hashCode();
		_h_ += (int)costmoney;
		_h_ += costyb;
		_h_ += costitemlist.hashCode();
		_h_ += autobattleinfo.hashCode();
		_h_ += costofflineexp;
		_h_ += (int)lastresettime;
		_h_ += todayawardids.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fubenresult).append(",");
		_sb_.append(crosssvrid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(money).append(",");
		_sb_.append(exp).append(",");
		_sb_.append(itemlist).append(",");
		_sb_.append(costmoney).append(",");
		_sb_.append(costyb).append(",");
		_sb_.append(costitemlist).append(",");
		_sb_.append(autobattleinfo).append(",");
		_sb_.append(costofflineexp).append(",");
		_sb_.append(lastresettime).append(",");
		_sb_.append(todayawardids).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

