
package global.rsp.item;
import global.rsp.GlobalClientManager;

import java.util.Arrays;

import knight.gsp.item.Bag;
import knight.gsp.item.EmailBox;
import knight.gsp.item.ItemAttr;
import knight.gsp.item.MailManager;
import knight.gsp.item.Module;

import knight.gsp.log.LogUtil.COST_ITEM_TYPE;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ResponseUseJDCard__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ResponseUseJDCard extends __ResponseUseJDCard__ {
	@Override
	protected void process() {
		new xdb.Procedure() {
			protected boolean process() throws Exception {
				EmailBox emailBox = new EmailBox(roleid, false);
				String[] arr = jdcardinfo.split("_");
				String cardNo = arr[0];
				String pwd = arr[1];
				ItemAttr itemAttr =  Module.getInstance().getItemManager().getAttr(itemid);
				if (null == itemAttr)
					return false;
				SendEmailCallBack snd = new SendEmailCallBack();
				snd.itemid = itemid;
				snd.jdcardinfo = jdcardinfo;
				if (1 != new Bag(roleid, false).removeItemById(itemid, 1, COST_ITEM_TYPE.JD_COST, "获取京东卡")) {
					snd.sendstate = 0;
					GlobalClientManager.getInstance().send(snd);
					return false;
				}
				boolean result = emailBox.sendMail(emailid, null, Arrays.asList(itemAttr.name,cardNo, pwd), null);
				
				if (result) {
					MailManager.LOG.info("【京东卡邮件】发送成功，roleId："+roleid+"，卡号："+cardNo);
					snd.sendstate = 1;
				} else {
					MailManager.LOG.info("【京东卡邮件】发送失败，roleId："+roleid);
					snd.sendstate = 0;
				}
				GlobalClientManager.getInstance().send(snd);
				return result;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925809;

	public int getType() {
		return 925809;
	}

	public long roleid; // 角色id
	public int itemid; // 京东卡道具id
	public java.lang.String jdcardinfo; // 京东卡信息
	public int activeid; // 活动id
	public int emailid; // 邮件id

	public ResponseUseJDCard() {
		jdcardinfo = "";
	}

	public ResponseUseJDCard(long _roleid_, int _itemid_, java.lang.String _jdcardinfo_, int _activeid_, int _emailid_) {
		this.roleid = _roleid_;
		this.itemid = _itemid_;
		this.jdcardinfo = _jdcardinfo_;
		this.activeid = _activeid_;
		this.emailid = _emailid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(itemid);
		_os_.marshal(jdcardinfo, "UTF-16LE");
		_os_.marshal(activeid);
		_os_.marshal(emailid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		itemid = _os_.unmarshal_int();
		jdcardinfo = _os_.unmarshal_String("UTF-16LE");
		activeid = _os_.unmarshal_int();
		emailid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ResponseUseJDCard) {
			ResponseUseJDCard _o_ = (ResponseUseJDCard)_o1_;
			if (roleid != _o_.roleid) return false;
			if (itemid != _o_.itemid) return false;
			if (!jdcardinfo.equals(_o_.jdcardinfo)) return false;
			if (activeid != _o_.activeid) return false;
			if (emailid != _o_.emailid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += itemid;
		_h_ += jdcardinfo.hashCode();
		_h_ += activeid;
		_h_ += emailid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(itemid).append(",");
		_sb_.append("T").append(jdcardinfo.length()).append(",");
		_sb_.append(activeid).append(",");
		_sb_.append(emailid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

