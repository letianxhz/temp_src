
package global.rsp.item;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RequestUseJDCard__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RequestUseJDCard extends __RequestUseJDCard__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925808;

	public int getType() {
		return 925808;
	}

	public final static int ACTIVTYID_LEDO_CHARGE_30_BACK = 1; // 乐道服务器充30返还30
	public final static int ACTIVTYID_LEDO_CHARGE_100_BACK = 2; // 乐道服务器充100返还30
	public final static int ACTIVTYID_LEDO_ROAST_AWARD = 3; // 乐道服务器家族烤火

	public long roleid; // 角色id
	public int itemid; // 京东卡道具id
	public int serverid; // 服务器id
	public int activeid; // 活动id
	public int emailid; // 邮件id

	public RequestUseJDCard() {
	}

	public RequestUseJDCard(long _roleid_, int _itemid_, int _serverid_, int _activeid_, int _emailid_) {
		this.roleid = _roleid_;
		this.itemid = _itemid_;
		this.serverid = _serverid_;
		this.activeid = _activeid_;
		this.emailid = _emailid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(itemid);
		_os_.marshal(serverid);
		_os_.marshal(activeid);
		_os_.marshal(emailid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		itemid = _os_.unmarshal_int();
		serverid = _os_.unmarshal_int();
		activeid = _os_.unmarshal_int();
		emailid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RequestUseJDCard) {
			RequestUseJDCard _o_ = (RequestUseJDCard)_o1_;
			if (roleid != _o_.roleid) return false;
			if (itemid != _o_.itemid) return false;
			if (serverid != _o_.serverid) return false;
			if (activeid != _o_.activeid) return false;
			if (emailid != _o_.emailid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += itemid;
		_h_ += serverid;
		_h_ += activeid;
		_h_ += emailid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(itemid).append(",");
		_sb_.append(serverid).append(",");
		_sb_.append(activeid).append(",");
		_sb_.append(emailid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(RequestUseJDCard _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = itemid - _o_.itemid;
		if (0 != _c_) return _c_;
		_c_ = serverid - _o_.serverid;
		if (0 != _c_) return _c_;
		_c_ = activeid - _o_.activeid;
		if (0 != _c_) return _c_;
		_c_ = emailid - _o_.emailid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

