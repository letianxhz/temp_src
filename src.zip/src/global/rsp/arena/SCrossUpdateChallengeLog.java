
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SCrossUpdateChallengeLog__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SCrossUpdateChallengeLog extends __SCrossUpdateChallengeLog__ {
	@Override
	protected void process() {
		knight.gsp.arena.ArenaManager.getInstance().handleCrossChallengeLog(roleid, win == 1, logtype, opponentid, msgid, param);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924610;

	public int getType() {
		return 924610;
	}

	public byte win; // 是否胜利
	public long roleid; // 角色ID
	public byte logtype; // 日志类型
	public long opponentid; // 挑战者ID
	public int msgid; // 日志消息ID
	public java.util.ArrayList<com.goldhuman.Common.Octets> param; // 参数

	public SCrossUpdateChallengeLog() {
		param = new java.util.ArrayList<com.goldhuman.Common.Octets>();
	}

	public SCrossUpdateChallengeLog(byte _win_, long _roleid_, byte _logtype_, long _opponentid_, int _msgid_, java.util.ArrayList<com.goldhuman.Common.Octets> _param_) {
		this.win = _win_;
		this.roleid = _roleid_;
		this.logtype = _logtype_;
		this.opponentid = _opponentid_;
		this.msgid = _msgid_;
		this.param = _param_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(win);
		_os_.marshal(roleid);
		_os_.marshal(logtype);
		_os_.marshal(opponentid);
		_os_.marshal(msgid);
		_os_.compact_uint32(param.size());
		for (com.goldhuman.Common.Octets _v_ : param) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		win = _os_.unmarshal_byte();
		roleid = _os_.unmarshal_long();
		logtype = _os_.unmarshal_byte();
		opponentid = _os_.unmarshal_long();
		msgid = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			param.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SCrossUpdateChallengeLog) {
			SCrossUpdateChallengeLog _o_ = (SCrossUpdateChallengeLog)_o1_;
			if (win != _o_.win) return false;
			if (roleid != _o_.roleid) return false;
			if (logtype != _o_.logtype) return false;
			if (opponentid != _o_.opponentid) return false;
			if (msgid != _o_.msgid) return false;
			if (!param.equals(_o_.param)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)win;
		_h_ += (int)roleid;
		_h_ += (int)logtype;
		_h_ += (int)opponentid;
		_h_ += msgid;
		_h_ += param.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(win).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(logtype).append(",");
		_sb_.append(opponentid).append(",");
		_sb_.append(msgid).append(",");
		_sb_.append(param).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

