
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CCrossArenaMemberFight__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CCrossArenaMemberFight extends __CCrossArenaMemberFight__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924607;

	public int getType() {
		return 924607;
	}

	public final static int TYPE_RANDOM = 1; // 随机战
	public final static int TYPE_RANK = 2; // 排名战
	public final static int TYPE_AGAINST = 3; // 反击战

	public int group; // 所属组
	public int fromzoneid; // 服务器ID
	public int rank; // 排名
	public long challengerid; // 挑战者ID
	public int fighttype; // 挑战类型
	public long opponentid; // 对手ID

	public CCrossArenaMemberFight() {
	}

	public CCrossArenaMemberFight(int _group_, int _fromzoneid_, int _rank_, long _challengerid_, int _fighttype_, long _opponentid_) {
		this.group = _group_;
		this.fromzoneid = _fromzoneid_;
		this.rank = _rank_;
		this.challengerid = _challengerid_;
		this.fighttype = _fighttype_;
		this.opponentid = _opponentid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(group);
		_os_.marshal(fromzoneid);
		_os_.marshal(rank);
		_os_.marshal(challengerid);
		_os_.marshal(fighttype);
		_os_.marshal(opponentid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		group = _os_.unmarshal_int();
		fromzoneid = _os_.unmarshal_int();
		rank = _os_.unmarshal_int();
		challengerid = _os_.unmarshal_long();
		fighttype = _os_.unmarshal_int();
		opponentid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CCrossArenaMemberFight) {
			CCrossArenaMemberFight _o_ = (CCrossArenaMemberFight)_o1_;
			if (group != _o_.group) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (rank != _o_.rank) return false;
			if (challengerid != _o_.challengerid) return false;
			if (fighttype != _o_.fighttype) return false;
			if (opponentid != _o_.opponentid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += group;
		_h_ += fromzoneid;
		_h_ += rank;
		_h_ += (int)challengerid;
		_h_ += fighttype;
		_h_ += (int)opponentid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(group).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(rank).append(",");
		_sb_.append(challengerid).append(",");
		_sb_.append(fighttype).append(",");
		_sb_.append(opponentid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CCrossArenaMemberFight _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = group - _o_.group;
		if (0 != _c_) return _c_;
		_c_ = fromzoneid - _o_.fromzoneid;
		if (0 != _c_) return _c_;
		_c_ = rank - _o_.rank;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(challengerid - _o_.challengerid);
		if (0 != _c_) return _c_;
		_c_ = fighttype - _o_.fighttype;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(opponentid - _o_.opponentid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

