
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SUpdateCrossArenaRank__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SUpdateCrossArenaRank extends __SUpdateCrossArenaRank__ {
	@Override
	protected void process() {
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				knight.gsp.arena.ArenaManager.getInstance().updateCrossArenaRank(roleid, oldrank, newrank);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924620;

	public int getType() {
		return 924620;
	}

	public long roleid;
	public int oldrank;
	public int newrank;

	public SUpdateCrossArenaRank() {
	}

	public SUpdateCrossArenaRank(long _roleid_, int _oldrank_, int _newrank_) {
		this.roleid = _roleid_;
		this.oldrank = _oldrank_;
		this.newrank = _newrank_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(oldrank);
		_os_.marshal(newrank);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		oldrank = _os_.unmarshal_int();
		newrank = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SUpdateCrossArenaRank) {
			SUpdateCrossArenaRank _o_ = (SUpdateCrossArenaRank)_o1_;
			if (roleid != _o_.roleid) return false;
			if (oldrank != _o_.oldrank) return false;
			if (newrank != _o_.newrank) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += oldrank;
		_h_ += newrank;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(oldrank).append(",");
		_sb_.append(newrank).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SUpdateCrossArenaRank _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = oldrank - _o_.oldrank;
		if (0 != _c_) return _c_;
		_c_ = newrank - _o_.newrank;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

