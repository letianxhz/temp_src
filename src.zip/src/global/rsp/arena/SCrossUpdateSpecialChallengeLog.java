
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SCrossUpdateSpecialChallengeLog__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SCrossUpdateSpecialChallengeLog extends __SCrossUpdateSpecialChallengeLog__ {
	@Override
	protected void process() {
		knight.gsp.arena.ArenaManager.getInstance().handleCrossSpecialChallengeLog(logtype, opponentid, msgid, param);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924616;

	public int getType() {
		return 924616;
	}

	public byte logtype; // 日志类型
	public long opponentid; // 挑战者ID
	public int msgid; // 日志消息ID
	public java.util.ArrayList<com.goldhuman.Common.Octets> param; // 参数

	public SCrossUpdateSpecialChallengeLog() {
		param = new java.util.ArrayList<com.goldhuman.Common.Octets>();
	}

	public SCrossUpdateSpecialChallengeLog(byte _logtype_, long _opponentid_, int _msgid_, java.util.ArrayList<com.goldhuman.Common.Octets> _param_) {
		this.logtype = _logtype_;
		this.opponentid = _opponentid_;
		this.msgid = _msgid_;
		this.param = _param_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(logtype);
		_os_.marshal(opponentid);
		_os_.marshal(msgid);
		_os_.compact_uint32(param.size());
		for (com.goldhuman.Common.Octets _v_ : param) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		logtype = _os_.unmarshal_byte();
		opponentid = _os_.unmarshal_long();
		msgid = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			param.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SCrossUpdateSpecialChallengeLog) {
			SCrossUpdateSpecialChallengeLog _o_ = (SCrossUpdateSpecialChallengeLog)_o1_;
			if (logtype != _o_.logtype) return false;
			if (opponentid != _o_.opponentid) return false;
			if (msgid != _o_.msgid) return false;
			if (!param.equals(_o_.param)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)logtype;
		_h_ += (int)opponentid;
		_h_ += msgid;
		_h_ += param.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(logtype).append(",");
		_sb_.append(opponentid).append(",");
		_sb_.append(msgid).append(",");
		_sb_.append(param).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

