
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SCrossArenaFightResult__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SCrossArenaFightResult extends __SCrossArenaFightResult__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924612;

	public int getType() {
		return 924612;
	}

	public short win; // 是否胜利
	public long challengerid; // 挑战者ID
	public int rank; // 名次

	public SCrossArenaFightResult() {
	}

	public SCrossArenaFightResult(short _win_, long _challengerid_, int _rank_) {
		this.win = _win_;
		this.challengerid = _challengerid_;
		this.rank = _rank_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(win);
		_os_.marshal(challengerid);
		_os_.marshal(rank);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		win = _os_.unmarshal_short();
		challengerid = _os_.unmarshal_long();
		rank = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SCrossArenaFightResult) {
			SCrossArenaFightResult _o_ = (SCrossArenaFightResult)_o1_;
			if (win != _o_.win) return false;
			if (challengerid != _o_.challengerid) return false;
			if (rank != _o_.rank) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += win;
		_h_ += (int)challengerid;
		_h_ += rank;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(win).append(",");
		_sb_.append(challengerid).append(",");
		_sb_.append(rank).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SCrossArenaFightResult _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = win - _o_.win;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(challengerid - _o_.challengerid);
		if (0 != _c_) return _c_;
		_c_ = rank - _o_.rank;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

