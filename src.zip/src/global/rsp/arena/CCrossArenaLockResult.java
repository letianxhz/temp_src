
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CCrossArenaLockResult__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CCrossArenaLockResult extends __CCrossArenaLockResult__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924614;

	public int getType() {
		return 924614;
	}

	public int group; // 所属组
	public long roleid; // 锁定角色
	public byte lock; // 是否锁定
	public int crosscontinuewin; // 连胜

	public CCrossArenaLockResult() {
	}

	public CCrossArenaLockResult(int _group_, long _roleid_, byte _lock_, int _crosscontinuewin_) {
		this.group = _group_;
		this.roleid = _roleid_;
		this.lock = _lock_;
		this.crosscontinuewin = _crosscontinuewin_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(group);
		_os_.marshal(roleid);
		_os_.marshal(lock);
		_os_.marshal(crosscontinuewin);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		group = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		lock = _os_.unmarshal_byte();
		crosscontinuewin = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CCrossArenaLockResult) {
			CCrossArenaLockResult _o_ = (CCrossArenaLockResult)_o1_;
			if (group != _o_.group) return false;
			if (roleid != _o_.roleid) return false;
			if (lock != _o_.lock) return false;
			if (crosscontinuewin != _o_.crosscontinuewin) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += group;
		_h_ += (int)roleid;
		_h_ += (int)lock;
		_h_ += crosscontinuewin;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(group).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(lock).append(",");
		_sb_.append(crosscontinuewin).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CCrossArenaLockResult _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = group - _o_.group;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = lock - _o_.lock;
		if (0 != _c_) return _c_;
		_c_ = crosscontinuewin - _o_.crosscontinuewin;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

