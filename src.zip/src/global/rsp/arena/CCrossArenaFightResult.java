
package global.rsp.arena;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CCrossArenaFightResult__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CCrossArenaFightResult extends __CCrossArenaFightResult__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924611;

	public int getType() {
		return 924611;
	}

	public int group; // 所属组
	public int fromzoneid; // 服务器ID
	public short win; // 是否胜利
	public long challengerid; // 挑战者ID

	public CCrossArenaFightResult() {
	}

	public CCrossArenaFightResult(int _group_, int _fromzoneid_, short _win_, long _challengerid_) {
		this.group = _group_;
		this.fromzoneid = _fromzoneid_;
		this.win = _win_;
		this.challengerid = _challengerid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(group);
		_os_.marshal(fromzoneid);
		_os_.marshal(win);
		_os_.marshal(challengerid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		group = _os_.unmarshal_int();
		fromzoneid = _os_.unmarshal_int();
		win = _os_.unmarshal_short();
		challengerid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CCrossArenaFightResult) {
			CCrossArenaFightResult _o_ = (CCrossArenaFightResult)_o1_;
			if (group != _o_.group) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (win != _o_.win) return false;
			if (challengerid != _o_.challengerid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += group;
		_h_ += fromzoneid;
		_h_ += win;
		_h_ += (int)challengerid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(group).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(win).append(",");
		_sb_.append(challengerid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CCrossArenaFightResult _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = group - _o_.group;
		if (0 != _c_) return _c_;
		_c_ = fromzoneid - _o_.fromzoneid;
		if (0 != _c_) return _c_;
		_c_ = win - _o_.win;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(challengerid - _o_.challengerid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

