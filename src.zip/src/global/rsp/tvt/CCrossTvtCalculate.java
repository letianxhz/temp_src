
package global.rsp.tvt;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CCrossTvtCalculate__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CCrossTvtCalculate extends __CCrossTvtCalculate__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924816;

	public int getType() {
		return 924816;
	}

	public long roleid; // 角色id
	public int score; // 获得的积分
	public java.lang.String enemynames; // 对手名字

	public CCrossTvtCalculate() {
		enemynames = "";
	}

	public CCrossTvtCalculate(long _roleid_, int _score_, java.lang.String _enemynames_) {
		this.roleid = _roleid_;
		this.score = _score_;
		this.enemynames = _enemynames_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(score);
		_os_.marshal(enemynames, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		score = _os_.unmarshal_int();
		enemynames = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CCrossTvtCalculate) {
			CCrossTvtCalculate _o_ = (CCrossTvtCalculate)_o1_;
			if (roleid != _o_.roleid) return false;
			if (score != _o_.score) return false;
			if (!enemynames.equals(_o_.enemynames)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += score;
		_h_ += enemynames.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(score).append(",");
		_sb_.append("T").append(enemynames.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

