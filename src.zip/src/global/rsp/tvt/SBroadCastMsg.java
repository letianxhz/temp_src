
package global.rsp.tvt;

import java.util.Arrays;

import knight.gsp.msg.Message;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SBroadCastMsg__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SBroadCastMsg extends __SBroadCastMsg__ {
	@Override
	protected void process() {
		// protocol handle
		Message.sendSystemMsg(1024912, Arrays.asList(String.valueOf(fromzoneid),winname,enemynames,String.valueOf(wintimes)));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924823;

	public int getType() {
		return 924823;
	}

	public java.lang.String winname; // 连胜玩家名字
	public int fromzoneid; // 从哪个服务器来的
	public java.lang.String enemynames; // 敌方玩家名字
	public int wintimes; // 连胜次数

	public SBroadCastMsg() {
		winname = "";
		enemynames = "";
	}

	public SBroadCastMsg(java.lang.String _winname_, int _fromzoneid_, java.lang.String _enemynames_, int _wintimes_) {
		this.winname = _winname_;
		this.fromzoneid = _fromzoneid_;
		this.enemynames = _enemynames_;
		this.wintimes = _wintimes_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(winname, "UTF-16LE");
		_os_.marshal(fromzoneid);
		_os_.marshal(enemynames, "UTF-16LE");
		_os_.marshal(wintimes);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		winname = _os_.unmarshal_String("UTF-16LE");
		fromzoneid = _os_.unmarshal_int();
		enemynames = _os_.unmarshal_String("UTF-16LE");
		wintimes = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SBroadCastMsg) {
			SBroadCastMsg _o_ = (SBroadCastMsg)_o1_;
			if (!winname.equals(_o_.winname)) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (!enemynames.equals(_o_.enemynames)) return false;
			if (wintimes != _o_.wintimes) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += winname.hashCode();
		_h_ += fromzoneid;
		_h_ += enemynames.hashCode();
		_h_ += wintimes;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(winname.length()).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append("T").append(enemynames.length()).append(",");
		_sb_.append(wintimes).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

