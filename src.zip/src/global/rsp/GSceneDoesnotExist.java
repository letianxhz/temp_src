
package global.rsp;
import knight.gsp.family.familygather.PFamilyGatherSceneNotExist;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GSceneDoesnotExist__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GSceneDoesnotExist extends __GSceneDoesnotExist__ {
	@Override
	protected void process() {
		if(functype == FAMILY_GATHER){
			new PFamilyGatherSceneNotExist(sceneid,roleid, zoneid, rolezoneid).submit();
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924526;

	public int getType() {
		return 924526;
	}

	public final static int FAMILY_GATHER = 1; // 家族采集

	public int functype; // 功能类型
	public long sceneid; // 场景id
	public long roleid; // 玩家id
	public int zoneid; // 场景服务器id
	public int rolezoneid; // 玩家服务器id

	public GSceneDoesnotExist() {
	}

	public GSceneDoesnotExist(int _functype_, long _sceneid_, long _roleid_, int _zoneid_, int _rolezoneid_) {
		this.functype = _functype_;
		this.sceneid = _sceneid_;
		this.roleid = _roleid_;
		this.zoneid = _zoneid_;
		this.rolezoneid = _rolezoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(functype);
		_os_.marshal(sceneid);
		_os_.marshal(roleid);
		_os_.marshal(zoneid);
		_os_.marshal(rolezoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		functype = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		roleid = _os_.unmarshal_long();
		zoneid = _os_.unmarshal_int();
		rolezoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GSceneDoesnotExist) {
			GSceneDoesnotExist _o_ = (GSceneDoesnotExist)_o1_;
			if (functype != _o_.functype) return false;
			if (sceneid != _o_.sceneid) return false;
			if (roleid != _o_.roleid) return false;
			if (zoneid != _o_.zoneid) return false;
			if (rolezoneid != _o_.rolezoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += functype;
		_h_ += (int)sceneid;
		_h_ += (int)roleid;
		_h_ += zoneid;
		_h_ += rolezoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(functype).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(rolezoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GSceneDoesnotExist _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = functype - _o_.functype;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		_c_ = rolezoneid - _o_.rolezoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

