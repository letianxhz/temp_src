
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyGlobalRoleChange__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyGlobalRoleChange extends __NotifyGlobalRoleChange__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924523;

	public int getType() {
		return 924523;
	}

	public long roleid;
	public int serverid;
	public int userid;
	public global.rsp.ServerRoleInfo newinfo; // 改变的角色属性信息
	public java.lang.String accountname;

	public NotifyGlobalRoleChange() {
		newinfo = new global.rsp.ServerRoleInfo();
		accountname = "";
	}

	public NotifyGlobalRoleChange(long _roleid_, int _serverid_, int _userid_, global.rsp.ServerRoleInfo _newinfo_, java.lang.String _accountname_) {
		this.roleid = _roleid_;
		this.serverid = _serverid_;
		this.userid = _userid_;
		this.newinfo = _newinfo_;
		this.accountname = _accountname_;
	}

	public final boolean _validator_() {
		if (!newinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(serverid);
		_os_.marshal(userid);
		_os_.marshal(newinfo);
		_os_.marshal(accountname, "UTF-16LE");
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		serverid = _os_.unmarshal_int();
		userid = _os_.unmarshal_int();
		newinfo.unmarshal(_os_);
		accountname = _os_.unmarshal_String("UTF-16LE");
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyGlobalRoleChange) {
			NotifyGlobalRoleChange _o_ = (NotifyGlobalRoleChange)_o1_;
			if (roleid != _o_.roleid) return false;
			if (serverid != _o_.serverid) return false;
			if (userid != _o_.userid) return false;
			if (!newinfo.equals(_o_.newinfo)) return false;
			if (!accountname.equals(_o_.accountname)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += serverid;
		_h_ += userid;
		_h_ += newinfo.hashCode();
		_h_ += accountname.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(serverid).append(",");
		_sb_.append(userid).append(",");
		_sb_.append(newinfo).append(",");
		_sb_.append("T").append(accountname.length()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

