
package global.rsp;

import gnet.link.User;
import java.util.Map;
import knight.gsp.LocalIds;
import knight.gsp.SServerRoleInfos;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReplyServerInfoRoles__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReplyServerInfoRoles extends __ReplyServerInfoRoles__ {
	@Override
	protected void process() {
		SServerRoleInfos snd = new SServerRoleInfos();
		snd.opendlg = opendlg;
		for (Map.Entry<Integer, global.rsp.ServerRoles> serverEntry : roles.entrySet()) {
			if (opendlg == 1 && !LocalIds.isRemoteServerRole(serverEntry.getKey()))
				continue; //在跨服界面通过界面查询别服的角色
			
			knight.gsp.ServerRoles serverInfo = new knight.gsp.ServerRoles();
			for (ServerRoleInfo _roleInfo : serverEntry.getValue().roles) {
				knight.gsp.ServerRoleInfo info = new knight.gsp.ServerRoleInfo();
				info.level = _roleInfo.level;
				info.roleid = String.valueOf(_roleInfo.roleid);
				info.rolename = _roleInfo.rolename;
				info.school = _roleInfo.school;
				serverInfo.roles.add(info);
			}
			snd.servers.put(serverEntry.getKey(), serverInfo);
		}
		
		User user = gnet.link.Onlines.getInstance().getOnlineUsers().get((Integer) (int)roleid);
		if (user == null)
			return;
		
		user.send(snd);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924525;

	public int getType() {
		return 924525;
	}

	public long roleid; // 角色id
	public java.util.HashMap<Integer,global.rsp.ServerRoles> roles; // key为服务器id
	public byte opendlg; // 是否打开界面,1打开，0不打开

	public ReplyServerInfoRoles() {
		roles = new java.util.HashMap<Integer,global.rsp.ServerRoles>();
	}

	public ReplyServerInfoRoles(long _roleid_, java.util.HashMap<Integer,global.rsp.ServerRoles> _roles_, byte _opendlg_) {
		this.roleid = _roleid_;
		this.roles = _roles_;
		this.opendlg = _opendlg_;
	}

	public final boolean _validator_() {
		for (java.util.Map.Entry<Integer, global.rsp.ServerRoles> _e_ : roles.entrySet()) {
			if (!_e_.getValue()._validator_()) return false;
		}
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.compact_uint32(roles.size());
		for (java.util.Map.Entry<Integer, global.rsp.ServerRoles> _e_ : roles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(opendlg);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			global.rsp.ServerRoles _v_ = new global.rsp.ServerRoles();
			_v_.unmarshal(_os_);
			roles.put(_k_, _v_);
		}
		opendlg = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReplyServerInfoRoles) {
			ReplyServerInfoRoles _o_ = (ReplyServerInfoRoles)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!roles.equals(_o_.roles)) return false;
			if (opendlg != _o_.opendlg) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += roles.hashCode();
		_h_ += (int)opendlg;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(roles).append(",");
		_sb_.append(opendlg).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

