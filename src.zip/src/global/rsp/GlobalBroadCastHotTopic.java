
package global.rsp;
import knight.gsp.myzone.ZoneManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlobalBroadCastHotTopic__ extends xio.Protocol { }

/** Global向所有服务器 广播热门话题
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlobalBroadCastHotTopic extends __GlobalBroadCastHotTopic__ {
	@Override
	protected void process() {
		// protocol handle
		new xdb.Procedure(){
			protected boolean process() throws Exception {
				try {
					ZoneManager.getInstance().receiveHotTopic(hottopic);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return true;
			};
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918220;

	public int getType() {
		return 918220;
	}

	public com.goldhuman.Common.Octets hottopic;

	public GlobalBroadCastHotTopic() {
		hottopic = new com.goldhuman.Common.Octets();
	}

	public GlobalBroadCastHotTopic(com.goldhuman.Common.Octets _hottopic_) {
		this.hottopic = _hottopic_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(hottopic);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		hottopic = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlobalBroadCastHotTopic) {
			GlobalBroadCastHotTopic _o_ = (GlobalBroadCastHotTopic)_o1_;
			if (!hottopic.equals(_o_.hottopic)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += hottopic.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("B").append(hottopic.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

