
package global.rsp.ranklist;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SubPvp4SeasonScoreResult__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SubPvp4SeasonScoreResult extends __SubPvp4SeasonScoreResult__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 926112;

	public int getType() {
		return 926112;
	}

	public java.lang.String result;
	public long gmroleid;

	public SubPvp4SeasonScoreResult() {
		result = "";
	}

	public SubPvp4SeasonScoreResult(java.lang.String _result_, long _gmroleid_) {
		this.result = _result_;
		this.gmroleid = _gmroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(result, "UTF-16LE");
		_os_.marshal(gmroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		result = _os_.unmarshal_String("UTF-16LE");
		gmroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SubPvp4SeasonScoreResult) {
			SubPvp4SeasonScoreResult _o_ = (SubPvp4SeasonScoreResult)_o1_;
			if (!result.equals(_o_.result)) return false;
			if (gmroleid != _o_.gmroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += result.hashCode();
		_h_ += (int)gmroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(result.length()).append(",");
		_sb_.append(gmroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

