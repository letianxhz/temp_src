
package global.rsp.ranklist;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RankListBeanImport__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RankListBeanImport extends __RankListBeanImport__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 926105;

	public int getType() {
		return 926105;
	}

	public global.rsp.ranklist.RankType b1;
	public global.rsp.ranklist.RolePropertyRankData b2;
	public global.rsp.ranklist.MercenariesRankData b3;
	public global.rsp.ranklist.DragonRankData b4;
	public global.rsp.ranklist.WingsRankData b5;
	public global.rsp.ranklist.RideRankData b6;
	public global.rsp.ranklist.FashionRankData b7;
	public global.rsp.ranklist.PVP4RankData b8;
	public global.rsp.ranklist.PVP8RankData b9;
	public global.rsp.ranklist.DaLuanDouRankData b10;
	public global.rsp.ranklist.ShenQiRankData b11;
	public global.rsp.ranklist.GuangYingRankData b12;
	public global.rsp.ranklist.FightSpiritRankData b13;

	public RankListBeanImport() {
		b1 = new global.rsp.ranklist.RankType();
		b2 = new global.rsp.ranklist.RolePropertyRankData();
		b3 = new global.rsp.ranklist.MercenariesRankData();
		b4 = new global.rsp.ranklist.DragonRankData();
		b5 = new global.rsp.ranklist.WingsRankData();
		b6 = new global.rsp.ranklist.RideRankData();
		b7 = new global.rsp.ranklist.FashionRankData();
		b8 = new global.rsp.ranklist.PVP4RankData();
		b9 = new global.rsp.ranklist.PVP8RankData();
		b10 = new global.rsp.ranklist.DaLuanDouRankData();
		b11 = new global.rsp.ranklist.ShenQiRankData();
		b12 = new global.rsp.ranklist.GuangYingRankData();
		b13 = new global.rsp.ranklist.FightSpiritRankData();
	}

	public RankListBeanImport(global.rsp.ranklist.RankType _b1_, global.rsp.ranklist.RolePropertyRankData _b2_, global.rsp.ranklist.MercenariesRankData _b3_, global.rsp.ranklist.DragonRankData _b4_, global.rsp.ranklist.WingsRankData _b5_, global.rsp.ranklist.RideRankData _b6_, global.rsp.ranklist.FashionRankData _b7_, global.rsp.ranklist.PVP4RankData _b8_, global.rsp.ranklist.PVP8RankData _b9_, global.rsp.ranklist.DaLuanDouRankData _b10_, global.rsp.ranklist.ShenQiRankData _b11_, global.rsp.ranklist.GuangYingRankData _b12_, global.rsp.ranklist.FightSpiritRankData _b13_) {
		this.b1 = _b1_;
		this.b2 = _b2_;
		this.b3 = _b3_;
		this.b4 = _b4_;
		this.b5 = _b5_;
		this.b6 = _b6_;
		this.b7 = _b7_;
		this.b8 = _b8_;
		this.b9 = _b9_;
		this.b10 = _b10_;
		this.b11 = _b11_;
		this.b12 = _b12_;
		this.b13 = _b13_;
	}

	public final boolean _validator_() {
		if (!b1._validator_()) return false;
		if (!b2._validator_()) return false;
		if (!b3._validator_()) return false;
		if (!b4._validator_()) return false;
		if (!b5._validator_()) return false;
		if (!b6._validator_()) return false;
		if (!b7._validator_()) return false;
		if (!b8._validator_()) return false;
		if (!b9._validator_()) return false;
		if (!b10._validator_()) return false;
		if (!b11._validator_()) return false;
		if (!b12._validator_()) return false;
		if (!b13._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(b1);
		_os_.marshal(b2);
		_os_.marshal(b3);
		_os_.marshal(b4);
		_os_.marshal(b5);
		_os_.marshal(b6);
		_os_.marshal(b7);
		_os_.marshal(b8);
		_os_.marshal(b9);
		_os_.marshal(b10);
		_os_.marshal(b11);
		_os_.marshal(b12);
		_os_.marshal(b13);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		b1.unmarshal(_os_);
		b2.unmarshal(_os_);
		b3.unmarshal(_os_);
		b4.unmarshal(_os_);
		b5.unmarshal(_os_);
		b6.unmarshal(_os_);
		b7.unmarshal(_os_);
		b8.unmarshal(_os_);
		b9.unmarshal(_os_);
		b10.unmarshal(_os_);
		b11.unmarshal(_os_);
		b12.unmarshal(_os_);
		b13.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RankListBeanImport) {
			RankListBeanImport _o_ = (RankListBeanImport)_o1_;
			if (!b1.equals(_o_.b1)) return false;
			if (!b2.equals(_o_.b2)) return false;
			if (!b3.equals(_o_.b3)) return false;
			if (!b4.equals(_o_.b4)) return false;
			if (!b5.equals(_o_.b5)) return false;
			if (!b6.equals(_o_.b6)) return false;
			if (!b7.equals(_o_.b7)) return false;
			if (!b8.equals(_o_.b8)) return false;
			if (!b9.equals(_o_.b9)) return false;
			if (!b10.equals(_o_.b10)) return false;
			if (!b11.equals(_o_.b11)) return false;
			if (!b12.equals(_o_.b12)) return false;
			if (!b13.equals(_o_.b13)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += b1.hashCode();
		_h_ += b2.hashCode();
		_h_ += b3.hashCode();
		_h_ += b4.hashCode();
		_h_ += b5.hashCode();
		_h_ += b6.hashCode();
		_h_ += b7.hashCode();
		_h_ += b8.hashCode();
		_h_ += b9.hashCode();
		_h_ += b10.hashCode();
		_h_ += b11.hashCode();
		_h_ += b12.hashCode();
		_h_ += b13.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(b1).append(",");
		_sb_.append(b2).append(",");
		_sb_.append(b3).append(",");
		_sb_.append(b4).append(",");
		_sb_.append(b5).append(",");
		_sb_.append(b6).append(",");
		_sb_.append(b7).append(",");
		_sb_.append(b8).append(",");
		_sb_.append(b9).append(",");
		_sb_.append(b10).append(",");
		_sb_.append(b11).append(",");
		_sb_.append(b12).append(",");
		_sb_.append(b13).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

