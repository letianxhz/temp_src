
package global.rsp.ranklist;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SubPvp4SeasonScore__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SubPvp4SeasonScore extends __SubPvp4SeasonScore__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 926111;

	public int getType() {
		return 926111;
	}

	public int subscore;
	public long roleid;
	public long gmroleid;

	public SubPvp4SeasonScore() {
	}

	public SubPvp4SeasonScore(int _subscore_, long _roleid_, long _gmroleid_) {
		this.subscore = _subscore_;
		this.roleid = _roleid_;
		this.gmroleid = _gmroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(subscore);
		_os_.marshal(roleid);
		_os_.marshal(gmroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		subscore = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		gmroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SubPvp4SeasonScore) {
			SubPvp4SeasonScore _o_ = (SubPvp4SeasonScore)_o1_;
			if (subscore != _o_.subscore) return false;
			if (roleid != _o_.roleid) return false;
			if (gmroleid != _o_.gmroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += subscore;
		_h_ += (int)roleid;
		_h_ += (int)gmroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(subscore).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(gmroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SubPvp4SeasonScore _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = subscore - _o_.subscore;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(gmroleid - _o_.gmroleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

