
package global.rsp.ranklist;

import global.rsp.GlobalClientManager;

import java.util.List;

import knight.gsp.ranklist.SRequestRankList;
import knight.gsp.ranklist.provider.IProvider;
import knight.gsp.ranklist.provider.RankProviderFactory;
import com.goldhuman.Common.Octets;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqSinglgeServerRankData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqSinglgeServerRankData extends __ReqSinglgeServerRankData__ {
	@Override
	protected void process() {
		IProvider provider = RankProviderFactory.getInstance().createRankProvider(ranktype, -1L);
		if(null == provider)
			return;
		
		SRequestRankList response = new SRequestRankList();
		List<Octets> octets = provider.getMarshalOctets(response);
		if(null == octets)
			return;
		
		
		ReplySinglgeServerRankData snd = new ReplySinglgeServerRankData();
		snd.list.addAll(octets);
		snd.ranktype = ranktype;
		GlobalClientManager.getInstance().send(snd);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 926106;

	public int getType() {
		return 926106;
	}

	public int ranktype;

	public ReqSinglgeServerRankData() {
	}

	public ReqSinglgeServerRankData(int _ranktype_) {
		this.ranktype = _ranktype_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(ranktype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		ranktype = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqSinglgeServerRankData) {
			ReqSinglgeServerRankData _o_ = (ReqSinglgeServerRankData)_o1_;
			if (ranktype != _o_.ranktype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += ranktype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(ranktype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(ReqSinglgeServerRankData _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = ranktype - _o_.ranktype;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

