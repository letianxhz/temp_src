
package global.rsp;

import knight.gsp.LocalIds;
import knight.gsp.log.Module;
import knight.gsp.main.ConfigManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RegistGlobalerverResponse__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RegistGlobalerverResponse extends __RegistGlobalerverResponse__ {
	@Override
	protected void process() {
		//向全局服务器发出注册协议
		int zoneid = ConfigManager.getGsZoneId();
		RegistGlobalServerRequest registRequest = new RegistGlobalServerRequest();
		registRequest.zoneid = zoneid;
		registRequest.startport = ConfigManager.getDockerStartPort();
		registRequest.ip = ConfigManager.getExternalIp();
		registRequest.gamexloginip = ConfigManager.getGameXLoginIp();
		registRequest.serverlocalids.addAll(LocalIds.SAVE_LOCAL_IDS);
		registRequest.linknum = ConfigManager.getLinkNum();
		if (!GlobalClientManager.getInstance().send(registRequest)){
			Module.logger.error("服务器启动是向GlobalServer注册失败！");
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924505;

	public int getType() {
		return 924505;
	}


	public RegistGlobalerverResponse() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RegistGlobalerverResponse) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(RegistGlobalerverResponse _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

