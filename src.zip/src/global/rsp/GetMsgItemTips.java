
package global.rsp;

import knight.gsp.msg.ChannelChat;
import com.goldhuman.Common.Octets;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GetMsgItemTips__ extends xio.Protocol { }

/** 请求消息链接的内容
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GetMsgItemTips extends __GetMsgItemTips__ {
	@Override
	protected void process() {
		knight.gsp.msg.ShowInfo _showInfo = new knight.gsp.msg.ShowInfo();
		
		OctetsStream octstram = OctetsStream.wrap(showinfo);
		try {
			_showInfo.unmarshal(octstram);
		} catch (MarshalException e) {
			e.printStackTrace();
			return;
		}
		
		ChannelChat channelChat = new ChannelChat(fromroleid);
		
		SendItemTips res = new SendItemTips();
		res.fromroleid = fromroleid;
		res.roleid = targetroleid;
		
		res.showinfo = new OctetsStream().marshal(_showInfo);
		
		Octets octs1 = channelChat.getOctets(_showInfo);
		if (octs1 == null)
			return;
		
		res.octs1 = octs1;
		
		Octets octs2 = channelChat.getOctetsExt(_showInfo);
		if (octs2 == null)
			return;
		
		res.octs2 = octs2;
		
		GlobalClientManager.getInstance().send(fromzoneid, res);
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924519;

	public int getType() {
		return 924519;
	}

	public int fromzoneid; // 源服务器zoneid
	public long fromroleid;
	public long targetroleid;
	public com.goldhuman.Common.Octets showinfo; // showinfo

	public GetMsgItemTips() {
		showinfo = new com.goldhuman.Common.Octets();
	}

	public GetMsgItemTips(int _fromzoneid_, long _fromroleid_, long _targetroleid_, com.goldhuman.Common.Octets _showinfo_) {
		this.fromzoneid = _fromzoneid_;
		this.fromroleid = _fromroleid_;
		this.targetroleid = _targetroleid_;
		this.showinfo = _showinfo_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fromzoneid);
		_os_.marshal(fromroleid);
		_os_.marshal(targetroleid);
		_os_.marshal(showinfo);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fromzoneid = _os_.unmarshal_int();
		fromroleid = _os_.unmarshal_long();
		targetroleid = _os_.unmarshal_long();
		showinfo = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GetMsgItemTips) {
			GetMsgItemTips _o_ = (GetMsgItemTips)_o1_;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (fromroleid != _o_.fromroleid) return false;
			if (targetroleid != _o_.targetroleid) return false;
			if (!showinfo.equals(_o_.showinfo)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += fromzoneid;
		_h_ += (int)fromroleid;
		_h_ += (int)targetroleid;
		_h_ += showinfo.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(fromroleid).append(",");
		_sb_.append(targetroleid).append(",");
		_sb_.append("B").append(showinfo.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

