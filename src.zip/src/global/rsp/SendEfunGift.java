
package global.rsp;
import knight.gsp.LocalIds;
import knight.gsp.item.EmailBox;
import knight.gsp.item.MailManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendEfunGift__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendEfunGift extends __SendEfunGift__ {
	@Override
	protected void process() {
		if(roleid <= 0 || LocalIds.isRemoteServerRole(roleid))
			return;
		new xdb.Procedure(){
			@Override
			protected boolean process() throws Exception {
				for(int i = 0; i < giftids.size(); i++){
					int giftId = giftids.get(i);
					int giftNum = giftnums.get(i);
					MailManager.LOG.info("yunying bind gift!!!!roleid=" + roleid + ",giftId=" + giftId + ",giftNum:" + giftNum);
					for(int j = 0; j < giftNum; j++){
						if(!new EmailBox(roleid, false).sendMail(giftId)){
							xdb.Trace.error("SendEfunGift.failedroleid=" + roleid + ",giftId=" + giftId + ",giftNum:" + giftNum);
							return false;
						}
					}
				}
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918212;

	public int getType() {
		return 918212;
	}

	public long roleid; // 角色id
	public java.util.ArrayList<Integer> giftids; // 礼包id
	public java.util.ArrayList<Integer> giftnums; // 礼包id

	public SendEfunGift() {
		giftids = new java.util.ArrayList<Integer>();
		giftnums = new java.util.ArrayList<Integer>();
	}

	public SendEfunGift(long _roleid_, java.util.ArrayList<Integer> _giftids_, java.util.ArrayList<Integer> _giftnums_) {
		this.roleid = _roleid_;
		this.giftids = _giftids_;
		this.giftnums = _giftnums_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.compact_uint32(giftids.size());
		for (Integer _v_ : giftids) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(giftnums.size());
		for (Integer _v_ : giftnums) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			giftids.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			giftnums.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendEfunGift) {
			SendEfunGift _o_ = (SendEfunGift)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!giftids.equals(_o_.giftids)) return false;
			if (!giftnums.equals(_o_.giftnums)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += giftids.hashCode();
		_h_ += giftnums.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(giftids).append(",");
		_sb_.append(giftnums).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

