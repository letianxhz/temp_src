
package global.rsp;

import knight.gsp.cache.CachePool;
import knight.gsp.cache.LruCache;
import knight.gsp.dragon.SQueryOtherDragonInfo;
import knight.gsp.fashion.SRetOthterFashionInfo;
import knight.gsp.item.SPkCardInfo;
import knight.gsp.mercenary.SQueryOtherMercenary;
import knight.gsp.ride.SQueryOtherRideInfo;
import knight.gsp.shenqi.SQueryOtherShenQiInfo;
import knight.gsp.wing.SQueryOtherWingInfo;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReplyCrossInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReplyCrossInfo extends __ReplyCrossInfo__ {
	@Override
	protected void process() {
		xio.Protocol requestData = null;
		LruCache cache = null;
		if (protocoltype == SPkCardInfo.PROTOCOL_TYPE) {
			//请求PK卡信息
			requestData = new SPkCardInfo();
			//获得协议缓存
			cache = CachePool.getCache(SPkCardInfo.PROTOCOL_TYPE);
		} else if (protocoltype == SQueryOtherWingInfo.PROTOCOL_TYPE) {
			requestData = new SQueryOtherWingInfo();
			
			cache = CachePool.getCache(SQueryOtherWingInfo.PROTOCOL_TYPE);
		} else if (protocoltype == SQueryOtherRideInfo.PROTOCOL_TYPE) {
			requestData = new SQueryOtherRideInfo();
			
			cache = CachePool.getCache(SQueryOtherRideInfo.PROTOCOL_TYPE);
		} else if (protocoltype == SQueryOtherDragonInfo.PROTOCOL_TYPE) {
			requestData = new SQueryOtherDragonInfo();
			
			cache = CachePool.getCache(SQueryOtherDragonInfo.PROTOCOL_TYPE);
		} else if (protocoltype == SQueryOtherMercenary.PROTOCOL_TYPE) {
			requestData = new SQueryOtherMercenary();
			
			cache = CachePool.getCache(SQueryOtherMercenary.PROTOCOL_TYPE);
		} else if (protocoltype == SRetOthterFashionInfo.PROTOCOL_TYPE) {
			requestData = new SRetOthterFashionInfo();
			
			cache = CachePool.getCache(SRetOthterFashionInfo.PROTOCOL_TYPE);
		} else if (protocoltype == SQueryOtherShenQiInfo.PROTOCOL_TYPE) {
			requestData = new SQueryOtherShenQiInfo();
			cache = CachePool.getCache(SQueryOtherShenQiInfo.PROTOCOL_TYPE);
		}
		
		if (requestData == null)
			return;
		
		OctetsStream os = OctetsStream.wrap(pdata);
		try {
			requestData.unmarshal(os);
		} catch (MarshalException e) {
			e.printStackTrace();
			return;
		}
		
		gnet.link.Onlines.getInstance().send(fromroleid, requestData);
		
		if (cache != null) {
			cache.put(dstroleid, requestData);
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918217;

	public int getType() {
		return 918217;
	}

	public int protocoltype;
	public com.goldhuman.Common.Octets pdata;
	public int fromzoneid;
	public int dstzoneid;
	public long fromroleid;
	public long dstroleid;

	public ReplyCrossInfo() {
		pdata = new com.goldhuman.Common.Octets();
	}

	public ReplyCrossInfo(int _protocoltype_, com.goldhuman.Common.Octets _pdata_, int _fromzoneid_, int _dstzoneid_, long _fromroleid_, long _dstroleid_) {
		this.protocoltype = _protocoltype_;
		this.pdata = _pdata_;
		this.fromzoneid = _fromzoneid_;
		this.dstzoneid = _dstzoneid_;
		this.fromroleid = _fromroleid_;
		this.dstroleid = _dstroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(protocoltype);
		_os_.marshal(pdata);
		_os_.marshal(fromzoneid);
		_os_.marshal(dstzoneid);
		_os_.marshal(fromroleid);
		_os_.marshal(dstroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		protocoltype = _os_.unmarshal_int();
		pdata = _os_.unmarshal_Octets();
		fromzoneid = _os_.unmarshal_int();
		dstzoneid = _os_.unmarshal_int();
		fromroleid = _os_.unmarshal_long();
		dstroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReplyCrossInfo) {
			ReplyCrossInfo _o_ = (ReplyCrossInfo)_o1_;
			if (protocoltype != _o_.protocoltype) return false;
			if (!pdata.equals(_o_.pdata)) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (dstzoneid != _o_.dstzoneid) return false;
			if (fromroleid != _o_.fromroleid) return false;
			if (dstroleid != _o_.dstroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += protocoltype;
		_h_ += pdata.hashCode();
		_h_ += fromzoneid;
		_h_ += dstzoneid;
		_h_ += (int)fromroleid;
		_h_ += (int)dstroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(protocoltype).append(",");
		_sb_.append("B").append(pdata.size()).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(dstzoneid).append(",");
		_sb_.append(fromroleid).append(",");
		_sb_.append(dstroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

