
package global.rsp.rpc;

import org.json.JSONObject;

import com.goldhuman.Common.Octets;

import knight.gsp.LocalIds;
import knight.gsp.dny.DongNanYaManager;
import knight.gsp.game.SGoodstype;
import knight.gsp.yuanbao.YuanbaoManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS

abstract class __CheckProductCanBuyOrNot__ extends xio.Rpc<global.rsp.rpc.BuyProductInfoReq, global.rsp.rpc.BuyProductInfoRep> { }
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CheckProductCanBuyOrNot extends __CheckProductCanBuyOrNot__ {
	@Override
	protected void onServer() {
		global.rsp.rpc.BuyProductInfoReq arg = getArgument();
		long roleId = arg.roleid;
		String productId = arg.productid;
		JSONObject json = new JSONObject();
		xbean.Properties propRole = xtable.Properties.select(roleId);
		if(LocalIds.isRemoteServerRole(roleId) || propRole == null){
			json.put("result", 0);
			json.put("code", 1003);
			json.put("msg", "该角色不是当前服务器的玩家！");
		} else {
			json.put("result", 1);
			json.put("code", 1);
			json.put("msg", "success");
			JSONObject data = new JSONObject();
			SGoodstype good = DongNanYaManager.getInstance().getGoodBySpecialId(productId);
			if(good == null || !YuanbaoManager.SQWAN_DONGNANYA_GOOGLE.equalsIgnoreCase(good.pingtaiid)){
				json.put("result", 0);
				json.put("code", 1004);
				json.put("msg", "商品id错误！！！");
				getResult().msg = Octets.wrap(json.toString(), "UTF-8");
				return;
			}
			int result = YuanbaoManager.checkSpecialGoodsBuy(roleId, good);
			if(result == 1){
				data.put("canBuy", "N");
			} else {
				data.put("canBuy", "Y");
			}
			json.put("data", data);
		}
		getResult().msg = Octets.wrap(json.toString(), "UTF-8");
	}

	@Override
	protected void onClient() {
		// response handle
	}

	@Override
	protected void onTimeout(int code) {
		// client only. 当使用 submit 方式调用 rpc 时，不会产生这个回调。
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public int getType() {
		return 926306;
	}

	public CheckProductCanBuyOrNot() {
		super.setArgument(new global.rsp.rpc.BuyProductInfoReq());
		super.setResult(new global.rsp.rpc.BuyProductInfoRep());
	}

	public CheckProductCanBuyOrNot(global.rsp.rpc.BuyProductInfoReq argument) {
		super.setArgument(argument);
		super.setResult(new global.rsp.rpc.BuyProductInfoRep());
	}

	public int getTimeout() {
		return 1000 * 20;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}
}

