
package global.rsp.rpc;

import java.util.concurrent.ExecutionException;

import knight.gsp.game.SGoodstype;
import knight.gsp.main.ConfigManager;
import knight.gsp.yuanbao.PConfirmCharge;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS

abstract class __GenYunDingOrderId__ extends xio.Rpc<global.rsp.rpc.GenYunDingOrderArg, global.rsp.rpc.GenYunDingOrderRes> { }
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GenYunDingOrderId extends __GenYunDingOrderId__ {
	@Override
	protected void onServer() {
		long roleId = getArgument().player_id;
		xbean.Properties prop = xtable.Properties.select(roleId);
		if (prop == null) {
			setGenOrderResult(1, "不存在这个玩家:" + roleId);
			return;
		}
		
		if (!prop.getNickname().equalsIgnoreCase("ydad")) {
			setGenOrderResult(1, "玩家渠道标示错误:" + prop.getNickname());
			return;
		}
		
		int proid = -1;
		
		for (SGoodstype cfg : ConfigManager.getInstance().getConf(SGoodstype.class).values()) {
			if (!cfg.pingtaiid.equals("ydad"))
				continue;
			
			if (Integer.valueOf(cfg.specialproid) == getArgument().good_code) {
				proid = cfg.id;
				break;
			}
		}
		
		if (proid == -1) {
			setGenOrderResult(1, "找不到这个商品" + getArgument().good_code);
			return;
		
		}
		
		try {
			
			PConfirmCharge p = new PConfirmCharge(roleId, proid, getArgument().payexpanddata, 0, new java.util.LinkedList<Integer>());
			p.submit().get();
			if (p.result) {
				setGenOrderResult(0, "" + p.genBilId);
			} else {
				setGenOrderResult(1, "生产订单失败");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void setGenOrderResult(int sucess, String desc) {
		getResult().result = sucess;
		getResult().desc = desc;
	}

	@Override
	protected void onClient() {
		// response handle
	}

	@Override
	protected void onTimeout(int code) {
		// client only. 当使用 submit 方式调用 rpc 时，不会产生这个回调。
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public int getType() {
		return 926308;
	}

	public GenYunDingOrderId() {
		super.setArgument(new global.rsp.rpc.GenYunDingOrderArg());
		super.setResult(new global.rsp.rpc.GenYunDingOrderRes());
	}

	public GenYunDingOrderId(global.rsp.rpc.GenYunDingOrderArg argument) {
		super.setArgument(argument);
		super.setResult(new global.rsp.rpc.GenYunDingOrderRes());
	}

	public int getTimeout() {
		return 1000 * 20;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}
}

