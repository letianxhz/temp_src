
package global.rsp.rpc;

import knight.gsp.game.SGoodstype;
import knight.gsp.main.ConfigManager;
import knight.gsp.yuanbao.YuanbaoManager;

import org.json.JSONArray;
import org.json.JSONObject;

import com.goldhuman.Common.Octets;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS

abstract class __GetGATRoleProductInfo__ extends xio.Rpc<global.rsp.rpc.GATRoleProductInfoReq, global.rsp.rpc.GATRoleProductInfoRep> { }
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GetGATRoleProductInfo extends __GetGATRoleProductInfo__ {
	@Override
	protected void onServer() {
		JSONObject json = new JSONObject();
		json.put("code", "0000");
		int userId = getArgument().userid;
		JSONArray jsonArray = new JSONArray();
		xbean.User xuser = xtable.User.select(userId);
		if(xuser == null || xuser.getIdlist().isEmpty()){
			json.put("code", "0100");
		} else {
			for(long roleId : xuser.getIdlist()){
				xbean.Properties properties = xtable.Properties.select(roleId);
				JSONObject roleData = new JSONObject();
				roleData.put("roleid", roleId);
				roleData.put("name", properties.getRolename());
				roleData.put("level", properties.getLevel());
				roleData.put("subgame", ConfigManager.getGsZoneId());
				String platString = properties.getNickname().substring(0, 4);
				for(SGoodstype good : YuanbaoManager.getAllGoodsTypeToShow(platString)){
					int goodValue = YuanbaoManager.checkSpecialGoodsBuy(roleId, good);
					if(goodValue == -1)
						continue;
					roleData.put(good.specialproid, goodValue);
				}
				jsonArray.put(roleData);
			}
			json.put("list", jsonArray);
		}
		getResult().msg = Octets.wrap(json.toString(), "UTF-8");
	}

	@Override
	protected void onClient() {
		// response handle
	}

	@Override
	protected void onTimeout(int code) {
		// client only. 当使用 submit 方式调用 rpc 时，不会产生这个回调。
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public int getType() {
		return 926307;
	}

	public GetGATRoleProductInfo() {
		super.setArgument(new global.rsp.rpc.GATRoleProductInfoReq());
		super.setResult(new global.rsp.rpc.GATRoleProductInfoRep());
	}

	public GetGATRoleProductInfo(global.rsp.rpc.GATRoleProductInfoReq argument) {
		super.setArgument(argument);
		super.setResult(new global.rsp.rpc.GATRoleProductInfoRep());
	}

	public int getTimeout() {
		return 1000 * 20;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}
}

