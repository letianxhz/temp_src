
package global.rsp.rpc;

import org.json.JSONObject;

import com.goldhuman.Common.Octets;

import knight.gsp.LocalIds;
import knight.gsp.game.SGoodstype;
import knight.gsp.yuanbao.GoodsCashType;
import knight.gsp.yuanbao.YuanbaoManager;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS

abstract class __GetProductInfo__ extends xio.Rpc<global.rsp.rpc.BuyProductInfoReq, global.rsp.rpc.BuyProductInfoRep> { }
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GetProductInfo extends __GetProductInfo__ {
	@Override
	protected void onServer() {
		global.rsp.rpc.BuyProductInfoReq arg = getArgument();
		long roleId = arg.roleid;
		xbean.Properties propRole = xtable.Properties.select(roleId);
		JSONObject json = new JSONObject();
		if(LocalIds.isRemoteServerRole(roleId) || propRole == null){
			json.put("result", 0);
			json.put("code", 1003);
			json.put("msg", "该角色不是当前服务器的玩家！");
		} else {
			json.put("result", 1);
			json.put("code", 1);
			json.put("msg", "success");
			JSONObject data = new JSONObject();
			String platString = propRole.getNickname().substring(0, 4);
			for(SGoodstype good : YuanbaoManager.getAllGoodsTypeToShow(platString)){
				int result = YuanbaoManager.checkSpecialGoodsBuy(roleId, good);
				if(result == -1){
					if(good.cashtype == GoodsCashType.YB)
						continue;
					data.append("canBuyProductID", good.specialproid);
				} else if (result == 0){
					data.append("activityProductID", good.specialproid);
				}
			}
			json.put("data", data);
		}
		getResult().msg = Octets.wrap(json.toString(), "UTF-8");
	}

	@Override
	protected void onClient() {
		// response handle
	}

	@Override
	protected void onTimeout(int code) {
		// client only. 当使用 submit 方式调用 rpc 时，不会产生这个回调。
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public int getType() {
		return 926305;
	}

	public GetProductInfo() {
		super.setArgument(new global.rsp.rpc.BuyProductInfoReq());
		super.setResult(new global.rsp.rpc.BuyProductInfoRep());
	}

	public GetProductInfo(global.rsp.rpc.BuyProductInfoReq argument) {
		super.setArgument(argument);
		super.setResult(new global.rsp.rpc.BuyProductInfoRep());
	}

	public int getTimeout() {
		return 1000 * 20;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}
}

