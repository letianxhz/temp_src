
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsSendHotTopic__ extends xio.Protocol { }

/** GS向Global 推送热门话题
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsSendHotTopic extends __GsSendHotTopic__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918219;

	public int getType() {
		return 918219;
	}

	public com.goldhuman.Common.Octets hottopic;

	public GsSendHotTopic() {
		hottopic = new com.goldhuman.Common.Octets();
	}

	public GsSendHotTopic(com.goldhuman.Common.Octets _hottopic_) {
		this.hottopic = _hottopic_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(hottopic);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		hottopic = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsSendHotTopic) {
			GsSendHotTopic _o_ = (GsSendHotTopic)_o1_;
			if (!hottopic.equals(_o_.hottopic)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += hottopic.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("B").append(hottopic.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

