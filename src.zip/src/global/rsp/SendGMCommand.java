
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendGMCommand__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendGMCommand extends __SendGMCommand__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918209;

	public int getType() {
		return 918209;
	}

	public final static int ADDJD = 1; // 添加京东卡
	public final static int CHECKJD = 2; // 检查京东卡
	public final static int RECYCLEJD = 3; // 回收京东卡
	public final static int RELOAD_GIFTCARD = 4; // 热加载礼品卡数据
	public final static int CHECK_TEMP = 5; // 查看使用异常的京东卡
	public final static int JUBAOPEN_CLEAR = 8; // 清除掉已经bind的聚宝盆帐号和乐道帐号之间的对应关系

	public long roleid; // 操作角色id
	public int gmtype; // gm命令类型
	public java.lang.String params; // gm命令参数  param1,param2,.....
	public int serverid; // 角色当前所在的服务器

	public SendGMCommand() {
		params = "";
	}

	public SendGMCommand(long _roleid_, int _gmtype_, java.lang.String _params_, int _serverid_) {
		this.roleid = _roleid_;
		this.gmtype = _gmtype_;
		this.params = _params_;
		this.serverid = _serverid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(gmtype);
		_os_.marshal(params, "UTF-16LE");
		_os_.marshal(serverid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		gmtype = _os_.unmarshal_int();
		params = _os_.unmarshal_String("UTF-16LE");
		serverid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendGMCommand) {
			SendGMCommand _o_ = (SendGMCommand)_o1_;
			if (roleid != _o_.roleid) return false;
			if (gmtype != _o_.gmtype) return false;
			if (!params.equals(_o_.params)) return false;
			if (serverid != _o_.serverid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += gmtype;
		_h_ += params.hashCode();
		_h_ += serverid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(gmtype).append(",");
		_sb_.append("T").append(params.length()).append(",");
		_sb_.append(serverid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

