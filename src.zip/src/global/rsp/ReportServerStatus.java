
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReportServerStatus__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReportServerStatus extends __ReportServerStatus__ {
	@Override
	protected void process() {
//		knight.gsp.cross.CrossManager.getInstance().reportServerStatus(zoneid, load);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924514;

	public int getType() {
		return 924514;
	}

	public int zoneid; // 服务器ID
	public int onlinenum; // 当前在线人数
	public int maxonlinenum; // 能够承载的最大在线人数
	public java.util.HashMap<Long,Integer> bigwildrolenum; // 当前野外人数 key:sceneid value: 人数
	public int bigwildmaxrolenum; // 野外场景能够承载的最大人数

	public ReportServerStatus() {
		bigwildrolenum = new java.util.HashMap<Long,Integer>();
	}

	public ReportServerStatus(int _zoneid_, int _onlinenum_, int _maxonlinenum_, java.util.HashMap<Long,Integer> _bigwildrolenum_, int _bigwildmaxrolenum_) {
		this.zoneid = _zoneid_;
		this.onlinenum = _onlinenum_;
		this.maxonlinenum = _maxonlinenum_;
		this.bigwildrolenum = _bigwildrolenum_;
		this.bigwildmaxrolenum = _bigwildmaxrolenum_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(onlinenum);
		_os_.marshal(maxonlinenum);
		_os_.compact_uint32(bigwildrolenum.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : bigwildrolenum.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(bigwildmaxrolenum);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_int();
		onlinenum = _os_.unmarshal_int();
		maxonlinenum = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			bigwildrolenum.put(_k_, _v_);
		}
		bigwildmaxrolenum = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReportServerStatus) {
			ReportServerStatus _o_ = (ReportServerStatus)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (onlinenum != _o_.onlinenum) return false;
			if (maxonlinenum != _o_.maxonlinenum) return false;
			if (!bigwildrolenum.equals(_o_.bigwildrolenum)) return false;
			if (bigwildmaxrolenum != _o_.bigwildmaxrolenum) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += zoneid;
		_h_ += onlinenum;
		_h_ += maxonlinenum;
		_h_ += bigwildrolenum.hashCode();
		_h_ += bigwildmaxrolenum;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(onlinenum).append(",");
		_sb_.append(maxonlinenum).append(",");
		_sb_.append(bigwildrolenum).append(",");
		_sb_.append(bigwildmaxrolenum).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

