
package global.rsp;

import knight.gsp.cache.CachePool;
import knight.gsp.cache.LruCache;
import knight.gsp.item.SGetOtherRoleEquipBag;
import knight.gsp.item.SGetOtherRoleEquipBagLua;
import knight.gsp.item.SRepEquipSetProps;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendOtherRoleEquipBag__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendOtherRoleEquipBag extends __SendOtherRoleEquipBag__ {
	@Override
	protected void process() {
		final knight.gsp.map.Role thisrole = knight.gsp.map.RoleManager.getInstance().getRoleByID(fromroleid);
		if (null == thisrole) {
			return;
		}

		final SGetOtherRoleEquipBag p1 = new SGetOtherRoleEquipBag();
		final SGetOtherRoleEquipBagLua p2 = new SGetOtherRoleEquipBagLua();
		final SRepEquipSetProps p3 = new SRepEquipSetProps();
		
		OctetsStream os1 = OctetsStream.wrap(octs1);
		OctetsStream os2 = OctetsStream.wrap(octs2);
		OctetsStream os3 = OctetsStream.wrap(octs3);
		
		try {
			p1.unmarshal(os1);
			p2.unmarshal(os2);
			p3.unmarshal(os3);
		} catch (MarshalException e) {
			e.printStackTrace();
			return;
		}
		
		gnet.link.Onlines.getInstance().send(fromroleid, p1);
		gnet.link.Onlines.getInstance().send(fromroleid, p2);
		gnet.link.Onlines.getInstance().send(fromroleid, p3);
		
		//缓存一下刚查询到的数据
		LruCache cache1 = CachePool.getCache(SendOtherRoleEquipBag.PROTOCOL_TYPE);
		LruCache cache2 = CachePool.getCache(SGetOtherRoleEquipBagLua.PROTOCOL_TYPE);
		LruCache cache3 = CachePool.getCache(SRepEquipSetProps.PROTOCOL_TYPE);
		
		cache1.put(roleid, p1);
		cache2.put(roleid, p2);
		cache3.put(roleid, p3);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924513;

	public int getType() {
		return 924513;
	}

	public long fromroleid;
	public long roleid;
	public com.goldhuman.Common.Octets octs1;
	public com.goldhuman.Common.Octets octs2;
	public com.goldhuman.Common.Octets octs3;

	public SendOtherRoleEquipBag() {
		octs1 = new com.goldhuman.Common.Octets();
		octs2 = new com.goldhuman.Common.Octets();
		octs3 = new com.goldhuman.Common.Octets();
	}

	public SendOtherRoleEquipBag(long _fromroleid_, long _roleid_, com.goldhuman.Common.Octets _octs1_, com.goldhuman.Common.Octets _octs2_, com.goldhuman.Common.Octets _octs3_) {
		this.fromroleid = _fromroleid_;
		this.roleid = _roleid_;
		this.octs1 = _octs1_;
		this.octs2 = _octs2_;
		this.octs3 = _octs3_;
	}

	public final boolean _validator_() {
		if (roleid < 1) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fromroleid);
		_os_.marshal(roleid);
		_os_.marshal(octs1);
		_os_.marshal(octs2);
		_os_.marshal(octs3);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fromroleid = _os_.unmarshal_long();
		roleid = _os_.unmarshal_long();
		octs1 = _os_.unmarshal_Octets();
		octs2 = _os_.unmarshal_Octets();
		octs3 = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendOtherRoleEquipBag) {
			SendOtherRoleEquipBag _o_ = (SendOtherRoleEquipBag)_o1_;
			if (fromroleid != _o_.fromroleid) return false;
			if (roleid != _o_.roleid) return false;
			if (!octs1.equals(_o_.octs1)) return false;
			if (!octs2.equals(_o_.octs2)) return false;
			if (!octs3.equals(_o_.octs3)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)fromroleid;
		_h_ += (int)roleid;
		_h_ += octs1.hashCode();
		_h_ += octs2.hashCode();
		_h_ += octs3.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fromroleid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append("B").append(octs1.size()).append(",");
		_sb_.append("B").append(octs2.size()).append(",");
		_sb_.append("B").append(octs3.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

