
package global.rsp.family;
import knight.gsp.GsClient;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneService;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsUnloadAllFamilyScene__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsUnloadAllFamilyScene extends __GlGsUnloadAllFamilyScene__ {
	@Override
	protected void process() {
		for(final long sceneId :sceneids) {
			GsClient.sendToScene(sceneId, new xio.Protocol(){

				
				
				@Override
				protected void process() {
					Scene scene = SceneService.getInstance().getSceneById(sceneId);
					if(scene != null){
						scene.unload();
					}
				}

				@Override
				public OctetsStream marshal(OctetsStream arg0) {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public OctetsStream unmarshal(OctetsStream arg0)
						throws MarshalException {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public int getType() {
					// TODO Auto-generated method stub
					return 0;
				}
				
			});
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925917;

	public int getType() {
		return 925917;
	}

	public java.util.ArrayList<Long> sceneids; // 场景id

	public GlGsUnloadAllFamilyScene() {
		sceneids = new java.util.ArrayList<Long>();
	}

	public GlGsUnloadAllFamilyScene(java.util.ArrayList<Long> _sceneids_) {
		this.sceneids = _sceneids_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(sceneids.size());
		for (Long _v_ : sceneids) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			sceneids.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsUnloadAllFamilyScene) {
			GlGsUnloadAllFamilyScene _o_ = (GlGsUnloadAllFamilyScene)_o1_;
			if (!sceneids.equals(_o_.sceneids)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += sceneids.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(sceneids).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

