
package global.rsp.family;
import knight.gsp.GsClient;
import knight.msp.move.GFamilyJoinGatherScene;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsFamilyJoinGatherScene__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsFamilyJoinGatherScene extends __GlGsFamilyJoinGatherScene__ {
	@Override
	protected void process() {
		GsClient.sendToScene(sceneid, new GFamilyJoinGatherScene(sceneid, familyinfo));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925911;

	public int getType() {
		return 925911;
	}

	public global.rsp.family.FamilyGatherProtocol familyinfo;
	public long sceneid; // 场景id

	public GlGsFamilyJoinGatherScene() {
		familyinfo = new global.rsp.family.FamilyGatherProtocol();
	}

	public GlGsFamilyJoinGatherScene(global.rsp.family.FamilyGatherProtocol _familyinfo_, long _sceneid_) {
		this.familyinfo = _familyinfo_;
		this.sceneid = _sceneid_;
	}

	public final boolean _validator_() {
		if (!familyinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(familyinfo);
		_os_.marshal(sceneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		familyinfo.unmarshal(_os_);
		sceneid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsFamilyJoinGatherScene) {
			GlGsFamilyJoinGatherScene _o_ = (GlGsFamilyJoinGatherScene)_o1_;
			if (!familyinfo.equals(_o_.familyinfo)) return false;
			if (sceneid != _o_.sceneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += familyinfo.hashCode();
		_h_ += (int)sceneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familyinfo).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

