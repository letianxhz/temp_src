
package global.rsp.family;
import global.rsp.fuben.GReqCrossSetWatchBattle;
import knight.gsp.LocalIds;
import knight.gsp.scene.CommonThread;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsNotifySSetWatchBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsNotifySSetWatchBattle extends __GlGsNotifySSetWatchBattle__ {
	@Override
	protected void process() {
		if (battlesceneid <=0) 
			return;
		if (LocalIds.isRemoteServerRole(watchrole)) 
			return;
		CommonThread.getInstance().add(new GReqCrossSetWatchBattle(battleserverid, battlesceneid, watchrole));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925944;

	public int getType() {
		return 925944;
	}

	public int battleserverid; // 战场所在的serverid
	public long battlesceneid; // 战斗所在的场景
	public long watchrole; // 观战的玩家

	public GlGsNotifySSetWatchBattle() {
	}

	public GlGsNotifySSetWatchBattle(int _battleserverid_, long _battlesceneid_, long _watchrole_) {
		this.battleserverid = _battleserverid_;
		this.battlesceneid = _battlesceneid_;
		this.watchrole = _watchrole_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserverid);
		_os_.marshal(battlesceneid);
		_os_.marshal(watchrole);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserverid = _os_.unmarshal_int();
		battlesceneid = _os_.unmarshal_long();
		watchrole = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsNotifySSetWatchBattle) {
			GlGsNotifySSetWatchBattle _o_ = (GlGsNotifySSetWatchBattle)_o1_;
			if (battleserverid != _o_.battleserverid) return false;
			if (battlesceneid != _o_.battlesceneid) return false;
			if (watchrole != _o_.watchrole) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserverid;
		_h_ += (int)battlesceneid;
		_h_ += (int)watchrole;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserverid).append(",");
		_sb_.append(battlesceneid).append(",");
		_sb_.append(watchrole).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsNotifySSetWatchBattle _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = battleserverid - _o_.battleserverid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(battlesceneid - _o_.battlesceneid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(watchrole - _o_.watchrole);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

