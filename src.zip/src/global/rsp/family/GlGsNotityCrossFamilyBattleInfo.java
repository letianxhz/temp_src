
package global.rsp.family;
import knight.gsp.family.crossfamilybattle.PGenCrossFamilyFightMatrix;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsNotityCrossFamilyBattleInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsNotityCrossFamilyBattleInfo extends __GlGsNotityCrossFamilyBattleInfo__ {
	@Override
	protected void process() {
		// protocol handle
		//TODO判断当前自己的服务器开服时间是否满足条件不满足就不往下处理了
		new PGenCrossFamilyFightMatrix(crossfmailybattledata).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925925;

	public int getType() {
		return 925925;
	}

	public global.rsp.family.CrossFamilytBattle crossfmailybattledata;

	public GlGsNotityCrossFamilyBattleInfo() {
		crossfmailybattledata = new global.rsp.family.CrossFamilytBattle();
	}

	public GlGsNotityCrossFamilyBattleInfo(global.rsp.family.CrossFamilytBattle _crossfmailybattledata_) {
		this.crossfmailybattledata = _crossfmailybattledata_;
	}

	public final boolean _validator_() {
		if (!crossfmailybattledata._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(crossfmailybattledata);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		crossfmailybattledata.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsNotityCrossFamilyBattleInfo) {
			GlGsNotityCrossFamilyBattleInfo _o_ = (GlGsNotityCrossFamilyBattleInfo)_o1_;
			if (!crossfmailybattledata.equals(_o_.crossfmailybattledata)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += crossfmailybattledata.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(crossfmailybattledata).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

