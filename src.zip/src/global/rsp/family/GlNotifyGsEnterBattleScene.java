
package global.rsp.family;
import knight.gsp.family.crossfamilybattle.PUpdateSaveBattleScene;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlNotifyGsEnterBattleScene__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlNotifyGsEnterBattleScene extends __GlNotifyGsEnterBattleScene__ {
	@Override
	protected void process() {
		new PUpdateSaveBattleScene(updatecrossfmailybattledata, startfighttime).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925930;

	public int getType() {
		return 925930;
	}

	public global.rsp.family.CrossFamilytBattle updatecrossfmailybattledata; // 更新当前全服的数据
	public long startfighttime; // 战斗开启时间

	public GlNotifyGsEnterBattleScene() {
		updatecrossfmailybattledata = new global.rsp.family.CrossFamilytBattle();
	}

	public GlNotifyGsEnterBattleScene(global.rsp.family.CrossFamilytBattle _updatecrossfmailybattledata_, long _startfighttime_) {
		this.updatecrossfmailybattledata = _updatecrossfmailybattledata_;
		this.startfighttime = _startfighttime_;
	}

	public final boolean _validator_() {
		if (!updatecrossfmailybattledata._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(updatecrossfmailybattledata);
		_os_.marshal(startfighttime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		updatecrossfmailybattledata.unmarshal(_os_);
		startfighttime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlNotifyGsEnterBattleScene) {
			GlNotifyGsEnterBattleScene _o_ = (GlNotifyGsEnterBattleScene)_o1_;
			if (!updatecrossfmailybattledata.equals(_o_.updatecrossfmailybattledata)) return false;
			if (startfighttime != _o_.startfighttime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += updatecrossfmailybattledata.hashCode();
		_h_ += (int)startfighttime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(updatecrossfmailybattledata).append(",");
		_sb_.append(startfighttime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

