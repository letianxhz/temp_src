
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlCreateCrossFamilyBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlCreateCrossFamilyBattle extends __GsGlCreateCrossFamilyBattle__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925929;

	public int getType() {
		return 925929;
	}

	public int battleserverid; // 战斗场景创建的服务器
	public long sceneid; // 家族对战的场景
	public java.util.HashMap<Long,global.rsp.family.Pos> familyenterpos; // key:对阵的家族 value:战斗场景家族的入口坐标
	public int familyteamindex; // 家族对战队伍索引

	public GsGlCreateCrossFamilyBattle() {
		familyenterpos = new java.util.HashMap<Long,global.rsp.family.Pos>();
	}

	public GsGlCreateCrossFamilyBattle(int _battleserverid_, long _sceneid_, java.util.HashMap<Long,global.rsp.family.Pos> _familyenterpos_, int _familyteamindex_) {
		this.battleserverid = _battleserverid_;
		this.sceneid = _sceneid_;
		this.familyenterpos = _familyenterpos_;
		this.familyteamindex = _familyteamindex_;
	}

	public final boolean _validator_() {
		for (java.util.Map.Entry<Long, global.rsp.family.Pos> _e_ : familyenterpos.entrySet()) {
			if (!_e_.getValue()._validator_()) return false;
		}
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserverid);
		_os_.marshal(sceneid);
		_os_.compact_uint32(familyenterpos.size());
		for (java.util.Map.Entry<Long, global.rsp.family.Pos> _e_ : familyenterpos.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(familyteamindex);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserverid = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			global.rsp.family.Pos _v_ = new global.rsp.family.Pos();
			_v_.unmarshal(_os_);
			familyenterpos.put(_k_, _v_);
		}
		familyteamindex = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlCreateCrossFamilyBattle) {
			GsGlCreateCrossFamilyBattle _o_ = (GsGlCreateCrossFamilyBattle)_o1_;
			if (battleserverid != _o_.battleserverid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (!familyenterpos.equals(_o_.familyenterpos)) return false;
			if (familyteamindex != _o_.familyteamindex) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserverid;
		_h_ += (int)sceneid;
		_h_ += familyenterpos.hashCode();
		_h_ += familyteamindex;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserverid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(familyenterpos).append(",");
		_sb_.append(familyteamindex).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

