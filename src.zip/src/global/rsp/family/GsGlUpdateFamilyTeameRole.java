
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlUpdateFamilyTeameRole__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlUpdateFamilyTeameRole extends __GsGlUpdateFamilyTeameRole__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925941;

	public int getType() {
		return 925941;
	}

	public int changetype; // 更新类型 0: 替换队员(从非战队中替换) 1:交换队员（两个队伍之间交换）
	public long familykey; // 家族的key
	public int teamindex1; // 更新的队伍索引1
	public int teamindex2; // 更新的队伍索引2
	public long role1; // 相对于队伍1这个是要移除的玩家,相对于队伍2是要添加的玩家
	public long role2; // 相对于队伍1是要添加的玩家 相对于队伍2是要移除的玩家

	public GsGlUpdateFamilyTeameRole() {
	}

	public GsGlUpdateFamilyTeameRole(int _changetype_, long _familykey_, int _teamindex1_, int _teamindex2_, long _role1_, long _role2_) {
		this.changetype = _changetype_;
		this.familykey = _familykey_;
		this.teamindex1 = _teamindex1_;
		this.teamindex2 = _teamindex2_;
		this.role1 = _role1_;
		this.role2 = _role2_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(changetype);
		_os_.marshal(familykey);
		_os_.marshal(teamindex1);
		_os_.marshal(teamindex2);
		_os_.marshal(role1);
		_os_.marshal(role2);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		changetype = _os_.unmarshal_int();
		familykey = _os_.unmarshal_long();
		teamindex1 = _os_.unmarshal_int();
		teamindex2 = _os_.unmarshal_int();
		role1 = _os_.unmarshal_long();
		role2 = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlUpdateFamilyTeameRole) {
			GsGlUpdateFamilyTeameRole _o_ = (GsGlUpdateFamilyTeameRole)_o1_;
			if (changetype != _o_.changetype) return false;
			if (familykey != _o_.familykey) return false;
			if (teamindex1 != _o_.teamindex1) return false;
			if (teamindex2 != _o_.teamindex2) return false;
			if (role1 != _o_.role1) return false;
			if (role2 != _o_.role2) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += changetype;
		_h_ += (int)familykey;
		_h_ += teamindex1;
		_h_ += teamindex2;
		_h_ += (int)role1;
		_h_ += (int)role2;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(changetype).append(",");
		_sb_.append(familykey).append(",");
		_sb_.append(teamindex1).append(",");
		_sb_.append(teamindex2).append(",");
		_sb_.append(role1).append(",");
		_sb_.append(role2).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GsGlUpdateFamilyTeameRole _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = changetype - _o_.changetype;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(familykey - _o_.familykey);
		if (0 != _c_) return _c_;
		_c_ = teamindex1 - _o_.teamindex1;
		if (0 != _c_) return _c_;
		_c_ = teamindex2 - _o_.teamindex2;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(role1 - _o_.role1);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(role2 - _o_.role2);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

