package global.rsp.family;
import global.rsp.fuben.GReqAddCrossFamilyBattleAward;
import knight.gsp.scene.CommonThread;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsNotifyWatchBattleAward__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsNotifyWatchBattleAward extends __GlGsNotifyWatchBattleAward__ {
	@Override
	protected void process() {
		if (battlesceneid <= 0) 
			return;		
		CommonThread.getInstance().add(new GReqAddCrossFamilyBattleAward(battleserverid, battlesceneid, awardtype, battleaward, nextlotterytime));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925943;

	public int getType() {
		return 925943;
	}

	public int awardtype; // 奖励类型 0: 观战奖励 1:观战抽奖奖励
	public int battleserverid; // 战场所在的serverid
	public long battlesceneid; // 战斗所在的场景
	public int battleaward; // 观战抽奖奖励id
	public long nextlotterytime; // 下次观战抽奖剩余时间

	public GlGsNotifyWatchBattleAward() {
	}

	public GlGsNotifyWatchBattleAward(int _awardtype_, int _battleserverid_, long _battlesceneid_, int _battleaward_, long _nextlotterytime_) {
		this.awardtype = _awardtype_;
		this.battleserverid = _battleserverid_;
		this.battlesceneid = _battlesceneid_;
		this.battleaward = _battleaward_;
		this.nextlotterytime = _nextlotterytime_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(awardtype);
		_os_.marshal(battleserverid);
		_os_.marshal(battlesceneid);
		_os_.marshal(battleaward);
		_os_.marshal(nextlotterytime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		awardtype = _os_.unmarshal_int();
		battleserverid = _os_.unmarshal_int();
		battlesceneid = _os_.unmarshal_long();
		battleaward = _os_.unmarshal_int();
		nextlotterytime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsNotifyWatchBattleAward) {
			GlGsNotifyWatchBattleAward _o_ = (GlGsNotifyWatchBattleAward)_o1_;
			if (awardtype != _o_.awardtype) return false;
			if (battleserverid != _o_.battleserverid) return false;
			if (battlesceneid != _o_.battlesceneid) return false;
			if (battleaward != _o_.battleaward) return false;
			if (nextlotterytime != _o_.nextlotterytime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += awardtype;
		_h_ += battleserverid;
		_h_ += (int)battlesceneid;
		_h_ += battleaward;
		_h_ += (int)nextlotterytime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(awardtype).append(",");
		_sb_.append(battleserverid).append(",");
		_sb_.append(battlesceneid).append(",");
		_sb_.append(battleaward).append(",");
		_sb_.append(nextlotterytime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsNotifyWatchBattleAward _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = awardtype - _o_.awardtype;
		if (0 != _c_) return _c_;
		_c_ = battleserverid - _o_.battleserverid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(battlesceneid - _o_.battlesceneid);
		if (0 != _c_) return _c_;
		_c_ = battleaward - _o_.battleaward;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(nextlotterytime - _o_.nextlotterytime);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

