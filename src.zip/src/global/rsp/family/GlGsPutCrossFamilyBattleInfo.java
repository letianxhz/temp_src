
package global.rsp.family;
import knight.gsp.family.crossfamilybattle.GsCrossFamilyBattleManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsPutCrossFamilyBattleInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsPutCrossFamilyBattleInfo extends __GlGsPutCrossFamilyBattleInfo__ {
	@Override
	protected void process() {
		GsCrossFamilyBattleManager.getInstance().getCrossFamilyInfo(fighttype);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925926;

	public int getType() {
		return 925926;
	}

	public int fighttype; // 战斗类型 0:8个家族晋级 1:32个家族晋级

	public GlGsPutCrossFamilyBattleInfo() {
	}

	public GlGsPutCrossFamilyBattleInfo(int _fighttype_) {
		this.fighttype = _fighttype_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fighttype);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fighttype = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsPutCrossFamilyBattleInfo) {
			GlGsPutCrossFamilyBattleInfo _o_ = (GlGsPutCrossFamilyBattleInfo)_o1_;
			if (fighttype != _o_.fighttype) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += fighttype;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fighttype).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsPutCrossFamilyBattleInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = fighttype - _o_.fighttype;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

