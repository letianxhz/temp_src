
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GResponseAttendFamilyGather__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GResponseAttendFamilyGather extends __GResponseAttendFamilyGather__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925906;

	public int getType() {
		return 925906;
	}

	public long familykey; // 家族key
	public long sceneid; // 场景id
	public int destzoneid; // 目标服务器id

	public GResponseAttendFamilyGather() {
	}

	public GResponseAttendFamilyGather(long _familykey_, long _sceneid_, int _destzoneid_) {
		this.familykey = _familykey_;
		this.sceneid = _sceneid_;
		this.destzoneid = _destzoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(familykey);
		_os_.marshal(sceneid);
		_os_.marshal(destzoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		familykey = _os_.unmarshal_long();
		sceneid = _os_.unmarshal_long();
		destzoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GResponseAttendFamilyGather) {
			GResponseAttendFamilyGather _o_ = (GResponseAttendFamilyGather)_o1_;
			if (familykey != _o_.familykey) return false;
			if (sceneid != _o_.sceneid) return false;
			if (destzoneid != _o_.destzoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)familykey;
		_h_ += (int)sceneid;
		_h_ += destzoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familykey).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(destzoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GResponseAttendFamilyGather _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(familykey - _o_.familykey);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = destzoneid - _o_.destzoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

