
package global.rsp.family;
import knight.gsp.ActivityStatusManager;
import knight.gsp.activity.SNotifyActivityStatus;
import knight.gsp.camp.CampRole;
import knight.gsp.family.familygather.FamilyGatherManager;
import knight.gsp.family.familygather.SStartFamilyGather;




import knight.gsp.log.LogUtil;




// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsResponseAttendFamilyGather__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsResponseAttendFamilyGather extends __GlGsResponseAttendFamilyGather__ {
	@Override
	protected void process() {
		new xdb.Procedure(){
			@Override
			protected boolean process() throws Exception {
				xbean.FamilyInfoBean infoBean = xtable.Families.get(familykey);
				if(infoBean == null)
					return false;
				xbean.FamilyGatherInfo familyGather = xtable.Familygatherinfo.get(familykey);
				if(familyGather == null){
					familyGather = xbean.Pod.newFamilyGatherInfo();
					familyGather.setGathertimeid(FamilyGatherManager.getInstance().getDefaultCollectTime().id);
					xtable.Familygatherinfo.insert(familykey, familyGather);
				}
				familyGather.setAchievedgoal(0);
				familyGather.setBattlesceneid(sceneid);
				familyGather.setDestserverid(destzoneid);
				familyGather.setLastattendtime(System.currentTimeMillis());
				familyGather.setHasattended(1);
				for(long memId : infoBean.getMembers()){
					psendWhileCommit(memId, new SStartFamilyGather());
				}
				
				ActivityStatusManager.getInstance().broadcastActivityState(SNotifyActivityStatus.FAMILY_GATHER, (byte) 1, familykey);
				long familyMasterId = infoBean.getFamilymaster();
				xbean.Properties properties = xtable.Properties.select(familyMasterId);
				if(properties == null)
					return false;
				String platString = properties.getNickname().substring(0, 4);
				LogUtil.doFamilyGatherStartLog(infoBean.getFamilyname(), familyMasterId, properties.getRolename(), platString, new CampRole(familyMasterId, true).getStandCamp());
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925906;

	public int getType() {
		return 925906;
	}

	public long familykey; // 家族key
	public long sceneid; // 场景id
	public int destzoneid; // 目标服务器id
	public long tick; // 服务器时间

	public GlGsResponseAttendFamilyGather() {
	}

	public GlGsResponseAttendFamilyGather(long _familykey_, long _sceneid_, int _destzoneid_, long _tick_) {
		this.familykey = _familykey_;
		this.sceneid = _sceneid_;
		this.destzoneid = _destzoneid_;
		this.tick = _tick_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(familykey);
		_os_.marshal(sceneid);
		_os_.marshal(destzoneid);
		_os_.marshal(tick);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		familykey = _os_.unmarshal_long();
		sceneid = _os_.unmarshal_long();
		destzoneid = _os_.unmarshal_int();
		tick = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsResponseAttendFamilyGather) {
			GlGsResponseAttendFamilyGather _o_ = (GlGsResponseAttendFamilyGather)_o1_;
			if (familykey != _o_.familykey) return false;
			if (sceneid != _o_.sceneid) return false;
			if (destzoneid != _o_.destzoneid) return false;
			if (tick != _o_.tick) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)familykey;
		_h_ += (int)sceneid;
		_h_ += destzoneid;
		_h_ += (int)tick;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familykey).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(destzoneid).append(",");
		_sb_.append(tick).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsResponseAttendFamilyGather _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(familykey - _o_.familykey);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = destzoneid - _o_.destzoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(tick - _o_.tick);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

