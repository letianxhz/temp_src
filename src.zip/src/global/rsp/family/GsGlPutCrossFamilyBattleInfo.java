
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlPutCrossFamilyBattleInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlPutCrossFamilyBattleInfo extends __GsGlPutCrossFamilyBattleInfo__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925927;

	public int getType() {
		return 925927;
	}

	public int currzoneid; // 当前的服务器id
	public java.util.LinkedList<global.rsp.family.CrossBattleFamilyInfos> crossfamilyinfos;

	public GsGlPutCrossFamilyBattleInfo() {
		crossfamilyinfos = new java.util.LinkedList<global.rsp.family.CrossBattleFamilyInfos>();
	}

	public GsGlPutCrossFamilyBattleInfo(int _currzoneid_, java.util.LinkedList<global.rsp.family.CrossBattleFamilyInfos> _crossfamilyinfos_) {
		this.currzoneid = _currzoneid_;
		this.crossfamilyinfos = _crossfamilyinfos_;
	}

	public final boolean _validator_() {
		for (global.rsp.family.CrossBattleFamilyInfos _v_ : crossfamilyinfos)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(currzoneid);
		_os_.compact_uint32(crossfamilyinfos.size());
		for (global.rsp.family.CrossBattleFamilyInfos _v_ : crossfamilyinfos) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		currzoneid = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.family.CrossBattleFamilyInfos _v_ = new global.rsp.family.CrossBattleFamilyInfos();
			_v_.unmarshal(_os_);
			crossfamilyinfos.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlPutCrossFamilyBattleInfo) {
			GsGlPutCrossFamilyBattleInfo _o_ = (GsGlPutCrossFamilyBattleInfo)_o1_;
			if (currzoneid != _o_.currzoneid) return false;
			if (!crossfamilyinfos.equals(_o_.crossfamilyinfos)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += currzoneid;
		_h_ += crossfamilyinfos.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(currzoneid).append(",");
		_sb_.append(crossfamilyinfos).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

