
package global.rsp.family;
import knight.gsp.family.FamilyModule;
import knight.gsp.family.crossfamilybattle.CrossFamilyBattleData;
import knight.gsp.msg.Message;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsCrossFamilyPreMsg__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsCrossFamilyPreMsg extends __GlGsCrossFamilyPreMsg__ {
	@Override
	protected void process() {
		CrossFamilyBattleData familyBattleData = new CrossFamilyBattleData(true);
		int curRound = familyBattleData.getCurrentRound();
		int fightType = familyBattleData.getXBean().getFighttype();
		if (fightType == 0) {//八个家族晋级的
			switch (curRound) {
			case FamilyModule.FAMILY_8:
				//1029122  <T t="本届首轮跨服家族战将于15分钟后开始，请各个参战家族的勇士们做好准备！" c="ffddbb77"></T>
				Message.sendSystemMsg(1029122, null);
				break;
			case FamilyModule.FAMILY_4:
				//1029125  <T t="本届第二轮跨服家族战已进入备战阶段，请各家族参战成员在5分钟内迅速入场！" c="ffddbb77"></T>
				Message.sendSystemMsg(1029125, null);
				break;
			case FamilyModule.FAMILY_2:
				//102011  <T t="本届终极跨服家族战已进入备战阶段，请各家族参战成员在5分钟内迅速入场！" c="ffddbb77"></T>
				Message.sendSystemMsg(102011, null);
				break;
			}
		} else if (fightType == 1) {
			switch (curRound) {
			case FamilyModule.CROSS_FAMILY_32:
				//102009  本周家族战八强战将于15分钟后开始，请各个参战家族的勇士们做好准备！  4
				Message.sendSystemMsg(1029122, null);
				break;
			case FamilyModule.CROSS_FAMILY_16:
				//102010  本周家族战四强战将于15分钟后开始，请各个参战家族的勇士们做好准备！  4
				Message.sendSystemMsg(102010, null);
				break;
			case FamilyModule.CROSS_FAMILY_8:
				//102011  本周家族战冠军战将于15分钟后开始，请各个参战家族的勇士们做好准备！  4
				Message.sendSystemMsg(102011, null);
				break;
			case FamilyModule.CROSS_FAMILY_4:
				//102011  本周家族战冠军战将于15分钟后开始，请各个参战家族的勇士们做好准备！  4
				Message.sendSystemMsg(102011, null);
				break;
			case FamilyModule.CROSS_FAMILY_2:
				//102011  本周家族战冠军战将于15分钟后开始，请各个参战家族的勇士们做好准备！  4
				Message.sendSystemMsg(102011, null);
				break;
			}
		}
	}
	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925935;

	public int getType() {
		return 925935;
	}


	public GlGsCrossFamilyPreMsg() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsCrossFamilyPreMsg) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsCrossFamilyPreMsg _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

