
package global.rsp.family;
import java.util.ArrayList;

import knight.gsp.LocalIds;
import knight.gsp.award.Item;
import knight.gsp.item.EmailBox;
import knight.gsp.item.ItemAttr;
import knight.gsp.util.DateValidate;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendAwardToOriginalServer__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendAwardToOriginalServer extends __SendAwardToOriginalServer__ {
	@Override
	protected void process() {
		if(LocalIds.isRemoteServerRole(roleid))
			return;
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				xbean.Properties properties = xtable.Properties.get(roleid);
				if(properties == null)
					return false;
				if(DateValidate.inTheSameDay(properties.getReceivefamilygatherawardtime(), System.currentTimeMillis())){
					return false;
				}
				int mailId = 46;
				ArrayList<String> paramList = new ArrayList<String>();
				paramList.add(familyname);
				int exp = items.get(Item.EXP_ITEM);
				int money = items.get(Item.MONEY_ITEM1);
				if(goalscore != familyscore){
					mailId = 47;
				} else {
					long time = DateValidate.getDayFirstSecond(System.currentTimeMillis()) + finishtime;
					String date = DateValidate.formatTimeByType(time, DateValidate.YYYYMMDDHHmmss);
					paramList.add(date.split(" ")[1]);
				}
				paramList.add(String.valueOf(myscore));
				paramList.add(String.valueOf(exp));
				paramList.add(String.valueOf(money));
				for(int itemId : items.keySet()){
					if(Item.isMoney(itemId) || itemId == Item.EXP_ITEM)
						continue;
					paramList.add(items.get(itemId) + "");
					ItemAttr itemAttr = knight.gsp.item.Module.getInstance().getItemManager().getAttr(itemId);
					if(itemAttr == null){
						continue;
					}
					paramList.add(itemAttr.name);
				}
				properties.setReceivefamilygatherawardtime(System.currentTimeMillis());
				new EmailBox(roleid, false).sendMailWithGivenItems(mailId, null, paramList, null, items, null);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925912;

	public int getType() {
		return 925912;
	}

	public long roleid; // 角色id
	public long finishtime; // 完成时间
	public int familyscore; // 达成采集度
	public int goalscore; // 目标采集度
	public int myscore; // 我的采集度
	public java.lang.String familyname; // 家族名称
	public java.util.HashMap<Integer,Integer> items; // 奖励

	public SendAwardToOriginalServer() {
		familyname = "";
		items = new java.util.HashMap<Integer,Integer>();
	}

	public SendAwardToOriginalServer(long _roleid_, long _finishtime_, int _familyscore_, int _goalscore_, int _myscore_, java.lang.String _familyname_, java.util.HashMap<Integer,Integer> _items_) {
		this.roleid = _roleid_;
		this.finishtime = _finishtime_;
		this.familyscore = _familyscore_;
		this.goalscore = _goalscore_;
		this.myscore = _myscore_;
		this.familyname = _familyname_;
		this.items = _items_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(finishtime);
		_os_.marshal(familyscore);
		_os_.marshal(goalscore);
		_os_.marshal(myscore);
		_os_.marshal(familyname, "UTF-16LE");
		_os_.compact_uint32(items.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : items.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		finishtime = _os_.unmarshal_long();
		familyscore = _os_.unmarshal_int();
		goalscore = _os_.unmarshal_int();
		myscore = _os_.unmarshal_int();
		familyname = _os_.unmarshal_String("UTF-16LE");
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			items.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendAwardToOriginalServer) {
			SendAwardToOriginalServer _o_ = (SendAwardToOriginalServer)_o1_;
			if (roleid != _o_.roleid) return false;
			if (finishtime != _o_.finishtime) return false;
			if (familyscore != _o_.familyscore) return false;
			if (goalscore != _o_.goalscore) return false;
			if (myscore != _o_.myscore) return false;
			if (!familyname.equals(_o_.familyname)) return false;
			if (!items.equals(_o_.items)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)finishtime;
		_h_ += familyscore;
		_h_ += goalscore;
		_h_ += myscore;
		_h_ += familyname.hashCode();
		_h_ += items.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(finishtime).append(",");
		_sb_.append(familyscore).append(",");
		_sb_.append(goalscore).append(",");
		_sb_.append(myscore).append(",");
		_sb_.append("T").append(familyname.length()).append(",");
		_sb_.append(items).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

