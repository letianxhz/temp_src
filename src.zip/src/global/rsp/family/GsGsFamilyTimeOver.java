
package global.rsp.family;
import java.util.Arrays;
import java.util.HashSet;

import knight.gsp.family.FamilyModule;
import knight.gsp.family.familygather.SStartFamilyGather;
import knight.gsp.log.LogUtil;
import knight.gsp.main.ConfigManager;
import knight.gsp.map.SceneManager;
import knight.gsp.msg.Message;
import knight.gsp.util.StringValidateUtil;
import gnet.link.Onlines;





// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGsFamilyTimeOver__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGsFamilyTimeOver extends __GsGsFamilyTimeOver__ {
	@Override
	protected void process() {
		new xdb.Procedure(){
			@Override
			protected boolean process() throws Exception {
				xbean.FamilyGatherInfo info = xtable.Familygatherinfo.get(familykey);
				if(info == null)
					return false;
				info.setDestserverid(0);
				info.setBattlesceneid(0);
				if(info.getAchievedgoal() == 0){
					info.setAchievedgoal(xbean.FamilyGatherInfo.FAIL);
				}
				xbean.FamilyInfoBean infoBean = xtable.Families.select(familykey);
				if(infoBean == null)
					return false;
				LogUtil.doFamilyGatherEndLog(infoBean.getFamilyname(), familyscore, ConfigManager.getGsZoneId(), familykey, camp);
				// 获取玩家锁
				lock(xtable.Locks.ROLELOCK, infoBean.getMembers());
				// 发送活动结束标志
				HashSet<Long> set = new HashSet<Long>(infoBean.getMembers());
				Onlines.getInstance().send(set, new SStartFamilyGather(-1));
				// 修改玩家离线位置数据
				for(long rid : infoBean.getMembers()){
					xbean.Properties prop = xtable.Properties.get(rid);
					if(prop == null)
						continue;
					if(SceneManager.getInstance().isFamilyGatherScene(prop.getSceneid())){
						prop.setSceneid(prop.getLaststaticsceneid());
						prop.setPosx(prop.getLaststaticposx());
						prop.setPosy(prop.getLaststaticposy());
						prop.setPosz(prop.getLaststaticposz());
					}
					xbean.CrossState crossstate = xtable.Crossstate.get(rid);
					if(crossstate != null && SceneManager.getInstance().isFamilyGatherScene(crossstate.getSceneid())){
						xtable.Crossstate.remove(rid);
					}
				}
				if(rank != 0 && !StringValidateUtil.isBlank(championrolename)){
					Message.psendFamilyMsgNotify(familykey, 1039057, Arrays.asList(rank + "", championrolename), FamilyModule.FAMILY_ZONGGUAN_NPC_ID);
				}
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925918;

	public int getType() {
		return 925918;
	}

	public long familykey; // 家族key
	public int rank; // 家族在当前场景的排名
	public java.lang.String championrolename; // 家族中采集分数最高者
	public int camp; // 阵营
	public int familyscore; // 采集积分

	public GsGsFamilyTimeOver() {
		championrolename = "";
	}

	public GsGsFamilyTimeOver(long _familykey_, int _rank_, java.lang.String _championrolename_, int _camp_, int _familyscore_) {
		this.familykey = _familykey_;
		this.rank = _rank_;
		this.championrolename = _championrolename_;
		this.camp = _camp_;
		this.familyscore = _familyscore_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(familykey);
		_os_.marshal(rank);
		_os_.marshal(championrolename, "UTF-16LE");
		_os_.marshal(camp);
		_os_.marshal(familyscore);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		familykey = _os_.unmarshal_long();
		rank = _os_.unmarshal_int();
		championrolename = _os_.unmarshal_String("UTF-16LE");
		camp = _os_.unmarshal_int();
		familyscore = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGsFamilyTimeOver) {
			GsGsFamilyTimeOver _o_ = (GsGsFamilyTimeOver)_o1_;
			if (familykey != _o_.familykey) return false;
			if (rank != _o_.rank) return false;
			if (!championrolename.equals(_o_.championrolename)) return false;
			if (camp != _o_.camp) return false;
			if (familyscore != _o_.familyscore) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)familykey;
		_h_ += rank;
		_h_ += championrolename.hashCode();
		_h_ += camp;
		_h_ += familyscore;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familykey).append(",");
		_sb_.append(rank).append(",");
		_sb_.append("T").append(championrolename.length()).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(familyscore).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

