
package global.rsp.family;
import knight.gsp.family.familygather.PCreateFamilyGatherScene;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsCreateFamilyGatherScene__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsCreateFamilyGatherScene extends __GlGsCreateFamilyGatherScene__ {
	@Override
	protected void process() {
		new PCreateFamilyGatherScene(familyinfos).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925907;

	public int getType() {
		return 925907;
	}

	public java.util.ArrayList<global.rsp.family.FamilyGatherProtocol> familyinfos;

	public GlGsCreateFamilyGatherScene() {
		familyinfos = new java.util.ArrayList<global.rsp.family.FamilyGatherProtocol>();
	}

	public GlGsCreateFamilyGatherScene(java.util.ArrayList<global.rsp.family.FamilyGatherProtocol> _familyinfos_) {
		this.familyinfos = _familyinfos_;
	}

	public final boolean _validator_() {
		for (global.rsp.family.FamilyGatherProtocol _v_ : familyinfos)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(familyinfos.size());
		for (global.rsp.family.FamilyGatherProtocol _v_ : familyinfos) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.family.FamilyGatherProtocol _v_ = new global.rsp.family.FamilyGatherProtocol();
			_v_.unmarshal(_os_);
			familyinfos.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsCreateFamilyGatherScene) {
			GlGsCreateFamilyGatherScene _o_ = (GlGsCreateFamilyGatherScene)_o1_;
			if (!familyinfos.equals(_o_.familyinfos)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += familyinfos.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familyinfos).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

