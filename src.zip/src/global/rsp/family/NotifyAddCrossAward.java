
package global.rsp.family;
import java.util.HashMap;
import java.util.Map;
import knight.gsp.PAddExpProc.EXP_TYPE;
import knight.gsp.award.AwardManager;
import knight.gsp.family.crossfamilybattle.GsCrossFamilyBattleManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyAddCrossAward__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyAddCrossAward extends __NotifyAddCrossAward__ {
	@Override
	protected void process() {
		if (awardtype == 0) {
			GsCrossFamilyBattleManager.getInstance().giveTakePartInAward(roles, awardid);
		} else if (awardtype == 1) {
			new xdb.Procedure(){
				protected boolean process() throws Exception {
					Map<String, Object> paras = new HashMap<String, Object>();
					paras.put(AwardManager.FAMILY_SCORE, score);
					xdb.Lockeys.lock(xtable.Locks.ROLELOCK, roles);
					for (long roleid : roles) {
						AwardManager.getInstance().distributeAllAward(roleid, awardid, paras, EXP_TYPE.CROSS_FAMILY_FIGHT, 0,"跨服家族战");
					}
					return true;
				};
			}.submit();
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925933;

	public int getType() {
		return 925933;
	}

	public byte awardtype; // 奖励类型 0:参与奖励 1:结算奖励
	public java.util.HashSet<Long> roles; // 跨服的角色
	public int awardid; // 奖励id
	public int score; // 奖励附加参数

	public NotifyAddCrossAward() {
		roles = new java.util.HashSet<Long>();
	}

	public NotifyAddCrossAward(byte _awardtype_, java.util.HashSet<Long> _roles_, int _awardid_, int _score_) {
		this.awardtype = _awardtype_;
		this.roles = _roles_;
		this.awardid = _awardid_;
		this.score = _score_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(awardtype);
		_os_.compact_uint32(roles.size());
		for (Long _v_ : roles) {
			_os_.marshal(_v_);
		}
		_os_.marshal(awardid);
		_os_.marshal(score);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		awardtype = _os_.unmarshal_byte();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			roles.add(_v_);
		}
		awardid = _os_.unmarshal_int();
		score = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyAddCrossAward) {
			NotifyAddCrossAward _o_ = (NotifyAddCrossAward)_o1_;
			if (awardtype != _o_.awardtype) return false;
			if (!roles.equals(_o_.roles)) return false;
			if (awardid != _o_.awardid) return false;
			if (score != _o_.score) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)awardtype;
		_h_ += roles.hashCode();
		_h_ += awardid;
		_h_ += score;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(awardtype).append(",");
		_sb_.append(roles).append(",");
		_sb_.append(awardid).append(",");
		_sb_.append(score).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

