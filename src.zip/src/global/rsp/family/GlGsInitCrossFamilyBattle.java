
package global.rsp.family;
import knight.gsp.family.crossfamilybattle.GsCrossFamilyBattleManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsInitCrossFamilyBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsInitCrossFamilyBattle extends __GlGsInitCrossFamilyBattle__ {
	@Override
	protected void process() {
		GsCrossFamilyBattleManager.getInstance().createCrossFamilyBattleScene(familyinfos, familyteamindex);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925928;

	public int getType() {
		return 925928;
	}

	public java.util.HashMap<Long,global.rsp.family.CrossFamilyInfo> familyinfos; // 对战家族信息
	public int familyteamindex; // 家族对战队伍索引

	public GlGsInitCrossFamilyBattle() {
		familyinfos = new java.util.HashMap<Long,global.rsp.family.CrossFamilyInfo>();
	}

	public GlGsInitCrossFamilyBattle(java.util.HashMap<Long,global.rsp.family.CrossFamilyInfo> _familyinfos_, int _familyteamindex_) {
		this.familyinfos = _familyinfos_;
		this.familyteamindex = _familyteamindex_;
	}

	public final boolean _validator_() {
		for (java.util.Map.Entry<Long, global.rsp.family.CrossFamilyInfo> _e_ : familyinfos.entrySet()) {
			if (!_e_.getValue()._validator_()) return false;
		}
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(familyinfos.size());
		for (java.util.Map.Entry<Long, global.rsp.family.CrossFamilyInfo> _e_ : familyinfos.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(familyteamindex);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			global.rsp.family.CrossFamilyInfo _v_ = new global.rsp.family.CrossFamilyInfo();
			_v_.unmarshal(_os_);
			familyinfos.put(_k_, _v_);
		}
		familyteamindex = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsInitCrossFamilyBattle) {
			GlGsInitCrossFamilyBattle _o_ = (GlGsInitCrossFamilyBattle)_o1_;
			if (!familyinfos.equals(_o_.familyinfos)) return false;
			if (familyteamindex != _o_.familyteamindex) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += familyinfos.hashCode();
		_h_ += familyteamindex;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familyinfos).append(",");
		_sb_.append(familyteamindex).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

