
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlFamilyTimeOver__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlFamilyTimeOver extends __GsGlFamilyTimeOver__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925913;

	public int getType() {
		return 925913;
	}

	public long sceneid; // 场景id
	public int zoneid; // 服务器id
	public long familykey; // 家族key
	public int camp; // 阵营

	public GsGlFamilyTimeOver() {
	}

	public GsGlFamilyTimeOver(long _sceneid_, int _zoneid_, long _familykey_, int _camp_) {
		this.sceneid = _sceneid_;
		this.zoneid = _zoneid_;
		this.familykey = _familykey_;
		this.camp = _camp_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(sceneid);
		_os_.marshal(zoneid);
		_os_.marshal(familykey);
		_os_.marshal(camp);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		sceneid = _os_.unmarshal_long();
		zoneid = _os_.unmarshal_int();
		familykey = _os_.unmarshal_long();
		camp = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlFamilyTimeOver) {
			GsGlFamilyTimeOver _o_ = (GsGlFamilyTimeOver)_o1_;
			if (sceneid != _o_.sceneid) return false;
			if (zoneid != _o_.zoneid) return false;
			if (familykey != _o_.familykey) return false;
			if (camp != _o_.camp) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)sceneid;
		_h_ += zoneid;
		_h_ += (int)familykey;
		_h_ += camp;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(sceneid).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(familykey).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GsGlFamilyTimeOver _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(familykey - _o_.familykey);
		if (0 != _c_) return _c_;
		_c_ = camp - _o_.camp;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

