
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlFamilyGatherBeanRegist__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlFamilyGatherBeanRegist extends __GsGlFamilyGatherBeanRegist__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925920;

	public int getType() {
		return 925920;
	}

	public int action; // 1-更改时间
	public global.rsp.family.FamilyGatherProtocol familyinfo;

	public GsGlFamilyGatherBeanRegist() {
		familyinfo = new global.rsp.family.FamilyGatherProtocol();
	}

	public GsGlFamilyGatherBeanRegist(int _action_, global.rsp.family.FamilyGatherProtocol _familyinfo_) {
		this.action = _action_;
		this.familyinfo = _familyinfo_;
	}

	public final boolean _validator_() {
		if (!familyinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(action);
		_os_.marshal(familyinfo);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		action = _os_.unmarshal_int();
		familyinfo.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlFamilyGatherBeanRegist) {
			GsGlFamilyGatherBeanRegist _o_ = (GsGlFamilyGatherBeanRegist)_o1_;
			if (action != _o_.action) return false;
			if (!familyinfo.equals(_o_.familyinfo)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += action;
		_h_ += familyinfo.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(action).append(",");
		_sb_.append(familyinfo).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

