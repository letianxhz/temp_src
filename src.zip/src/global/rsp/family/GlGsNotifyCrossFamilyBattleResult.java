
package global.rsp.family;
import knight.gsp.family.FamilyModule;
import knight.gsp.family.crossfamilybattle.GsCrossFamilyBattleManager;
import knight.gsp.family.crossfamilybattle.PAwardFirstFamily;
import knight.gsp.msg.Message;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsNotifyCrossFamilyBattleResult__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsNotifyCrossFamilyBattleResult extends __GlGsNotifyCrossFamilyBattleResult__ {
	@Override
	protected void process() {
		new xdb.Procedure(){
			protected boolean process() throws Exception {
				
				if (fighttype == 0) {//8个家族晋级
					switch (battlecount) { //索引还用原来非跨服的值吧
						case FamilyModule.FAMILY_4:
							//1029134 <T t="本届首轮跨服家族战已结束，恭喜$parameter1$、$parameter2$、$parameter3$、$parameter4$成功晋级全服4强家族！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029134, winfamilys);
							break;
						case FamilyModule.FAMILY_2:
							//1029135 <T t="本届第二轮跨服家族战已结束，恭喜$parameter1$、$parameter2$成功晋级！10分钟后将会进行最强家族之间的对决，最强家族！谁与争锋！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029135, winfamilys);
							break;
						case FamilyModule.FAMILY_1:
							//1029132  <T t="本届跨服家族战已圆满结束，恭喜$parameter1$家族在本届跨服家族战中成功登顶！鲜血与荣耀同在！暗黑大陆最强家族诞生！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029132, winfamilys);
							break;
						default:
							break;
					}
				} else if (fighttype == 1) {//32个家族晋级
					switch (battlecount) {
						case FamilyModule.CROSS_FAMILY_16:
							//1029124<T t="本届首轮跨服家族战已结束，恭喜获胜的家族成功晋级全服16强家族！第二轮跨服家族战将于10分钟后开始！请参赛人员做好准备！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029124, null);
							break;
						case FamilyModule.CROSS_FAMILY_8:
							//1029126  <T t="本届第二轮跨服家族战已结束，恭喜获胜的家族成功晋级全服8强家族！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029126, null);
							break;
						case FamilyModule.CROSS_FAMILY_4:
							//1029128  <T t="本届第三轮跨服家族战已结束，恭喜$parameter1$、$parameter2$、$parameter3$、$parameter4$成功晋级全服4强家族！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029128, winfamilys);
							break;
						case FamilyModule.CROSS_FAMILY_2:
							//1029130  <T t="本届第四轮跨服家族战已结束，恭喜$parameter1$、$parameter2$成功晋级！5分钟后将会进行最强家族之间的对决，最强家族！谁与争锋！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029130, winfamilys);
							break;
						case FamilyModule.CROSS_FAMILY_1:
							//1029132  <T t="本届跨服家族战已圆满结束，恭喜$parameter1$家族在本届跨服家族战中成功登顶！鲜血与荣耀同在！暗黑大陆最强家族诞生！" c="ffddbb77"></T>
							Message.sendSystemMsg(1029132, winfamilys);
							break;
						default:
							break;
					}
				}
				GsCrossFamilyBattleManager.getInstance().updateCrossFamilyBattleData(crossfmailybattledata);
				//冠军出来了就给冠军家族发奖了,给参赛家族族长分配奖励
				global.rsp.family.CrossFamilytBattleRoundResult roundResult = getCurrentRound();
				if (null != roundResult && roundResult.roundresults.size() == 1) {
					GsCrossFamilyBattleManager.getInstance().setDuringCrossFamilyPeriod(false);
					xdb.Procedure.pexecuteWhileCommit(new PAwardFirstFamily());
				}
				return true;
			};
		}.submit();
	}
	
	public global.rsp.family.CrossFamilytBattleRoundResult getCurrentRound() {
		if (crossfmailybattledata.roundresults.size() < 1) 
			return null;
		return crossfmailybattledata.roundresults.get(battlecount);
	}
	
	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925937;

	public int getType() {
		return 925937;
	}

	public java.util.LinkedList<java.lang.String> winfamilys; // 获胜的家族(在晋级出4强时才填充数据)
	public int fighttype; // 对战类型 0:8个家族晋级 1:32个家族晋级
	public int battlecount; // 当前轮数
	public global.rsp.family.CrossFamilytBattle crossfmailybattledata; // 新的对战信息也下发下去

	public GlGsNotifyCrossFamilyBattleResult() {
		winfamilys = new java.util.LinkedList<java.lang.String>();
		crossfmailybattledata = new global.rsp.family.CrossFamilytBattle();
	}

	public GlGsNotifyCrossFamilyBattleResult(java.util.LinkedList<java.lang.String> _winfamilys_, int _fighttype_, int _battlecount_, global.rsp.family.CrossFamilytBattle _crossfmailybattledata_) {
		this.winfamilys = _winfamilys_;
		this.fighttype = _fighttype_;
		this.battlecount = _battlecount_;
		this.crossfmailybattledata = _crossfmailybattledata_;
	}

	public final boolean _validator_() {
		if (!crossfmailybattledata._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(winfamilys.size());
		for (java.lang.String _v_ : winfamilys) {
			_os_.marshal(_v_, "UTF-16LE");
		}
		_os_.marshal(fighttype);
		_os_.marshal(battlecount);
		_os_.marshal(crossfmailybattledata);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			java.lang.String _v_;
			_v_ = _os_.unmarshal_String("UTF-16LE");
			winfamilys.add(_v_);
		}
		fighttype = _os_.unmarshal_int();
		battlecount = _os_.unmarshal_int();
		crossfmailybattledata.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsNotifyCrossFamilyBattleResult) {
			GlGsNotifyCrossFamilyBattleResult _o_ = (GlGsNotifyCrossFamilyBattleResult)_o1_;
			if (!winfamilys.equals(_o_.winfamilys)) return false;
			if (fighttype != _o_.fighttype) return false;
			if (battlecount != _o_.battlecount) return false;
			if (!crossfmailybattledata.equals(_o_.crossfmailybattledata)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += winfamilys.hashCode();
		_h_ += fighttype;
		_h_ += battlecount;
		_h_ += crossfmailybattledata.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(winfamilys).append(",");
		_sb_.append(fighttype).append(",");
		_sb_.append(battlecount).append(",");
		_sb_.append(crossfmailybattledata).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

