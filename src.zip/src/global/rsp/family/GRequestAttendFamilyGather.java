
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GRequestAttendFamilyGather__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GRequestAttendFamilyGather extends __GRequestAttendFamilyGather__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925905;

	public int getType() {
		return 925905;
	}

	public int zoneid; // 服务器id
	public long familykey; // 家族key
	public int camp; // 阵营
	public long roleid; // 角色id

	public GRequestAttendFamilyGather() {
	}

	public GRequestAttendFamilyGather(int _zoneid_, long _familykey_, int _camp_, long _roleid_) {
		this.zoneid = _zoneid_;
		this.familykey = _familykey_;
		this.camp = _camp_;
		this.roleid = _roleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(familykey);
		_os_.marshal(camp);
		_os_.marshal(roleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_int();
		familykey = _os_.unmarshal_long();
		camp = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GRequestAttendFamilyGather) {
			GRequestAttendFamilyGather _o_ = (GRequestAttendFamilyGather)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (familykey != _o_.familykey) return false;
			if (camp != _o_.camp) return false;
			if (roleid != _o_.roleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += zoneid;
		_h_ += (int)familykey;
		_h_ += camp;
		_h_ += (int)roleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(familykey).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GRequestAttendFamilyGather _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(familykey - _o_.familykey);
		if (0 != _c_) return _c_;
		_c_ = camp - _o_.camp;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

