
package global.rsp.family;
import knight.gsp.family.crossfamilybattle.GsCrossFamilyBattleManager;
import knight.gsp.family.crossfamilybattle.PGiveCrossFightOverAward;
import knight.gsp.family.familybattle.FamilyBattleTeamResultData;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsBytoQualify__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsBytoQualify extends __GlGsBytoQualify__ {
	@Override
	protected void process() {
		new xdb.Procedure(){
			protected boolean process() throws Exception {
				//更新本地数据
				GsCrossFamilyBattleManager.getInstance().updateCrossFamilyBattleData(crossfmailybattledata);
				global.rsp.family.CrossFamilytBattleRoundResult pBattleRoundResult = crossfmailybattledata.roundresults.get(battlecount);
				if (null == pBattleRoundResult)
					return false;
				giveAward(winfamilykey, -1L, pBattleRoundResult, crossfmailybattledata, battlecount);
				return true;
			};
		}.submit();
	}
	
	//给予结算奖励
	private void giveAward(long winFamilyKey, long loseFamilyKey, CrossFamilytBattleRoundResult curResult, CrossFamilytBattle battleinfo, int awardRound) {
		if (winFamilyKey > 0)
			giveSingleFamilyAward(winFamilyKey, 1, curResult, battleinfo, awardRound, 0, 0);
	}
		
	private void giveSingleFamilyAward(long familykey, int result, CrossFamilytBattleRoundResult curResult, 
				CrossFamilytBattle battleinfo, int awardRound, long mostScoreId, long mostKillId) {
		global.rsp.family.CrossBattleFamily battleFamily = null;
		for (global.rsp.family.CrossBattleFamily checkFamily : curResult.roundresults.values()) {
			if (checkFamily.famillykey == familykey) {
				battleFamily = checkFamily;
				break;
			}
		}
		if (battleFamily == null)
			return;
			
		global.rsp.family.CrossBattleFamilyTeams teams = battleinfo.familyteams.get(familykey);
		if (teams == null)
			return;
			
		FamilyBattleTeamResultData data = new FamilyBattleTeamResultData();
		data.setAwardRound(awardRound);
		data.setMostKillId(mostKillId);
		data.setMostKillNum(0);
		data.setMostScore(0);
		data.setMostScoreId(mostScoreId);
		data.setResult(result);
			
		for(global.rsp.family.CrossBattleFamilyTeam team : teams.teams) {
			for(long rid : team.members) {
				xdb.Procedure.pexecuteWhileCommit(new PGiveCrossFightOverAward(rid, data, null, battleFamily.serverid));
			}
		}
	}
	
	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925942;

	public int getType() {
		return 925942;
	}

	public long winfamilykey; // 轮空获胜的家族
	public int battlecount; // 当前轮数
	public global.rsp.family.CrossFamilytBattle crossfmailybattledata; // 新的对战信息也下发下去

	public GlGsBytoQualify() {
		crossfmailybattledata = new global.rsp.family.CrossFamilytBattle();
	}

	public GlGsBytoQualify(long _winfamilykey_, int _battlecount_, global.rsp.family.CrossFamilytBattle _crossfmailybattledata_) {
		this.winfamilykey = _winfamilykey_;
		this.battlecount = _battlecount_;
		this.crossfmailybattledata = _crossfmailybattledata_;
	}

	public final boolean _validator_() {
		if (!crossfmailybattledata._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(winfamilykey);
		_os_.marshal(battlecount);
		_os_.marshal(crossfmailybattledata);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		winfamilykey = _os_.unmarshal_long();
		battlecount = _os_.unmarshal_int();
		crossfmailybattledata.unmarshal(_os_);
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsBytoQualify) {
			GlGsBytoQualify _o_ = (GlGsBytoQualify)_o1_;
			if (winfamilykey != _o_.winfamilykey) return false;
			if (battlecount != _o_.battlecount) return false;
			if (!crossfmailybattledata.equals(_o_.crossfmailybattledata)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)winfamilykey;
		_h_ += battlecount;
		_h_ += crossfmailybattledata.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(winfamilykey).append(",");
		_sb_.append(battlecount).append(",");
		_sb_.append(crossfmailybattledata).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

