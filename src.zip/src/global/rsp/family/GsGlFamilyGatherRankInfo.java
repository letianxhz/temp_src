
package global.rsp.family;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlFamilyGatherRankInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlFamilyGatherRankInfo extends __GsGlFamilyGatherRankInfo__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925910;

	public int getType() {
		return 925910;
	}

	public global.rsp.family.FamilyGatherProtocol familyinfo;
	public int familyscore; // 家族采集度
	public long finishtime; // 完成时间

	public GsGlFamilyGatherRankInfo() {
		familyinfo = new global.rsp.family.FamilyGatherProtocol();
	}

	public GsGlFamilyGatherRankInfo(global.rsp.family.FamilyGatherProtocol _familyinfo_, int _familyscore_, long _finishtime_) {
		this.familyinfo = _familyinfo_;
		this.familyscore = _familyscore_;
		this.finishtime = _finishtime_;
	}

	public final boolean _validator_() {
		if (!familyinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(familyinfo);
		_os_.marshal(familyscore);
		_os_.marshal(finishtime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		familyinfo.unmarshal(_os_);
		familyscore = _os_.unmarshal_int();
		finishtime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlFamilyGatherRankInfo) {
			GsGlFamilyGatherRankInfo _o_ = (GsGlFamilyGatherRankInfo)_o1_;
			if (!familyinfo.equals(_o_.familyinfo)) return false;
			if (familyscore != _o_.familyscore) return false;
			if (finishtime != _o_.finishtime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += familyinfo.hashCode();
		_h_ += familyscore;
		_h_ += (int)finishtime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(familyinfo).append(",");
		_sb_.append(familyscore).append(",");
		_sb_.append(finishtime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

