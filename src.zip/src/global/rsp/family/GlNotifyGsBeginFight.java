
package global.rsp.family;
import java.util.Map.Entry;
import knight.gsp.family.FamilyModule;
import knight.gsp.family.crossfamilybattle.CrossFamilyBattleData;
import knight.gsp.msg.Message;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlNotifyGsBeginFight__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlNotifyGsBeginFight extends __GlNotifyGsBeginFight__ {
	@Override
	protected void process() {
		new xdb.Procedure() {
			protected boolean process() throws Exception {
				xbean.FamilyIndexBean indexBean = xtable.Familyindex.select(1);
				if (indexBean != null) {
					for(Entry<Integer, Long> entry : indexBean.getIndex().entrySet()) {
						long familyKey = entry.getValue();
						//通知玩家跨服家族战开打了，可以观战了
						Message.sendFamilyMsgNotify(familyKey, 1029138, null, FamilyModule.FAMILY_ZONGGUAN_NPC_ID);
			    	}
				}
				//设置一下。正式开打了
				new CrossFamilyBattleData(false).setInBattlePeriod((byte) 2);
				return true;
			};
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925931;

	public int getType() {
		return 925931;
	}


	public GlNotifyGsBeginFight() {
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlNotifyGsBeginFight) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlNotifyGsBeginFight _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

