
package global.rsp;
import knight.gsp.ledo.auth.PUpDateGlobalJbpAccProc;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SRspAccBindState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SRspAccBindState extends __SRspAccBindState__ {
	@Override
	protected void process() {
		xdb.Trace.info("SRspAccBindState  roleid="+roleid  +"  phonenum="+phonenum + "  flag="+flag + "  ledouid="+ledouid);
		new PUpDateGlobalJbpAccProc(roleid, phonenum, flag, ledouid).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918228;

	public int getType() {
		return 918228;
	}

	public long roleid; // 角色id
	public java.lang.String phonenum; // bind成功电话号不为空
	public java.lang.String ledouid; // 乐道uid
	public int flag; // 1=查询  2=bind

	public SRspAccBindState() {
		phonenum = "";
		ledouid = "";
	}

	public SRspAccBindState(long _roleid_, java.lang.String _phonenum_, java.lang.String _ledouid_, int _flag_) {
		this.roleid = _roleid_;
		this.phonenum = _phonenum_;
		this.ledouid = _ledouid_;
		this.flag = _flag_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(phonenum, "UTF-16LE");
		_os_.marshal(ledouid, "UTF-16LE");
		_os_.marshal(flag);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		phonenum = _os_.unmarshal_String("UTF-16LE");
		ledouid = _os_.unmarshal_String("UTF-16LE");
		flag = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SRspAccBindState) {
			SRspAccBindState _o_ = (SRspAccBindState)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!phonenum.equals(_o_.phonenum)) return false;
			if (!ledouid.equals(_o_.ledouid)) return false;
			if (flag != _o_.flag) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += phonenum.hashCode();
		_h_ += ledouid.hashCode();
		_h_ += flag;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append("T").append(phonenum.length()).append(",");
		_sb_.append("T").append(ledouid.length()).append(",");
		_sb_.append(flag).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

