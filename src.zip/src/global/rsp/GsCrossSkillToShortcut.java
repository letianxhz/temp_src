
package global.rsp;
import knight.gsp.LocalIds;
import knight.gsp.skill.SkillRole;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsCrossSkillToShortcut__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsCrossSkillToShortcut extends __GsCrossSkillToShortcut__ {
	@Override
	protected void process() {
		if (LocalIds.isRemoteServerRole(fromroleid)) 
			return;
		new xdb.Procedure(){
			@Override
			public boolean process(){
				return new SkillRole(fromroleid, false).skillToShortcut(battlegs, skillid, shortcut2id);
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918225;

	public int getType() {
		return 918225;
	}

	public long fromroleid;
	public int battlegs;
	public int skillid;
	public short shortcut2id;

	public GsCrossSkillToShortcut() {
	}

	public GsCrossSkillToShortcut(long _fromroleid_, int _battlegs_, int _skillid_, short _shortcut2id_) {
		this.fromroleid = _fromroleid_;
		this.battlegs = _battlegs_;
		this.skillid = _skillid_;
		this.shortcut2id = _shortcut2id_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fromroleid);
		_os_.marshal(battlegs);
		_os_.marshal(skillid);
		_os_.marshal(shortcut2id);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fromroleid = _os_.unmarshal_long();
		battlegs = _os_.unmarshal_int();
		skillid = _os_.unmarshal_int();
		shortcut2id = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsCrossSkillToShortcut) {
			GsCrossSkillToShortcut _o_ = (GsCrossSkillToShortcut)_o1_;
			if (fromroleid != _o_.fromroleid) return false;
			if (battlegs != _o_.battlegs) return false;
			if (skillid != _o_.skillid) return false;
			if (shortcut2id != _o_.shortcut2id) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)fromroleid;
		_h_ += battlegs;
		_h_ += skillid;
		_h_ += shortcut2id;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fromroleid).append(",");
		_sb_.append(battlegs).append(",");
		_sb_.append(skillid).append(",");
		_sb_.append(shortcut2id).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GsCrossSkillToShortcut _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(fromroleid - _o_.fromroleid);
		if (0 != _c_) return _c_;
		_c_ = battlegs - _o_.battlegs;
		if (0 != _c_) return _c_;
		_c_ = skillid - _o_.skillid;
		if (0 != _c_) return _c_;
		_c_ = shortcut2id - _o_.shortcut2id;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

