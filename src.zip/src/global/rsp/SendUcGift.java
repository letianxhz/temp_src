
package global.rsp;

import knight.gsp.LocalIds;
import knight.gsp.item.EmailBox;
import knight.gsp.util.DateValidate;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendUcGift__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendUcGift extends __SendUcGift__ {
	@Override
	protected void process() {
		if (LocalIds.isRemoteServerRole(roleid))
			return;
		
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				xbean.UcAwardRecords records = xtable.Ucawardrecords.get(roleid);
				if (records == null) {
					records = xbean.Pod.newUcAwardRecords();
					xtable.Ucawardrecords.insert(roleid, records);
				}
				xbean.UcAwardRecord record = records.getRecords().get(giftid);
				if (record == null) {
					record = xbean.Pod.newUcAwardRecord();
					records.getRecords().put(giftid, record);
				}
				
				long now = System.currentTimeMillis();
				if (DateValidate.inTheSameDay(now, record.getLastawardtime()))
					return false;  //今天已经领过了
				
				record.setLastawardtime(now);
				
				knight.gsp.log.Module.logger.info("UC role : " + roleid + " take email award: " + giftid);
				
				return new EmailBox(roleid, false).sendMail(giftid);
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918208;

	public int getType() {
		return 918208;
	}

	public long roleid; // gm命令名字
	public int giftid; // 礼包id

	public SendUcGift() {
	}

	public SendUcGift(long _roleid_, int _giftid_) {
		this.roleid = _roleid_;
		this.giftid = _giftid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(giftid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		giftid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendUcGift) {
			SendUcGift _o_ = (SendUcGift)_o1_;
			if (roleid != _o_.roleid) return false;
			if (giftid != _o_.giftid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += giftid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(giftid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(SendUcGift _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = giftid - _o_.giftid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

