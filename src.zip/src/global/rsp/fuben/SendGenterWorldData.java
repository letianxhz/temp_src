
package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import knight.gsp.main.ConfigManager;
import knight.msp.GEnterWorld;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendGenterWorldData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendGenterWorldData extends __SendGenterWorldData__ {
	@Override
	protected void process() {

		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				
				//清除一遍，以防万一
				xtable.Crossroles.remove(roleid);
				xtable.Crossgenterworld.remove(roleid);
				
				xbean.CrossGenterWorld crossGEnterWorld = xbean.Pod.newCrossGenterWorld();
				xtable.Crossgenterworld.insert(roleid, crossGEnterWorld);
				OctetsStream octstram = OctetsStream.wrap(genterworld);
				GEnterWorld gsnd = new GEnterWorld();
				try {
					gsnd.unmarshal(octstram);

					crossGEnterWorld.setGenterworld(gsnd);

				} catch (MarshalException e) {
					e.printStackTrace();
				}
				
				xbean.CrossRole crossRole = xbean.Pod.newCrossRole();
				xtable.Crossroles.insert(roleid, crossRole);
				
				/*
				 * 跨服用户的渠道名和渠道ID
				 */
				crossRole.setRolename(rolename);
				crossRole.setNickname(nickname);
				crossRole.setUsername(username);
				crossRole.setUserid(userid);
				crossRole.setInitmoney(initmoney);
				crossRole.setInityb(inityb);
				crossRole.setViplv(viplv);
				crossRole.setCurexp(curexp);
				crossRole.setLevel(level);
				crossRole.setSchool(school);
				crossRole.setPower(power);
				crossRole.setCamp(camp);
				crossRole.setPasscount(passfubencount);
				crossRole.getInititems().putAll(inititemlist);
				crossRole.getAutobattleinfo().setDefaultautobattle(autobattleinfo.defaultautobattle == 1);
				crossRole.getAutobattleinfo().setIsautofanpai(autobattleinfo.isautofanpai == 1);
				crossRole.getAutobattleinfo().setIsautorecover(autobattleinfo.isautorecover == 1);
				crossRole.getAutobattleinfo().setLastusetime(autobattleinfo.lastusetime);
				crossRole.getAutobattleinfo().setTimeouttime(autobattleinfo.timeouttime);
				crossRole.getAutobattleinfo().setUsednum(autobattleinfo.usednum);
				crossRole.setHelptimes(helptimes);
				crossRole.setFamilykey(familykey);
				crossRole.setFamilyposition(familyposition);
				crossRole.getResourcefightaward().putAll(resourcefightawardtimes);
				crossRole.setLastresettime(lastresettime);
				crossRole.getTodayawardids().putAll(todayawardids);
				NotifyCross snd = new NotifyCross();
				snd.destserver = ConfigManager.getGsZoneId();
				snd.roleid = roleid;
				GlobalClientManager.getInstance().send(fromserver, snd);
				return true;
			}

		}.submit();

	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925709;

	public int getType() {
		return 925709;
	}

	public long roleid;
	public int fromserver;
	public com.goldhuman.Common.Octets genterworld;
	public int userid; // 所属角色id
	public java.lang.String nickname; // 渠道名
	public java.lang.String username; // 渠道id$渠道名
	public java.lang.String rolename; // 角色名
	public long initmoney; // 钱
	public int inityb; // 钻石
	public short viplv; // vip等级
	public long curexp; // 当前经验
	public short level; // 等级
	public int school; // 职业
	public int titleid; // 当前称谓
	public int power; // 战力
	public short camp; // 所属阵营
	public int passfubencount; // 通关这个副本的次数
	public global.rsp.fuben.AutobattleInfo autobattleinfo; // 自动战斗数据
	public java.util.HashMap<Integer,Integer> inititemlist; // 初始化需要使用的道具信息
	public int helptimes; // 帮杀次数
	public long familykey; // 家族key
	public int familyposition; // 家族职位
	public java.util.HashMap<Integer,Integer> resourcefightawardtimes; // 资源争夺战奖励次数
	public long lastresettime; // 上一次重新设置的时间
	public java.util.HashMap<Integer,Integer> todayawardids; // 今日获得已经调用的奖励id次数

	public SendGenterWorldData() {
		genterworld = new com.goldhuman.Common.Octets();
		nickname = "";
		username = "";
		rolename = "";
		autobattleinfo = new global.rsp.fuben.AutobattleInfo();
		inititemlist = new java.util.HashMap<Integer,Integer>();
		resourcefightawardtimes = new java.util.HashMap<Integer,Integer>();
		todayawardids = new java.util.HashMap<Integer,Integer>();
	}

	public SendGenterWorldData(long _roleid_, int _fromserver_, com.goldhuman.Common.Octets _genterworld_, int _userid_, java.lang.String _nickname_, java.lang.String _username_, java.lang.String _rolename_, long _initmoney_, int _inityb_, short _viplv_, long _curexp_, short _level_, int _school_, int _titleid_, int _power_, short _camp_, int _passfubencount_, global.rsp.fuben.AutobattleInfo _autobattleinfo_, java.util.HashMap<Integer,Integer> _inititemlist_, int _helptimes_, long _familykey_, int _familyposition_, java.util.HashMap<Integer,Integer> _resourcefightawardtimes_, long _lastresettime_, java.util.HashMap<Integer,Integer> _todayawardids_) {
		this.roleid = _roleid_;
		this.fromserver = _fromserver_;
		this.genterworld = _genterworld_;
		this.userid = _userid_;
		this.nickname = _nickname_;
		this.username = _username_;
		this.rolename = _rolename_;
		this.initmoney = _initmoney_;
		this.inityb = _inityb_;
		this.viplv = _viplv_;
		this.curexp = _curexp_;
		this.level = _level_;
		this.school = _school_;
		this.titleid = _titleid_;
		this.power = _power_;
		this.camp = _camp_;
		this.passfubencount = _passfubencount_;
		this.autobattleinfo = _autobattleinfo_;
		this.inititemlist = _inititemlist_;
		this.helptimes = _helptimes_;
		this.familykey = _familykey_;
		this.familyposition = _familyposition_;
		this.resourcefightawardtimes = _resourcefightawardtimes_;
		this.lastresettime = _lastresettime_;
		this.todayawardids = _todayawardids_;
	}

	public final boolean _validator_() {
		if (!autobattleinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fromserver);
		_os_.marshal(genterworld);
		_os_.marshal(userid);
		_os_.marshal(nickname, "UTF-16LE");
		_os_.marshal(username, "UTF-16LE");
		_os_.marshal(rolename, "UTF-16LE");
		_os_.marshal(initmoney);
		_os_.marshal(inityb);
		_os_.marshal(viplv);
		_os_.marshal(curexp);
		_os_.marshal(level);
		_os_.marshal(school);
		_os_.marshal(titleid);
		_os_.marshal(power);
		_os_.marshal(camp);
		_os_.marshal(passfubencount);
		_os_.marshal(autobattleinfo);
		_os_.compact_uint32(inititemlist.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : inititemlist.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(helptimes);
		_os_.marshal(familykey);
		_os_.marshal(familyposition);
		_os_.compact_uint32(resourcefightawardtimes.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : resourcefightawardtimes.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(lastresettime);
		_os_.compact_uint32(todayawardids.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : todayawardids.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fromserver = _os_.unmarshal_int();
		genterworld = _os_.unmarshal_Octets();
		userid = _os_.unmarshal_int();
		nickname = _os_.unmarshal_String("UTF-16LE");
		username = _os_.unmarshal_String("UTF-16LE");
		rolename = _os_.unmarshal_String("UTF-16LE");
		initmoney = _os_.unmarshal_long();
		inityb = _os_.unmarshal_int();
		viplv = _os_.unmarshal_short();
		curexp = _os_.unmarshal_long();
		level = _os_.unmarshal_short();
		school = _os_.unmarshal_int();
		titleid = _os_.unmarshal_int();
		power = _os_.unmarshal_int();
		camp = _os_.unmarshal_short();
		passfubencount = _os_.unmarshal_int();
		autobattleinfo.unmarshal(_os_);
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			inititemlist.put(_k_, _v_);
		}
		helptimes = _os_.unmarshal_int();
		familykey = _os_.unmarshal_long();
		familyposition = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			resourcefightawardtimes.put(_k_, _v_);
		}
		lastresettime = _os_.unmarshal_long();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			todayawardids.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendGenterWorldData) {
			SendGenterWorldData _o_ = (SendGenterWorldData)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fromserver != _o_.fromserver) return false;
			if (!genterworld.equals(_o_.genterworld)) return false;
			if (userid != _o_.userid) return false;
			if (!nickname.equals(_o_.nickname)) return false;
			if (!username.equals(_o_.username)) return false;
			if (!rolename.equals(_o_.rolename)) return false;
			if (initmoney != _o_.initmoney) return false;
			if (inityb != _o_.inityb) return false;
			if (viplv != _o_.viplv) return false;
			if (curexp != _o_.curexp) return false;
			if (level != _o_.level) return false;
			if (school != _o_.school) return false;
			if (titleid != _o_.titleid) return false;
			if (power != _o_.power) return false;
			if (camp != _o_.camp) return false;
			if (passfubencount != _o_.passfubencount) return false;
			if (!autobattleinfo.equals(_o_.autobattleinfo)) return false;
			if (!inititemlist.equals(_o_.inititemlist)) return false;
			if (helptimes != _o_.helptimes) return false;
			if (familykey != _o_.familykey) return false;
			if (familyposition != _o_.familyposition) return false;
			if (!resourcefightawardtimes.equals(_o_.resourcefightawardtimes)) return false;
			if (lastresettime != _o_.lastresettime) return false;
			if (!todayawardids.equals(_o_.todayawardids)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fromserver;
		_h_ += genterworld.hashCode();
		_h_ += userid;
		_h_ += nickname.hashCode();
		_h_ += username.hashCode();
		_h_ += rolename.hashCode();
		_h_ += (int)initmoney;
		_h_ += inityb;
		_h_ += viplv;
		_h_ += (int)curexp;
		_h_ += level;
		_h_ += school;
		_h_ += titleid;
		_h_ += power;
		_h_ += camp;
		_h_ += passfubencount;
		_h_ += autobattleinfo.hashCode();
		_h_ += inititemlist.hashCode();
		_h_ += helptimes;
		_h_ += (int)familykey;
		_h_ += familyposition;
		_h_ += resourcefightawardtimes.hashCode();
		_h_ += (int)lastresettime;
		_h_ += todayawardids.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fromserver).append(",");
		_sb_.append("B").append(genterworld.size()).append(",");
		_sb_.append(userid).append(",");
		_sb_.append("T").append(nickname.length()).append(",");
		_sb_.append("T").append(username.length()).append(",");
		_sb_.append("T").append(rolename.length()).append(",");
		_sb_.append(initmoney).append(",");
		_sb_.append(inityb).append(",");
		_sb_.append(viplv).append(",");
		_sb_.append(curexp).append(",");
		_sb_.append(level).append(",");
		_sb_.append(school).append(",");
		_sb_.append(titleid).append(",");
		_sb_.append(power).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(passfubencount).append(",");
		_sb_.append(autobattleinfo).append(",");
		_sb_.append(inititemlist).append(",");
		_sb_.append(helptimes).append(",");
		_sb_.append(familykey).append(",");
		_sb_.append(familyposition).append(",");
		_sb_.append(resourcefightawardtimes).append(",");
		_sb_.append(lastresettime).append(",");
		_sb_.append(todayawardids).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

