
package global.rsp.fuben;
import knight.gsp.fuben.SQuitMatchPvp4;
import knight.gsp.msg.Message;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsRemoveTeamMatch__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsRemoveTeamMatch extends __GlGsRemoveTeamMatch__ {
	@Override
	protected void process() {
		new xdb.Procedure() {
			@Override
			protected boolean process() throws Exception {
				Team team = TeamManager.selectTeamByTeamID(teamid);
				if (team == null)
					return false;
				lock(xtable.Locks.ROLELOCK, team.getAllMemberIds());
				for (long memId : team.getAllMemberIds()) {
					xtable.Matchingroles.remove(memId);
					Message.sendMsgNotify(memId, 1029742);
					xdb.Procedure.psendWhileCommit(memId, new SQuitMatchPvp4());
				}
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925766;

	public int getType() {
		return 925766;
	}

	public long teamid; // teamid

	public GlGsRemoveTeamMatch() {
	}

	public GlGsRemoveTeamMatch(long _teamid_) {
		this.teamid = _teamid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsRemoveTeamMatch) {
			GlGsRemoveTeamMatch _o_ = (GlGsRemoveTeamMatch)_o1_;
			if (teamid != _o_.teamid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsRemoveTeamMatch _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

