package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import global.rsp.team.LeaveGlobalTeamPlatQueueBroast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.goldhuman.Common.Marshal.OctetsStream;

import xbean.TeamFubenInfos;
import xbean.TeamMember;
import knight.gsp.LocalIds;
import knight.gsp.PropRole;
import knight.gsp.StateCommon;
import knight.gsp.fuben.CheckCrossRoleInfoTask;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.fuben.FubenConfig;
import knight.gsp.fuben.FubenEnterProcess;
import knight.gsp.main.ConfigManager;
import knight.gsp.msg.Message;
import knight.gsp.scene.SceneClient;
import knight.gsp.state.logical.LogicalState;
import knight.gsp.task.TaskScenario;
import knight.gsp.task.TaskScenarioColumn;
import knight.gsp.task.TaskStatus;
import knight.gsp.team.PRemoveTeamFromPlatform;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;
import knight.gsp.team.TeamMemberState;
import knight.gsp.util.Misc;

/**
 * 剧情组队副本处理
 * 
 * @author yangzhenyu
 *
 * @date 2015年12月9日 上午10:42:25
 *
 */
public class TaskTeamFubenProcess extends FubenEnterProcess {

	private static final long ENTER_FUBEN_GAP_TIME = 3000L;// 单位毫秒
	
	private Team team = null;
	
	private TeamFubenInfos infos;
	
	private long roleId;
	
	public TaskTeamFubenProcess(FubenConfig fubenCfg, long roleId) {
		super(fubenCfg, roleId);
		team = TeamManager.getTeamByRoleId(roleId);
		this.roleId = roleId;
		if (team != null) {
			infos = xtable.Teamfubenroleinfos.get(team.teamId);
			if (infos == null) {
				infos = xbean.Pod.newTeamFubenInfos();
				xtable.Teamfubenroleinfos.insert(team.teamId, infos);
			}
		}
	}
	
	/**
	 * 点 创建 流程判断
	 */
	@Override
	public boolean canCreateTeamPlat() {
		
		if (team != null) {
			//有队伍的话，只有队长可以创建
			if (!team.isTeamLeader(roleId)) {
				//这里不弹出消息提示了，因为按理不会走到这里的，在PEnterTeamPlatQueue里就有判断
				return false;
			}
		}
		
		if (LocalIds.isRemoteServerRole(roleId))
			return false; //跨服是不能出现这种操作的，防止外挂
		
		if (fubenCfg.taskId <= 0)
			return false;

		TaskScenarioColumn taskCol = new TaskScenarioColumn(roleId, true);
		TaskScenario task = taskCol.getTask(fubenCfg.taskId);
		if (task == null || task.getState() != TaskStatus.PROCESSING) {
			//必须有任务，并且正在进行才能创建副本
			Message.psendMsgNotify(roleId, 1036011, null);
			return false;
		}
		if (team != null) {
			List<String> lvNotEnoughRoleNames = new ArrayList<String>();
			for (TeamMember member : team.getTeamMembers()) {
				if (member.getLevel() < fubenCfg.minlv) {
					lvNotEnoughRoleNames.add(member.getName());
				}
			}
			if (lvNotEnoughRoleNames.size() > 0) {
				Message.psendMsgNotify(roleId, 100818, Arrays.asList(Misc.makeNameStr(lvNotEnoughRoleNames, ','), String.valueOf(fubenCfg.minlv)));
				return false;
			}
		}
		return true;
	}
	
	/**
	 * 能否加入组队平台，只有组队副本需要判断
	 * 
	 * @return
	 */
	@Override
	public boolean canJoinTeamPlat(Team team) {
		xbean.Properties prop = xtable.Properties.select(roleId);
		if (prop == null)
			return false;
		if (prop.getLevel() < fubenCfg.minlv) {
			Message.sendMsgNotify(roleId, 1035984, null);
			return false;
		}
		return true;
	}
	
	@Override
	public boolean checkBefore() {
		if (team == null) {
			//这里就不弹消息提示了，可能是外挂伪造的协议
			return false;
		}
		
		//队长才可以点开战
		if (!team.isTeamLeader(roleId)) {
			Message.psendMsgNotify(roleId, 1035657, null);
			return false;
		}
		
		//人数不足
		if (team.size() < 2) {
			Message.psendMsgNotify(roleId, 101271, null);
			return false;
		}
		int checkPlatId = platId;
		if (checkPlatId == 0){
			checkPlatId = fubenCfg.fubenId;
		}
		if (!isRobotIllegal(team, checkPlatId)){
			return false;
		}
		//防止点击过于频繁
		final long now = System.currentTimeMillis();
		long availableTime = team.getTeamInfo().getEnterfubentime() + ENTER_FUBEN_GAP_TIME;
		if (now < availableTime) {
			//操作过于频繁,请x秒后再试
			Message.psendMsgNotify(roleId, 1036043, Arrays.asList(String.valueOf(Math.ceil(0.001f*(availableTime - now)))));
			return false;
		}
		team.getTeamInfo().setEnterfubentime(now);
		
		if (!team.checkUserNotRepeat()) {
			Message.psendMsgNotify(roleId, 1035788, null);
			return false;
		}
		
		//清除下查询的旧数据
		infos.getTeam().clear();
		
		return true;
	}
	
	@Override
	public boolean process() {
		if (team == null){
			return false;
		}
		
		int fubenId = fubenCfg.fubenId;
		InitCrossBattle msg = new InitCrossBattle();
		msg.fubenid = fubenId;
		if (checkAllTeamMembers(msg)) {
			if (infos.getTeam().size() == team.getAllMemberIdSet().size()){
				if (team.isGlobalTeam()) {
					GlobalClientManager.getInstance().psendWhileCommit(new LeaveGlobalTeamPlatQueueBroast(team.teamId, team.getPlatId(), 1));
				} else {
					xdb.Procedure.pexecuteWhileCommit(new PRemoveTeamFromPlatform(team.teamId, team.getPlatId(), false, true));
				}
				msg.friendlyhelpers.addAll(getHelperRoles()); //把没奖励的玩家存进来
				msg.taskroles.addAll(getTaskRoles()); //有任务的玩家
				msg.teamid = team.teamId;
				msg.robotteammates.putAll(getRobotTeammates(team));
				SceneClient.pSend(msg);
				FubenCommon.clearTeamFubenInfo(team.teamId);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 获得没掉落奖励的玩家，包括帮杀次数为0和有任务玩家
	 * 
	 * @return
	 */
	private List<Long> getHelperRoles() {
		List<Long> unAwardRoles = new ArrayList<Long>();
		if (infos != null) {
			for (Map.Entry<Long, Object> entry : infos.getTeam().entrySet()) {
				TeamTaskRoleInfo info = (TeamTaskRoleInfo) entry.getValue();
				if (info.hastask == 1) {
					//有任务的人不算帮杀
					continue;
				}
				unAwardRoles.add(entry.getKey());
			}
		}
		return unAwardRoles;
	}
	
	/**
	 * 有任务的人
	 * 
	 * @return
	 */
	private List<Long> getTaskRoles() {
		List<Long> taskRoles = new ArrayList<Long>();
		if (infos != null) {
			for (Map.Entry<Long, Object> entry : infos.getTeam().entrySet()) {
				TeamTaskRoleInfo info = (TeamTaskRoleInfo) entry.getValue();
				long rid = entry.getKey();
				if (info.hastask == 1) {
					taskRoles.add(rid);
				}
			}
		}
		
		return taskRoles;
	}
	
	private boolean checkAllTeamMembers(InitCrossBattle msg) {
		final int fubenId = fubenCfg.fubenId;
		List<Long> otherServerRoleIds = new ArrayList<Long>();
		xdb.Lockeys.lock(xtable.Locks.ROLELOCK, team.getAllMemberIds());
		
		//是不是已经请求 拉取过数据了，因为这个方法会被回调两遍
		boolean hasRequested = (infos.getTeam().size() == team.getAllMemberIds().size());
		
		for (long rid : team.getAllMemberIds()) {
			final xbean.TeamMember member = team.getMemBean(rid);
			msg.summonroles.put(rid, member.getZoneid());
			if (!hasRequested) {
				//之前没有请求过数据，需要请求一次
				if (member.getZoneid() != ConfigManager.getGsZoneId()) {
					otherServerRoleIds.add(rid);
					
					//别服玩家的数据需要去异步拉取
					ReqCrossRoleInfo reqMsg = new ReqCrossRoleInfo();
					reqMsg.fubenid = fubenId;
					reqMsg.operation = ReqCrossRoleInfo.START_TEAMFUBEN;
					reqMsg.tozoneid = ConfigManager.getGsZoneId();
					reqMsg.roleid = rid;
					GlobalClientManager.getInstance().send(member.getCurzoneid(), reqMsg);
				} else {
					//本服玩家的数据之间就能查询到
					infos.getTeam().put(rid, getRoleData(rid));
				}
			}
		}
		
		if (!hasRequested && !otherServerRoleIds.isEmpty()) {
			//有别服玩家的数据，是异步拉取的，需要等所有数据都拉取完成再判断是否满足条件
			//这里启动一个定时器
			ScheduledFuture<?> future = xdb.Executor.getInstance().schedule(
					new CheckCrossRoleInfoTask(otherServerRoleIds, team.teamId, team.getTeamLeaderId()),
					FubenCommon.getCrossFubenRoleInfoReqTime(fubenId), TimeUnit.SECONDS);
			xbean.CrossTeamMemberFuture memberFutre = xtable.Crossteamfubenfutres.get(team.teamId);
			if (memberFutre == null) {
				memberFutre = xbean.Pod.newCrossTeamMemberFuture();
				xtable.Crossteamfubenfutres.insert(team.teamId, memberFutre);
			}
			memberFutre.setGetcrossteammemberfuture(future);
			return true;
		}
		if (!check(infos.getTeam())){
			return false;
		}
		return true;
	}
	
	/**
	 * 获取到角色数据
	 */
	@Override
	public Object getRoleData(long roleid) {
		TeamTaskRoleInfo info = new TeamTaskRoleInfo();
		
		TaskScenarioColumn taskCol = new TaskScenarioColumn(roleid, true);
		TaskScenario task = taskCol.getTask(fubenCfg.taskId);
		if (task != null && task.getState() == TaskStatus.PROCESSING) {
			//身上 有这个任务
			info.hastask =  1;
		}
		
		PropRole propRole = new PropRole(roleid, true);
		
		//等级
		info.lv = (short) (int) propRole.getLevel();
		
		//判断玩家是否在战斗场景中
		if (StateCommon.isOnline(roleid)) {
			//在线的话判断他是否在战斗场景中. 包括副本，野外，离线副本中
			info.inbattlestate = (byte) (LogicalState.isInBattleScene(roleid) ? 1 : 0);
		} else {
			//不在线的话，看下这个玩家是否还处于跨服战斗状态
			xbean.CrossState crossState = xtable.Crossstate.select(roleid);
			if (crossState != null) {
				info.inbattlestate = 1;
			} else {
				if (team != null && team.getMemberState(roleid) != TeamMemberState.eTeamFallline) {
					info.inbattlestate = 1;
				}
			}
			
		}
		
		//角色名
		info.rolename = propRole.getName();
		
		return info;
	}
	
	/**
	 * 把收集到的角色数据暂时先存起来
	 */
	@Override
	public boolean setRoleData(long roleId, Object roleData) {
		xbean.CrossTeamMemberFuture memberFutre = xtable.Crossteamfubenfutres.get(team.teamId);
		if (memberFutre != null){
			memberFutre.getCrossmember().add(roleId);
		} else {
			// 已经超时，不予处理后面传来的数据
			return false;
		}
		infos.getTeam().put(roleId, roleData);
		return infos.getTeam().size() == team.getAllMemberIds().size();
	}
	
	@Override
	public Object getCrossData(OctetsStream ostream) throws Exception {
		TeamTaskRoleInfo info = new TeamTaskRoleInfo();
		info.unmarshal(ostream);
		return info;
	}
	
	@Override
	public boolean check(Map<Long, Object> datas) {
		List<Long> hasTaskRoles = new ArrayList<Long>(); //有任务的玩家
		List<String> inBattleRoleNames = new ArrayList<String>(); //在战斗中的玩家
		List<String> offlineRoleNames = new ArrayList<String>();// 玩家不在线
		List<String> lvNotEnoughRoleNames = new ArrayList<String>();
		for (Map.Entry<Long, Object> entry : datas.entrySet()) {
			long rid = entry.getKey();
			TeamTaskRoleInfo info = (TeamTaskRoleInfo) entry.getValue();
			
			if (info.hastask == 1) {
				//有任务的角色
				hasTaskRoles.add(rid);
			}
			if (info.lv < fubenCfg.minlv) {
				lvNotEnoughRoleNames.add(info.rolename);
			}
			if (info.inbattlestate > 0) {
				//这个玩家在战斗场景
				inBattleRoleNames.add(info.rolename);
			}
			
			if (team.getMemberState(rid) != TeamMemberState.eTeamNormal) {
				//离线状态
				offlineRoleNames.add(info.rolename);
			}
		}
		
		if (hasTaskRoles.isEmpty()) {
			//至少要有1个人有任务才能进入副本
			Message.psendMsgNotify(roleId, 1036012, null);
			return false;
		}
		
		if (inBattleRoleNames.size() > 0) {
			//队伍中的xxx,xxx处于战斗场景，当前无法进入场景
			Message.psendMsgNotify(roleId, 100819, Arrays.asList(Misc.makeNameStr(inBattleRoleNames, ',')));
			return false;
		}
		
		if (offlineRoleNames.size() > 0) {
			//队伍中的xxx,xxx处于离线状态
			Message.psendMsgNotify(roleId, 1024902, Arrays.asList(Misc.makeNameStr(offlineRoleNames, ',')));
			return false;
		}
		if (lvNotEnoughRoleNames.size() > 0) {
			Message.psendMsgNotify(roleId, 100818, Arrays.asList(Misc.makeNameStr(lvNotEnoughRoleNames, ','), String.valueOf(fubenCfg.minlv)));
			return false;
		}
		
		return true;
	}
	
	public TeamFubenInfos getInfos(){
		return infos;
	}
	
	@Override
	public boolean checkEnterPlatOrEnterFuben(int operation) {
		
		if (operation == ReqCrossRoleInfo.START_TEAMFUBEN) {
			return process();
		}
		
		return false;
	}
}

