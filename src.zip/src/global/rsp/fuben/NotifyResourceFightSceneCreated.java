
package global.rsp.fuben;
import knight.gsp.activity.resourcefight.ResourceFightBossConfig;
import knight.gsp.activity.resourcefight.ResourceFightManager;
import knight.gsp.activity.springfestival.treasuresteal.TreasureStealGhostManager;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.map.Position;
import knight.gsp.scene.SceneClient;
import knight.msp.NotifyEnterFuben;




// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyResourceFightSceneCreated__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyResourceFightSceneCreated extends __NotifyResourceFightSceneCreated__ {
	@Override
	protected void process() {
		new POnResourceFightSceneCreated(this).submit();
		for(long rid : teammemberids){
			ResourceFightBossConfig bossInfo = null;
			Position pos = null;
			if(!ResourceFightManager.getInstance().isInActivityPeriod()){
				bossInfo = TreasureStealGhostManager.getInstance().getBossCfg(npcid);
				pos = TreasureStealGhostManager.getInstance().getEnterPos(bossInfo, camp);
			} else {
				pos = ResourceFightManager.getInstance().getEnterPos(bossInfo, camp);
				bossInfo = ResourceFightManager.getInstance().getBossCfg(npcid);
			}
			if(fromserverid != sceneserverid){
				FubenCommon.sendGenterWorldData(rid, 0, sceneserverid, sceneid, pos.getX(), pos.getY(), pos.getZ());
			} else {// 就在本服
				NotifyEnterFuben msg = new NotifyEnterFuben();
				msg.enterpos = pos.toProtocolPos();
				msg.roleid = rid;
				msg.sceneid = sceneid;
				SceneClient.pSend(msg);
			}
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925741;

	public int getType() {
		return 925741;
	}

	public long teamid; // 队伍id
	public int fromserverid; // 队伍原服id
	public int sceneserverid; // 场景服务器id
	public java.util.HashSet<Long> teammemberids; // 角色
	public int npcid; // 要打的bossid
	public long sceneid; // 场景id
	public int camp; // 阵营id

	public NotifyResourceFightSceneCreated() {
		teammemberids = new java.util.HashSet<Long>();
	}

	public NotifyResourceFightSceneCreated(long _teamid_, int _fromserverid_, int _sceneserverid_, java.util.HashSet<Long> _teammemberids_, int _npcid_, long _sceneid_, int _camp_) {
		this.teamid = _teamid_;
		this.fromserverid = _fromserverid_;
		this.sceneserverid = _sceneserverid_;
		this.teammemberids = _teammemberids_;
		this.npcid = _npcid_;
		this.sceneid = _sceneid_;
		this.camp = _camp_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(fromserverid);
		_os_.marshal(sceneserverid);
		_os_.compact_uint32(teammemberids.size());
		for (Long _v_ : teammemberids) {
			_os_.marshal(_v_);
		}
		_os_.marshal(npcid);
		_os_.marshal(sceneid);
		_os_.marshal(camp);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		fromserverid = _os_.unmarshal_int();
		sceneserverid = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			teammemberids.add(_v_);
		}
		npcid = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		camp = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyResourceFightSceneCreated) {
			NotifyResourceFightSceneCreated _o_ = (NotifyResourceFightSceneCreated)_o1_;
			if (teamid != _o_.teamid) return false;
			if (fromserverid != _o_.fromserverid) return false;
			if (sceneserverid != _o_.sceneserverid) return false;
			if (!teammemberids.equals(_o_.teammemberids)) return false;
			if (npcid != _o_.npcid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (camp != _o_.camp) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += fromserverid;
		_h_ += sceneserverid;
		_h_ += teammemberids.hashCode();
		_h_ += npcid;
		_h_ += (int)sceneid;
		_h_ += camp;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(fromserverid).append(",");
		_sb_.append(sceneserverid).append(",");
		_sb_.append(teammemberids).append(",");
		_sb_.append(npcid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

