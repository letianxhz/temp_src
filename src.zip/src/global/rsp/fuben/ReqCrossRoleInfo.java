
package global.rsp.fuben;
import global.rsp.GlobalClientManager;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.fuben.FubenEnterProcess;





import com.goldhuman.Common.Marshal.Marshal;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqCrossRoleInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqCrossRoleInfo extends __ReqCrossRoleInfo__ {
	@Override
	protected void process() {
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				RespCrossRoleInfo respMsg = new RespCrossRoleInfo();
				respMsg.roleid = roleid;
				respMsg.fubenid = fubenid;
				respMsg.operation = operation;
				FubenEnterProcess enterProcess = FubenCommon.getFubenEnterProcess(roleid, fubenid);
				Marshal info = (Marshal)enterProcess.getRoleData(roleid);
				OctetsStream ostream = new OctetsStream();
				OctetsStream memberInfo = info.marshal(ostream);
				respMsg.memberinfo = memberInfo;
				GlobalClientManager.getInstance().send(tozoneid, respMsg);
				return true;
			}
			
		}.submit();
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925712;

	public int getType() {
		return 925712;
	}

	public final static int CREATE_TEAM = 1;
	public final static int START_TEAMFUBEN = 2;

	public int fubenid;
	public int tozoneid;
	public long roleid;
	public int operation; // 操作类型1-创建队伍；2-开始战斗

	public ReqCrossRoleInfo() {
	}

	public ReqCrossRoleInfo(int _fubenid_, int _tozoneid_, long _roleid_, int _operation_) {
		this.fubenid = _fubenid_;
		this.tozoneid = _tozoneid_;
		this.roleid = _roleid_;
		this.operation = _operation_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fubenid);
		_os_.marshal(tozoneid);
		_os_.marshal(roleid);
		_os_.marshal(operation);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fubenid = _os_.unmarshal_int();
		tozoneid = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		operation = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqCrossRoleInfo) {
			ReqCrossRoleInfo _o_ = (ReqCrossRoleInfo)_o1_;
			if (fubenid != _o_.fubenid) return false;
			if (tozoneid != _o_.tozoneid) return false;
			if (roleid != _o_.roleid) return false;
			if (operation != _o_.operation) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += fubenid;
		_h_ += tozoneid;
		_h_ += (int)roleid;
		_h_ += operation;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fubenid).append(",");
		_sb_.append(tozoneid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(operation).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(ReqCrossRoleInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = fubenid - _o_.fubenid;
		if (0 != _c_) return _c_;
		_c_ = tozoneid - _o_.tozoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = operation - _o_.operation;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

