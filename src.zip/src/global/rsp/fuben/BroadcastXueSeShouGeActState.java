
package global.rsp.fuben;

import knight.gsp.GsClient;
import knight.gsp.activity.xssgz.XueSeShouGeZhanManager;
import knight.gsp.scene.MapThreadProtocolParams;
import knight.gsp.scene.Scene;
import knight.gsp.scene.battle.BigWildSceneBattle;
import knight.gsp.scene.battle.SceneBattle;
import knight.msp.AbstractProtocol;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BroadcastXueSeShouGeActState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BroadcastXueSeShouGeActState extends __BroadcastXueSeShouGeActState__ {
	@Override
	protected void process() {
		
		if (actstate == 1) {
			//活动开启的时候，清一下数据
			XueSeShouGeZhanManager.getInstance().resetData();
			XueSeShouGeZhanManager.getInstance().notifyRoleReadyForAct();
		}
		
		if (actstate != 2) {
			if (actstate == 0) {
				XueSeShouGeZhanManager.getInstance().closeSummonRoles();
			}
			
			GsClient.sendToScene(XueSeShouGeZhanManager.BATTLE_SCENE_ID, new AbstractProtocol() {
				
				@Override
				public void _process() {
					Scene scene = MapThreadProtocolParams.parseScene(getSender());
					if (scene == null)
						return;
					
					SceneBattle battle = scene.getBattleEngine().getSceneBattle();
					if (battle == null || !(battle instanceof BigWildSceneBattle))
						return;
					
					BigWildSceneBattle bigWildBattle = (BigWildSceneBattle) battle;
					if (actstate == 1) {
						bigWildBattle.readyForXueSeShouGeBattle(actfinishtime);
					} else if (actstate == 0) {
						bigWildBattle.finishXueSeShouGeAct();
					} else if (actstate == 3) {
						bigWildBattle.getXueSeShouGeBattleInfo().clearXueSeBattleInfoWhileActEnd(true);
					}
				}
			});
		} else {
			//对所有玩家最终进行汇总发奖
			XueSeShouGeZhanManager.getInstance().calcFinalAward();
		}
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925780;

	public int getType() {
		return 925780;
	}

	public int actstate; // 0代表关闭，1代表进入准备期间,2是给所有人发奖
	public long actfinishtime; // 定时活动的总时长

	public BroadcastXueSeShouGeActState() {
	}

	public BroadcastXueSeShouGeActState(int _actstate_, long _actfinishtime_) {
		this.actstate = _actstate_;
		this.actfinishtime = _actfinishtime_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(actstate);
		_os_.marshal(actfinishtime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		actstate = _os_.unmarshal_int();
		actfinishtime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BroadcastXueSeShouGeActState) {
			BroadcastXueSeShouGeActState _o_ = (BroadcastXueSeShouGeActState)_o1_;
			if (actstate != _o_.actstate) return false;
			if (actfinishtime != _o_.actfinishtime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += actstate;
		_h_ += (int)actfinishtime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(actstate).append(",");
		_sb_.append(actfinishtime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(BroadcastXueSeShouGeActState _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = actstate - _o_.actstate;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(actfinishtime - _o_.actfinishtime);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

