
package global.rsp.fuben;

import gnet.link.Onlines;
import java.util.ArrayList;
import java.util.List;
import knight.gsp.scene.CommonThread;
import knight.gsp.scene.battle.AddBattleReceiverTask;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReplyReceiverBroadcast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReplyReceiverBroadcast extends __ReplyReceiverBroadcast__ {
	@Override
	protected void process() {
		List<xio.Protocol> sendProtocols = new ArrayList<xio.Protocol>();
		
		try {
			Coder coder = (Coder) Onlines.getInstance().getCoder();
			for (int i = 0; i < initptypes.size(); i ++) {
				int ptype = initptypes.get(i);
				xio.Protocol p = coder.getStub(ptype).newInstance();
				OctetsStream octstram = OctetsStream.wrap(initprotocols.get(i));
				p.unmarshal(octstram);
				sendProtocols.add(p);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		CommonThread.getInstance().add(new AddBattleReceiverTask(roleid, battleserver, sceneid, sendProtocols));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925718;

	public int getType() {
		return 925718;
	}

	public int battleserver; // 战场所在的服务器id
	public long roleid; // 角色id
	public long sceneid; // 战场场景id
	public java.util.ArrayList<Integer> initptypes; // 协议对应的协议号
	public java.util.ArrayList<com.goldhuman.Common.Octets> initprotocols; // 场景的初始化协议数据

	public ReplyReceiverBroadcast() {
		initptypes = new java.util.ArrayList<Integer>();
		initprotocols = new java.util.ArrayList<com.goldhuman.Common.Octets>();
	}

	public ReplyReceiverBroadcast(int _battleserver_, long _roleid_, long _sceneid_, java.util.ArrayList<Integer> _initptypes_, java.util.ArrayList<com.goldhuman.Common.Octets> _initprotocols_) {
		this.battleserver = _battleserver_;
		this.roleid = _roleid_;
		this.sceneid = _sceneid_;
		this.initptypes = _initptypes_;
		this.initprotocols = _initprotocols_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserver);
		_os_.marshal(roleid);
		_os_.marshal(sceneid);
		_os_.compact_uint32(initptypes.size());
		for (Integer _v_ : initptypes) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(initprotocols.size());
		for (com.goldhuman.Common.Octets _v_ : initprotocols) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserver = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		sceneid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			initptypes.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			initprotocols.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReplyReceiverBroadcast) {
			ReplyReceiverBroadcast _o_ = (ReplyReceiverBroadcast)_o1_;
			if (battleserver != _o_.battleserver) return false;
			if (roleid != _o_.roleid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (!initptypes.equals(_o_.initptypes)) return false;
			if (!initprotocols.equals(_o_.initprotocols)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserver;
		_h_ += (int)roleid;
		_h_ += (int)sceneid;
		_h_ += initptypes.hashCode();
		_h_ += initprotocols.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserver).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(initptypes).append(",");
		_sb_.append(initprotocols).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

