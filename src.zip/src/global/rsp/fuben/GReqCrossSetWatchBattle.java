package global.rsp.fuben;
import knight.gsp.family.familybattle.SSetWatchBattle;
import knight.gsp.scene.SendProtocolThread;
import knight.gsp.scene.battle.BattleBroadcastReceiver;
import com.goldhuman.Common.Marshal.MarshalException;
import com.goldhuman.Common.Marshal.OctetsStream;

import xio.Protocol;

public class GReqCrossSetWatchBattle extends Protocol {
	private int battleServer;
	private long battlesceneid; // 战斗所在的场景
	private long roleid;
	
	
	public GReqCrossSetWatchBattle(int battleServer, long battleSceneId, long roleid) {
		super();
		this.battleServer = battleServer;
		this.battlesceneid = battleSceneId;
		this.roleid = roleid;
	}


	@Override
	public void process() {
		
		BattleBroadcastReceiver battReceiver = BattleBroadcastReceiver.getReceiver(battleServer, battlesceneid);
		if (null == battReceiver)
			return;
		if (!battReceiver.getWatchRoleAsCopy().contains(roleid)) 
			return;
		SendProtocolThread.getInstance().send(roleid, new SSetWatchBattle());
	}
	
	
	@Override
	public OctetsStream marshal(OctetsStream arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OctetsStream unmarshal(OctetsStream arg0) throws MarshalException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return 0;
	}

}
