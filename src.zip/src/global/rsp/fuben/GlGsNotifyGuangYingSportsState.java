
package global.rsp.fuben;

import knight.gsp.activity.guangyingduijue.GuangYingManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsNotifyGuangYingSportsState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsNotifyGuangYingSportsState extends __GlGsNotifyGuangYingSportsState__ {
	@Override
	protected void process() {
		if (state == 0) {
			new xdb.Procedure(){
				protected boolean process() throws Exception {
					GuangYingManager.getInstance().guangYingDuiJueSportsEnd(starttime, endtime);
					return true;
				};
			}.submit();
		} else if (state == 1) {
			new xdb.Procedure(){
				protected boolean process() throws Exception {
					GuangYingManager.getInstance().guangYingDuiJueSportsOpen(starttime, endtime);
					return true;
				};
			}.submit();
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925803;

	public int getType() {
		return 925803;
	}

	public byte state; // 0:关闭 1:开启
	public long starttime; // 赛季开启时间
	public long endtime; // 赛季结束的时间

	public GlGsNotifyGuangYingSportsState() {
	}

	public GlGsNotifyGuangYingSportsState(byte _state_, long _starttime_, long _endtime_) {
		this.state = _state_;
		this.starttime = _starttime_;
		this.endtime = _endtime_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(state);
		_os_.marshal(starttime);
		_os_.marshal(endtime);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		state = _os_.unmarshal_byte();
		starttime = _os_.unmarshal_long();
		endtime = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsNotifyGuangYingSportsState) {
			GlGsNotifyGuangYingSportsState _o_ = (GlGsNotifyGuangYingSportsState)_o1_;
			if (state != _o_.state) return false;
			if (starttime != _o_.starttime) return false;
			if (endtime != _o_.endtime) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)state;
		_h_ += (int)starttime;
		_h_ += (int)endtime;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(state).append(",");
		_sb_.append(starttime).append(",");
		_sb_.append(endtime).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GlGsNotifyGuangYingSportsState _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = state - _o_.state;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(starttime - _o_.starttime);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(endtime - _o_.endtime);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

