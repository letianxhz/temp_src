
package global.rsp.fuben;

import knight.msp.MFinishPvp8Battle;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __FinishPvp8Battle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class FinishPvp8Battle extends __FinishPvp8Battle__ {
	@Override
	protected void process() {
		MFinishPvp8Battle msnd  = new MFinishPvp8Battle();
		msnd.role2result.putAll(roleresults);
		msnd.hasAwardRoles.putAll(awardroles);
		msnd.getpointroles.putAll(getpointroles);
		msnd.battleScoreRoles.putAll(battlescoreroles);
		msnd.battleKValueRoles.putAll(battlescorekvalueroles);
		msnd.mvpRoleIds = mvproleids;
		msnd.execInstant();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925731;

	public int getType() {
		return 925731;
	}

	public java.util.HashMap<Long,Short> roleresults; // key为角色id，value为结果，0为平局,1获胜，2失败
	public java.util.HashMap<Long,Integer> awardroles; // 能够获得奖励的角色 key：roleId value：今日已经进入次数
	public java.util.HashMap<Long,Integer> getpointroles; // 能够获得兑换积分的玩家
	public java.util.HashMap<Long,Integer> battlescoreroles; // 有战场排行积分的玩家
	public java.util.HashMap<Long,Integer> battlescorekvalueroles; // 战场获得K值的玩家信息
	public java.util.HashSet<Long> mvproleids; // 本场比赛的mvp玩家,失败方胜利方各有一个

	public FinishPvp8Battle() {
		roleresults = new java.util.HashMap<Long,Short>();
		awardroles = new java.util.HashMap<Long,Integer>();
		getpointroles = new java.util.HashMap<Long,Integer>();
		battlescoreroles = new java.util.HashMap<Long,Integer>();
		battlescorekvalueroles = new java.util.HashMap<Long,Integer>();
		mvproleids = new java.util.HashSet<Long>();
	}

	public FinishPvp8Battle(java.util.HashMap<Long,Short> _roleresults_, java.util.HashMap<Long,Integer> _awardroles_, java.util.HashMap<Long,Integer> _getpointroles_, java.util.HashMap<Long,Integer> _battlescoreroles_, java.util.HashMap<Long,Integer> _battlescorekvalueroles_, java.util.HashSet<Long> _mvproleids_) {
		this.roleresults = _roleresults_;
		this.awardroles = _awardroles_;
		this.getpointroles = _getpointroles_;
		this.battlescoreroles = _battlescoreroles_;
		this.battlescorekvalueroles = _battlescorekvalueroles_;
		this.mvproleids = _mvproleids_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(roleresults.size());
		for (java.util.Map.Entry<Long, Short> _e_ : roleresults.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(awardroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : awardroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(getpointroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : getpointroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(battlescoreroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : battlescoreroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(battlescorekvalueroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : battlescorekvalueroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(mvproleids.size());
		for (Long _v_ : mvproleids) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			short _v_;
			_v_ = _os_.unmarshal_short();
			roleresults.put(_k_, _v_);
		}
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			awardroles.put(_k_, _v_);
		}
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			getpointroles.put(_k_, _v_);
		}
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			battlescoreroles.put(_k_, _v_);
		}
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			battlescorekvalueroles.put(_k_, _v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			mvproleids.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof FinishPvp8Battle) {
			FinishPvp8Battle _o_ = (FinishPvp8Battle)_o1_;
			if (!roleresults.equals(_o_.roleresults)) return false;
			if (!awardroles.equals(_o_.awardroles)) return false;
			if (!getpointroles.equals(_o_.getpointroles)) return false;
			if (!battlescoreroles.equals(_o_.battlescoreroles)) return false;
			if (!battlescorekvalueroles.equals(_o_.battlescorekvalueroles)) return false;
			if (!mvproleids.equals(_o_.mvproleids)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += roleresults.hashCode();
		_h_ += awardroles.hashCode();
		_h_ += getpointroles.hashCode();
		_h_ += battlescoreroles.hashCode();
		_h_ += battlescorekvalueroles.hashCode();
		_h_ += mvproleids.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleresults).append(",");
		_sb_.append(awardroles).append(",");
		_sb_.append(getpointroles).append(",");
		_sb_.append(battlescoreroles).append(",");
		_sb_.append(battlescorekvalueroles).append(",");
		_sb_.append(mvproleids).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

