
package global.rsp.fuben;
import xbean.CrossRole;
import knight.gsp.GsClient;
import knight.gsp.LocalIds;
import knight.gsp.game.SVIPlevelprivilege;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.Pos;
import knight.msp.GNotifyTeamMemberEnterScene;
import knight.msp.RoleBattleNpcInfo;




// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendCrossRoleBattleData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendCrossRoleBattleData extends __SendCrossRoleBattleData__ {
	@Override
	protected void process() {
		new xdb.Procedure(){
			@Override
			protected boolean process() throws Exception {
				if (!LocalIds.isRemoteServerRole(roleid))
					return false;
				GNotifyTeamMemberEnterScene gsnd = new GNotifyTeamMemberEnterScene();
				OctetsStream octstream = OctetsStream.wrap(topos);
				Pos topos = new Pos();
				try {
					topos.unmarshal(octstream);
				} catch (MarshalException e) {
					e.printStackTrace();
				}
				gsnd.topos = topos;
				gsnd.sceneid = sceneid;
				OctetsStream octstream1 = OctetsStream.wrap(rolebattlenpcinfo);
				RoleBattleNpcInfo battleNpcInfo = new RoleBattleNpcInfo();
				try {
					battleNpcInfo.unmarshal(octstream1);
				} catch (MarshalException e) {
					e.printStackTrace();
				}
				gsnd.battlenpcinfo = battleNpcInfo;
				SVIPlevelprivilege cfg = ConfigManager.getInstance().getConf(SVIPlevelprivilege.class).get(viplv + 1);
				if (cfg != null)
					gsnd.memberautobattleinfo.autorecovertimes = (short) cfg.autorivivetimes;
				gsnd.isfriendlyhelper = isfriendlyhelper;
				if (autobattleinfo != null) {
					//具有队伍副本自动托管的权限
					gsnd.memberautobattleinfo.remaintime = autobattleinfo.timeouttime;
					gsnd.memberautobattleinfo.isautobattle = (byte) autobattleinfo.defaultautobattle;
					gsnd.memberautobattleinfo.isautorecover = (byte) autobattleinfo.isautorecover;
				}
				CrossRole crossRole = xtable.Crossroles.get(roleid);
				if(crossRole == null){
					crossRole = xbean.Pod.newCrossRole();
					xtable.Crossroles.insert(roleid, crossRole);
				}
				/*
				 * 跨服用户的渠道名和渠道ID
				 */
				crossRole.setRolename(rolename);
				crossRole.setNickname(nickname);
				crossRole.setUsername(username);
				crossRole.setUserid(userid);
				crossRole.setInitmoney(initmoney);
				crossRole.setInityb(inityb);
				crossRole.setViplv(viplv);
				crossRole.setCurexp(curexp);
				crossRole.setLevel(level);
				crossRole.setSchool(school);
				crossRole.setPower(power);
				crossRole.setCamp(camp);
				crossRole.setOfflineexp(offlineexp);
				crossRole.setPasscount(passfubencount);
				crossRole.getInititems().putAll(inititemlist);
				crossRole.getAutobattleinfo().setDefaultautobattle(autobattleinfo.defaultautobattle == 1);
				crossRole.getAutobattleinfo().setIsautofanpai(autobattleinfo.isautofanpai == 1);
				crossRole.getAutobattleinfo().setIsautorecover(autobattleinfo.isautorecover == 1);
				crossRole.getAutobattleinfo().setLastusetime(autobattleinfo.lastusetime);
				crossRole.getAutobattleinfo().setTimeouttime(autobattleinfo.timeouttime);
				crossRole.getAutobattleinfo().setUsednum(autobattleinfo.usednum);
				crossRole.getFriendinteam().addAll(friendinteam);
				crossRole.setReceivefamilygiftnum(familygiftreceivenum);
				crossRole.setReceiveweiwangxunzhangnum(weiwangxunzhangreceivenum);
				crossRole.setReceivefamilygifttime(familygiftreceivetime);
				crossRole.getOriginteammates().addAll(originteammemberids);
				crossRole.setLastresettime(lastresettime);
				crossRole.getTodayawardids().putAll(todayawardids);
				GsClient.psend2RoleSceneWhileCommit(roleid, gsnd);
				return true;
			}
			
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925722;

	public int getType() {
		return 925722;
	}

	public long roleid;
	public int fromserver;
	public int userid; // 所属角色id
	public java.lang.String nickname; // 渠道名
	public java.lang.String username; // 渠道id$渠道名
	public java.lang.String rolename; // 角色名
	public long initmoney; // 钱
	public int inityb; // 钻石
	public short viplv; // vip等级
	public long curexp; // 当前经验
	public short level; // 等级
	public int school; // 职业
	public int titleid; // 当前称谓
	public int power; // 战力
	public short camp; // 所属阵营
	public int passfubencount; // 通关这个副本的次数
	public global.rsp.fuben.AutobattleInfo autobattleinfo; // 自动战斗数据
	public java.util.HashMap<Integer,Integer> inititemlist; // 初始化需要使用的道具信息
	public long sceneid;
	public com.goldhuman.Common.Octets topos;
	public com.goldhuman.Common.Octets rolebattlenpcinfo; // 佣兵信息
	public int offlineexp; // 离线经验
	public int isfriendlyhelper; // 是否是帮杀1-是帮杀，0-不是帮杀
	public java.util.HashSet<Long> friendinteam; // 队伍里面好友id
	public java.util.HashSet<Long> originteammemberids; // 初始队伍成员id
	public int familygiftreceivenum; // 家族礼包获取次数
	public int weiwangxunzhangreceivenum; // 威望勋章获取次数
	public long familygiftreceivetime; // 家族礼包/威望勋章获得时间
	public long lastresettime; // 上一次重新设置的时间
	public java.util.HashMap<Integer,Integer> todayawardids; // 今日获得已经调用的奖励id次数

	public SendCrossRoleBattleData() {
		nickname = "";
		username = "";
		rolename = "";
		autobattleinfo = new global.rsp.fuben.AutobattleInfo();
		inititemlist = new java.util.HashMap<Integer,Integer>();
		topos = new com.goldhuman.Common.Octets();
		rolebattlenpcinfo = new com.goldhuman.Common.Octets();
		friendinteam = new java.util.HashSet<Long>();
		originteammemberids = new java.util.HashSet<Long>();
		todayawardids = new java.util.HashMap<Integer,Integer>();
	}

	public SendCrossRoleBattleData(long _roleid_, int _fromserver_, int _userid_, java.lang.String _nickname_, java.lang.String _username_, java.lang.String _rolename_, long _initmoney_, int _inityb_, short _viplv_, long _curexp_, short _level_, int _school_, int _titleid_, int _power_, short _camp_, int _passfubencount_, global.rsp.fuben.AutobattleInfo _autobattleinfo_, java.util.HashMap<Integer,Integer> _inititemlist_, long _sceneid_, com.goldhuman.Common.Octets _topos_, com.goldhuman.Common.Octets _rolebattlenpcinfo_, int _offlineexp_, int _isfriendlyhelper_, java.util.HashSet<Long> _friendinteam_, java.util.HashSet<Long> _originteammemberids_, int _familygiftreceivenum_, int _weiwangxunzhangreceivenum_, long _familygiftreceivetime_, long _lastresettime_, java.util.HashMap<Integer,Integer> _todayawardids_) {
		this.roleid = _roleid_;
		this.fromserver = _fromserver_;
		this.userid = _userid_;
		this.nickname = _nickname_;
		this.username = _username_;
		this.rolename = _rolename_;
		this.initmoney = _initmoney_;
		this.inityb = _inityb_;
		this.viplv = _viplv_;
		this.curexp = _curexp_;
		this.level = _level_;
		this.school = _school_;
		this.titleid = _titleid_;
		this.power = _power_;
		this.camp = _camp_;
		this.passfubencount = _passfubencount_;
		this.autobattleinfo = _autobattleinfo_;
		this.inititemlist = _inititemlist_;
		this.sceneid = _sceneid_;
		this.topos = _topos_;
		this.rolebattlenpcinfo = _rolebattlenpcinfo_;
		this.offlineexp = _offlineexp_;
		this.isfriendlyhelper = _isfriendlyhelper_;
		this.friendinteam = _friendinteam_;
		this.originteammemberids = _originteammemberids_;
		this.familygiftreceivenum = _familygiftreceivenum_;
		this.weiwangxunzhangreceivenum = _weiwangxunzhangreceivenum_;
		this.familygiftreceivetime = _familygiftreceivetime_;
		this.lastresettime = _lastresettime_;
		this.todayawardids = _todayawardids_;
	}

	public final boolean _validator_() {
		if (!autobattleinfo._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fromserver);
		_os_.marshal(userid);
		_os_.marshal(nickname, "UTF-16LE");
		_os_.marshal(username, "UTF-16LE");
		_os_.marshal(rolename, "UTF-16LE");
		_os_.marshal(initmoney);
		_os_.marshal(inityb);
		_os_.marshal(viplv);
		_os_.marshal(curexp);
		_os_.marshal(level);
		_os_.marshal(school);
		_os_.marshal(titleid);
		_os_.marshal(power);
		_os_.marshal(camp);
		_os_.marshal(passfubencount);
		_os_.marshal(autobattleinfo);
		_os_.compact_uint32(inititemlist.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : inititemlist.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(sceneid);
		_os_.marshal(topos);
		_os_.marshal(rolebattlenpcinfo);
		_os_.marshal(offlineexp);
		_os_.marshal(isfriendlyhelper);
		_os_.compact_uint32(friendinteam.size());
		for (Long _v_ : friendinteam) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(originteammemberids.size());
		for (Long _v_ : originteammemberids) {
			_os_.marshal(_v_);
		}
		_os_.marshal(familygiftreceivenum);
		_os_.marshal(weiwangxunzhangreceivenum);
		_os_.marshal(familygiftreceivetime);
		_os_.marshal(lastresettime);
		_os_.compact_uint32(todayawardids.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : todayawardids.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fromserver = _os_.unmarshal_int();
		userid = _os_.unmarshal_int();
		nickname = _os_.unmarshal_String("UTF-16LE");
		username = _os_.unmarshal_String("UTF-16LE");
		rolename = _os_.unmarshal_String("UTF-16LE");
		initmoney = _os_.unmarshal_long();
		inityb = _os_.unmarshal_int();
		viplv = _os_.unmarshal_short();
		curexp = _os_.unmarshal_long();
		level = _os_.unmarshal_short();
		school = _os_.unmarshal_int();
		titleid = _os_.unmarshal_int();
		power = _os_.unmarshal_int();
		camp = _os_.unmarshal_short();
		passfubencount = _os_.unmarshal_int();
		autobattleinfo.unmarshal(_os_);
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			inititemlist.put(_k_, _v_);
		}
		sceneid = _os_.unmarshal_long();
		topos = _os_.unmarshal_Octets();
		rolebattlenpcinfo = _os_.unmarshal_Octets();
		offlineexp = _os_.unmarshal_int();
		isfriendlyhelper = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			friendinteam.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			originteammemberids.add(_v_);
		}
		familygiftreceivenum = _os_.unmarshal_int();
		weiwangxunzhangreceivenum = _os_.unmarshal_int();
		familygiftreceivetime = _os_.unmarshal_long();
		lastresettime = _os_.unmarshal_long();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			todayawardids.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendCrossRoleBattleData) {
			SendCrossRoleBattleData _o_ = (SendCrossRoleBattleData)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fromserver != _o_.fromserver) return false;
			if (userid != _o_.userid) return false;
			if (!nickname.equals(_o_.nickname)) return false;
			if (!username.equals(_o_.username)) return false;
			if (!rolename.equals(_o_.rolename)) return false;
			if (initmoney != _o_.initmoney) return false;
			if (inityb != _o_.inityb) return false;
			if (viplv != _o_.viplv) return false;
			if (curexp != _o_.curexp) return false;
			if (level != _o_.level) return false;
			if (school != _o_.school) return false;
			if (titleid != _o_.titleid) return false;
			if (power != _o_.power) return false;
			if (camp != _o_.camp) return false;
			if (passfubencount != _o_.passfubencount) return false;
			if (!autobattleinfo.equals(_o_.autobattleinfo)) return false;
			if (!inititemlist.equals(_o_.inititemlist)) return false;
			if (sceneid != _o_.sceneid) return false;
			if (!topos.equals(_o_.topos)) return false;
			if (!rolebattlenpcinfo.equals(_o_.rolebattlenpcinfo)) return false;
			if (offlineexp != _o_.offlineexp) return false;
			if (isfriendlyhelper != _o_.isfriendlyhelper) return false;
			if (!friendinteam.equals(_o_.friendinteam)) return false;
			if (!originteammemberids.equals(_o_.originteammemberids)) return false;
			if (familygiftreceivenum != _o_.familygiftreceivenum) return false;
			if (weiwangxunzhangreceivenum != _o_.weiwangxunzhangreceivenum) return false;
			if (familygiftreceivetime != _o_.familygiftreceivetime) return false;
			if (lastresettime != _o_.lastresettime) return false;
			if (!todayawardids.equals(_o_.todayawardids)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fromserver;
		_h_ += userid;
		_h_ += nickname.hashCode();
		_h_ += username.hashCode();
		_h_ += rolename.hashCode();
		_h_ += (int)initmoney;
		_h_ += inityb;
		_h_ += viplv;
		_h_ += (int)curexp;
		_h_ += level;
		_h_ += school;
		_h_ += titleid;
		_h_ += power;
		_h_ += camp;
		_h_ += passfubencount;
		_h_ += autobattleinfo.hashCode();
		_h_ += inititemlist.hashCode();
		_h_ += (int)sceneid;
		_h_ += topos.hashCode();
		_h_ += rolebattlenpcinfo.hashCode();
		_h_ += offlineexp;
		_h_ += isfriendlyhelper;
		_h_ += friendinteam.hashCode();
		_h_ += originteammemberids.hashCode();
		_h_ += familygiftreceivenum;
		_h_ += weiwangxunzhangreceivenum;
		_h_ += (int)familygiftreceivetime;
		_h_ += (int)lastresettime;
		_h_ += todayawardids.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fromserver).append(",");
		_sb_.append(userid).append(",");
		_sb_.append("T").append(nickname.length()).append(",");
		_sb_.append("T").append(username.length()).append(",");
		_sb_.append("T").append(rolename.length()).append(",");
		_sb_.append(initmoney).append(",");
		_sb_.append(inityb).append(",");
		_sb_.append(viplv).append(",");
		_sb_.append(curexp).append(",");
		_sb_.append(level).append(",");
		_sb_.append(school).append(",");
		_sb_.append(titleid).append(",");
		_sb_.append(power).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(passfubencount).append(",");
		_sb_.append(autobattleinfo).append(",");
		_sb_.append(inititemlist).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append("B").append(topos.size()).append(",");
		_sb_.append("B").append(rolebattlenpcinfo.size()).append(",");
		_sb_.append(offlineexp).append(",");
		_sb_.append(isfriendlyhelper).append(",");
		_sb_.append(friendinteam).append(",");
		_sb_.append(originteammemberids).append(",");
		_sb_.append(familygiftreceivenum).append(",");
		_sb_.append(weiwangxunzhangreceivenum).append(",");
		_sb_.append(familygiftreceivetime).append(",");
		_sb_.append(lastresettime).append(",");
		_sb_.append(todayawardids).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

