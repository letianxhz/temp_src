
package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import knight.gsp.LogicalSceneEntry;
import knight.gsp.fuben.Swormholereward;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.scene.DynamicScene;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.battle.CrossBossDeathHandler;
import knight.gsp.scene.battle.CrossBossSceneBattle;
import knight.gsp.scene.battle.DeathHandler;
import knight.gsp.scene.movable.Monster;
import knight.gsp.scene.sPos.Position;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CreateCrossBossCopy__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CreateCrossBossCopy extends __CreateCrossBossCopy__ {
	@Override
	protected void process() {
		final Swormholereward cfg = ConfigManager.getInstance().getConf(Swormholereward.class).get(bosscfgid);
		if (cfg == null)
			return;
		
		
		final int mapId = cfg.map;
		
		LogicalSceneEntry.createDynamicScene(mapId, null, new ICreateSceneCallback() {
			
			@Override
			public void handle(Object obj, Scene newScene) {
				newScene.setSceneType(SceneType.WILD_BOSS); //用野外boss的场景类型
				((DynamicScene) newScene).setStilAliveWhileEmpty(true); //场景没人的时候也不卸载
				CrossBossSceneBattle battle = newScene.getBattleEngine().startCrossBossBattle();
				DeathHandler deathHandler = new CrossBossDeathHandler(battle);
				newScene.getBattleEngine().setDeathHandler(deathHandler);
				
				//设置一个fubenid,怪物掉落的地方需要一个大于-1的副本id处理
				newScene.getBattleEngine().setFubenId(mapId);
				
				String[] pseArr = cfg.mostercoordinates.split(",");
				Position pos = new Position(Integer.valueOf(pseArr[0]), Integer.valueOf(pseArr[1]), Integer.valueOf(pseArr[2]));
				Monster boss = battle.summonMonsterByMonterTemplate(bosscfgid, pos, (byte) 0, null);
				battle.initData(bosscfgid, copyid, boss, deathHandler);
				
				//副本创建完毕，需要通知global
				GlobalClientManager.getInstance().send(new CrossBossCopyCreated(copyid, newScene.getSceneID()));
			}
		}, null);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925746;

	public int getType() {
		return 925746;
	}

	public long copyid; // 战场唯一id
	public int bosscfgid; // 随机出的世界bossid

	public CreateCrossBossCopy() {
	}

	public CreateCrossBossCopy(long _copyid_, int _bosscfgid_) {
		this.copyid = _copyid_;
		this.bosscfgid = _bosscfgid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(copyid);
		_os_.marshal(bosscfgid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		copyid = _os_.unmarshal_long();
		bosscfgid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CreateCrossBossCopy) {
			CreateCrossBossCopy _o_ = (CreateCrossBossCopy)_o1_;
			if (copyid != _o_.copyid) return false;
			if (bosscfgid != _o_.bosscfgid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)copyid;
		_h_ += bosscfgid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(copyid).append(",");
		_sb_.append(bosscfgid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CreateCrossBossCopy _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(copyid - _o_.copyid);
		if (0 != _c_) return _c_;
		_c_ = bosscfgid - _o_.bosscfgid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

