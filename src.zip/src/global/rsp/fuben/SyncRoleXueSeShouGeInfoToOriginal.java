
package global.rsp.fuben;

import knight.gsp.LocalIds;
import knight.gsp.activity.xssgz.PSendAwardMailWithGiveItems;
import knight.gsp.activity.xssgz.XueSeShouGeZhanManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SyncRoleXueSeShouGeInfoToOriginal__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SyncRoleXueSeShouGeInfoToOriginal extends __SyncRoleXueSeShouGeInfoToOriginal__ {
	@Override
	protected void process() {
		if (LocalIds.isRemoteServerRole(data.roleid))
			return;
		
		XueSeShouGeZhanManager.getInstance().saveRoleData(data.roleid, data);
		
		if (giveaward == 1) {
			//给奖励，需要发送奖励邮件
			new PSendAwardMailWithGiveItems(data.roleid, rankindex, data, awarditem).submit();
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925783;

	public int getType() {
		return 925783;
	}

	public global.rsp.fuben.XueSeShouGeBattleRoleInfo data;
	public byte giveaward; // 1为给奖励，0为不给
	public java.util.HashMap<Integer,Integer> awarditem; // 奖励内容
	public int rankindex; // 排名，用于邮件通知

	public SyncRoleXueSeShouGeInfoToOriginal() {
		data = new global.rsp.fuben.XueSeShouGeBattleRoleInfo();
		awarditem = new java.util.HashMap<Integer,Integer>();
	}

	public SyncRoleXueSeShouGeInfoToOriginal(global.rsp.fuben.XueSeShouGeBattleRoleInfo _data_, byte _giveaward_, java.util.HashMap<Integer,Integer> _awarditem_, int _rankindex_) {
		this.data = _data_;
		this.giveaward = _giveaward_;
		this.awarditem = _awarditem_;
		this.rankindex = _rankindex_;
	}

	public final boolean _validator_() {
		if (!data._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(data);
		_os_.marshal(giveaward);
		_os_.compact_uint32(awarditem.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : awarditem.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(rankindex);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		data.unmarshal(_os_);
		giveaward = _os_.unmarshal_byte();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			awarditem.put(_k_, _v_);
		}
		rankindex = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SyncRoleXueSeShouGeInfoToOriginal) {
			SyncRoleXueSeShouGeInfoToOriginal _o_ = (SyncRoleXueSeShouGeInfoToOriginal)_o1_;
			if (!data.equals(_o_.data)) return false;
			if (giveaward != _o_.giveaward) return false;
			if (!awarditem.equals(_o_.awarditem)) return false;
			if (rankindex != _o_.rankindex) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += data.hashCode();
		_h_ += (int)giveaward;
		_h_ += awarditem.hashCode();
		_h_ += rankindex;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(data).append(",");
		_sb_.append(giveaward).append(",");
		_sb_.append(awarditem).append(",");
		_sb_.append(rankindex).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

