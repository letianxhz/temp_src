
package global.rsp.fuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqMatchPvp4__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqMatchPvp4 extends __ReqMatchPvp4__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925756;

	public int getType() {
		return 925756;
	}

	public int serverid; // 队伍所在服务器
	public long teamid; // 队伍id
	public int isaddmercenary; // 是否添加替补佣兵 0:否 1:是
	public java.util.ArrayList<global.rsp.fuben.Pvp4MatchRole> roleinfos; // 队员的相关数据

	public ReqMatchPvp4() {
		roleinfos = new java.util.ArrayList<global.rsp.fuben.Pvp4MatchRole>();
	}

	public ReqMatchPvp4(int _serverid_, long _teamid_, int _isaddmercenary_, java.util.ArrayList<global.rsp.fuben.Pvp4MatchRole> _roleinfos_) {
		this.serverid = _serverid_;
		this.teamid = _teamid_;
		this.isaddmercenary = _isaddmercenary_;
		this.roleinfos = _roleinfos_;
	}

	public final boolean _validator_() {
		for (global.rsp.fuben.Pvp4MatchRole _v_ : roleinfos)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(serverid);
		_os_.marshal(teamid);
		_os_.marshal(isaddmercenary);
		_os_.compact_uint32(roleinfos.size());
		for (global.rsp.fuben.Pvp4MatchRole _v_ : roleinfos) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		serverid = _os_.unmarshal_int();
		teamid = _os_.unmarshal_long();
		isaddmercenary = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.Pvp4MatchRole _v_ = new global.rsp.fuben.Pvp4MatchRole();
			_v_.unmarshal(_os_);
			roleinfos.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqMatchPvp4) {
			ReqMatchPvp4 _o_ = (ReqMatchPvp4)_o1_;
			if (serverid != _o_.serverid) return false;
			if (teamid != _o_.teamid) return false;
			if (isaddmercenary != _o_.isaddmercenary) return false;
			if (!roleinfos.equals(_o_.roleinfos)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += serverid;
		_h_ += (int)teamid;
		_h_ += isaddmercenary;
		_h_ += roleinfos.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(serverid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(isaddmercenary).append(",");
		_sb_.append(roleinfos).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

