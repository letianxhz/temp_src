
package global.rsp.fuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __FinishGuangYingBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class FinishGuangYingBattle extends __FinishGuangYingBattle__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925800;

	public int getType() {
		return 925800;
	}

	public java.util.HashMap<Long,Short> roleresults; // key为角色id，value为结果，0为平局,1获胜，2失败
	public java.util.HashMap<Long,Integer> getpointroles; // key:roleId value:获得的战斗积分
	public java.util.HashSet<Long> endwindroles; // 有终结连胜加成的角色
	public long mvproleid; // 本场的mvp

	public FinishGuangYingBattle() {
		roleresults = new java.util.HashMap<Long,Short>();
		getpointroles = new java.util.HashMap<Long,Integer>();
		endwindroles = new java.util.HashSet<Long>();
	}

	public FinishGuangYingBattle(java.util.HashMap<Long,Short> _roleresults_, java.util.HashMap<Long,Integer> _getpointroles_, java.util.HashSet<Long> _endwindroles_, long _mvproleid_) {
		this.roleresults = _roleresults_;
		this.getpointroles = _getpointroles_;
		this.endwindroles = _endwindroles_;
		this.mvproleid = _mvproleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(roleresults.size());
		for (java.util.Map.Entry<Long, Short> _e_ : roleresults.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(getpointroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : getpointroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(endwindroles.size());
		for (Long _v_ : endwindroles) {
			_os_.marshal(_v_);
		}
		_os_.marshal(mvproleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			short _v_;
			_v_ = _os_.unmarshal_short();
			roleresults.put(_k_, _v_);
		}
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			getpointroles.put(_k_, _v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			endwindroles.add(_v_);
		}
		mvproleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof FinishGuangYingBattle) {
			FinishGuangYingBattle _o_ = (FinishGuangYingBattle)_o1_;
			if (!roleresults.equals(_o_.roleresults)) return false;
			if (!getpointroles.equals(_o_.getpointroles)) return false;
			if (!endwindroles.equals(_o_.endwindroles)) return false;
			if (mvproleid != _o_.mvproleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += roleresults.hashCode();
		_h_ += getpointroles.hashCode();
		_h_ += endwindroles.hashCode();
		_h_ += (int)mvproleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleresults).append(",");
		_sb_.append(getpointroles).append(",");
		_sb_.append(endwindroles).append(",");
		_sb_.append(mvproleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

