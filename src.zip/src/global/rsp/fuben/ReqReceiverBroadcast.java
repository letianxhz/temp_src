
package global.rsp.fuben;

import knight.gsp.GsClient;
import knight.msp.GReq4ReceiveBroadcast;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqReceiverBroadcast__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqReceiverBroadcast extends __ReqReceiverBroadcast__ {
	@Override
	protected void process() {
		
		if (sceneid <= 0 && roleid > 0) {
			knight.gsp.map.Role mapRole = knight.gsp.map.RoleManager.getInstance().getRoleByID(directrole);
			if (mapRole != null) {
				sceneid = mapRole.getScene();
			}
		}
		
		if (sceneid <= 0)
			return;
		
		int mapId = (int) sceneid;
		if (mapId == sceneid)
			return; //静态场景不允许
		
		GsClient.pSendWhileCommit(sceneid, new GReq4ReceiveBroadcast(roleid, zoneid, sceneid, (byte) initcamp, ""));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925717;

	public int getType() {
		return 925717;
	}

	public int zoneid; // 请求的玩家所在服务器
	public long roleid; // 角色id
	public long sceneid; // 战场场景id
	public long directrole; // 直接观察角色的战场
	public int initcamp; // 观战的阵营

	public ReqReceiverBroadcast() {
	}

	public ReqReceiverBroadcast(int _zoneid_, long _roleid_, long _sceneid_, long _directrole_, int _initcamp_) {
		this.zoneid = _zoneid_;
		this.roleid = _roleid_;
		this.sceneid = _sceneid_;
		this.directrole = _directrole_;
		this.initcamp = _initcamp_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(roleid);
		_os_.marshal(sceneid);
		_os_.marshal(directrole);
		_os_.marshal(initcamp);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		sceneid = _os_.unmarshal_long();
		directrole = _os_.unmarshal_long();
		initcamp = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqReceiverBroadcast) {
			ReqReceiverBroadcast _o_ = (ReqReceiverBroadcast)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (roleid != _o_.roleid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (directrole != _o_.directrole) return false;
			if (initcamp != _o_.initcamp) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += zoneid;
		_h_ += (int)roleid;
		_h_ += (int)sceneid;
		_h_ += (int)directrole;
		_h_ += initcamp;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(directrole).append(",");
		_sb_.append(initcamp).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(ReqReceiverBroadcast _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(directrole - _o_.directrole);
		if (0 != _c_) return _c_;
		_c_ = initcamp - _o_.initcamp;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

