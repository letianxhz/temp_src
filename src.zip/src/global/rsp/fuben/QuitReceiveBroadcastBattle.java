
package global.rsp.fuben;

import knight.gsp.GsClient;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneService;
import knight.gsp.scene.battle.SceneBattle;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __QuitReceiveBroadcastBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class QuitReceiveBroadcastBattle extends __QuitReceiveBroadcastBattle__ {
	@Override
	protected void process() {
		GsClient.sendToScene(battlesceneid, new xio.Protocol() {
			
			@Override
			protected void process() {
				Scene scene = SceneService.getInstance().getSceneById(battlesceneid);
				if (scene == null)
					return;
				
				SceneBattle battle = scene.getBattleEngine().getSceneBattle();
				if (battle == null)
					return;
				
				battle.onRmBattleWatcher(roleid);
			}

			@Override
			public OctetsStream marshal(OctetsStream arg0) {
				return null;
			}

			@Override
			public OctetsStream unmarshal(OctetsStream arg0)
					throws MarshalException {
				return null;
			}

			@Override
			public int getType() {
				return 0;
			}
			
		});
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925727;

	public int getType() {
		return 925727;
	}

	public int battleserverid; // 战场所在的服务器id
	public long battlesceneid; // 战场场景id
	public long roleid; // 战场场景id

	public QuitReceiveBroadcastBattle() {
	}

	public QuitReceiveBroadcastBattle(int _battleserverid_, long _battlesceneid_, long _roleid_) {
		this.battleserverid = _battleserverid_;
		this.battlesceneid = _battlesceneid_;
		this.roleid = _roleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserverid);
		_os_.marshal(battlesceneid);
		_os_.marshal(roleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserverid = _os_.unmarshal_int();
		battlesceneid = _os_.unmarshal_long();
		roleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof QuitReceiveBroadcastBattle) {
			QuitReceiveBroadcastBattle _o_ = (QuitReceiveBroadcastBattle)_o1_;
			if (battleserverid != _o_.battleserverid) return false;
			if (battlesceneid != _o_.battlesceneid) return false;
			if (roleid != _o_.roleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserverid;
		_h_ += (int)battlesceneid;
		_h_ += (int)roleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserverid).append(",");
		_sb_.append(battlesceneid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(QuitReceiveBroadcastBattle _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = battleserverid - _o_.battleserverid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(battlesceneid - _o_.battlesceneid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

