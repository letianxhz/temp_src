
package global.rsp.fuben;
import global.rsp.GlobalClientManager;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import xbean.FamilyInfoBean;
import xbean.FamilyMemberBean;
import knight.gsp.LocalIds;
import knight.gsp.camp.CampRole;
import knight.gsp.family.FamilyManager;
import knight.gsp.fuben.FubenRole;
import knight.gsp.item.Bag;
import knight.gsp.item.GroceryItem;
import knight.gsp.main.ConfigManager;
import knight.gsp.map.Position;
import knight.gsp.mercenary.proc.MercenaryColumn;
import knight.gsp.move.Pos;
import knight.gsp.team.Team;
import knight.gsp.util.DateValidate;
import knight.gsp.yuanbao.Vip;
import knight.gsp.yuanbao.YbNum;
import knight.msp.MUseAutoBattleItem;
import knight.msp.RoleBattleNpcInfo;









// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GetCrossRoleBattleData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GetCrossRoleBattleData extends __GetCrossRoleBattleData__ {
	@Override
	protected void process() {
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				if(LocalIds.isRemoteServerRole(roleid)){
					return false;
				}
				Long teamId = xtable.Roleid2teamid.select(roleid);
				Team team = null;
				if (teamId != null) {
					//有队伍,先锁队伍锁
					lock(xtable.Locks.TEAMLOCK, Arrays.asList(teamId));
					team = new Team(teamId, true);
				}
				
				SendCrossRoleBattleData snd = new SendCrossRoleBattleData();
				snd.roleid = roleid;
				snd.fromserver = ConfigManager.getGsZoneId();
				Vip vip = new Vip(roleid, true);
				snd.viplv = (short)vip.getVipLevel();
				/*
				 * 往表中添加数据CrossState
				 */
				xbean.CrossState crossState = xtable.Crossstate.get(roleid);
				if (crossState == null) {
					crossState = xbean.Pod.newCrossState();
					xtable.Crossstate.insert(roleid, crossState);
				}
				crossState.setSceneid(sceneid);
				crossState.setServerid(copytoserver);

				xbean.Properties prop = xtable.Properties.select(roleid);
				Map<Byte,Integer> components = new HashMap<Byte,Integer>();
				try {
					knight.gsp.map.Role.getPlayerComponents(roleid, components, prop.getSchool(), false);
				} catch (Exception e) {e.printStackTrace();}
				Position position = new Position(x, y, z);
				Pos topos = position.toProtocolPos();
				OctetsStream ostream = new OctetsStream();
				topos.marshal(ostream);
				snd.topos = ostream;
				snd.sceneid = sceneid;
				/*
				 * 跨服队员的渠道名和渠道ID
				 */
				snd.rolename = prop.getRolename();
				snd.nickname = prop.getNickname();
				snd.username = prop.getUsername();
				snd.userid = prop.getUserid();
				Bag bag = new Bag(roleid, true);
				snd.initmoney = bag.getMoney();
				snd.inityb = new YbNum(roleid, true).getYbNum();
				snd.curexp = prop.getExp();
				snd.camp = new CampRole(roleid, true).getStandCamp();
				snd.level = (short) prop.getLevel();
				snd.school = prop.getSchool();
				snd.titleid = prop.getTitle();
				snd.power = prop.getPower();
				snd.offlineexp = prop.getOfflineexp();
				snd.inititemlist = new HashMap<Integer, Integer>();
				snd.inititemlist.put(GroceryItem.AUTO_BATTLE_ITEM, bag.countItemNumber(GroceryItem.AUTO_BATTLE_ITEM, 0));
				snd.inititemlist.put(MUseAutoBattleItem.AUTO_BATTLE_TICKET, bag.countItemNumber(MUseAutoBattleItem.AUTO_BATTLE_TICKET, 0));
				xbean.AutoBattleItemUseRole abir = xtable.Autobattleitemuseroles.get(roleid);
				if (abir != null) {
					if (!DateValidate.inTheSameDay(System.currentTimeMillis(), abir.getLastusetime())) {
						//跨周了，清空一下数据
						abir.setUsednum((short) 0);
					}
					snd.autobattleinfo.defaultautobattle = (abir.getDefaultautobattle())? 1 : 0;
					snd.autobattleinfo.isautofanpai = (abir.getIsautofanpai())? 1:0;
					snd.autobattleinfo.isautorecover = (abir.getIsautorecover())?1:0;
					snd.autobattleinfo.lastusetime = abir.getLastusetime();
					snd.autobattleinfo.timeouttime = abir.getTimeouttime();
					snd.autobattleinfo.usednum = abir.getUsednum();
				}
				if (fubenid > 0) {
					snd.passfubencount = new FubenRole(roleid, true).getPassCount(fubenid);
				}
				RoleBattleNpcInfo battleNpcInfo = MercenaryColumn.getMercenaryColumn(roleid, true).getAllFighetrMercenaryWhileEnterFuben();
				OctetsStream ostream1 = new OctetsStream();
				battleNpcInfo.marshal(ostream1);
				snd.rolebattlenpcinfo = ostream1;
				if(team != null){
					xbean.FriendGroups groups = xtable.Friends.select(roleid);
					if(groups != null){
						for(long rid : team.getAllMemberIds()){
							if(groups.getFriendsmap().containsKey(rid) && groups.getBeaddedasfriends().contains(rid)){
								snd.friendinteam.add(rid);
							}
						}
					}
					FamilyMemberBean familyMemberBean = xtable.Familymember.select(roleid);
					if(familyMemberBean != null){
						FamilyInfoBean infoBean = xtable.Families.select(familyMemberBean.getFamilykey());
						FamilyManager familyMgr = new FamilyManager(infoBean);
						for(long rid : team.getAllMemberIds()){
							if(familyMgr.isMember(rid) && rid != roleid){
								snd.friendinteam.add(rid);
							}
						}
					}
					FubenRole fubenRole = new FubenRole(roleid, true);
					snd.originteammemberids.addAll(fubenRole.getOriginTeammates());
				}
				xbean.OndeDragonGift gift = xtable.Onedragongift.get(roleid);
				if(gift != null){
					if(DateValidate.inTheSameDay(System.currentTimeMillis(), gift.getLastreceivetime())){
						snd.familygiftreceivenum = gift.getFamilygiftnum();
						snd.weiwangxunzhangreceivenum = gift.getWeiwangxunzhangnum();
					} else {
						gift.setFamilygiftnum(0);
						gift.setWeiwangxunzhangnum(0);
						gift.setLastreceivetime(System.currentTimeMillis());
					}
				}
				xbean.GainLimitRole gainLimitRole = xtable.Gainlimitroles.select(roleid);
				if (null != gainLimitRole) {
					snd.lastresettime = gainLimitRole.getLastresettime();
					snd.todayawardids.putAll(gainLimitRole.getTodayawardids());
				}
				return GlobalClientManager.getInstance().send(copytoserver, snd);
			}

		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925721;

	public int getType() {
		return 925721;
	}

	public int copytoserver; // 需要拷贝到那个服务器
	public long roleid;
	public long sceneid;
	public int x;
	public int y;
	public int z;
	public int fubenid; // 要去打的副本id，没有则不填

	public GetCrossRoleBattleData() {
	}

	public GetCrossRoleBattleData(int _copytoserver_, long _roleid_, long _sceneid_, int _x_, int _y_, int _z_, int _fubenid_) {
		this.copytoserver = _copytoserver_;
		this.roleid = _roleid_;
		this.sceneid = _sceneid_;
		this.x = _x_;
		this.y = _y_;
		this.z = _z_;
		this.fubenid = _fubenid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(copytoserver);
		_os_.marshal(roleid);
		_os_.marshal(sceneid);
		_os_.marshal(x);
		_os_.marshal(y);
		_os_.marshal(z);
		_os_.marshal(fubenid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		copytoserver = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		sceneid = _os_.unmarshal_long();
		x = _os_.unmarshal_int();
		y = _os_.unmarshal_int();
		z = _os_.unmarshal_int();
		fubenid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GetCrossRoleBattleData) {
			GetCrossRoleBattleData _o_ = (GetCrossRoleBattleData)_o1_;
			if (copytoserver != _o_.copytoserver) return false;
			if (roleid != _o_.roleid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (x != _o_.x) return false;
			if (y != _o_.y) return false;
			if (z != _o_.z) return false;
			if (fubenid != _o_.fubenid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += copytoserver;
		_h_ += (int)roleid;
		_h_ += (int)sceneid;
		_h_ += x;
		_h_ += y;
		_h_ += z;
		_h_ += fubenid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(copytoserver).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(x).append(",");
		_sb_.append(y).append(",");
		_sb_.append(z).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GetCrossRoleBattleData _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = copytoserver - _o_.copytoserver;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = x - _o_.x;
		if (0 != _c_) return _c_;
		_c_ = y - _o_.y;
		if (0 != _c_) return _c_;
		_c_ = z - _o_.z;
		if (0 != _c_) return _c_;
		_c_ = fubenid - _o_.fubenid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

