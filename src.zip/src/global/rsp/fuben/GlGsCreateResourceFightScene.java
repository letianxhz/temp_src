
package global.rsp.fuben;
import knight.gsp.activity.resourcefight.ResourceFightManager;

import knight.gsp.activity.springfestival.treasuresteal.TreasureStealGhostManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsCreateResourceFightScene__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsCreateResourceFightScene extends __GlGsCreateResourceFightScene__ {
	@Override
	protected void process() {
		if(ResourceFightManager.getInstance().isInActivityPeriod()){
			ResourceFightManager.getInstance().createScene(teamid, teammemberids, fromserverid, camp, npcid);
		} else {
			TreasureStealGhostManager.getInstance().createScene(teamid, teammemberids, fromserverid, camp, npcid);
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925740;

	public int getType() {
		return 925740;
	}

	public long teamid; // 队伍id
	public java.util.HashSet<Long> teammemberids; // 角色
	public int fromserverid; // 服务器id
	public int camp; // 阵营id
	public int npcid; // 要打的bossid

	public GlGsCreateResourceFightScene() {
		teammemberids = new java.util.HashSet<Long>();
	}

	public GlGsCreateResourceFightScene(long _teamid_, java.util.HashSet<Long> _teammemberids_, int _fromserverid_, int _camp_, int _npcid_) {
		this.teamid = _teamid_;
		this.teammemberids = _teammemberids_;
		this.fromserverid = _fromserverid_;
		this.camp = _camp_;
		this.npcid = _npcid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.compact_uint32(teammemberids.size());
		for (Long _v_ : teammemberids) {
			_os_.marshal(_v_);
		}
		_os_.marshal(fromserverid);
		_os_.marshal(camp);
		_os_.marshal(npcid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			teammemberids.add(_v_);
		}
		fromserverid = _os_.unmarshal_int();
		camp = _os_.unmarshal_int();
		npcid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsCreateResourceFightScene) {
			GlGsCreateResourceFightScene _o_ = (GlGsCreateResourceFightScene)_o1_;
			if (teamid != _o_.teamid) return false;
			if (!teammemberids.equals(_o_.teammemberids)) return false;
			if (fromserverid != _o_.fromserverid) return false;
			if (camp != _o_.camp) return false;
			if (npcid != _o_.npcid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += teammemberids.hashCode();
		_h_ += fromserverid;
		_h_ += camp;
		_h_ += npcid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(teammemberids).append(",");
		_sb_.append(fromserverid).append(",");
		_sb_.append(camp).append(",");
		_sb_.append(npcid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

