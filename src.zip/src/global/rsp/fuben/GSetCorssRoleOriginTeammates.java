
package global.rsp.fuben;
import knight.gsp.LocalIds;

import knight.gsp.cross.CrossRole;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GSetCorssRoleOriginTeammates__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GSetCorssRoleOriginTeammates extends __GSetCorssRoleOriginTeammates__ {
	@Override
	protected void process() {
		if(!LocalIds.isRemoteServerRole(roleid)){
			return;
		}
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				CrossRole crossRole = new CrossRole(roleid, false);
				crossRole.setOriginTeammates(mates);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925724;

	public int getType() {
		return 925724;
	}

	public long roleid; // 玩家id
	public java.util.HashSet<Long> mates; // 队友id

	public GSetCorssRoleOriginTeammates() {
		mates = new java.util.HashSet<Long>();
	}

	public GSetCorssRoleOriginTeammates(long _roleid_, java.util.HashSet<Long> _mates_) {
		this.roleid = _roleid_;
		this.mates = _mates_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.compact_uint32(mates.size());
		for (Long _v_ : mates) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			mates.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GSetCorssRoleOriginTeammates) {
			GSetCorssRoleOriginTeammates _o_ = (GSetCorssRoleOriginTeammates)_o1_;
			if (roleid != _o_.roleid) return false;
			if (!mates.equals(_o_.mates)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += mates.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(mates).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

