
package global.rsp.fuben;

import knight.gsp.scene.CommonThread;
import knight.gsp.scene.battle.BroadBattleDataTask;
import gnet.link.Onlines;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BroadcastBattleData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BroadcastBattleData extends __BroadcastBattleData__ {
	@Override
	protected void process() {
		try {
			Coder coder = (Coder) Onlines.getInstance().getCoder();
			xio.Protocol p = coder.getStub(ptype).newInstance();
			OctetsStream octstram = OctetsStream.wrap(pdata);
			p.unmarshal(octstram);
			
			CommonThread.getInstance().add(new BroadBattleDataTask(battleserver, sceneid, p));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925719;

	public int getType() {
		return 925719;
	}

	public int battleserver; // 战场所在的服务器id
	public long sceneid; // 战场场景id
	public int ptype; // 协议号
	public com.goldhuman.Common.Octets pdata; // 协议数据

	public BroadcastBattleData() {
		pdata = new com.goldhuman.Common.Octets();
	}

	public BroadcastBattleData(int _battleserver_, long _sceneid_, int _ptype_, com.goldhuman.Common.Octets _pdata_) {
		this.battleserver = _battleserver_;
		this.sceneid = _sceneid_;
		this.ptype = _ptype_;
		this.pdata = _pdata_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserver);
		_os_.marshal(sceneid);
		_os_.marshal(ptype);
		_os_.marshal(pdata);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserver = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		ptype = _os_.unmarshal_int();
		pdata = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BroadcastBattleData) {
			BroadcastBattleData _o_ = (BroadcastBattleData)_o1_;
			if (battleserver != _o_.battleserver) return false;
			if (sceneid != _o_.sceneid) return false;
			if (ptype != _o_.ptype) return false;
			if (!pdata.equals(_o_.pdata)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserver;
		_h_ += (int)sceneid;
		_h_ += ptype;
		_h_ += pdata.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserver).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(ptype).append(",");
		_sb_.append("B").append(pdata.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

