
package global.rsp.fuben;
import knight.gsp.LocalIds;
import knight.gsp.PAddExpProc;
import knight.gsp.PAddExpProc.EXP_TYPE;
import knight.gsp.activity.resourcefight.ResourceFightManager;
import knight.gsp.award.Item;
import knight.gsp.item.Bag;
import knight.gsp.log.LogUtil;
import knight.gsp.log.LogUtil.ADD_ITEM_TYPE;
import knight.gsp.log.LogUtil.MONEY_TYPE;
import knight.gsp.yuanbao.PAddYuanBao;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendResourceFightAward__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendResourceFightAward extends __SendResourceFightAward__ {
	@Override
	protected void process() {
		if(LocalIds.isRemoteServerRole(roleid))
			return;
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				String hint = "国庆资源争夺战";
				EXP_TYPE expType = EXP_TYPE.CROSS_RESOURCE_FIGHT;
				int logUtilId = LogUtil.RESOURCE_FIGHT;
				ADD_ITEM_TYPE addItemType = ADD_ITEM_TYPE.RESOURCE_FIGHT;
				if(!ResourceFightManager.getInstance().isInActivityPeriod()){
					hint = "盗宝精灵";
					expType = EXP_TYPE.TREASURE_STEAL_GHOST;
					logUtilId = LogUtil.TREASURE_STEAL_GHOST;
					addItemType = ADD_ITEM_TYPE.TREASURE_STEAL_GHOST;
				}
				Bag bag = new Bag(roleid, false);
				for(int itemId : awardmap.keySet()){
					int itemNum = awardmap.get(itemId);
					if(itemId == Item.EXP_ITEM){
						if(!new PAddExpProc(roleid, itemNum, expType, hint).call()){
							ResourceFightManager.logger.error("经验奖励获取错误！！！");
							return false;
						}
					} else if (Item.isMoney(itemId)){
						if (itemNum != bag.addSysMoney(itemNum, MONEY_TYPE.AWARD, hint)){
							ResourceFightManager.logger.error("金币奖励获取错误！！！itemId:" + itemId + ",itemNum:" + itemNum);
							return false;
						}
					} else if(Item.isDiamond(itemId)){
						if (!new PAddYuanBao(roleid, itemNum, logUtilId, 0).call()) {
							return false;
						}
					} else {
						if(awardmap.get(itemId) != bag.addItem(itemId, awardmap.get(itemId), addItemType, hint)){
							return false;
						}
					}
				}
				xbean.ResourceFightRecord record = xtable.Resourcefightrecord.get(roleid);
				Integer oldTimes = record.getAwardrecord().get(npcid);
				if(oldTimes == null){
					record.getAwardrecord().put(npcid, 1);
				} else {
					record.getAwardrecord().put(npcid, oldTimes + 1);
				}
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925743;

	public int getType() {
		return 925743;
	}

	public long roleid; // 角色id
	public int npcid; // bossid
	public java.util.HashMap<Integer,Integer> awardmap; // 奖励

	public SendResourceFightAward() {
		awardmap = new java.util.HashMap<Integer,Integer>();
	}

	public SendResourceFightAward(long _roleid_, int _npcid_, java.util.HashMap<Integer,Integer> _awardmap_) {
		this.roleid = _roleid_;
		this.npcid = _npcid_;
		this.awardmap = _awardmap_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(npcid);
		_os_.compact_uint32(awardmap.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : awardmap.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		npcid = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			awardmap.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendResourceFightAward) {
			SendResourceFightAward _o_ = (SendResourceFightAward)_o1_;
			if (roleid != _o_.roleid) return false;
			if (npcid != _o_.npcid) return false;
			if (!awardmap.equals(_o_.awardmap)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += npcid;
		_h_ += awardmap.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(npcid).append(",");
		_sb_.append(awardmap).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

