
package global.rsp.fuben;

import gnet.link.Onlines;
import knight.gsp.fuben.SAskToEnterPvp8;
import knight.gsp.fuben.pvp8.CacheBattleSceneInfo;
import knight.gsp.fuben.pvp8.Pvp8Manager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyPvp8SceneBattleCreated__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyPvp8SceneBattleCreated extends __NotifyPvp8SceneBattleCreated__ {
	@Override
	protected void process() {
		
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				CacheBattleSceneInfo info = new CacheBattleSceneInfo();
				info.serverId = battleserverid;
				info.sceneId = sceneid;
				info.x = x;
				info.y = y;
				info.z = z;
				
				lock(xtable.Locks.ROLELOCK, notifyroles);
				for (long roleId : notifyroles) {
					xtable.Matchingroles.remove(roleId);
					Onlines.getInstance().send(roleId, new SAskToEnterPvp8((byte) 1));
					Pvp8Manager.getInstance().addCacheBattleScene(roleId, info);
				}
				
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925730;

	public int getType() {
		return 925730;
	}

	public int battleserverid; // 战场所在服务器
	public long sceneid; // 战场的场景id
	public int x; // 传入点x
	public int y; // 传入点y
	public int z; // 传入点z
	public long teamid; // 队伍id
	public java.util.HashSet<Long> notifyroles; // 角色id

	public NotifyPvp8SceneBattleCreated() {
		notifyroles = new java.util.HashSet<Long>();
	}

	public NotifyPvp8SceneBattleCreated(int _battleserverid_, long _sceneid_, int _x_, int _y_, int _z_, long _teamid_, java.util.HashSet<Long> _notifyroles_) {
		this.battleserverid = _battleserverid_;
		this.sceneid = _sceneid_;
		this.x = _x_;
		this.y = _y_;
		this.z = _z_;
		this.teamid = _teamid_;
		this.notifyroles = _notifyroles_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserverid);
		_os_.marshal(sceneid);
		_os_.marshal(x);
		_os_.marshal(y);
		_os_.marshal(z);
		_os_.marshal(teamid);
		_os_.compact_uint32(notifyroles.size());
		for (Long _v_ : notifyroles) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserverid = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		x = _os_.unmarshal_int();
		y = _os_.unmarshal_int();
		z = _os_.unmarshal_int();
		teamid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			notifyroles.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyPvp8SceneBattleCreated) {
			NotifyPvp8SceneBattleCreated _o_ = (NotifyPvp8SceneBattleCreated)_o1_;
			if (battleserverid != _o_.battleserverid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (x != _o_.x) return false;
			if (y != _o_.y) return false;
			if (z != _o_.z) return false;
			if (teamid != _o_.teamid) return false;
			if (!notifyroles.equals(_o_.notifyroles)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserverid;
		_h_ += (int)sceneid;
		_h_ += x;
		_h_ += y;
		_h_ += z;
		_h_ += (int)teamid;
		_h_ += notifyroles.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserverid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(x).append(",");
		_sb_.append(y).append(",");
		_sb_.append(z).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(notifyroles).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

