
package global.rsp.fuben;
import global.rsp.GlobalClientManager;
import java.util.List;
import knight.gsp.LogicalSceneEntry;
import knight.gsp.fuben.FubenConfig;
import knight.gsp.fuben.pvp4.Pvp4Manager;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.battle.Pvp4Battle;
import knight.gsp.scene.battle.newcopy.cfg.CopyCfg;
import knight.gsp.scene.sPos.Position;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __InitPvp4SceneBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class InitPvp4SceneBattle extends __InitPvp4SceneBattle__ {
	@Override
	protected void process() {
		FubenConfig fubenCfg = knight.gsp.fuben.Module.getInstance().getFubenConfig(Pvp4Manager.FUBEN_ID);
		if (fubenCfg == null)
			return;
		CopyCfg copyCfg = knight.gsp.scene.battle.Module.getInstance().getCopyCfgById(fubenCfg.battleId);
		if (copyCfg == null)
			return;
		final int limitTime = fubenCfg.limitTime;
		final int copyId = copyCfg.getCopyId();
		
		LogicalSceneEntry.createDynamicScene(copyCfg.getMapdId(), null, new ICreateSceneCallback() {

			@Override
			public void handle(Object obj, Scene newScene) {
				if (newScene == null)
					return;
				
				newScene.setSceneType(SceneType.PVP4);
				Pvp4Battle battle = newScene.getBattleEngine().startPvp4Battle(copyId);
				newScene.getBattleEngine().setFubenId(Pvp4Manager.FUBEN_ID);
				battle.setLimitTime(limitTime);
				
				battle.initTeamInfos((byte) Pvp4Battle.BLUE_CAMP, blueteams);
				battle.initTeamInfos((byte) Pvp4Battle.RED_CAMP, readteams);
				String[] pos1Array = newScene.getMapcfg().camp1roleinpos.split(",");
				String[] pos2Array = newScene.getMapcfg().camp2roleinpos.split(",");
				Position bluecampEnterPos = new Position(Float.parseFloat(pos1Array[0]), Float.parseFloat(pos1Array[1]), Float.parseFloat(pos1Array[2]));
				Position redcampEnterPos = new Position(Float.parseFloat(pos2Array[0]), Float.parseFloat(pos2Array[1]), Float.parseFloat(pos2Array[2]));
				
				notifySceneCreated(newScene, bluecampEnterPos, blueteams);
				notifySceneCreated(newScene, redcampEnterPos, readteams);
				
				battle.scheduleCountDownToSummonRoleEnterScene();
			}
			
		}, null);
	}
	
	private void notifySceneCreated(Scene newScene, Position enterPos, List<global.rsp.fuben.Pvp4TeamInfo> teamInfos) {
		final int serverId = ConfigManager.getGsZoneId();
		for (global.rsp.fuben.Pvp4TeamInfo teamInfo : teamInfos) {
			NotifyPvp4SceneBattleCreated notify = new NotifyPvp4SceneBattleCreated();
			notify.battleserverid = serverId;
			notify.sceneid = newScene.getSceneID();
			notify.teamid = teamInfo.teamid;
			notify.x = enterPos.getX();
			notify.y = enterPos.getY();
			notify.z = enterPos.getZ();
			notify.notifyroles.addAll(teamInfo.roleinfos.keySet());
			if (serverId == teamInfo.teamserverid) {
				//这个队伍就在本服
				SceneClient.pSend(notify);
			} else {
				//这个队伍时跨服队伍
				GlobalClientManager.getInstance().send(teamInfo.teamserverid, notify);
			}
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925757;

	public int getType() {
		return 925757;
	}

	public java.util.ArrayList<global.rsp.fuben.Pvp4TeamInfo> readteams; // 蓝方队伍
	public java.util.ArrayList<global.rsp.fuben.Pvp4TeamInfo> blueteams; // 红方队伍

	public InitPvp4SceneBattle() {
		readteams = new java.util.ArrayList<global.rsp.fuben.Pvp4TeamInfo>();
		blueteams = new java.util.ArrayList<global.rsp.fuben.Pvp4TeamInfo>();
	}

	public InitPvp4SceneBattle(java.util.ArrayList<global.rsp.fuben.Pvp4TeamInfo> _readteams_, java.util.ArrayList<global.rsp.fuben.Pvp4TeamInfo> _blueteams_) {
		this.readteams = _readteams_;
		this.blueteams = _blueteams_;
	}

	public final boolean _validator_() {
		for (global.rsp.fuben.Pvp4TeamInfo _v_ : readteams)
			if (!_v_._validator_()) return false;
		for (global.rsp.fuben.Pvp4TeamInfo _v_ : blueteams)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(readteams.size());
		for (global.rsp.fuben.Pvp4TeamInfo _v_ : readteams) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(blueteams.size());
		for (global.rsp.fuben.Pvp4TeamInfo _v_ : blueteams) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.Pvp4TeamInfo _v_ = new global.rsp.fuben.Pvp4TeamInfo();
			_v_.unmarshal(_os_);
			readteams.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.Pvp4TeamInfo _v_ = new global.rsp.fuben.Pvp4TeamInfo();
			_v_.unmarshal(_os_);
			blueteams.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof InitPvp4SceneBattle) {
			InitPvp4SceneBattle _o_ = (InitPvp4SceneBattle)_o1_;
			if (!readteams.equals(_o_.readteams)) return false;
			if (!blueteams.equals(_o_.blueteams)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += readteams.hashCode();
		_h_ += blueteams.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(readteams).append(",");
		_sb_.append(blueteams).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

