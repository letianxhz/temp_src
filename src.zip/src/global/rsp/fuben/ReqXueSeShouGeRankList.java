
package global.rsp.fuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqXueSeShouGeRankList__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqXueSeShouGeRankList extends __ReqXueSeShouGeRankList__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925795;

	public int getType() {
		return 925795;
	}

	public int requestserverid;
	public long requestroleid;

	public ReqXueSeShouGeRankList() {
	}

	public ReqXueSeShouGeRankList(int _requestserverid_, long _requestroleid_) {
		this.requestserverid = _requestserverid_;
		this.requestroleid = _requestroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(requestserverid);
		_os_.marshal(requestroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		requestserverid = _os_.unmarshal_int();
		requestroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqXueSeShouGeRankList) {
			ReqXueSeShouGeRankList _o_ = (ReqXueSeShouGeRankList)_o1_;
			if (requestserverid != _o_.requestserverid) return false;
			if (requestroleid != _o_.requestroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += requestserverid;
		_h_ += (int)requestroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(requestserverid).append(",");
		_sb_.append(requestroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(ReqXueSeShouGeRankList _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = requestserverid - _o_.requestserverid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(requestroleid - _o_.requestroleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

