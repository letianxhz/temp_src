
package global.rsp.fuben;

import knight.gsp.GsClient;
import knight.gsp.activity.xssgz.XueSeShouGeZhanManager;
import knight.gsp.scene.MapThreadProtocolParams;
import knight.gsp.scene.Scene;
import knight.gsp.scene.battle.BigWildSceneBattle;
import knight.gsp.scene.battle.SceneBattle;
import knight.gsp.scene.battle.XueSeShouGeBattleInfo;
import knight.msp.AbstractProtocol;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendTotalXueSeShouGeRankList__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendTotalXueSeShouGeRankList extends __SendTotalXueSeShouGeRankList__ {
	@Override
	protected void process() {
		//把全服排行数据先缓存一下
		for (int rank = 1; rank <= ranklist.size(); rank ++) {
			global.rsp.fuben.XueSeShouGeBattleRoleInfo rankRoleInfo = ranklist.get(rank - 1);
			if (rankRoleInfo == null)
				continue;
			
			XueSeShouGeZhanManager.getInstance().recordRoleRank(rankRoleInfo, rank);
		}
		
		XueSeShouGeZhanManager.getInstance().saveRankList(ranklist, -1L);
		
		GsClient.sendToScene(XueSeShouGeZhanManager.BATTLE_SCENE_ID, new AbstractProtocol() {
			
			@Override
			public void _process() {
				Scene scene = MapThreadProtocolParams.parseScene(getSender());
				if (scene == null)
					return;
				
				SceneBattle battle = scene.getBattleEngine().getSceneBattle();
				if (battle == null || !(battle instanceof BigWildSceneBattle))
					return;
				
				BigWildSceneBattle bigWildBattle = (BigWildSceneBattle) battle;
				XueSeShouGeBattleInfo battleInfo = bigWildBattle.getXueSeShouGeBattleInfo();
				battleInfo.clearXueSeBattleInfoWhileActEnd(false);
			}
		});
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925782;

	public int getType() {
		return 925782;
	}

	public java.util.ArrayList<global.rsp.fuben.XueSeShouGeBattleRoleInfo> ranklist;

	public SendTotalXueSeShouGeRankList() {
		ranklist = new java.util.ArrayList<global.rsp.fuben.XueSeShouGeBattleRoleInfo>();
	}

	public SendTotalXueSeShouGeRankList(java.util.ArrayList<global.rsp.fuben.XueSeShouGeBattleRoleInfo> _ranklist_) {
		this.ranklist = _ranklist_;
	}

	public final boolean _validator_() {
		for (global.rsp.fuben.XueSeShouGeBattleRoleInfo _v_ : ranklist)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(ranklist.size());
		for (global.rsp.fuben.XueSeShouGeBattleRoleInfo _v_ : ranklist) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.XueSeShouGeBattleRoleInfo _v_ = new global.rsp.fuben.XueSeShouGeBattleRoleInfo();
			_v_.unmarshal(_os_);
			ranklist.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendTotalXueSeShouGeRankList) {
			SendTotalXueSeShouGeRankList _o_ = (SendTotalXueSeShouGeRankList)_o1_;
			if (!ranklist.equals(_o_.ranklist)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += ranklist.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(ranklist).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

