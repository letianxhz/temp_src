
package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.main.ConfigManager;
import knight.gsp.scene.SceneClient;
import knight.gsp.team.Team;
import knight.gsp.team.TeamManager;
import knight.msp.NotifyEnterFuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyEnterCrossBossCopy__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyEnterCrossBossCopy extends __NotifyEnterCrossBossCopy__ {
	@Override
	protected void process() {
		Team team = TeamManager.selectTeamByTeamID(teamid);
		if (team == null || team.getSizeRobotNotInclude() < 2) {
			//这个队伍不存在了，把global的队伍删除一下
			GlobalClientManager.getInstance().send(new RemoveCrossBossTeam(copyid, teamid, teamcamp));
			return;
		}
		
		for (final long roleId : team.getAllMemberIds()) {
			if (battleserverid != ConfigManager.getGsZoneId()) {
				FubenCommon.sendGenterWorldData(roleId, FubenCommon.CROSS_BOSS_FUBEN_ID, battleserverid, battlesceneid, posx, posy, posz);
			} else {
				// 这个角色就在本服
				NotifyEnterFuben snd = new NotifyEnterFuben();
				snd.roleid = roleId;
				snd.sceneid = battlesceneid;
				snd.enterpos = new knight.gsp.scene.sPos.Position(posx, posy, posz).toProtocolPos();
				snd.fubenid = FubenCommon.CROSS_BOSS_FUBEN_ID;
				SceneClient.pSend(snd);
			}
			
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925748;

	public int getType() {
		return 925748;
	}

	public long copyid; // 战场唯一id
	public int battleserverid; // 战场服务器id
	public long battlesceneid; // 战场场景id
	public int posx;
	public int posy;
	public int posz;
	public long teamid; // 通知的队伍id
	public byte teamcamp; // 队伍所属阵营

	public NotifyEnterCrossBossCopy() {
	}

	public NotifyEnterCrossBossCopy(long _copyid_, int _battleserverid_, long _battlesceneid_, int _posx_, int _posy_, int _posz_, long _teamid_, byte _teamcamp_) {
		this.copyid = _copyid_;
		this.battleserverid = _battleserverid_;
		this.battlesceneid = _battlesceneid_;
		this.posx = _posx_;
		this.posy = _posy_;
		this.posz = _posz_;
		this.teamid = _teamid_;
		this.teamcamp = _teamcamp_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(copyid);
		_os_.marshal(battleserverid);
		_os_.marshal(battlesceneid);
		_os_.marshal(posx);
		_os_.marshal(posy);
		_os_.marshal(posz);
		_os_.marshal(teamid);
		_os_.marshal(teamcamp);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		copyid = _os_.unmarshal_long();
		battleserverid = _os_.unmarshal_int();
		battlesceneid = _os_.unmarshal_long();
		posx = _os_.unmarshal_int();
		posy = _os_.unmarshal_int();
		posz = _os_.unmarshal_int();
		teamid = _os_.unmarshal_long();
		teamcamp = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyEnterCrossBossCopy) {
			NotifyEnterCrossBossCopy _o_ = (NotifyEnterCrossBossCopy)_o1_;
			if (copyid != _o_.copyid) return false;
			if (battleserverid != _o_.battleserverid) return false;
			if (battlesceneid != _o_.battlesceneid) return false;
			if (posx != _o_.posx) return false;
			if (posy != _o_.posy) return false;
			if (posz != _o_.posz) return false;
			if (teamid != _o_.teamid) return false;
			if (teamcamp != _o_.teamcamp) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)copyid;
		_h_ += battleserverid;
		_h_ += (int)battlesceneid;
		_h_ += posx;
		_h_ += posy;
		_h_ += posz;
		_h_ += (int)teamid;
		_h_ += (int)teamcamp;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(copyid).append(",");
		_sb_.append(battleserverid).append(",");
		_sb_.append(battlesceneid).append(",");
		_sb_.append(posx).append(",");
		_sb_.append(posy).append(",");
		_sb_.append(posz).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(teamcamp).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(NotifyEnterCrossBossCopy _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(copyid - _o_.copyid);
		if (0 != _c_) return _c_;
		_c_ = battleserverid - _o_.battleserverid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(battlesceneid - _o_.battlesceneid);
		if (0 != _c_) return _c_;
		_c_ = posx - _o_.posx;
		if (0 != _c_) return _c_;
		_c_ = posy - _o_.posy;
		if (0 != _c_) return _c_;
		_c_ = posz - _o_.posz;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = teamcamp - _o_.teamcamp;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

