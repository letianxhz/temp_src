
package global.rsp.fuben;

import knight.gsp.scene.SceneClient;
import knight.msp.MSendCrossBossAwardMail;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendCrossCopyAwardMail__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendCrossCopyAwardMail extends __SendCrossCopyAwardMail__ {
	@Override
	protected void process() {
		MSendCrossBossAwardMail notifySendMail = new MSendCrossBossAwardMail();
		notifySendMail.mailid = mailid;
		notifySendMail.roleid = roleid;
		notifySendMail.items.putAll(items);
		SceneClient.pSend(notifySendMail);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925752;

	public int getType() {
		return 925752;
	}

	public long roleid; // 角色id
	public int mailid; // 邮件id
	public java.util.HashMap<Integer,Integer> items; // 奖励内容

	public SendCrossCopyAwardMail() {
		items = new java.util.HashMap<Integer,Integer>();
	}

	public SendCrossCopyAwardMail(long _roleid_, int _mailid_, java.util.HashMap<Integer,Integer> _items_) {
		this.roleid = _roleid_;
		this.mailid = _mailid_;
		this.items = _items_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(mailid);
		_os_.compact_uint32(items.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : items.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		mailid = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			items.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendCrossCopyAwardMail) {
			SendCrossCopyAwardMail _o_ = (SendCrossCopyAwardMail)_o1_;
			if (roleid != _o_.roleid) return false;
			if (mailid != _o_.mailid) return false;
			if (!items.equals(_o_.items)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += mailid;
		_h_ += items.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(mailid).append(",");
		_sb_.append(items).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

