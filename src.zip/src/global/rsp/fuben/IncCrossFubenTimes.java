
package global.rsp.fuben;
import knight.gsp.LocalIds;
import knight.gsp.fuben.FubenType;
import knight.gsp.fuben.PIncreaseCrossFubenTimes;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __IncCrossFubenTimes__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class IncCrossFubenTimes extends __IncCrossFubenTimes__ {
	@Override
	protected void process() {
		
		if (LocalIds.isRemoteServerRole(roleid))
			return;
		
		knight.gsp.fuben.FubenConfig fubenCfg = knight.gsp.fuben.Module.getInstance().getFubenConfig(fubenid);
		if (fubenCfg == null)
			return;
		
		if (fubenCfg.fubentype == FubenType.TASK_TEAM) {
			if (ishelper == 1 || istaskrole == 1)
				return;
		}
		
		new PIncreaseCrossFubenTimes(roleid, fubenid, ishelper == 1).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925716;

	public int getType() {
		return 925716;
	}

	public long roleid;
	public int fubenid;
	public byte ishelper; // 是否为帮杀者
	public byte istaskrole; // 是否为有任务者

	public IncCrossFubenTimes() {
		ishelper = 0;
		istaskrole = 0;
	}

	public IncCrossFubenTimes(long _roleid_, int _fubenid_, byte _ishelper_, byte _istaskrole_) {
		this.roleid = _roleid_;
		this.fubenid = _fubenid_;
		this.ishelper = _ishelper_;
		this.istaskrole = _istaskrole_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fubenid);
		_os_.marshal(ishelper);
		_os_.marshal(istaskrole);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fubenid = _os_.unmarshal_int();
		ishelper = _os_.unmarshal_byte();
		istaskrole = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof IncCrossFubenTimes) {
			IncCrossFubenTimes _o_ = (IncCrossFubenTimes)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fubenid != _o_.fubenid) return false;
			if (ishelper != _o_.ishelper) return false;
			if (istaskrole != _o_.istaskrole) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fubenid;
		_h_ += (int)ishelper;
		_h_ += (int)istaskrole;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(ishelper).append(",");
		_sb_.append(istaskrole).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(IncCrossFubenTimes _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = fubenid - _o_.fubenid;
		if (0 != _c_) return _c_;
		_c_ = ishelper - _o_.ishelper;
		if (0 != _c_) return _c_;
		_c_ = istaskrole - _o_.istaskrole;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

