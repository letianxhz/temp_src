
package global.rsp.fuben;
import knight.gsp.GsClient;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneService;
import knight.gsp.scene.battle.ResourceFightBattle;
import knight.gsp.scene.battle.SceneBattle;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SendCrossTeamInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SendCrossTeamInfo extends __SendCrossTeamInfo__ {
	@Override
	protected void process() {
		GsClient.sendToScene(sceneid, new xio.Protocol(){

			@Override
			protected void process() {
				Scene scene = SceneService.getInstance().getSceneById(sceneid);
				if (scene == null)
					return;
				
				SceneBattle sceneBattle = scene.getBattleEngine().getSceneBattle();
				if(sceneBattle == null || !(sceneBattle instanceof ResourceFightBattle)){
					return;
				}
				ResourceFightBattle battle = (ResourceFightBattle)sceneBattle;
				battle.addTeamMemberInfo(teamserverid, teamid, teammemberids);
			}

			@Override
			public OctetsStream marshal(OctetsStream arg0) {
				return null;
			}

			@Override
			public OctetsStream unmarshal(OctetsStream arg0)
					throws MarshalException {
				return null;
			}

			@Override
			public int getType() {
				return 0;
			}
			
		});
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925744;

	public int getType() {
		return 925744;
	}

	public long sceneid; // 场景id
	public int teamserverid; // 队伍原服服务器id
	public long teamid; // 队伍id
	public java.util.HashSet<Long> teammemberids; // 角色

	public SendCrossTeamInfo() {
		teammemberids = new java.util.HashSet<Long>();
	}

	public SendCrossTeamInfo(long _sceneid_, int _teamserverid_, long _teamid_, java.util.HashSet<Long> _teammemberids_) {
		this.sceneid = _sceneid_;
		this.teamserverid = _teamserverid_;
		this.teamid = _teamid_;
		this.teammemberids = _teammemberids_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(sceneid);
		_os_.marshal(teamserverid);
		_os_.marshal(teamid);
		_os_.compact_uint32(teammemberids.size());
		for (Long _v_ : teammemberids) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		sceneid = _os_.unmarshal_long();
		teamserverid = _os_.unmarshal_int();
		teamid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			teammemberids.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SendCrossTeamInfo) {
			SendCrossTeamInfo _o_ = (SendCrossTeamInfo)_o1_;
			if (sceneid != _o_.sceneid) return false;
			if (teamserverid != _o_.teamserverid) return false;
			if (teamid != _o_.teamid) return false;
			if (!teammemberids.equals(_o_.teammemberids)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)sceneid;
		_h_ += teamserverid;
		_h_ += (int)teamid;
		_h_ += teammemberids.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(sceneid).append(",");
		_sb_.append(teamserverid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(teammemberids).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

