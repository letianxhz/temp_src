
package global.rsp.fuben;

import knight.gsp.activity.xssgz.XueSeShouGeZhanManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReplyXueSeShouGeRankList__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReplyXueSeShouGeRankList extends __ReplyXueSeShouGeRankList__ {
	@Override
	protected void process() {
		XueSeShouGeZhanManager.getInstance().saveRankList(ranklist, requestroleid);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925796;

	public int getType() {
		return 925796;
	}

	public java.util.ArrayList<global.rsp.fuben.XueSeShouGeBattleRoleInfo> ranklist;
	public long requestroleid;

	public ReplyXueSeShouGeRankList() {
		ranklist = new java.util.ArrayList<global.rsp.fuben.XueSeShouGeBattleRoleInfo>();
	}

	public ReplyXueSeShouGeRankList(java.util.ArrayList<global.rsp.fuben.XueSeShouGeBattleRoleInfo> _ranklist_, long _requestroleid_) {
		this.ranklist = _ranklist_;
		this.requestroleid = _requestroleid_;
	}

	public final boolean _validator_() {
		for (global.rsp.fuben.XueSeShouGeBattleRoleInfo _v_ : ranklist)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(ranklist.size());
		for (global.rsp.fuben.XueSeShouGeBattleRoleInfo _v_ : ranklist) {
			_os_.marshal(_v_);
		}
		_os_.marshal(requestroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.XueSeShouGeBattleRoleInfo _v_ = new global.rsp.fuben.XueSeShouGeBattleRoleInfo();
			_v_.unmarshal(_os_);
			ranklist.add(_v_);
		}
		requestroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReplyXueSeShouGeRankList) {
			ReplyXueSeShouGeRankList _o_ = (ReplyXueSeShouGeRankList)_o1_;
			if (!ranklist.equals(_o_.ranklist)) return false;
			if (requestroleid != _o_.requestroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += ranklist.hashCode();
		_h_ += (int)requestroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(ranklist).append(",");
		_sb_.append(requestroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

