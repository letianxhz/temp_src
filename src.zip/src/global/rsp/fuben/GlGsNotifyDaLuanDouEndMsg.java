
package global.rsp.fuben;

import java.util.Arrays;
import knight.gsp.msg.Message;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GlGsNotifyDaLuanDouEndMsg__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GlGsNotifyDaLuanDouEndMsg extends __GlGsNotifyDaLuanDouEndMsg__ {
	@Override
	protected void process() {
		Message.sendSystemMsg(1030514, Arrays.asList(String.valueOf(servername), String.valueOf(firstname), String.valueOf(score)));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925791;

	public int getType() {
		return 925791;
	}

	public java.lang.String servername; // 冠军玩家服务器名称
	public java.lang.String firstname; // 冠军名字
	public int score; // 积分

	public GlGsNotifyDaLuanDouEndMsg() {
		servername = "";
		firstname = "";
	}

	public GlGsNotifyDaLuanDouEndMsg(java.lang.String _servername_, java.lang.String _firstname_, int _score_) {
		this.servername = _servername_;
		this.firstname = _firstname_;
		this.score = _score_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(servername, "UTF-16LE");
		_os_.marshal(firstname, "UTF-16LE");
		_os_.marshal(score);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		servername = _os_.unmarshal_String("UTF-16LE");
		firstname = _os_.unmarshal_String("UTF-16LE");
		score = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GlGsNotifyDaLuanDouEndMsg) {
			GlGsNotifyDaLuanDouEndMsg _o_ = (GlGsNotifyDaLuanDouEndMsg)_o1_;
			if (!servername.equals(_o_.servername)) return false;
			if (!firstname.equals(_o_.firstname)) return false;
			if (score != _o_.score) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += servername.hashCode();
		_h_ += firstname.hashCode();
		_h_ += score;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append("T").append(servername.length()).append(",");
		_sb_.append("T").append(firstname.length()).append(",");
		_sb_.append(score).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

