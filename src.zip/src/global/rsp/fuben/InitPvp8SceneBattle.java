
package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import java.util.List;
import knight.gsp.LogicalSceneEntry;
import knight.gsp.fuben.FubenConfig;
import knight.gsp.fuben.pvp8.Pvp8Manager;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.battle.Pvp8Battle;
import knight.gsp.scene.battle.newcopy.cfg.CopyCfg;
import knight.gsp.scene.sPos.Position;








// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __InitPvp8SceneBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class InitPvp8SceneBattle extends __InitPvp8SceneBattle__ {
	@Override
	protected void process() {
		FubenConfig fubenCfg = knight.gsp.fuben.Module.getInstance().getFubenConfig(Pvp8Manager.FUBEN_ID);
		if (fubenCfg == null)
			return;
		
		CopyCfg copyCfg = knight.gsp.scene.battle.Module.getInstance().getCopyCfgById(fubenCfg.battleId);
		if (copyCfg == null)
			return;
		
		final int limitTime = fubenCfg.limitTime;
		
		final int copyId = copyCfg.getCopyId();
		
		
		LogicalSceneEntry.createDynamicScene(copyCfg.getMapdId(), null, new ICreateSceneCallback() {

			@Override
			public void handle(Object obj, Scene newScene) {
				if (newScene == null)
					return;
				
				newScene.setSceneType(SceneType.PVP8);
				Pvp8Battle battle = newScene.getBattleEngine().startPvp8Battle(copyId);
				newScene.getBattleEngine().setFubenId(Pvp8Manager.FUBEN_ID);
				battle.setLimitTime(limitTime);
				//ps:协议没改 ： pvp8战斗是临时分配红蓝放阵营,没有骑士团兄弟会的概念
				battle.initTeamInfos((byte) Pvp8Battle.BLUE_CAMP, qishituanteams);
				battle.initTeamInfos((byte) Pvp8Battle.RED_CAMP, xiongdihuiteams);
				
				
				String[] pos1Array = newScene.getMapcfg().camp1roleinpos.split(",");
				String[] pos2Array = newScene.getMapcfg().camp2roleinpos.split(",");
				Position bluecampEnterPos = new Position(Float.parseFloat(pos1Array[0]), Float.parseFloat(pos1Array[1]), Float.parseFloat(pos1Array[2]));
				Position redcampEnterPos = new Position(Float.parseFloat(pos2Array[0]), Float.parseFloat(pos2Array[1]), Float.parseFloat(pos2Array[2]));
				
				notifySceneCreated(newScene, bluecampEnterPos, qishituanteams);
				notifySceneCreated(newScene, redcampEnterPos, xiongdihuiteams);
				
				battle.scheduleCountDownToSummonRoleEnterScene();
			}
			
		}, null);
	}
	
	private void notifySceneCreated(Scene newScene, Position enterPos, List<global.rsp.fuben.Pvp8TeamInfo> teamInfos) {
		final int serverId = ConfigManager.getGsZoneId();
		for (global.rsp.fuben.Pvp8TeamInfo teamInfo : teamInfos) {
			NotifyPvp8SceneBattleCreated notify = new NotifyPvp8SceneBattleCreated();
			notify.battleserverid = serverId;
			notify.sceneid = newScene.getSceneID();
			notify.teamid = teamInfo.teamid;
			notify.x = enterPos.getX();
			notify.y = enterPos.getY();
			notify.z = enterPos.getZ();
			notify.notifyroles.addAll(teamInfo.roleinfos.keySet());
			if (serverId == teamInfo.teamserverid) {
				//这个队伍就在本服
				SceneClient.pSend(notify);
			} else {
				//这个队伍时跨服队伍
				GlobalClientManager.getInstance().send(teamInfo.teamserverid, notify);
			}
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925729;

	public int getType() {
		return 925729;
	}

	public java.util.ArrayList<global.rsp.fuben.Pvp8TeamInfo> qishituanteams; // 骑士团的队伍
	public java.util.ArrayList<global.rsp.fuben.Pvp8TeamInfo> xiongdihuiteams; // 兄弟会的队伍

	public InitPvp8SceneBattle() {
		qishituanteams = new java.util.ArrayList<global.rsp.fuben.Pvp8TeamInfo>();
		xiongdihuiteams = new java.util.ArrayList<global.rsp.fuben.Pvp8TeamInfo>();
	}

	public InitPvp8SceneBattle(java.util.ArrayList<global.rsp.fuben.Pvp8TeamInfo> _qishituanteams_, java.util.ArrayList<global.rsp.fuben.Pvp8TeamInfo> _xiongdihuiteams_) {
		this.qishituanteams = _qishituanteams_;
		this.xiongdihuiteams = _xiongdihuiteams_;
	}

	public final boolean _validator_() {
		for (global.rsp.fuben.Pvp8TeamInfo _v_ : qishituanteams)
			if (!_v_._validator_()) return false;
		for (global.rsp.fuben.Pvp8TeamInfo _v_ : xiongdihuiteams)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.compact_uint32(qishituanteams.size());
		for (global.rsp.fuben.Pvp8TeamInfo _v_ : qishituanteams) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(xiongdihuiteams.size());
		for (global.rsp.fuben.Pvp8TeamInfo _v_ : xiongdihuiteams) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.Pvp8TeamInfo _v_ = new global.rsp.fuben.Pvp8TeamInfo();
			_v_.unmarshal(_os_);
			qishituanteams.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.Pvp8TeamInfo _v_ = new global.rsp.fuben.Pvp8TeamInfo();
			_v_.unmarshal(_os_);
			xiongdihuiteams.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof InitPvp8SceneBattle) {
			InitPvp8SceneBattle _o_ = (InitPvp8SceneBattle)_o1_;
			if (!qishituanteams.equals(_o_.qishituanteams)) return false;
			if (!xiongdihuiteams.equals(_o_.xiongdihuiteams)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += qishituanteams.hashCode();
		_h_ += xiongdihuiteams.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(qishituanteams).append(",");
		_sb_.append(xiongdihuiteams).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

