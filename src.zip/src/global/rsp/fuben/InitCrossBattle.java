
package global.rsp.fuben;
import global.rsp.GlobalClientManager;
import global.rsp.team.RobotTeammateTemplate;

import java.util.Map;

import knight.gsp.LogicalSceneEntry;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.move.battle.TeamFubenDeathHandler;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.battle.newcopy.CopySceneBattle;
import knight.gsp.scene.battle.newcopy.cfg.CopyCfg;
import knight.gsp.scene.sPos.Position;
import knight.msp.NotifyEnterFuben;



// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __InitCrossBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class InitCrossBattle extends __InitCrossBattle__ {
	@Override
	protected void process() {
		final knight.gsp.fuben.FubenConfig fubenCfg = knight.gsp.fuben.Module.getInstance().getFubenConfig(fubenid);
		final CopyCfg copyCfg = knight.gsp.scene.battle.Module.getInstance().getCopyCfgById(fubenCfg.battleId);
		
		LogicalSceneEntry.createDynamicScene(copyCfg.getMapdId(), null, new ICreateSceneCallback() {

			@Override
			public void handle(Object obj, Scene newScene) {

				Position pos = copyCfg.getEnterPos();
				newScene.setSceneType(SceneType.FUBEN);
				newScene.getBattleEngine().startCopyBattle(copyCfg.getCopyId());
				newScene.getBattleEngine().setFubenId(fubenid);
				
				CopySceneBattle copyBattle = newScene.getBattleEngine().getCopySceneBattle();
				copyBattle.setIsTeamFuben(true);
				copyBattle.setFubenType(fubenCfg.fubentype);
				copyBattle.setLimitTime(fubenCfg.limitTime);
				copyBattle.setFubenCfg(fubenCfg);
				for (long heperRoleId : friendlyhelpers) {
					copyBattle.addFriendlyHelpRole(heperRoleId);
				}
				copyBattle.addTaskRoles(taskroles);
				for (Map.Entry<Integer, RobotTeammateTemplate> entry : robotteammates.entrySet()){
					RobotTeammateTemplate robot = entry.getValue();
					copyBattle.summonRobotTeammates(robot, pos, entry.getKey(), teamid);
				}
				newScene.getBattleEngine().setDeathHandler(new TeamFubenDeathHandler(copyBattle));
				int curServerId = ConfigManager.getGsZoneId();
				
				for (Map.Entry<Long, Integer> entry : summonroles.entrySet()) {
					long roleId = entry.getKey();
					int toZoneId = entry.getValue();
					
					if (curServerId == toZoneId) {
						//就是本服的角色，告知切场景就好
						NotifyEnterFuben snd = new NotifyEnterFuben();
						snd.roleid = roleId;
						snd.sceneid = newScene.getSceneID();
						snd.enterpos = pos.toProtocolPos();
						SceneClient.pSend(snd);
					} else {
						final NotifySendGenterworldData snd = new NotifySendGenterworldData();
						snd.roleid = roleId;
						snd.sceneid = newScene.getSceneID();
						snd.copytoserver = ConfigManager.getGsZoneId();
						snd.x = pos.getX();
						snd.y = pos.getY();
						snd.z = pos.getZ();
						
						GlobalClientManager.getInstance().send(toZoneId, snd);
					}
				}
			
			}
			
		}, null);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925707;

	public int getType() {
		return 925707;
	}

	public long teamid;
	public int fubenid;
	public java.util.HashMap<Long,Integer> summonroles; // key为roleid，value为zoneid
	public java.util.HashSet<Long> friendlyhelpers; // 友情帮杀的人
	public java.util.HashSet<Long> taskroles; // 有任务的玩家，剧情组队副本中有用
	public java.util.HashMap<Integer,global.rsp.team.RobotTeammateTemplate> robotteammates; // 机器人

	public InitCrossBattle() {
		summonroles = new java.util.HashMap<Long,Integer>();
		friendlyhelpers = new java.util.HashSet<Long>();
		taskroles = new java.util.HashSet<Long>();
		robotteammates = new java.util.HashMap<Integer,global.rsp.team.RobotTeammateTemplate>();
	}

	public InitCrossBattle(long _teamid_, int _fubenid_, java.util.HashMap<Long,Integer> _summonroles_, java.util.HashSet<Long> _friendlyhelpers_, java.util.HashSet<Long> _taskroles_, java.util.HashMap<Integer,global.rsp.team.RobotTeammateTemplate> _robotteammates_) {
		this.teamid = _teamid_;
		this.fubenid = _fubenid_;
		this.summonroles = _summonroles_;
		this.friendlyhelpers = _friendlyhelpers_;
		this.taskroles = _taskroles_;
		this.robotteammates = _robotteammates_;
	}

	public final boolean _validator_() {
		for (java.util.Map.Entry<Integer, global.rsp.team.RobotTeammateTemplate> _e_ : robotteammates.entrySet()) {
			if (!_e_.getValue()._validator_()) return false;
		}
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(teamid);
		_os_.marshal(fubenid);
		_os_.compact_uint32(summonroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : summonroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(friendlyhelpers.size());
		for (Long _v_ : friendlyhelpers) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(taskroles.size());
		for (Long _v_ : taskroles) {
			_os_.marshal(_v_);
		}
		_os_.compact_uint32(robotteammates.size());
		for (java.util.Map.Entry<Integer, global.rsp.team.RobotTeammateTemplate> _e_ : robotteammates.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		teamid = _os_.unmarshal_long();
		fubenid = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			summonroles.put(_k_, _v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			friendlyhelpers.add(_v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			taskroles.add(_v_);
		}
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			global.rsp.team.RobotTeammateTemplate _v_ = new global.rsp.team.RobotTeammateTemplate();
			_v_.unmarshal(_os_);
			robotteammates.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof InitCrossBattle) {
			InitCrossBattle _o_ = (InitCrossBattle)_o1_;
			if (teamid != _o_.teamid) return false;
			if (fubenid != _o_.fubenid) return false;
			if (!summonroles.equals(_o_.summonroles)) return false;
			if (!friendlyhelpers.equals(_o_.friendlyhelpers)) return false;
			if (!taskroles.equals(_o_.taskroles)) return false;
			if (!robotteammates.equals(_o_.robotteammates)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)teamid;
		_h_ += fubenid;
		_h_ += summonroles.hashCode();
		_h_ += friendlyhelpers.hashCode();
		_h_ += taskroles.hashCode();
		_h_ += robotteammates.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(teamid).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(summonroles).append(",");
		_sb_.append(friendlyhelpers).append(",");
		_sb_.append(taskroles).append(",");
		_sb_.append(robotteammates).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

