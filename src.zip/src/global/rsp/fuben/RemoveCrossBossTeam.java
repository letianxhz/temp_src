
package global.rsp.fuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RemoveCrossBossTeam__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RemoveCrossBossTeam extends __RemoveCrossBossTeam__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925749;

	public int getType() {
		return 925749;
	}

	public long copyid; // 战场唯一id
	public long teamid; // 通知的队伍id
	public byte teamcamp; // 队伍所属阵营

	public RemoveCrossBossTeam() {
	}

	public RemoveCrossBossTeam(long _copyid_, long _teamid_, byte _teamcamp_) {
		this.copyid = _copyid_;
		this.teamid = _teamid_;
		this.teamcamp = _teamcamp_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(copyid);
		_os_.marshal(teamid);
		_os_.marshal(teamcamp);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		copyid = _os_.unmarshal_long();
		teamid = _os_.unmarshal_long();
		teamcamp = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RemoveCrossBossTeam) {
			RemoveCrossBossTeam _o_ = (RemoveCrossBossTeam)_o1_;
			if (copyid != _o_.copyid) return false;
			if (teamid != _o_.teamid) return false;
			if (teamcamp != _o_.teamcamp) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)copyid;
		_h_ += (int)teamid;
		_h_ += (int)teamcamp;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(copyid).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(teamcamp).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(RemoveCrossBossTeam _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(copyid - _o_.copyid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(teamid - _o_.teamid);
		if (0 != _c_) return _c_;
		_c_ = teamcamp - _o_.teamcamp;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

