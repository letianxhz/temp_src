
package global.rsp.fuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GsGlUpdateGuangYingRankData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GsGlUpdateGuangYingRankData extends __GsGlUpdateGuangYingRankData__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 926405;

	public int getType() {
		return 926405;
	}

	public int updatetype; // 类型 0:pvp4 1:pvp8
	public int serverid; // 请求的gs服务器id

	public GsGlUpdateGuangYingRankData() {
	}

	public GsGlUpdateGuangYingRankData(int _updatetype_, int _serverid_) {
		this.updatetype = _updatetype_;
		this.serverid = _serverid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(updatetype);
		_os_.marshal(serverid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		updatetype = _os_.unmarshal_int();
		serverid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GsGlUpdateGuangYingRankData) {
			GsGlUpdateGuangYingRankData _o_ = (GsGlUpdateGuangYingRankData)_o1_;
			if (updatetype != _o_.updatetype) return false;
			if (serverid != _o_.serverid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += updatetype;
		_h_ += serverid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(updatetype).append(",");
		_sb_.append(serverid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GsGlUpdateGuangYingRankData _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = updatetype - _o_.updatetype;
		if (0 != _c_) return _c_;
		_c_ = serverid - _o_.serverid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

