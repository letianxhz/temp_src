
package global.rsp.fuben;

import knight.gsp.LocalIds;
import knight.gsp.fuben.FubenCommon;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifySendGenterworldData__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifySendGenterworldData extends __NotifySendGenterworldData__ {
	@Override
	protected void process() {
		if (LocalIds.isRemoteServerRole(roleid))
			return;

		FubenCommon.sendGenterWorldData(roleid, fubenid, copytoserver, sceneid, x, y, z);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925708;

	public int getType() {
		return 925708;
	}

	public int copytoserver; // 需要拷贝到那个服务器
	public long roleid;
	public long sceneid;
	public int x;
	public int y;
	public int z;
	public int fubenid; // 要去打的副本id，没有则不填

	public NotifySendGenterworldData() {
	}

	public NotifySendGenterworldData(int _copytoserver_, long _roleid_, long _sceneid_, int _x_, int _y_, int _z_, int _fubenid_) {
		this.copytoserver = _copytoserver_;
		this.roleid = _roleid_;
		this.sceneid = _sceneid_;
		this.x = _x_;
		this.y = _y_;
		this.z = _z_;
		this.fubenid = _fubenid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(copytoserver);
		_os_.marshal(roleid);
		_os_.marshal(sceneid);
		_os_.marshal(x);
		_os_.marshal(y);
		_os_.marshal(z);
		_os_.marshal(fubenid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		copytoserver = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		sceneid = _os_.unmarshal_long();
		x = _os_.unmarshal_int();
		y = _os_.unmarshal_int();
		z = _os_.unmarshal_int();
		fubenid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifySendGenterworldData) {
			NotifySendGenterworldData _o_ = (NotifySendGenterworldData)_o1_;
			if (copytoserver != _o_.copytoserver) return false;
			if (roleid != _o_.roleid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (x != _o_.x) return false;
			if (y != _o_.y) return false;
			if (z != _o_.z) return false;
			if (fubenid != _o_.fubenid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += copytoserver;
		_h_ += (int)roleid;
		_h_ += (int)sceneid;
		_h_ += x;
		_h_ += y;
		_h_ += z;
		_h_ += fubenid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(copytoserver).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(x).append(",");
		_sb_.append(y).append(",");
		_sb_.append(z).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(NotifySendGenterworldData _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = copytoserver - _o_.copytoserver;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = x - _o_.x;
		if (0 != _c_) return _c_;
		_c_ = y - _o_.y;
		if (0 != _c_) return _c_;
		_c_ = z - _o_.z;
		if (0 != _c_) return _c_;
		_c_ = fubenid - _o_.fubenid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

