
package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import global.rsp.ranklist.GuangYingRankData;

import java.util.HashMap;
import java.util.Map;

import knight.gsp.LocalIds;
import knight.gsp.SExtGameData;
import knight.gsp.game.sguangyingjiangli;
import knight.gsp.item.EmailBox;
import knight.gsp.log.LogUtil;
import knight.gsp.main.ConfigManager;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __GiveGuangYingMailAward__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class GiveGuangYingMailAward extends __GiveGuangYingMailAward__ {
	@Override
	protected void process() {
		if (LocalIds.isRemoteServerRole(roleid))
			return;
		
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				
				int myRank = iswin == 1 ? rank : rank + 4;
				
				sguangyingjiangli mailAwardCfg = ConfigManager.getInstance().getConf(sguangyingjiangli.class).get(myRank);
				if (mailAwardCfg == null)
					return false;
				
				Map<String, Object> paras = new HashMap<String, Object>();
				paras.put("JingjiFieldScore", kscore);
				new EmailBox(roleid, false).sendMailWithGivenItems(mailAwardCfg.rewardmailid, null, null, null, null, paras);
				xbean.GuangYingRole dldr = xtable.Guangyingroles.get(roleid);
				if (dldr == null) {
					dldr = xbean.Pod.newGuangYingRole();
					xtable.Guangyingroles.insert(roleid, dldr);
				}
				
				dldr.setScore(dldr.getScore() + score);
				dldr.setEnternum(dldr.getEnternum() + 1);
				SExtGameData sndExtData = new SExtGameData();
				sndExtData.data.put(SExtGameData.GUANGYING_SCORE, dldr.getScore());
				xdb.Procedure.psendWhileCommit(roleid, sndExtData);
				
				if (iswin == 1 && !dldr.getIsreachfirstwin()) {
					//给予首胜奖励
					dldr.setIsreachfirstwin(true);
					new EmailBox(roleid, false).sendMail(ConfigManager.getInstance().getConf(sguangyingjiangli.class).get(9).rewardmailid);
				}
				//胜方mvp
				if(myRank == 1){
					new EmailBox(roleid, false).sendMail(ConfigManager.getInstance().getConf(sguangyingjiangli.class).get(10).rewardmailid);
				}
				//败方mvp
				if(myRank == 5){
					new EmailBox(roleid, false).sendMail(ConfigManager.getInstance().getConf(sguangyingjiangli.class).get(11).rewardmailid);
				}
				//战场积分放在Pvp8MatchInfo中
				xbean.Pvp8MatchInfo matchInfo = xtable.Pvp8matchdata.get(roleid);
				if (matchInfo == null) {
					matchInfo = xbean.Pod.newPvp8MatchInfo();
					xtable.Pvp8matchdata.insert(roleid, matchInfo);
				}
				matchInfo.setPiontcard(matchInfo.getPiontcard() + score);
				xbean.Properties prop = xtable.Properties.select(roleid);
				
				if (dldr.getScore() > 0) {
					//检查是否上榜
					GsGlNotifyGuangYingScoreData sndToGlobal = new GsGlNotifyGuangYingScoreData();
					OctetsStream os = new OctetsStream();
					GuangYingRankData pvpData = new GuangYingRankData();
					pvpData.name = prop.getRolename();
					pvpData.roleid = roleid;
					pvpData.school = prop.getSchool();
					pvpData.score = dldr.getScore();
					pvpData.zoneid = ConfigManager.getGsZoneId();
					sndToGlobal.pdata = os.marshal(pvpData);
					GlobalClientManager.getInstance().psendWhileCommit(sndToGlobal);
				}
				LogUtil.doGuangYingDuiJueFinishLog(roleid, dldr.getEnternum(), iswin, score, kscore, dldr.getScore(),killnum,assistnum,deadnum,boxnum);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 926407;

	public int getType() {
		return 926407;
	}

	public long roleid;
	public byte rank; // 排名
	public int score; // 积分
	public int kscore; // k值
	public byte iswin; // 1为获胜了，0输了
	public int killnum; // 杀人数
	public int assistnum; // 助攻数
	public int deadnum; // 死亡数
	public int boxnum; // 积分箱数

	public GiveGuangYingMailAward() {
	}

	public GiveGuangYingMailAward(long _roleid_, byte _rank_, int _score_, int _kscore_, byte _iswin_, int _killnum_, int _assistnum_, int _deadnum_, int _boxnum_) {
		this.roleid = _roleid_;
		this.rank = _rank_;
		this.score = _score_;
		this.kscore = _kscore_;
		this.iswin = _iswin_;
		this.killnum = _killnum_;
		this.assistnum = _assistnum_;
		this.deadnum = _deadnum_;
		this.boxnum = _boxnum_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(rank);
		_os_.marshal(score);
		_os_.marshal(kscore);
		_os_.marshal(iswin);
		_os_.marshal(killnum);
		_os_.marshal(assistnum);
		_os_.marshal(deadnum);
		_os_.marshal(boxnum);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		rank = _os_.unmarshal_byte();
		score = _os_.unmarshal_int();
		kscore = _os_.unmarshal_int();
		iswin = _os_.unmarshal_byte();
		killnum = _os_.unmarshal_int();
		assistnum = _os_.unmarshal_int();
		deadnum = _os_.unmarshal_int();
		boxnum = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof GiveGuangYingMailAward) {
			GiveGuangYingMailAward _o_ = (GiveGuangYingMailAward)_o1_;
			if (roleid != _o_.roleid) return false;
			if (rank != _o_.rank) return false;
			if (score != _o_.score) return false;
			if (kscore != _o_.kscore) return false;
			if (iswin != _o_.iswin) return false;
			if (killnum != _o_.killnum) return false;
			if (assistnum != _o_.assistnum) return false;
			if (deadnum != _o_.deadnum) return false;
			if (boxnum != _o_.boxnum) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += (int)rank;
		_h_ += score;
		_h_ += kscore;
		_h_ += (int)iswin;
		_h_ += killnum;
		_h_ += assistnum;
		_h_ += deadnum;
		_h_ += boxnum;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(rank).append(",");
		_sb_.append(score).append(",");
		_sb_.append(kscore).append(",");
		_sb_.append(iswin).append(",");
		_sb_.append(killnum).append(",");
		_sb_.append(assistnum).append(",");
		_sb_.append(deadnum).append(",");
		_sb_.append(boxnum).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(GiveGuangYingMailAward _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = rank - _o_.rank;
		if (0 != _c_) return _c_;
		_c_ = score - _o_.score;
		if (0 != _c_) return _c_;
		_c_ = kscore - _o_.kscore;
		if (0 != _c_) return _c_;
		_c_ = iswin - _o_.iswin;
		if (0 != _c_) return _c_;
		_c_ = killnum - _o_.killnum;
		if (0 != _c_) return _c_;
		_c_ = assistnum - _o_.assistnum;
		if (0 != _c_) return _c_;
		_c_ = deadnum - _o_.deadnum;
		if (0 != _c_) return _c_;
		_c_ = boxnum - _o_.boxnum;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

