
package global.rsp.fuben;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CrossRoleInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CrossRoleInfo extends __CrossRoleInfo__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925713;

	public int getType() {
		return 925713;
	}

	public long roleid;
	public int fromzoneid; // 从哪个服务器读取数据
	public int challengetimes; // 副本剩余次数
	public int physical; // 体力值
	public int fubenid;
	public int level;
	public int isinbattle; // 1表示在战斗或者野外场景，0表示不在战斗或者野外场景
	public int checkscore; // 用于判断是否解锁当前副本的积分或者评级

	public CrossRoleInfo() {
	}

	public CrossRoleInfo(long _roleid_, int _fromzoneid_, int _challengetimes_, int _physical_, int _fubenid_, int _level_, int _isinbattle_, int _checkscore_) {
		this.roleid = _roleid_;
		this.fromzoneid = _fromzoneid_;
		this.challengetimes = _challengetimes_;
		this.physical = _physical_;
		this.fubenid = _fubenid_;
		this.level = _level_;
		this.isinbattle = _isinbattle_;
		this.checkscore = _checkscore_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fromzoneid);
		_os_.marshal(challengetimes);
		_os_.marshal(physical);
		_os_.marshal(fubenid);
		_os_.marshal(level);
		_os_.marshal(isinbattle);
		_os_.marshal(checkscore);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fromzoneid = _os_.unmarshal_int();
		challengetimes = _os_.unmarshal_int();
		physical = _os_.unmarshal_int();
		fubenid = _os_.unmarshal_int();
		level = _os_.unmarshal_int();
		isinbattle = _os_.unmarshal_int();
		checkscore = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CrossRoleInfo) {
			CrossRoleInfo _o_ = (CrossRoleInfo)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (challengetimes != _o_.challengetimes) return false;
			if (physical != _o_.physical) return false;
			if (fubenid != _o_.fubenid) return false;
			if (level != _o_.level) return false;
			if (isinbattle != _o_.isinbattle) return false;
			if (checkscore != _o_.checkscore) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fromzoneid;
		_h_ += challengetimes;
		_h_ += physical;
		_h_ += fubenid;
		_h_ += level;
		_h_ += isinbattle;
		_h_ += checkscore;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(challengetimes).append(",");
		_sb_.append(physical).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(level).append(",");
		_sb_.append(isinbattle).append(",");
		_sb_.append(checkscore).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(CrossRoleInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = fromzoneid - _o_.fromzoneid;
		if (0 != _c_) return _c_;
		_c_ = challengetimes - _o_.challengetimes;
		if (0 != _c_) return _c_;
		_c_ = physical - _o_.physical;
		if (0 != _c_) return _c_;
		_c_ = fubenid - _o_.fubenid;
		if (0 != _c_) return _c_;
		_c_ = level - _o_.level;
		if (0 != _c_) return _c_;
		_c_ = isinbattle - _o_.isinbattle;
		if (0 != _c_) return _c_;
		_c_ = checkscore - _o_.checkscore;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

