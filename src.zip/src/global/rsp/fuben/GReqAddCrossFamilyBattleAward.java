package global.rsp.fuben;

import java.util.Set;

import knight.gsp.family.familyshop.SNextLotteryTime;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.SendProtocolThread;
import knight.gsp.scene.battle.BattleBroadcastReceiver;
import knight.msp.MGiveFamilyBattleLotteryAward;
import knight.msp.MGiveViewBattleAward;

import com.goldhuman.Common.Marshal.MarshalException;
import com.goldhuman.Common.Marshal.OctetsStream;

import xio.Protocol;

public class GReqAddCrossFamilyBattleAward extends Protocol {
	private int battleServer;
	private long battlesceneid; // 战斗所在的场景
	private int battleaward; // 观战抽奖奖励id
	private long nextlotterytime; // 下次观战抽奖时间
	private int awardType;//观战奖励类型 0：观战奖励 1：观战抽奖
	
	
	public GReqAddCrossFamilyBattleAward(int battleServer, long battleSceneId,
			int awardType, int battleaward, long nextlotterytime) {
		super();
		this.battleServer = battleServer;
		this.battlesceneid = battleSceneId;
		this.awardType = awardType;
		this.battleaward = battleaward;
		this.nextlotterytime = nextlotterytime;
	}


	@Override
	public void process() {
		
		BattleBroadcastReceiver battReceiver = BattleBroadcastReceiver.getReceiver(battleServer, battlesceneid);
		if (null == battReceiver)
			return;
		Set<Long> watchRoleIds = battReceiver.getWatchRoleAsCopy();
		if (watchRoleIds.isEmpty()) 
			return;
		if (awardType == 0) {
			MGiveViewBattleAward snd = new MGiveViewBattleAward();
			snd.viewerset.addAll(watchRoleIds);
			SceneClient.pSend(snd);
		} else if (awardType == 1) {
			SceneClient.pSend(new MGiveFamilyBattleLotteryAward(battleaward, watchRoleIds));
			long nextAwardTime = System.currentTimeMillis() + nextlotterytime;
			SendProtocolThread.getInstance().send(watchRoleIds, new SNextLotteryTime(nextAwardTime));
		}
	}
	
	
	@Override
	public OctetsStream marshal(OctetsStream arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OctetsStream unmarshal(OctetsStream arg0) throws MarshalException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return 0;
	}

}
