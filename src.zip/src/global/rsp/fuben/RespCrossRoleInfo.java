
package global.rsp.fuben;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.fuben.FubenEnterProcess;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __RespCrossRoleInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class RespCrossRoleInfo extends __RespCrossRoleInfo__ {
	@Override
	protected void process() {
			new xdb.Procedure(){
				@Override
				protected boolean process() throws Exception {
					OctetsStream ostream = OctetsStream.wrap(memberinfo);
					FubenEnterProcess enterProcess = FubenCommon.getFubenEnterProcess(roleid, fubenid);
					if (enterProcess.setRoleData(roleid, enterProcess.getCrossData(ostream))){
						enterProcess.checkEnterPlatOrEnterFuben(operation);
					}
					return true;
				}
				
			}.submit();
			
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925714;

	public int getType() {
		return 925714;
	}

	public long roleid;
	public int fubenid;
	public int operation; // 操作类型1-创建队伍；2-开始战斗
	public com.goldhuman.Common.Octets memberinfo;

	public RespCrossRoleInfo() {
		memberinfo = new com.goldhuman.Common.Octets();
	}

	public RespCrossRoleInfo(long _roleid_, int _fubenid_, int _operation_, com.goldhuman.Common.Octets _memberinfo_) {
		this.roleid = _roleid_;
		this.fubenid = _fubenid_;
		this.operation = _operation_;
		this.memberinfo = _memberinfo_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fubenid);
		_os_.marshal(operation);
		_os_.marshal(memberinfo);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fubenid = _os_.unmarshal_int();
		operation = _os_.unmarshal_int();
		memberinfo = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof RespCrossRoleInfo) {
			RespCrossRoleInfo _o_ = (RespCrossRoleInfo)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fubenid != _o_.fubenid) return false;
			if (operation != _o_.operation) return false;
			if (!memberinfo.equals(_o_.memberinfo)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fubenid;
		_h_ += operation;
		_h_ += memberinfo.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(operation).append(",");
		_sb_.append("B").append(memberinfo.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

