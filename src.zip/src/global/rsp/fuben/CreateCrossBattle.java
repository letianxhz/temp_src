
package global.rsp.fuben;
import knight.gsp.LogicalSceneEntry;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.battle.newcopy.cfg.CopyCfg;
import knight.gsp.scene.sPos.Position;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __CreateCrossBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class CreateCrossBattle extends __CreateCrossBattle__ {
	@Override
	protected void process() {
		final CopyCfg copyCfg = knight.gsp.scene.battle.Module.getInstance().getCopyCfgById(fubenid);
		
		LogicalSceneEntry.createDynamicScene(copyCfg.getMapdId(), null, new ICreateSceneCallback() {
			
			@Override
			public void handle(Object obj, Scene newScene) {
				Position pos = copyCfg.getEnterPos();
				newScene.setSceneType(SceneType.FUBEN);
				newScene.getBattleEngine().startCopyBattle(fubenid);
				
				final SummonToCross snd = new SummonToCross();
				snd.roleid = roleid;
				snd.sceneid = newScene.getSceneID();
				snd.zoneid = ConfigManager.getGsZoneId();
				snd.x = pos.getX();
				snd.y = pos.getY();
				snd.z = pos.getZ();
				
				SceneClient.pSend(new xio.Protocol() {
					
					@Override
					protected void process() {
						new xdb.Procedure() {

							@Override
							protected boolean process() throws Exception {
//								xbean.SaveCrossRole saveCrossRole = xtable.Savecrossroles.get(roleid);
//								if (saveCrossRole == null) {
//									saveCrossRole = xbean.Pod.newSaveCrossRole();
//									xtable.Savecrossroles.insert(roleid, saveCrossRole);
//								}
//								
//								OctetsStream octstram = OctetsStream.wrap(genterworld);
//								GEnterWorld gsnd = new GEnterWorld();
//								try {
//									gsnd.unmarshal(octstram);
//									
//									gsnd.mapinfo.posx = snd.x;
//									gsnd.mapinfo.posy = snd.y;
//									gsnd.mapinfo.posz = snd.z;
//									gsnd.mapinfo.sceneid = snd.sceneid;
//									saveCrossRole.setGenterworld(gsnd);
//									
//								} catch (MarshalException e) {
//									e.printStackTrace();
//								}
//								
//								GlobalClientManager.getInstance().send(zoneid, snd);
//								return true;
//							}
								return true;}
						}.submit();
						
					}

					@Override
					public OctetsStream marshal(OctetsStream arg0) {
						return null;
					}

					@Override
					public OctetsStream unmarshal(OctetsStream arg0)
							throws MarshalException {
						return null;
					}

					@Override
					public int getType() {
						return 0;
					}
					
				});
				
			}
		}, null);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925705;

	public int getType() {
		return 925705;
	}

	public int zoneid; // 服务器id
	public int fubenid;
	public long roleid;
	public com.goldhuman.Common.Octets genterworld;

	public CreateCrossBattle() {
		genterworld = new com.goldhuman.Common.Octets();
	}

	public CreateCrossBattle(int _zoneid_, int _fubenid_, long _roleid_, com.goldhuman.Common.Octets _genterworld_) {
		this.zoneid = _zoneid_;
		this.fubenid = _fubenid_;
		this.roleid = _roleid_;
		this.genterworld = _genterworld_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(fubenid);
		_os_.marshal(roleid);
		_os_.marshal(genterworld);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_int();
		fubenid = _os_.unmarshal_int();
		roleid = _os_.unmarshal_long();
		genterworld = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof CreateCrossBattle) {
			CreateCrossBattle _o_ = (CreateCrossBattle)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (fubenid != _o_.fubenid) return false;
			if (roleid != _o_.roleid) return false;
			if (!genterworld.equals(_o_.genterworld)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += zoneid;
		_h_ += fubenid;
		_h_ += (int)roleid;
		_h_ += genterworld.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append("B").append(genterworld.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

