
package global.rsp.fuben;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.main.ConfigManager;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.battle.BigWildSceneBattle;
import knight.gsp.scene.sPos.Position;
import knight.msp.NotifyEnterFuben;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __InitRoleEnterBigWildScene__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class InitRoleEnterBigWildScene extends __InitRoleEnterBigWildScene__ {
	@Override
	protected void process() {
		Position enterPos = BigWildSceneBattle.enterPosition;
		if (zoneid != ConfigManager.getGsZoneId()) {
			FubenCommon.sendGenterWorldData(role, FubenCommon.CROSS_BIG_WILD, zoneid, sceneid, enterPos.getX(), enterPos.getY(), enterPos.getZ());
		} else {
			// 这个角色就在本服
			NotifyEnterFuben snd = new NotifyEnterFuben();
			snd.roleid = role;
			snd.sceneid = sceneid;
			snd.enterpos = new knight.gsp.scene.sPos.Position(enterPos.getX(), enterPos.getY(), enterPos.getZ()).toProtocolPos();
			snd.fubenid = FubenCommon.CROSS_BIG_WILD;
			SceneClient.pSend(snd);
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925777;

	public int getType() {
		return 925777;
	}

	public long sceneid;
	public int zoneid;
	public long role;

	public InitRoleEnterBigWildScene() {
	}

	public InitRoleEnterBigWildScene(long _sceneid_, int _zoneid_, long _role_) {
		this.sceneid = _sceneid_;
		this.zoneid = _zoneid_;
		this.role = _role_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(sceneid);
		_os_.marshal(zoneid);
		_os_.marshal(role);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		sceneid = _os_.unmarshal_long();
		zoneid = _os_.unmarshal_int();
		role = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof InitRoleEnterBigWildScene) {
			InitRoleEnterBigWildScene _o_ = (InitRoleEnterBigWildScene)_o1_;
			if (sceneid != _o_.sceneid) return false;
			if (zoneid != _o_.zoneid) return false;
			if (role != _o_.role) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)sceneid;
		_h_ += zoneid;
		_h_ += (int)role;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(sceneid).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(role).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(InitRoleEnterBigWildScene _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(role - _o_.role);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

