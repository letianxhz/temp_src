
package global.rsp.fuben;
import knight.gsp.move.FighterStandCamp;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyBigWildPvpModelInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyBigWildPvpModelInfo extends __NotifyBigWildPvpModelInfo__ {
	@Override
	protected void process() {
		final xbean.Properties pro = xtable.Properties.select(roleid);
		if(null == pro)
			return;
		new xdb.Procedure(){
			protected boolean process() throws Exception {
				xbean.PvpModeRole pvpModeRole = xtable.Pvpmoderoles.get(roleid);
				if (pvpModeRole == null) {
					pvpModeRole = xbean.Pod.newPvpModeRole();
					xtable.Pvpmoderoles.insert(roleid, pvpModeRole);
				}
				xbean.FamilyMemberBean member = xtable.Familymember.select(roleid);
				//下线保存一下PVP模式相关数据
				if (null == member && curstate == FighterStandCamp.WILD_FAMILY_STATE) //这哥们被提出家族了,且开家族模式了,把他置为和平模式
					pvpModeRole.setCurstate((short)FighterStandCamp.WILD_PEACE_STATE);
				else
					pvpModeRole.setCurstate(curstate);
				pvpModeRole.setCdendtime(cdendtime);
				pvpModeRole.setIsautochangemode(isautochangemode == 1);
				pvpModeRole.setCritcdaddnow(critcdaddnow);
				return true;
			};
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925778;

	public int getType() {
		return 925778;
	}

	public long roleid;
	public short curstate; // 当前状态,0为和平模式，默认值，1为家族模式，2为杀戮模式。
	public long cdendtime; // CD结束时间
	public int isautochangemode; // 1:是 0:不是
	public short critcdaddnow; // 杀戮模式的CD叠加次数，每杀一个非杀戮模式的玩家会叠加一次CD

	public NotifyBigWildPvpModelInfo() {
	}

	public NotifyBigWildPvpModelInfo(long _roleid_, short _curstate_, long _cdendtime_, int _isautochangemode_, short _critcdaddnow_) {
		this.roleid = _roleid_;
		this.curstate = _curstate_;
		this.cdendtime = _cdendtime_;
		this.isautochangemode = _isautochangemode_;
		this.critcdaddnow = _critcdaddnow_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(curstate);
		_os_.marshal(cdendtime);
		_os_.marshal(isautochangemode);
		_os_.marshal(critcdaddnow);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		curstate = _os_.unmarshal_short();
		cdendtime = _os_.unmarshal_long();
		isautochangemode = _os_.unmarshal_int();
		critcdaddnow = _os_.unmarshal_short();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyBigWildPvpModelInfo) {
			NotifyBigWildPvpModelInfo _o_ = (NotifyBigWildPvpModelInfo)_o1_;
			if (roleid != _o_.roleid) return false;
			if (curstate != _o_.curstate) return false;
			if (cdendtime != _o_.cdendtime) return false;
			if (isautochangemode != _o_.isautochangemode) return false;
			if (critcdaddnow != _o_.critcdaddnow) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += curstate;
		_h_ += (int)cdendtime;
		_h_ += isautochangemode;
		_h_ += critcdaddnow;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(curstate).append(",");
		_sb_.append(cdendtime).append(",");
		_sb_.append(isautochangemode).append(",");
		_sb_.append(critcdaddnow).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(NotifyBigWildPvpModelInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = curstate - _o_.curstate;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(cdendtime - _o_.cdendtime);
		if (0 != _c_) return _c_;
		_c_ = isautochangemode - _o_.isautochangemode;
		if (0 != _c_) return _c_;
		_c_ = critcdaddnow - _o_.critcdaddnow;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

