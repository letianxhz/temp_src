
package global.rsp.fuben;

import global.rsp.GlobalClientManager;
import knight.gsp.LogicalSceneEntry;
import knight.gsp.fuben.FubenConfig;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.move.battle.SoloFubenDeathHandler;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.battle.newcopy.CopySceneBattle;
import knight.gsp.scene.battle.newcopy.cfg.CopyCfg;
import knight.gsp.scene.sPos.Position;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __TestGoCrossFuben__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class TestGoCrossFuben extends __TestGoCrossFuben__ {
	@Override
	protected void process() {

		final FubenConfig fubenCfg = knight.gsp.fuben.Module.getInstance().getFubenConfig(fubenid);
		
		if (fubenCfg == null) {
			return;
		}
		
		final CopyCfg copyCfg = knight.gsp.scene.battle.Module.getInstance().getCopyCfgById(fubenCfg.battleId);
		
		final int copyId = copyCfg.getCopyId();
		
		final int limitTime = fubenCfg.limitTime;
		
		LogicalSceneEntry.createDynamicScene(copyCfg.getMapdId(), null, new ICreateSceneCallback() {
			
			@Override
			public void handle(Object obj, Scene newScene) {
				Position pos = copyCfg.getEnterPos();
				newScene.setSceneType(SceneType.FUBEN);
				newScene.getBattleEngine().startCopyBattle(copyId);
				newScene.getBattleEngine().setFubenId(fubenid);
				
				CopySceneBattle copyBattle = newScene.getBattleEngine().getCopySceneBattle();
				copyBattle.setFubenCfg(fubenCfg);
				copyBattle.setFubenType(fubenCfg.fubentype);
				
				newScene.getBattleEngine().setDeathHandler(new SoloFubenDeathHandler(copyBattle,fubenid));
				newScene.getBattleEngine().getSceneBattle().setLimitTime(limitTime);
				
				final NotifySendGenterworldData snd = new NotifySendGenterworldData();
				snd.roleid = roleid;
				snd.sceneid = newScene.getSceneID();
				snd.copytoserver = ConfigManager.getGsZoneId();
				snd.x = pos.getX();
				snd.y = pos.getY();
				snd.z = pos.getZ();
				
				GlobalClientManager.getInstance().send(zoneid, snd);
				
			}
		}, null);
	
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925733;

	public int getType() {
		return 925733;
	}

	public long roleid;
	public int fubenid;
	public int zoneid;

	public TestGoCrossFuben() {
	}

	public TestGoCrossFuben(long _roleid_, int _fubenid_, int _zoneid_) {
		this.roleid = _roleid_;
		this.fubenid = _fubenid_;
		this.zoneid = _zoneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fubenid);
		_os_.marshal(zoneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fubenid = _os_.unmarshal_int();
		zoneid = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof TestGoCrossFuben) {
			TestGoCrossFuben _o_ = (TestGoCrossFuben)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fubenid != _o_.fubenid) return false;
			if (zoneid != _o_.zoneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fubenid;
		_h_ += zoneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(zoneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(TestGoCrossFuben _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = fubenid - _o_.fubenid;
		if (0 != _c_) return _c_;
		_c_ = zoneid - _o_.zoneid;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

