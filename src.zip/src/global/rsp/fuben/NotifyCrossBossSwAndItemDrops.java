
package global.rsp.fuben;

import knight.gsp.scene.SceneClient;
import knight.msp.MCalcCrossBossSwAndItemDrops;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyCrossBossSwAndItemDrops__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyCrossBossSwAndItemDrops extends __NotifyCrossBossSwAndItemDrops__ {
	@Override
	protected void process() {
		SceneClient.pSend(new MCalcCrossBossSwAndItemDrops(roleid, swchange, todaygainnum, todaylosenum, addtodaykillnum, itemchanges));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925753;

	public int getType() {
		return 925753;
	}

	public long roleid; // 角色id
	public int swchange; // 声望变化
	public int todaygainnum; // 今日获得
	public int todaylosenum; // 今日被抢
	public int addtodaykillnum; // 今日击杀增量
	public java.util.HashMap<Integer,Integer> itemchanges; // 魔化石最终变化，key为Itemid，value为数量，正数代表获得，负数代表失去

	public NotifyCrossBossSwAndItemDrops() {
		itemchanges = new java.util.HashMap<Integer,Integer>();
	}

	public NotifyCrossBossSwAndItemDrops(long _roleid_, int _swchange_, int _todaygainnum_, int _todaylosenum_, int _addtodaykillnum_, java.util.HashMap<Integer,Integer> _itemchanges_) {
		this.roleid = _roleid_;
		this.swchange = _swchange_;
		this.todaygainnum = _todaygainnum_;
		this.todaylosenum = _todaylosenum_;
		this.addtodaykillnum = _addtodaykillnum_;
		this.itemchanges = _itemchanges_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(swchange);
		_os_.marshal(todaygainnum);
		_os_.marshal(todaylosenum);
		_os_.marshal(addtodaykillnum);
		_os_.compact_uint32(itemchanges.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : itemchanges.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		swchange = _os_.unmarshal_int();
		todaygainnum = _os_.unmarshal_int();
		todaylosenum = _os_.unmarshal_int();
		addtodaykillnum = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			itemchanges.put(_k_, _v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyCrossBossSwAndItemDrops) {
			NotifyCrossBossSwAndItemDrops _o_ = (NotifyCrossBossSwAndItemDrops)_o1_;
			if (roleid != _o_.roleid) return false;
			if (swchange != _o_.swchange) return false;
			if (todaygainnum != _o_.todaygainnum) return false;
			if (todaylosenum != _o_.todaylosenum) return false;
			if (addtodaykillnum != _o_.addtodaykillnum) return false;
			if (!itemchanges.equals(_o_.itemchanges)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += swchange;
		_h_ += todaygainnum;
		_h_ += todaylosenum;
		_h_ += addtodaykillnum;
		_h_ += itemchanges.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(swchange).append(",");
		_sb_.append(todaygainnum).append(",");
		_sb_.append(todaylosenum).append(",");
		_sb_.append(addtodaykillnum).append(",");
		_sb_.append(itemchanges).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

