
package global.rsp.fuben;
import knight.gsp.scene.SceneClient;
import knight.msp.MCalcCrossBigWildAwardItemDrops;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyCrossBigWildAwardItemDrops__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyCrossBigWildAwardItemDrops extends __NotifyCrossBigWildAwardItemDrops__ {
	@Override
	protected void process() {
		SceneClient.pSend(new MCalcCrossBigWildAwardItemDrops(roleid, todaygainnum, todaylosenum, itemchanges, addkillcommonmonsternum, addkilljingyingmonsternum));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925779;

	public int getType() {
		return 925779;
	}

	public long roleid; // 角色id
	public int todaygainnum; // 今日获得
	public int todaylosenum; // 今日被抢
	public java.util.HashMap<Integer,Integer> itemchanges; // 魔化石最终变化，key为Itemid，value为数量，正数代表获得，负数代表失去
	public int addkillcommonmonsternum; // 新增击杀普通怪物数量
	public int addkilljingyingmonsternum; // 新增击杀精英怪物数量

	public NotifyCrossBigWildAwardItemDrops() {
		itemchanges = new java.util.HashMap<Integer,Integer>();
	}

	public NotifyCrossBigWildAwardItemDrops(long _roleid_, int _todaygainnum_, int _todaylosenum_, java.util.HashMap<Integer,Integer> _itemchanges_, int _addkillcommonmonsternum_, int _addkilljingyingmonsternum_) {
		this.roleid = _roleid_;
		this.todaygainnum = _todaygainnum_;
		this.todaylosenum = _todaylosenum_;
		this.itemchanges = _itemchanges_;
		this.addkillcommonmonsternum = _addkillcommonmonsternum_;
		this.addkilljingyingmonsternum = _addkilljingyingmonsternum_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(todaygainnum);
		_os_.marshal(todaylosenum);
		_os_.compact_uint32(itemchanges.size());
		for (java.util.Map.Entry<Integer, Integer> _e_ : itemchanges.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(addkillcommonmonsternum);
		_os_.marshal(addkilljingyingmonsternum);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		todaygainnum = _os_.unmarshal_int();
		todaylosenum = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			int _k_;
			_k_ = _os_.unmarshal_int();
			int _v_;
			_v_ = _os_.unmarshal_int();
			itemchanges.put(_k_, _v_);
		}
		addkillcommonmonsternum = _os_.unmarshal_int();
		addkilljingyingmonsternum = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyCrossBigWildAwardItemDrops) {
			NotifyCrossBigWildAwardItemDrops _o_ = (NotifyCrossBigWildAwardItemDrops)_o1_;
			if (roleid != _o_.roleid) return false;
			if (todaygainnum != _o_.todaygainnum) return false;
			if (todaylosenum != _o_.todaylosenum) return false;
			if (!itemchanges.equals(_o_.itemchanges)) return false;
			if (addkillcommonmonsternum != _o_.addkillcommonmonsternum) return false;
			if (addkilljingyingmonsternum != _o_.addkilljingyingmonsternum) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += todaygainnum;
		_h_ += todaylosenum;
		_h_ += itemchanges.hashCode();
		_h_ += addkillcommonmonsternum;
		_h_ += addkilljingyingmonsternum;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(todaygainnum).append(",");
		_sb_.append(todaylosenum).append(",");
		_sb_.append(itemchanges).append(",");
		_sb_.append(addkillcommonmonsternum).append(",");
		_sb_.append(addkilljingyingmonsternum).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

