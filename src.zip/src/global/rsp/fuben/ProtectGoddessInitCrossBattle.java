
package global.rsp.fuben;

import global.rsp.GlobalClientManager;

import java.util.Map;

import knight.gsp.LogicalSceneEntry;
import knight.gsp.main.ConfigManager;
import knight.gsp.move.SceneType;
import knight.gsp.move.battle.ProtectGoddessDeathHandler;
import knight.gsp.scene.ICreateSceneCallback;
import knight.gsp.scene.Scene;
import knight.gsp.scene.SceneClient;
import knight.gsp.scene.battle.newcopy.CopySceneBattle;
import knight.gsp.scene.battle.newcopy.cfg.CopyCfg;
import knight.gsp.scene.sPos.Position;
import knight.msp.NotifyEnterFuben;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ProtectGoddessInitCrossBattle__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ProtectGoddessInitCrossBattle extends __ProtectGoddessInitCrossBattle__ {
	@Override
	protected void process() {
		// protocol handle
		final knight.gsp.fuben.FubenConfig fubenCfg = knight.gsp.fuben.Module.getInstance().getFubenConfig(fubenid);
		final CopyCfg copyCfg = knight.gsp.scene.battle.Module.getInstance().getCopyCfgById(fubenCfg.battleId);
		
		LogicalSceneEntry.createDynamicScene(copyCfg.getMapdId(), null, new ICreateSceneCallback() {

			@Override
			public void handle(Object obj, Scene newScene) {

				Position pos = copyCfg.getEnterPos();
				newScene.setSceneType(SceneType.PROTECT_GODDESS);
				newScene.getBattleEngine().startProtectGoddessCopyBattle(copyCfg.getCopyId());
				newScene.getBattleEngine().setFubenId(fubenid);
				
				CopySceneBattle copyBattle = newScene.getBattleEngine().getCopySceneBattle();
				copyBattle.setIsTeamFuben(true);
				copyBattle.setFubenType(fubenCfg.fubentype);
				copyBattle.setLimitTime(fubenCfg.limitTime);
				copyBattle.setFubenCfg(fubenCfg);
				for (long heperRoleId : friendlyhelpers) {
					copyBattle.addFriendlyHelpRole(heperRoleId);
				}
				
				newScene.getBattleEngine().setDeathHandler(new ProtectGoddessDeathHandler(copyBattle));
				int curServerId = ConfigManager.getGsZoneId();
				
				for (Map.Entry<Long, Integer> entry : summonroles.entrySet()) {
					long roleId = entry.getKey();
					int toZoneId = entry.getValue();
					
					if (curServerId == toZoneId) {
						//就是本服的角色，告知切场景就好
						NotifyEnterFuben snd = new NotifyEnterFuben();
						snd.roleid = roleId;
						snd.sceneid = newScene.getSceneID();
						snd.enterpos = pos.toProtocolPos();
						SceneClient.pSend(snd);
					} else {
						final NotifySendGenterworldData snd = new NotifySendGenterworldData();
						snd.roleid = roleId;
						snd.sceneid = newScene.getSceneID();
						snd.copytoserver = ConfigManager.getGsZoneId();
						snd.x = pos.getX();
						snd.y = pos.getY();
						snd.z = pos.getZ();
						
						GlobalClientManager.getInstance().send(toZoneId, snd);
					}
				}
			
			}
			
		}, null);
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925726;

	public int getType() {
		return 925726;
	}

	public int fubenid;
	public java.util.HashMap<Long,Integer> summonroles; // key为roleid，value为zoneid
	public java.util.HashSet<Long> friendlyhelpers; // 友情帮杀的人

	public ProtectGoddessInitCrossBattle() {
		summonroles = new java.util.HashMap<Long,Integer>();
		friendlyhelpers = new java.util.HashSet<Long>();
	}

	public ProtectGoddessInitCrossBattle(int _fubenid_, java.util.HashMap<Long,Integer> _summonroles_, java.util.HashSet<Long> _friendlyhelpers_) {
		this.fubenid = _fubenid_;
		this.summonroles = _summonroles_;
		this.friendlyhelpers = _friendlyhelpers_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(fubenid);
		_os_.compact_uint32(summonroles.size());
		for (java.util.Map.Entry<Long, Integer> _e_ : summonroles.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.compact_uint32(friendlyhelpers.size());
		for (Long _v_ : friendlyhelpers) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		fubenid = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			long _k_;
			_k_ = _os_.unmarshal_long();
			int _v_;
			_v_ = _os_.unmarshal_int();
			summonroles.put(_k_, _v_);
		}
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			friendlyhelpers.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ProtectGoddessInitCrossBattle) {
			ProtectGoddessInitCrossBattle _o_ = (ProtectGoddessInitCrossBattle)_o1_;
			if (fubenid != _o_.fubenid) return false;
			if (!summonroles.equals(_o_.summonroles)) return false;
			if (!friendlyhelpers.equals(_o_.friendlyhelpers)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += fubenid;
		_h_ += summonroles.hashCode();
		_h_ += friendlyhelpers.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(fubenid).append(",");
		_sb_.append(summonroles).append(",");
		_sb_.append(friendlyhelpers).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

