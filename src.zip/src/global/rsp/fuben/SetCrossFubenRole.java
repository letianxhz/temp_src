
package global.rsp.fuben;
import knight.gsp.fuben.PSetCrossFubenRole;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __SetCrossFubenRole__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class SetCrossFubenRole extends __SetCrossFubenRole__ {
	@Override
	protected void process() {
		new PSetCrossFubenRole(roleid, fubenid, star, ishelper).submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925715;

	public int getType() {
		return 925715;
	}

	public long roleid;
	public int fubenid;
	public java.util.ArrayList<Integer> star; // 星星数
	public byte ishelper; // 是否为帮杀者

	public SetCrossFubenRole() {
		star = new java.util.ArrayList<Integer>();
		ishelper = 0;
	}

	public SetCrossFubenRole(long _roleid_, int _fubenid_, java.util.ArrayList<Integer> _star_, byte _ishelper_) {
		this.roleid = _roleid_;
		this.fubenid = _fubenid_;
		this.star = _star_;
		this.ishelper = _ishelper_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(fubenid);
		_os_.compact_uint32(star.size());
		for (Integer _v_ : star) {
			_os_.marshal(_v_);
		}
		_os_.marshal(ishelper);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		fubenid = _os_.unmarshal_int();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			star.add(_v_);
		}
		ishelper = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof SetCrossFubenRole) {
			SetCrossFubenRole _o_ = (SetCrossFubenRole)_o1_;
			if (roleid != _o_.roleid) return false;
			if (fubenid != _o_.fubenid) return false;
			if (!star.equals(_o_.star)) return false;
			if (ishelper != _o_.ishelper) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += fubenid;
		_h_ += star.hashCode();
		_h_ += (int)ishelper;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(fubenid).append(",");
		_sb_.append(star).append(",");
		_sb_.append(ishelper).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

