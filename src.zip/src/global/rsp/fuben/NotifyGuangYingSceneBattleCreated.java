
package global.rsp.fuben;

import java.util.List;

import gnet.link.Onlines;
import knight.gsp.activity.guangyingduijue.GuangYingManager;
import knight.gsp.fuben.SAskToEnterPvp8;
import knight.gsp.fuben.pvp8.CacheBattleSceneInfo;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __NotifyGuangYingSceneBattleCreated__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class NotifyGuangYingSceneBattleCreated extends __NotifyGuangYingSceneBattleCreated__ {
	@Override
	protected void process() {
		new xdb.Procedure() {
			@Override
			protected boolean process() throws Exception {
				List<gyPostion> list = enterpositions;
				lock(xtable.Locks.ROLELOCK, notifyroles);
				int i =0;
				for (long roleId : notifyroles) {
					CacheBattleSceneInfo info = new CacheBattleSceneInfo();
					info.serverId = battleserverid;
					info.sceneId = sceneid;
					xtable.Matchingroles.remove(roleId);
					Onlines.getInstance().send(roleId, new SAskToEnterPvp8((byte) 4));
					info.x = list.get(i).x;
					info.y = list.get(i).y;
					info.z = list.get(i).z;
					GuangYingManager.getInstance().addCacheBattleScene(roleId, info);
				    i++;
				}
				return true;
			}
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925799;

	public int getType() {
		return 925799;
	}

	public int battleserverid; // 战场所在服务器
	public long sceneid; // 战场的场景id
	public java.util.ArrayList<global.rsp.fuben.gyPostion> enterpositions;
	public long teamid; // 队伍id
	public java.util.HashSet<Long> notifyroles; // 角色id

	public NotifyGuangYingSceneBattleCreated() {
		enterpositions = new java.util.ArrayList<global.rsp.fuben.gyPostion>();
		notifyroles = new java.util.HashSet<Long>();
	}

	public NotifyGuangYingSceneBattleCreated(int _battleserverid_, long _sceneid_, java.util.ArrayList<global.rsp.fuben.gyPostion> _enterpositions_, long _teamid_, java.util.HashSet<Long> _notifyroles_) {
		this.battleserverid = _battleserverid_;
		this.sceneid = _sceneid_;
		this.enterpositions = _enterpositions_;
		this.teamid = _teamid_;
		this.notifyroles = _notifyroles_;
	}

	public final boolean _validator_() {
		for (global.rsp.fuben.gyPostion _v_ : enterpositions)
			if (!_v_._validator_()) return false;
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(battleserverid);
		_os_.marshal(sceneid);
		_os_.compact_uint32(enterpositions.size());
		for (global.rsp.fuben.gyPostion _v_ : enterpositions) {
			_os_.marshal(_v_);
		}
		_os_.marshal(teamid);
		_os_.compact_uint32(notifyroles.size());
		for (Long _v_ : notifyroles) {
			_os_.marshal(_v_);
		}
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		battleserverid = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			global.rsp.fuben.gyPostion _v_ = new global.rsp.fuben.gyPostion();
			_v_.unmarshal(_os_);
			enterpositions.add(_v_);
		}
		teamid = _os_.unmarshal_long();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			long _v_;
			_v_ = _os_.unmarshal_long();
			notifyroles.add(_v_);
		}
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof NotifyGuangYingSceneBattleCreated) {
			NotifyGuangYingSceneBattleCreated _o_ = (NotifyGuangYingSceneBattleCreated)_o1_;
			if (battleserverid != _o_.battleserverid) return false;
			if (sceneid != _o_.sceneid) return false;
			if (!enterpositions.equals(_o_.enterpositions)) return false;
			if (teamid != _o_.teamid) return false;
			if (!notifyroles.equals(_o_.notifyroles)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += battleserverid;
		_h_ += (int)sceneid;
		_h_ += enterpositions.hashCode();
		_h_ += (int)teamid;
		_h_ += notifyroles.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(battleserverid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(enterpositions).append(",");
		_sb_.append(teamid).append(",");
		_sb_.append(notifyroles).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

