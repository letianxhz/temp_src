
package global.rsp.fuben;
import xbean.CrossState;
import knight.gsp.LocalIds;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __UpdateCrossState__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class UpdateCrossState extends __UpdateCrossState__ {
	@Override
	protected void process() {
		if(roleid <= 0 || LocalIds.isRemoteServerRole(roleid)){
			return;
		}
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				CrossState crossState = xtable.Crossstate.get(roleid);
				if(crossState == null){
					return false;
				}
				crossState.setSceneid(sceneid);
				crossState.setServerid(crossserverid);
				return true;
			}
			
		}.submit();
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 925725;

	public int getType() {
		return 925725;
	}

	public long roleid;
	public int crossserverid;
	public long sceneid;

	public UpdateCrossState() {
	}

	public UpdateCrossState(long _roleid_, int _crossserverid_, long _sceneid_) {
		this.roleid = _roleid_;
		this.crossserverid = _crossserverid_;
		this.sceneid = _sceneid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(roleid);
		_os_.marshal(crossserverid);
		_os_.marshal(sceneid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		roleid = _os_.unmarshal_long();
		crossserverid = _os_.unmarshal_int();
		sceneid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof UpdateCrossState) {
			UpdateCrossState _o_ = (UpdateCrossState)_o1_;
			if (roleid != _o_.roleid) return false;
			if (crossserverid != _o_.crossserverid) return false;
			if (sceneid != _o_.sceneid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)roleid;
		_h_ += crossserverid;
		_h_ += (int)sceneid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(roleid).append(",");
		_sb_.append(crossserverid).append(",");
		_sb_.append(sceneid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(UpdateCrossState _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = Long.signum(roleid - _o_.roleid);
		if (0 != _c_) return _c_;
		_c_ = crossserverid - _o_.crossserverid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(sceneid - _o_.sceneid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

