package global.rsp.fuben;

import java.util.Arrays;

import knight.gsp.activity.resourcefight.ResourceFightManager;
import knight.gsp.activity.springfestival.treasuresteal.TreasureStealGhostManager;
import xdb.Procedure;

public class POnResourceFightSceneCreated extends Procedure {

	private NotifyResourceFightSceneCreated msg;
	
	public POnResourceFightSceneCreated(NotifyResourceFightSceneCreated msg) {
		super();
		this.msg = msg;
	}


	@Override
	protected boolean process() throws Exception {
		lock(xtable.Locks.TEAMLOCK, Arrays.asList(msg.teamid));
		lock(xtable.Locks.ROLELOCK, msg.teammemberids);
		for(long rid : msg.teammemberids){
			xbean.ResourceFightRecord record = xtable.Resourcefightrecord.get(rid);
			if(record == null){
				record = xbean.Pod.newResourceFightRecord();
				xtable.Resourcefightrecord.insert(rid, record);
			}
			boolean need2ClearRecord = false;
			if(ResourceFightManager.getInstance().isInActivityPeriod()){
				need2ClearRecord = ResourceFightManager.getInstance().need2ClearFightRecord(record.getTime());
				record.setTime(System.currentTimeMillis());
			} else {
				need2ClearRecord = TreasureStealGhostManager.getInstance().need2ClearFightRecord(record.getTime());
				record.setTime(TreasureStealGhostManager.getInstance().getNpcCreateTime());
			}
			if(!need2ClearRecord){
				Integer oldTimes = record.getFightrecord().get(msg.npcid);
				if(oldTimes == null){
					oldTimes = 0;
				}
				record.getFightrecord().put(msg.npcid, oldTimes + 1);
			} else {
				record.getFightrecord().clear();
				record.getFightrecord().put(msg.npcid, 1);
				record.getAwardrecord().clear();
			}
		}
		return true;
	}

}
