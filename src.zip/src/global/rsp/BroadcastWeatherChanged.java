
package global.rsp;

import knight.gsp.activity.weathercard.WeatherManager;
// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __BroadcastWeatherChanged__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class BroadcastWeatherChanged extends __BroadcastWeatherChanged__ {
	@Override
	protected void process() {
		if (isopen == 1) {
			WeatherManager.getInstance().startWeatherAct(actid);
		} else {
			WeatherManager.getInstance().endWeatherAct(actid);
		}
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918230;

	public int getType() {
		return 918230;
	}

	public int actid; // 角色id
	public byte isopen; // 1为开，0为关闭

	public BroadcastWeatherChanged() {
	}

	public BroadcastWeatherChanged(int _actid_, byte _isopen_) {
		this.actid = _actid_;
		this.isopen = _isopen_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(actid);
		_os_.marshal(isopen);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		actid = _os_.unmarshal_int();
		isopen = _os_.unmarshal_byte();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof BroadcastWeatherChanged) {
			BroadcastWeatherChanged _o_ = (BroadcastWeatherChanged)_o1_;
			if (actid != _o_.actid) return false;
			if (isopen != _o_.isopen) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += actid;
		_h_ += (int)isopen;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(actid).append(",");
		_sb_.append(isopen).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(BroadcastWeatherChanged _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = actid - _o_.actid;
		if (0 != _c_) return _c_;
		_c_ = isopen - _o_.isopen;
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

