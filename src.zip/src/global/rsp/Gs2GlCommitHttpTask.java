
package global.rsp;

// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __Gs2GlCommitHttpTask__ extends xio.Protocol { }

/** Gs向Global提交HTTP任务
*/
// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class Gs2GlCommitHttpTask extends __Gs2GlCommitHttpTask__ {
	@Override
	protected void process() {
		// protocol handle
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 924528;

	public int getType() {
		return 924528;
	}

	public long zoneid;
	public long roleid;
	public int operation;
	public java.util.HashMap<com.goldhuman.Common.Octets,com.goldhuman.Common.Octets> data; // 数据
	public int counter;

	public Gs2GlCommitHttpTask() {
		data = new java.util.HashMap<com.goldhuman.Common.Octets,com.goldhuman.Common.Octets>();
	}

	public Gs2GlCommitHttpTask(long _zoneid_, long _roleid_, int _operation_, java.util.HashMap<com.goldhuman.Common.Octets,com.goldhuman.Common.Octets> _data_, int _counter_) {
		this.zoneid = _zoneid_;
		this.roleid = _roleid_;
		this.operation = _operation_;
		this.data = _data_;
		this.counter = _counter_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(zoneid);
		_os_.marshal(roleid);
		_os_.marshal(operation);
		_os_.compact_uint32(data.size());
		for (java.util.Map.Entry<com.goldhuman.Common.Octets, com.goldhuman.Common.Octets> _e_ : data.entrySet()) {
			_os_.marshal(_e_.getKey());
			_os_.marshal(_e_.getValue());
		}
		_os_.marshal(counter);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		zoneid = _os_.unmarshal_long();
		roleid = _os_.unmarshal_long();
		operation = _os_.unmarshal_int();
		for (int size = _os_.uncompact_uint32(); size > 0; --size) {
			com.goldhuman.Common.Octets _k_;
			_k_ = _os_.unmarshal_Octets();
			com.goldhuman.Common.Octets _v_;
			_v_ = _os_.unmarshal_Octets();
			data.put(_k_, _v_);
		}
		counter = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof Gs2GlCommitHttpTask) {
			Gs2GlCommitHttpTask _o_ = (Gs2GlCommitHttpTask)_o1_;
			if (zoneid != _o_.zoneid) return false;
			if (roleid != _o_.roleid) return false;
			if (operation != _o_.operation) return false;
			if (!data.equals(_o_.data)) return false;
			if (counter != _o_.counter) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += (int)zoneid;
		_h_ += (int)roleid;
		_h_ += operation;
		_h_ += data.hashCode();
		_h_ += counter;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(zoneid).append(",");
		_sb_.append(roleid).append(",");
		_sb_.append(operation).append(",");
		_sb_.append(data).append(",");
		_sb_.append(counter).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

