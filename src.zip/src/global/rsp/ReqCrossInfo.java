
package global.rsp;

import knight.gsp.dragon.CQueryOtherDragonInfo;
import knight.gsp.dragon.SQueryOtherDragonInfo;
import knight.gsp.fashion.FashionManager;
import knight.gsp.fashion.SRetOthterFashionInfo;
import knight.gsp.item.CGetPkCardInfo;
import knight.gsp.item.SPkCardInfo;
import knight.gsp.mercenary.CQueryOtherMercenary;
import knight.gsp.mercenary.SQueryOtherMercenary;
import knight.gsp.ride.CQueryOtherRideInfo;
import knight.gsp.ride.SQueryOtherRideInfo;
import knight.gsp.shenqi.SQueryOtherShenQiInfo;
import knight.gsp.shenqi.ShenQiManager;
import knight.gsp.wing.SQueryOtherWingInfo;
import knight.gsp.wing.WingManager;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __ReqCrossInfo__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class ReqCrossInfo extends __ReqCrossInfo__ {
	@Override
	protected void process() {
		xio.Protocol requestData = null;
		if (protocoltype == SPkCardInfo.PROTOCOL_TYPE) {
			//请求PK卡信息
			requestData = CGetPkCardInfo.getCardMsg(fromroleid, dstroleid);
		} else if (protocoltype == SQueryOtherWingInfo.PROTOCOL_TYPE) {
			//翅膀信息
			requestData = WingManager.getInstance().getWingInfo(dstroleid);
		} else if (protocoltype == SQueryOtherRideInfo.PROTOCOL_TYPE) {
			requestData = CQueryOtherRideInfo.getOtherRoleRideInfo(dstroleid);
		} else if (protocoltype == SQueryOtherDragonInfo.PROTOCOL_TYPE) {
			requestData = CQueryOtherDragonInfo.getOtherRoleDragonInfo(dstroleid);
		} else if (protocoltype == SQueryOtherMercenary.PROTOCOL_TYPE) {
			requestData = CQueryOtherMercenary.getOtherRoleMercenaryInfo(dstroleid);
		} else if (protocoltype == SRetOthterFashionInfo.PROTOCOL_TYPE) {
			requestData = FashionManager.getInstance().getOthterRoleFashionInfo(dstroleid);
		} else if (protocoltype == SQueryOtherShenQiInfo.PROTOCOL_TYPE)
			requestData = ShenQiManager.getInstance().getOtherShenQiInfo(dstroleid);
		
		if (requestData == null)
			return;
		
		OctetsStream os = new OctetsStream();
		os.marshal(requestData);
		
		GlobalClientManager.getInstance().send(fromzoneid, new ReplyCrossInfo(protocoltype, os, fromzoneid, dstzoneid, fromroleid, dstroleid));
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 918216;

	public int getType() {
		return 918216;
	}

	public int protocoltype;
	public int fromzoneid;
	public int dstzoneid;
	public long fromroleid;
	public long dstroleid;

	public ReqCrossInfo() {
	}

	public ReqCrossInfo(int _protocoltype_, int _fromzoneid_, int _dstzoneid_, long _fromroleid_, long _dstroleid_) {
		this.protocoltype = _protocoltype_;
		this.fromzoneid = _fromzoneid_;
		this.dstzoneid = _dstzoneid_;
		this.fromroleid = _fromroleid_;
		this.dstroleid = _dstroleid_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(protocoltype);
		_os_.marshal(fromzoneid);
		_os_.marshal(dstzoneid);
		_os_.marshal(fromroleid);
		_os_.marshal(dstroleid);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		protocoltype = _os_.unmarshal_int();
		fromzoneid = _os_.unmarshal_int();
		dstzoneid = _os_.unmarshal_int();
		fromroleid = _os_.unmarshal_long();
		dstroleid = _os_.unmarshal_long();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof ReqCrossInfo) {
			ReqCrossInfo _o_ = (ReqCrossInfo)_o1_;
			if (protocoltype != _o_.protocoltype) return false;
			if (fromzoneid != _o_.fromzoneid) return false;
			if (dstzoneid != _o_.dstzoneid) return false;
			if (fromroleid != _o_.fromroleid) return false;
			if (dstroleid != _o_.dstroleid) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += protocoltype;
		_h_ += fromzoneid;
		_h_ += dstzoneid;
		_h_ += (int)fromroleid;
		_h_ += (int)dstroleid;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(protocoltype).append(",");
		_sb_.append(fromzoneid).append(",");
		_sb_.append(dstzoneid).append(",");
		_sb_.append(fromroleid).append(",");
		_sb_.append(dstroleid).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	public int compareTo(ReqCrossInfo _o_) {
		if (_o_ == this) return 0;
		int _c_ = 0;
		_c_ = protocoltype - _o_.protocoltype;
		if (0 != _c_) return _c_;
		_c_ = fromzoneid - _o_.fromzoneid;
		if (0 != _c_) return _c_;
		_c_ = dstzoneid - _o_.dstzoneid;
		if (0 != _c_) return _c_;
		_c_ = Long.signum(fromroleid - _o_.fromroleid);
		if (0 != _c_) return _c_;
		_c_ = Long.signum(dstroleid - _o_.dstroleid);
		if (0 != _c_) return _c_;
		return _c_;
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

