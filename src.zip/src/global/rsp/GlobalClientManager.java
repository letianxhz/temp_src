package global.rsp;

import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import knight.gsp.main.ConfigManager;

import org.apache.log4j.Logger;

import com.goldhuman.Common.Marshal.OctetsStream;

import xio.Manager;
import xio.Xio;

public class GlobalClientManager extends Manager {

	public static Logger logger = Logger.getLogger(GlobalClientManager.class);

	private static GlobalClientManager instance = null;
	
	private int delay = 0;
	long lastLogTime = 0;

	public GlobalClientManager() {
		instance = this;
	}

	public static GlobalClientManager getInstance() {
		return instance;
	}
	
	private xio.Xio handle = null;
	private final ReentrantLock lock = new ReentrantLock();
	

	@Override
	protected void addXio(Xio xio) {
		lock.lock();
		try {
			handle = xio;
			
			long timeSpace = System.currentTimeMillis() - lastLogTime;
			if(timeSpace < delay)
				return;
			if(timeSpace < 1000){
				delay = 30*1000;
				return;
			}
			lastLogTime = System.currentTimeMillis();
			
			if(null == xio){
				logger.info("添加global null 连接： ");
			}else{
				logger.info("添加global 连接： " + xio.getCreatorInfo());
			}
			logger.info("服务器连接到GlobalServer..........");
		} finally {
			lock.unlock();
		}
	}

	@Override
	public Xio get() {
		lock.lock();
		try {
			return handle;
		} finally {
			lock.unlock();
		}
	}

	@Override
	protected void removeXio(Xio xio, Throwable e) {
		lock.lock();
		try {
			handle = null;
		} finally {
			lock.unlock();
		}

	}

	@Override
	public int size() {
		lock.lock();
		try {
			return handle == null ? 0 : 1;
		} finally {
			lock.unlock();
		}
	}
	
	public boolean send(xio.Protocol protocol){
		return protocol.send(handle);
	}
	
	public void psendWhileCommit(xio.Protocol protocol) {
		xdb.Procedure.psendWhileCommit(handle, protocol);
	}

	/**
	 * 由某个服务器发个另一个服务器
	 * 
	 * @param toZoneId
	 * @param protocol
	 * @return
	 */
	public boolean send(final int toZoneId, xio.Protocol protocol) {
		GlobalDispatch dispatch = new GlobalDispatch();
		dispatch.fromzoneid = ConfigManager.getGsZoneId();
		dispatch.tozoneid = toZoneId;
		OctetsStream ostream = new OctetsStream();
		protocol.marshal(ostream);
		dispatch.pdata = ostream;
		dispatch.ptype = protocol.getType();
		return dispatch.send(handle);
	}
	
	
	/**
	 * 向指定某些服务器广播协议
	 * 
	 * @param serverList
	 * @param protocol
	 * @return
	 */
	public boolean broadcast(List<Integer> serverList, xio.Protocol protocol) {
		GlobalBroadcast2 broadcast = new GlobalBroadcast2();
		OctetsStream ostream = new OctetsStream();
		protocol.marshal(ostream);
		broadcast.pdata = ostream;
		broadcast.ptype = protocol.getType();
		broadcast.serverlist.addAll(serverList);
		return broadcast.send(handle);
	}
	
	/**
	 * 发送协议给其他服务器的某个角色
	 * 
	 * @param zoneId
	 * @param roleId
	 * @param protocol
	 * @return
	 */
	public boolean sendToRole(int zoneId, long roleId, xio.Protocol protocol) {
		SendToRoleRequest request = new SendToRoleRequest();
		
		OctetsStream ostream = new OctetsStream();
		protocol.marshal(ostream);
		
		request.zoneid = zoneId;
		request.roleid = roleId;
		request.ptype = protocol.getType();
		request.pdata = ostream;
		
		return GlobalClientManager.getInstance().send(zoneId, request);
	}
}
