
package gnet;
import java.util.Iterator;

import gnet.link.Onlines;
import gnet.link.User;
import knight.gsp.StateCommon;
import knight.gsp.StateCommon.UserLoginInfo;
import knight.gsp.SystemSetting.SGMsystem;
import knight.gsp.log.LogUtil;
import knight.gsp.main.ConfigManager;
import knight.gsp.util.InetAddressUtil;
import knight.gsp.yuanbao.IQueryOrderHandler;
import knight.gsp.yuanbao.YuanbaoManager;


// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __UserInfoRep__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}
public class UserInfoRep extends __UserInfoRep__ {
	@Override
	protected void process() {
		new xdb.Procedure(){

			@Override
			protected boolean process() throws Exception {
				xbean.AUUserInfo info = xtable.Auuserinfo.get(userid);
				if (info == null) {
					info = xbean.Pod.newAUUserInfo();
					xtable.Auuserinfo.insert(userid, info);
				}
				
				info.setRetcode(retcode);
				info.setFunc(func);
				info.setFuncparm(funcparm);
				info.setLoginip(loginip);
				info.setBlisgm(blisgm);
				info.getAuth().addAll(auth);
				info.setAlgorithm(algorithm);
				info.setNicknameOctets(nickname);
				OctetsStream octstream = new OctetsStream(nickname);
				String nickNameStr = octstream.unmarshal_String("ISO-8859-1");
				
				info.setUsername(octstream.unmarshal_String("UTF-8"));
				String[] strs = nickNameStr.split("#");
				info.setNickname(strs[0]);
				info.setExtinfo(nickNameStr);
				
				info.setLongintime(System.currentTimeMillis());
				try {
					Iterator<SGMsystem> sGMsystems = ConfigManager.getInstance().getConf(SGMsystem.class).values().iterator();
					if(null != sGMsystems) {
						while(sGMsystems.hasNext()) {
							SGMsystem sGMsystem = sGMsystems.next();
							if(info.getNickname().startsWith((sGMsystem.getNickname()))) {
								String value = sGMsystem.getUserid().toString();
								if (checkGM(value)){
									info.setBlisgm(1);
								} 
								break;
							}
						}
					}
				} catch(Exception e) {
					
				}
				
				int index = info.getUsername().lastIndexOf("$");
				if (index >= 0){
					info.setPlatform(info.getUsername().substring(index+1));
				} else {
					info.setPlatform(YuanbaoManager.LAHU_APP);
				}
				IQueryOrderHandler queryOrderHandler = YuanbaoManager.getChargeHandle(info.getPlatform());
				if(null != queryOrderHandler) {
					info.setOs(String.valueOf(queryOrderHandler.getOsType()));
				}
				StringBuilder sb = new StringBuilder();
				sb.append("UserInfoRep:").append("userid:").append(userid);
				sb.append("func:").append(func);
				sb.append("username:").append(info.getUsername());
				sb.append("plattype:").append(info.getNickname());
				sb.append("blisgm:"+info.getBlisgm());
				sb.append("loginip:"+loginip);
				xdb.Trace.info(sb.toString());
				
				UserLoginInfo userLoginInfo = StateCommon.userLoginInfo.get(userid);
				if (userLoginInfo == null) {
					userLoginInfo = new UserLoginInfo();
					StateCommon.userLoginInfo.put(userid, userLoginInfo);
				}
				userLoginInfo.peer = InetAddressUtil.ipInt2String(info.getLoginip());
				userLoginInfo.os = info.getOs();
				
				xbean.User xuser = xtable.User.get(userid);
				if(xuser == null)
				{
					long now = System.currentTimeMillis();
					xuser = xbean.Pod.newUser();
					xuser.setCreatetime(now);
					xtable.User.insert(userid, xuser);
					LogUtil.doUserCreataeLog(userid, "xx");
				}
				User user = Onlines.getInstance().getOnlineUsers().removeAuuserInfoId(userid);
				if(user != null)
					user.sendRoleList(false);
				if(knight.gsp.gat.GATManager.getInstance().isGATServer()){
					int platStringStartIndex = info.getUsername().lastIndexOf("$");
					String uid = info.getUsername();
					if(platStringStartIndex != -1){
						uid = info.getUsername().substring(0, platStringStartIndex);
					}
					xdb.Procedure.pexecuteWhileCommit(new knight.gsp.PUidToUserid(userid, uid));
				}
				return true;
			}

			private boolean checkGM(String value) {
				for(String useridStr : value.trim().split(";")){
					if(Integer.parseInt(useridStr) == userid)
						return true;
				}
				return false;
			}
			
		}.submit();
		
	}

	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 211;

	public int getType() {
		return 211;
	}

	public final static int ALGORITHM_NONE = 0x0; // 仅密码
	public final static int ALGORITHM_CARD = 0x00010000; // 密保卡
	public final static int ALGORITHM_HANDSET = 0x00020000; // 手机密保
	public final static int ALGORITHM_USBKEY = 0x00030000; // usbkey
	public final static int ALGORITHM_PHONE = 0x00040100; // 电话密保
	public final static int ALGORITHM_USBKEY2 = 0x00050000; // usbkey2

	public int userid;
	public int retcode;
	public int func; // 新手卡字段
	public int funcparm; // 新手卡附属字段
	public int loginip; // 客户端登录ip
	public byte blisgm; // 是否为GM
	public java.util.ArrayList<Integer> auth; // GM权限列表，具体权限见相关文档
	public int algorithm; // 账号安全级别
	public byte gender; // 0-female,1-male,2-unknown
	public com.goldhuman.Common.Octets nickname; // 昵称

	public UserInfoRep() {
		auth = new java.util.ArrayList<Integer>();
		nickname = new com.goldhuman.Common.Octets();
	}

	public UserInfoRep(int _userid_, int _retcode_, int _func_, int _funcparm_, int _loginip_, byte _blisgm_, java.util.ArrayList<Integer> _auth_, int _algorithm_, byte _gender_, com.goldhuman.Common.Octets _nickname_) {
		this.userid = _userid_;
		this.retcode = _retcode_;
		this.func = _func_;
		this.funcparm = _funcparm_;
		this.loginip = _loginip_;
		this.blisgm = _blisgm_;
		this.auth = _auth_;
		this.algorithm = _algorithm_;
		this.gender = _gender_;
		this.nickname = _nickname_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(userid);
		_os_.marshal(retcode);
		_os_.marshal(func);
		_os_.marshal(funcparm);
		_os_.marshal(loginip);
		_os_.marshal(blisgm);
		_os_.compact_uint32(auth.size());
		for (Integer _v_ : auth) {
			_os_.marshal(_v_);
		}
		_os_.marshal(algorithm);
		_os_.marshal(gender);
		_os_.marshal(nickname);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		userid = _os_.unmarshal_int();
		retcode = _os_.unmarshal_int();
		func = _os_.unmarshal_int();
		funcparm = _os_.unmarshal_int();
		loginip = _os_.unmarshal_int();
		blisgm = _os_.unmarshal_byte();
		for (int _size_ = _os_.uncompact_uint32(); _size_ > 0; --_size_) {
			int _v_;
			_v_ = _os_.unmarshal_int();
			auth.add(_v_);
		}
		algorithm = _os_.unmarshal_int();
		gender = _os_.unmarshal_byte();
		nickname = _os_.unmarshal_Octets();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof UserInfoRep) {
			UserInfoRep _o_ = (UserInfoRep)_o1_;
			if (userid != _o_.userid) return false;
			if (retcode != _o_.retcode) return false;
			if (func != _o_.func) return false;
			if (funcparm != _o_.funcparm) return false;
			if (loginip != _o_.loginip) return false;
			if (blisgm != _o_.blisgm) return false;
			if (!auth.equals(_o_.auth)) return false;
			if (algorithm != _o_.algorithm) return false;
			if (gender != _o_.gender) return false;
			if (!nickname.equals(_o_.nickname)) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += userid;
		_h_ += retcode;
		_h_ += func;
		_h_ += funcparm;
		_h_ += loginip;
		_h_ += (int)blisgm;
		_h_ += auth.hashCode();
		_h_ += algorithm;
		_h_ += (int)gender;
		_h_ += nickname.hashCode();
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(userid).append(",");
		_sb_.append(retcode).append(",");
		_sb_.append(func).append(",");
		_sb_.append(funcparm).append(",");
		_sb_.append(loginip).append(",");
		_sb_.append(blisgm).append(",");
		_sb_.append(auth).append(",");
		_sb_.append(algorithm).append(",");
		_sb_.append(gender).append(",");
		_sb_.append("B").append(nickname.size()).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

