package gnet.link;

import gnet.link.Onlines.Handle;

import java.util.Collection;

import knight.gsp.state.PRoleOffline;

public class RoleLinkBrokenHanle implements Handle {

	@Override
	public void onLinkBroken(Role role, int reason) {

		Onlines.logger.info("角色  " + role.getRoleid() + " 意外断开,原因：" + reason);
		new knight.gsp.state.PRoleOffline(role.getRoleid(), PRoleOffline.TYPE_LINK_BROKEN).submit();

	}

	@Override
	public void onManagerBroken(Collection<Role> roles) {
		// TODO Auto-generated method stub

	}

}
