package gnet;

import java.util.concurrent.locks.ReentrantLock;
import org.apache.log4j.Logger;
import xio.Manager;

public class DeliveryManager extends Manager {

	private static DeliveryManager instance = null;

	public DeliveryManager() {
		instance = this;
	}

	public static DeliveryManager getInstance() {
		return instance;
	}

	private static Logger logger = Logger.getLogger(DeliveryManager.class);

	private xio.Xio gdelivery = null;

	private final ReentrantLock lock = new ReentrantLock();

	@Override
	protected void addXio(xio.Xio xio) {

		lock.lock();
		try {
			// TODO: if gdelivery!=null ??
			gdelivery = xio;
			logger.info("delivery connected");
		} finally {
			lock.unlock();
		}
	}

	@Override
	public xio.Xio get() {

		lock.lock();
		try {
			return gdelivery;
		} finally {
			lock.unlock();
		}
	}

	@Override
	protected void removeXio(xio.Xio xio, Throwable e) {

		if (e != null)
			logger.error("err", e);
		lock.lock();
		try {
			gdelivery = null;
		} finally {
			lock.unlock();
		}

	}

	@Override
	public int size() {

		lock.lock();
		try {
			return gdelivery == null ? 0 : 1;
		} finally {
			lock.unlock();
		}
	}

	public void send(xio.Protocol p2) {

		// final Send p1 = new Send();
		// p1.linksids.add(ls.getSid());
		// p1.ptype = p2.getType();
		// p1.pdata = new OctetsStream().marshal(p2);
		// ls.getXio().getCreator().getManager().getCoder().checkSend(p2,
		// p1.pdata.size());
		p2.send(gdelivery);
	}
}
