
package gnet;


import global.rsp.GlobalClientManager;
import global.rsp.SNotifyBindSucc;
import knight.gsp.DefaultDataBetweenAuAnyAndGSHandler;
import knight.gsp.LocalIds;
import knight.gsp.SCrossServer;
import knight.gsp.SCrossServerOver;
import knight.gsp.SJuBaoPenBindState;
import knight.gsp.StateCommon;
import knight.gsp.fuben.FubenCommon;
import knight.gsp.main.ConfigManager;
import knight.gsp.main.ServerInfoProvider;
import knight.gsp.state.IState;
import knight.gsp.state.State;
import knight.gsp.state.StateManager;
import knight.gsp.util.Misc;
import knight.gsp.yuanbao.MSDKQueryOrderHandler;
import knight.gsp.yuanbao.MeizuQueryOrderHandler;
import knight.gsp.yuanbao.UcQueryOrderHandler;





// {{{ RPCGEN_IMPORT_BEGIN
// {{{ DO NOT EDIT THIS
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Marshal.MarshalException;

abstract class __DataBetweenAuAnyAndGS__ extends xio.Protocol { }

// DO NOT EDIT THIS }}}
// RPCGEN_IMPORT_END }}}

public class DataBetweenAuAnyAndGS extends __DataBetweenAuAnyAndGS__ {
	@Override
	protected void process() {
		// protocol handle
		
		if(qtype == knight.gsp.yuanbao.VivoQueryOrderHandler.VIVO_QTYPE ||
				qtype == knight.gsp.yuanbao.Viv3QueryOrderHandler.VIV3_QTYPE){
			if(info != null){
				new knight.gsp.yuanbao.PVivoCharge(info.getString("UTF-8")).submit();
			}
		}else if(qtype == knight.gsp.yuanbao.JinLiQueryOrderHandler.JINLI_QTYPE){
			if(info != null){
				new knight.gsp.yuanbao.PJinLiCharge(info.getString("UTF-8")).submit();
			}
		}else if(qtype == knight.gsp.yuanbao.KuPaiNewQueryOrderHandler.COPA_QTYPE){
			if(info != null){
				new knight.gsp.yuanbao.PKuPaiNewCharge(info.getString("UTF-8")).submit();
			}
		}else if (qtype == knight.gsp.yuanbao.KuPaiNewQueryOrderHandler.KUPAI_TOKEN_QTYPE) {
            if (info != null) {
                new DefaultDataBetweenAuAnyAndGSHandler().handleReq(DataBetweenAuAnyAndGS.this);
            }
		} else if (qtype == MSDKQueryOrderHandler.MSDK_GET_BALANCE || qtype == MSDKQueryOrderHandler.MSDK_GET_PAY 
				|| qtype == MeizuQueryOrderHandler.MEIZUFLYME_ORDER_SIGN_QTYPE || qtype == UcQueryOrderHandler.UC_QTYPE) {
			if(info != null){
				new DefaultDataBetweenAuAnyAndGSHandler().handleReq(DataBetweenAuAnyAndGS.this);
			}
		} else if (qtype == FubenCommon.AU_SEND_RELOGIN_PASSWD_TO_GS) {
			saveReloginToken();
		} else if (qtype == FubenCommon.LEDO_JBP_AUTH_PWD) {
			try {
				updateBindInfo();
			} catch (MarshalException e) {
				e.printStackTrace();
			}
		}
		
		if (qtype == FubenCommon.RESPONSE_CROSS_TEMP_PWD) {
			try {
				
				new xdb.Procedure() {

					@Override
					protected boolean process() throws Exception {
						OctetsStream os = new OctetsStream(info);

						String key = os.unmarshal_String();
						String pwd = os.unmarshal_String();
						String ext = os.unmarshal_String();
						
						long roleId = Long.parseLong(key);
						int zoneId = Integer.parseInt(ext.split("#")[1]);

						String ipStr = "";
						
						global.rsp.ServerInfo serverInfo = ServerInfoProvider.getServerInfo(zoneId);
						if (StateCommon.isGameXLogin(roleId)) {
							ipStr = serverInfo.gamexloginip;
						} else {
							ipStr = serverInfo.ip;
						}
						
						int randdomPort = 0;
						if (serverInfo.linknum > 1) {
							randdomPort = Misc.getRandomBetween(0, serverInfo.linknum - 1);
						}
						
						if (LocalIds.isRemoteServerRole(roleId)) {
							//跨服回到原服
							SCrossServerOver msg = new SCrossServerOver();
							msg.ipstr = ipStr;
							msg.statport = serverInfo.dockerstartport + randdomPort;
							msg.password = pwd;
							msg.roleid = roleId;
							xdb.Procedure.psendWhileCommit(roleId, msg);
						} else {
							//原服到跨服
							SCrossServer msg = new SCrossServer();
							msg.ipstr = ipStr;
							msg.statport = serverInfo.dockerstartport + randdomPort;
							msg.password = pwd;
							msg.roleid = roleId;
							xdb.Procedure.psendWhileCommit(roleId, msg);
						}
						
						
						
						IState state = StateManager.getStateByRoleId(roleId);
						if (state.getState() == State.WAIT_FOR_RETURN_TO_CROSS_STATE) {
							state.trigger(State.TRIGGER_PROCESS_DONE);
						}
						
						return true;
					}
					
				}.submit();
			
			} catch (Exception ex) {ex.printStackTrace();}
			
		}
	}
	
	private void saveReloginToken() {
		new xdb.Procedure() {

			@Override
			protected boolean process() throws Exception {
				OctetsStream os = new OctetsStream(info);

				String token = os.unmarshal_String();
				
				xbean.AUUserInfo info = xtable.Auuserinfo.get(userid);
				if (info == null) {
					info = xbean.Pod.newAUUserInfo();
					xtable.Auuserinfo.insert(userid, info);
				}
				String tokenArr[] = token.split("#");
				if(tokenArr.length >= 4){
					info.setSubplat(tokenArr[3]);
					token = token.substring(0, token.length() - tokenArr[3].length() - 1);
				} else {
					//清一下子渠道包名
					info.setSubplat("");
				}
				info.setRelogintoken(token);
				return true;
			}
			
		}.submit();
	}
	
	/**
	 * 更新聚宝盆帐号bind信息
	 * @param bindStr
	 * @throws MarshalException 
	 */
	private void updateBindInfo() throws MarshalException{
		new xdb.Procedure() {
			protected boolean process() throws Exception {
				OctetsStream os = new OctetsStream(info);
				String bindStr = os.unmarshal_String("UTF-8");
				//flag + "#"+ roleId + "#" + ledouserid + "#" + jbpacc;
				String[] infos = bindStr.split("#");
				//1=聚宝盆帐号不存在 
				//2=乐道帐号bind了不同的聚宝盆帐号   修正成当前聚宝盆帐号
				//3=bind成功
				String flag = infos[0];
				String rid = infos[1];
				String ledouserid = infos[3];
				String jbpacc = infos[3];
				long roleId = Long.parseLong(rid);

				xbean.Properties prop = xtable.Properties.select(roleId);
				if(prop == null){
					xdb.Trace.info("Exception  updateBindInfo " + bindStr + "  role=null");
					return false;
				}

				SJuBaoPenBindState send = new SJuBaoPenBindState();
				xbean.JuBaoPenBindState jbp= xtable.Jbpbind.get(prop.getUserid());
				if(jbp == null){
					xdb.Trace.info("Exception  updateBindInfo  " + bindStr +"  xtable.Jbpbind=null");
				}else{
					if("1".equals(flag)){
						jbp.setBindstate(0);
						send.flag = 0;
						send.phonenumber = jbp.getBindphonenumber();
						xdb.Procedure.psendWhileCommit(roleId, send);
						
					}else{
						jbp.setBindstate(4);
						jbp.setLedouserid(ledouserid);
						jbp.setJubaopenuserid(jbpacc);
						
						//同步数据到global
						SNotifyBindSucc snb = new SNotifyBindSucc();
						snb.roleid = roleId;
						snb.acc = jbpacc;
						snb.zoneid = ConfigManager.getGsZoneId();
						snb.phonenum = jbp.getBindphonenumber();
						snb.ledouid = ledouserid;
						GlobalClientManager.getInstance().send(snb);
					}
				}
				return true;
			};
		}.submit();
		
	}
	
	
	// {{{ RPCGEN_DEFINE_BEGIN
	// {{{ DO NOT EDIT THIS
	public static final int PROTOCOL_TYPE = 8920;

	public int getType() {
		return 8920;
	}

	public final static int AuAny_TO_GS = 1;
	public final static int GS_TO_AuAny = 2;

	public int userid;
	public int qtype;
	public byte flag;
	public com.goldhuman.Common.Octets info;
	public int reserved;

	public DataBetweenAuAnyAndGS() {
		info = new com.goldhuman.Common.Octets();
	}

	public DataBetweenAuAnyAndGS(int _userid_, int _qtype_, byte _flag_, com.goldhuman.Common.Octets _info_, int _reserved_) {
		this.userid = _userid_;
		this.qtype = _qtype_;
		this.flag = _flag_;
		this.info = _info_;
		this.reserved = _reserved_;
	}

	public final boolean _validator_() {
		return true;
	}

	public OctetsStream marshal(OctetsStream _os_) {
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		_os_.marshal(userid);
		_os_.marshal(qtype);
		_os_.marshal(flag);
		_os_.marshal(info);
		_os_.marshal(reserved);
		return _os_;
	}

	public OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {
		userid = _os_.unmarshal_int();
		qtype = _os_.unmarshal_int();
		flag = _os_.unmarshal_byte();
		info = _os_.unmarshal_Octets();
		reserved = _os_.unmarshal_int();
		if (!_validator_()) {
			throw new VerifyError("validator failed");
		}
		return _os_;
	}

	public boolean equals(Object _o1_) {
		if (_o1_ == this) return true;
		if (_o1_ instanceof DataBetweenAuAnyAndGS) {
			DataBetweenAuAnyAndGS _o_ = (DataBetweenAuAnyAndGS)_o1_;
			if (userid != _o_.userid) return false;
			if (qtype != _o_.qtype) return false;
			if (flag != _o_.flag) return false;
			if (!info.equals(_o_.info)) return false;
			if (reserved != _o_.reserved) return false;
			return true;
		}
		return false;
	}

	public int hashCode() {
		int _h_ = 0;
		_h_ += userid;
		_h_ += qtype;
		_h_ += (int)flag;
		_h_ += info.hashCode();
		_h_ += reserved;
		return _h_;
	}

	public String toString() {
		StringBuilder _sb_ = new StringBuilder();
		_sb_.append("(");
		_sb_.append(userid).append(",");
		_sb_.append(qtype).append(",");
		_sb_.append(flag).append(",");
		_sb_.append("B").append(info.size()).append(",");
		_sb_.append(reserved).append(",");
		_sb_.append(")");
		return _sb_.toString();
	}

	// DO NOT EDIT THIS }}}
	// RPCGEN_DEFINE_END }}}

}

